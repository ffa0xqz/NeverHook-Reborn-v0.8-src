/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import java.util.List;
import javax.annotation.Nullable;

public class ajy
extends agv {
    @Override
    public ain u() {
        return akg.a(super.u(), akh.z);
    }

    @Override
    public aef a(ams ams2, ain ain2, vn vn2) {
        aey aey2 = new aey(ams2, vn2);
        aey2.a(ain2);
        return aey2;
    }

    @Override
    public void a(ahn ahn2, fi<ain> fi2) {
        if (this.a(ahn2)) {
            for (ake ake2 : ake.a) {
                if (ake2.a().isEmpty()) continue;
                fi2.add(akg.a(new ain(this), ake2));
            }
        }
    }

    @Override
    public void a(ain ain2, @Nullable ams ams2, List<String> list, ajz ajz2) {
        akg.a(ain2, list, 0.125f);
    }

    @Override
    public String b(ain ain2) {
        return ft.a(akg.d(ain2).b("tipped_arrow.effect."));
    }
}

