/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import javax.annotation.Nullable;

public class bts
extends btd {
    private final awr a;
    private et b;

    protected bts(ams ams2, double d2, double d3, double d4, double d5, double d6, double d7, awr awr2) {
        super(ams2, d2, d3, d4, d5, d6, d7);
        this.a = awr2;
        this.a(bhz.z().ab().a().a(awr2));
        this.z = awr2.u().w;
        this.A = 0.6f;
        this.B = 0.6f;
        this.C = 0.6f;
        this.y /= 2.0f;
    }

    public bts a(et et2) {
        this.b = et2;
        if (this.a.u() == aov.c) {
            return this;
        }
        this.b(et2);
        return this;
    }

    public bts m() {
        this.b = new et(this.g, this.h, this.i);
        aou aou2 = this.a.u();
        if (aou2 == aov.c) {
            return this;
        }
        this.b(this.b);
        return this;
    }

    protected void b(@Nullable et et2) {
        int n2 = bhz.z().al().a(this.a, this.c, et2, 0);
        this.A *= (float)(n2 >> 16 & 0xFF) / 255.0f;
        this.B *= (float)(n2 >> 8 & 0xFF) / 255.0f;
        this.C *= (float)(n2 & 0xFF) / 255.0f;
    }

    @Override
    public int b() {
        return 1;
    }

    @Override
    public void a(bui bui2, ve ve2, float f2, float f3, float f4, float f5, float f6, float f7) {
        \u2603 = ((float)this.s + this.u / 4.0f) / 16.0f;
        \u2603 = \u2603 + 0.015609375f;
        \u2603 = ((float)this.t + this.v / 4.0f) / 16.0f;
        \u2603 = \u2603 + 0.015609375f;
        \u2603 = 0.1f * this.y;
        if (this.E != null) {
            \u2603 = this.E.a((double)(this.u / 4.0f * 16.0f));
            \u2603 = this.E.a((double)((this.u + 1.0f) / 4.0f * 16.0f));
            \u2603 = this.E.b((double)(this.v / 4.0f * 16.0f));
            \u2603 = this.E.b((double)((this.v + 1.0f) / 4.0f * 16.0f));
        }
        \u2603 = (float)(this.d + (this.g - this.d) * (double)f2 - H);
        \u2603 = (float)(this.e + (this.h - this.e) * (double)f2 - I);
        \u2603 = (float)(this.f + (this.i - this.f) * (double)f2 - J);
        int n2 = this.a(f2);
        \u2603 = n2 >> 16 & 0xFFFF;
        \u2603 = n2 & 0xFFFF;
        bui2.b((double)(\u2603 - f3 * \u2603 - f6 * \u2603), (double)(\u2603 - f4 * \u2603), (double)(\u2603 - f5 * \u2603 - f7 * \u2603)).a(\u2603, \u2603).a(this.A, this.B, this.C, 1.0f).a(\u2603, \u2603).d();
        bui2.b((double)(\u2603 - f3 * \u2603 + f6 * \u2603), (double)(\u2603 + f4 * \u2603), (double)(\u2603 - f5 * \u2603 + f7 * \u2603)).a(\u2603, \u2603).a(this.A, this.B, this.C, 1.0f).a(\u2603, \u2603).d();
        bui2.b((double)(\u2603 + f3 * \u2603 + f6 * \u2603), (double)(\u2603 + f4 * \u2603), (double)(\u2603 + f5 * \u2603 + f7 * \u2603)).a(\u2603, \u2603).a(this.A, this.B, this.C, 1.0f).a(\u2603, \u2603).d();
        bui2.b((double)(\u2603 + f3 * \u2603 - f6 * \u2603), (double)(\u2603 - f4 * \u2603), (double)(\u2603 + f5 * \u2603 - f7 * \u2603)).a(\u2603, \u2603).a(this.A, this.B, this.C, 1.0f).a(\u2603, \u2603).d();
    }

    @Override
    public int a(float f2) {
        int n2 = super.a(f2);
        \u2603 = 0;
        if (this.c.e(this.b)) {
            \u2603 = this.c.b(this.b, 0);
        }
        return n2 == 0 ? \u2603 : n2;
    }

    public static class a
    implements btf {
        @Override
        public btd a(int n2, ams ams2, double d2, double d3, double d4, double d5, double d6, double d7, int ... arrn) {
            return new bts(ams2, d2, d3, d4, d5, d6, d7, aou.d(arrn[0])).m();
        }
    }
}

