/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import javax.annotation.Nullable;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class aaq
extends aal
implements ade {
    private static final mx<Integer> bH = na.a(aaq.class, mz.b);
    private static final mx<Integer> bI = na.a(aaq.class, mz.b);
    private static final mx<Integer> bJ = na.a(aaq.class, mz.b);
    private boolean bK;
    @Nullable
    private aaq bL;
    @Nullable
    private aaq bM;

    public aaq(ams ams2) {
        super(ams2);
        this.a(0.9f, 1.87f);
    }

    private void p(int n2) {
        this.Y.b(bH, Math.max(1, Math.min(5, n2)));
    }

    private void dY() {
        int n2 = this.S.nextFloat() < 0.04f ? 5 : 3;
        this.p(1 + this.S.nextInt(n2));
    }

    public int dQ() {
        return this.Y.a(bH);
    }

    @Override
    public void b(fy fy2) {
        super.b(fy2);
        fy2.a("Variant", this.dR());
        fy2.a("Strength", this.dQ());
        if (!this.bC.a(1).b()) {
            fy2.a("DecorItem", this.bC.a(1).a(new fy()));
        }
    }

    @Override
    public void a(fy fy2) {
        this.p(fy2.h("Strength"));
        super.a(fy2);
        this.o(fy2.h("Variant"));
        if (fy2.b("DecorItem", 10)) {
            this.bC.a(1, new ain(fy2.p("DecorItem")));
        }
        this.dD();
    }

    @Override
    protected void r() {
        this.br.a(0, new wx(this));
        this.br.a(1, new yf(this, 1.2));
        this.br.a(2, new xi(this, 2.1f));
        this.br.a(3, new yb(this, 1.25, 40, 20.0f));
        this.br.a(3, new xw(this, 1.2));
        this.br.a(4, new wt(this, 1.0));
        this.br.a(5, new xb(this, 1.0));
        this.br.a(6, new yn(this, 0.7));
        this.br.a(7, new xj(this, aeb.class, 6.0f));
        this.br.a(8, new xz(this));
        this.bs.a(1, new c(this));
        this.bs.a(2, new a(this));
    }

    @Override
    protected void bM() {
        super.bM();
        this.a(adf.b).a(40.0);
    }

    @Override
    protected void i() {
        super.i();
        this.Y.a(bH, 0);
        this.Y.a(bI, -1);
        this.Y.a(bJ, 0);
    }

    public int dR() {
        return ri.a(this.Y.a(bJ), 0, 3);
    }

    public void o(int n2) {
        this.Y.b(bJ, n2);
    }

    @Override
    protected int dn() {
        if (this.dm()) {
            return 2 + 3 * this.dt();
        }
        return super.dn();
    }

    @Override
    public void k(ve ve2) {
        if (!this.w(ve2)) {
            return;
        }
        float f2 = ri.b(this.aN * ((float)Math.PI / 180));
        \u2603 = ri.a(this.aN * ((float)Math.PI / 180));
        \u2603 = 0.3f;
        ve2.b(this.p + (double)(0.3f * \u2603), this.q + this.aG() + ve2.aF(), this.r - (double)(0.3f * f2));
    }

    @Override
    public double aG() {
        return (double)this.H * 0.67;
    }

    @Override
    public boolean cV() {
        return false;
    }

    @Override
    protected boolean b(aeb aeb2, ain ain2) {
        int n2 = 0;
        \u2603 = 0;
        float \u26032 = 0.0f;
        boolean \u26033 = false;
        ail \u26034 = ain2.c();
        if (\u26034 == aip.R) {
            n2 = 10;
            \u2603 = 3;
            \u26032 = 2.0f;
        } else if (\u26034 == ail.a(aov.cx)) {
            n2 = 90;
            \u2603 = 6;
            \u26032 = 10.0f;
            if (this.du() && this.l() == 0) {
                \u26033 = true;
                this.f(aeb2);
            }
        }
        if (this.cd() < this.cj() && \u26032 > 0.0f) {
            this.b(\u26032);
            \u26033 = true;
        }
        if (this.l_() && n2 > 0) {
            this.l.a(fj.v, this.p + (double)(this.S.nextFloat() * this.G * 2.0f) - (double)this.G, this.q + 0.5 + (double)(this.S.nextFloat() * this.H), this.r + (double)(this.S.nextFloat() * this.G * 2.0f) - (double)this.G, 0.0, 0.0, 0.0, new int[0]);
            if (!this.l.G) {
                this.a(n2);
            }
            \u26033 = true;
        }
        if (\u2603 > 0 && (\u26033 || !this.du()) && this.dB() < this.dH()) {
            \u26033 = true;
            if (!this.l.G) {
                this.n(\u2603);
            }
        }
        if (\u26033 && !this.ai()) {
            this.l.a(null, this.p, this.q, this.r, qd.dQ, this.bK(), 1.0f, 1.0f + (this.S.nextFloat() - this.S.nextFloat()) * 0.2f);
        }
        return \u26033;
    }

    @Override
    protected boolean cs() {
        return this.cd() <= 0.0f || this.dy();
    }

    @Override
    @Nullable
    public vq a(ty ty2, @Nullable vq \u260322) {
        vq \u260322;
        int n2;
        \u260322 = super.a(ty2, \u260322);
        this.dY();
        if (\u260322 instanceof b) {
            n2 = ((b)\u260322).a;
        } else {
            n2 = this.S.nextInt(4);
            \u260322 = new b(n2);
        }
        this.o(n2);
        return \u260322;
    }

    public boolean dS() {
        return this.dT() != null;
    }

    @Override
    protected qc do() {
        return qd.dN;
    }

    @Override
    protected qc F() {
        return qd.dM;
    }

    @Override
    protected qc d(up up2) {
        return qd.dR;
    }

    @Override
    protected qc cf() {
        return qd.dP;
    }

    @Override
    protected void a(et et2, aou aou2) {
        this.a(qd.dT, 0.15f, 1.0f);
    }

    @Override
    protected void dp() {
        this.a(qd.dO, 1.0f, (this.S.nextFloat() - this.S.nextFloat()) * 0.2f + 1.0f);
    }

    @Override
    public void dK() {
        qc qc2 = this.do();
        if (qc2 != null) {
            this.a(qc2, this.cq(), this.cr());
        }
    }

    @Override
    @Nullable
    protected nd J() {
        return bfl.aw;
    }

    @Override
    public int dt() {
        return this.dQ();
    }

    @Override
    public boolean dP() {
        return true;
    }

    @Override
    public boolean f(ain ain2) {
        return ain2.c() == ail.a(aov.cy);
    }

    @Override
    public boolean dF() {
        return false;
    }

    @Override
    public void a(tt tt2) {
        ahq ahq2 = this.dT();
        super.a(tt2);
        \u2603 = this.dT();
        if (this.T > 20 && \u2603 != null && \u2603 != ahq2) {
            this.a(qd.dU, 0.5f, 1.0f);
        }
    }

    @Override
    protected void dD() {
        if (this.l.G) {
            return;
        }
        super.dD();
        this.g(this.bC.a(1));
    }

    private void a(@Nullable ahq ahq2) {
        this.Y.b(bI, ahq2 == null ? -1 : ahq2.a());
    }

    private void g(ain ain2) {
        if (this.f(ain2)) {
            this.a(ahq.b(ain2.j()));
        } else {
            this.a((ahq)null);
        }
    }

    @Nullable
    public ahq dT() {
        int n2 = this.Y.a(bI);
        return n2 == -1 ? null : ahq.b(n2);
    }

    @Override
    public int dH() {
        return 30;
    }

    @Override
    public boolean a(zt zt2) {
        return zt2 != this && zt2 instanceof aaq && this.dL() && ((aaq)zt2).dL();
    }

    public aaq b(vb vb2) {
        aaq aaq2 = new aaq(this.l);
        this.a(vb2, aaq2);
        \u2603 = (aaq)vb2;
        int \u26032 = this.S.nextInt(Math.max(this.dQ(), \u2603.dQ())) + 1;
        if (this.S.nextFloat() < 0.03f) {
            ++\u26032;
        }
        aaq2.p(\u26032);
        aaq2.o(this.S.nextBoolean() ? this.dR() : \u2603.dR());
        return aaq2;
    }

    private void e(vn vn2) {
        aem aem2 = new aem(this.l, this);
        double \u26032 = vn2.p - this.p;
        double \u26033 = vn2.bw().b + (double)(vn2.H / 3.0f) - aem2.q;
        double \u26034 = vn2.r - this.r;
        float \u26035 = ri.a(\u26032 * \u26032 + \u26034 * \u26034) * 0.2f;
        aem2.c(\u26032, \u26033 + (double)\u26035, \u26034, 1.5f, 10.0f);
        this.l.a(null, this.p, this.q, this.r, qd.dS, this.bK(), 1.0f, 1.0f + (this.S.nextFloat() - this.S.nextFloat()) * 0.2f);
        this.l.a(aem2);
        this.bK = true;
    }

    private void y(boolean bl2) {
        this.bK = bl2;
    }

    @Override
    public void e(float f2, float f3) {
        int n2 = ri.f((f2 * 0.5f - 3.0f) * f3);
        if (n2 <= 0) {
            return;
        }
        if (f2 >= 6.0f) {
            this.a(up.k, (float)n2);
            if (this.aT()) {
                for (ve ve2 : this.bG()) {
                    ve2.a(up.k, (float)n2);
                }
            }
        }
        awr awr2 = this.l.o(new et(this.p, this.q - 0.2 - (double)this.x, this.r));
        aou aou2 = awr2.u();
        if (awr2.a() != bcx.a && !this.ai()) {
            atw atw2 = aou2.v();
            this.l.a(null, this.p, this.q, this.r, atw2.d(), this.bK(), atw2.a() * 0.5f, atw2.b() * 0.75f);
        }
    }

    public void dU() {
        if (this.bL != null) {
            this.bL.bM = null;
        }
        this.bL = null;
    }

    public void a(aaq aaq2) {
        this.bL = aaq2;
        this.bL.bM = this;
    }

    public boolean dV() {
        return this.bM != null;
    }

    public boolean dW() {
        return this.bL != null;
    }

    @Nullable
    public aaq dX() {
        return this.bL;
    }

    @Override
    protected double dk() {
        return 2.0;
    }

    @Override
    protected void dI() {
        if (!this.dW() && this.l_()) {
            super.dI();
        }
    }

    @Override
    public boolean dJ() {
        return false;
    }

    @Override
    public void a(vn vn2, float f2) {
        this.e(vn2);
    }

    @Override
    public void p(boolean bl2) {
    }

    @Override
    public /* synthetic */ vb a(vb vb2) {
        return this.b(vb2);
    }

    static class a
    extends yu<aak> {
        public a(aaq aaq2) {
            super(aaq2, aak.class, 16, false, true, null);
        }

        @Override
        public boolean a() {
            if (super.a() && this.d != null && !((aak)this.d).dl()) {
                return true;
            }
            this.e.d((vn)null);
            return false;
        }

        @Override
        protected double i() {
            return super.i() * 0.25;
        }
    }

    static class c
    extends yr {
        public c(aaq aaq2) {
            super((vv)aaq2, false, new Class[0]);
        }

        @Override
        public boolean b() {
            aaq aaq2;
            if (this.e instanceof aaq && (aaq2 = (aaq)this.e).bK) {
                aaq2.y(false);
                return false;
            }
            return super.b();
        }
    }

    static class b
    implements vq {
        public int a;

        private b(int n2) {
            this.a = n2;
        }
    }
}

