/*
 * Decompiled with CFR 0.150.
 */
import java.io.IOException;

public class bml
extends bme
implements bns {
    private static final nd v = new nd("textures/gui/container/crafting_table.png");
    private bje w;
    private final bnm x = new bnm();
    private boolean y;

    public bml(aea playerInv, ams worldIn) {
        this(playerInv, worldIn, et.a);
    }

    public bml(aea playerInv, ams worldIn, et blockPosition) {
        super(new afx(playerInv, worldIn, blockPosition));
    }

    @Override
    public void b() {
        super.b();
        this.y = this.l < 379;
        this.x.func_194303_a(this.l, this.m, this.j, this.y, ((afx)this.h).a);
        this.i = this.x.a(this.y, this.l, this.f);
        this.w = new bje(10, this.i + 5, this.m / 2 - 49, 20, 18, 0, 168, 19, v);
        this.n.add(this.w);
    }

    @Override
    public void e() {
        super.e();
        this.x.d();
    }

    @Override
    public void a(int mouseX, int mouseY, float partialTicks) {
        this.c();
        if (this.x.c() && this.y) {
            this.a(partialTicks, mouseX, mouseY);
            this.x.a(mouseX, mouseY, partialTicks);
        } else {
            this.x.a(mouseX, mouseY, partialTicks);
            super.a(mouseX, mouseY, partialTicks);
            this.x.a(this.i, this.s, true, partialTicks);
        }
        this.b(mouseX, mouseY);
        this.x.c(this.i, this.s, mouseX, mouseY);
    }

    @Override
    protected void c(int mouseX, int mouseY) {
        this.q.drawString(cew.a("container.crafting", new Object[0]), 28.0f, 6.0f, 0x404040);
        this.q.drawString(cew.a("container.inventory", new Object[0]), 8.0f, this.g - 96 + 2, 0x404040);
    }

    @Override
    protected void a(float partialTicks, int mouseX, int mouseY) {
        buq.c(1.0f, 1.0f, 1.0f, 1.0f);
        this.j.N().a(v);
        int i2 = this.i;
        int j2 = (this.m - this.g) / 2;
        this.b(i2, j2, 0, 0, this.f, this.g);
    }

    @Override
    protected boolean c(int rectX, int rectY, int rectWidth, int rectHeight, int pointX, int pointY) {
        return (!this.y || !this.x.c()) && super.c(rectX, rectY, rectWidth, rectHeight, pointX, pointY);
    }

    @Override
    protected void a(int mouseX, int mouseY, int mouseButton) throws IOException {
        if (!(this.x.a(mouseX, mouseY, mouseButton) || this.y && this.x.c())) {
            super.a(mouseX, mouseY, mouseButton);
        }
    }

    @Override
    protected boolean c(int p_193983_1_, int p_193983_2_, int p_193983_3_, int p_193983_4_) {
        boolean flag = p_193983_1_ < p_193983_3_ || p_193983_2_ < p_193983_4_ || p_193983_1_ >= p_193983_3_ + this.f || p_193983_2_ >= p_193983_4_ + this.g;
        return this.x.c(p_193983_1_, p_193983_2_, this.i, this.s, this.f, this.g) && flag;
    }

    @Override
    protected void a(biy button) throws IOException {
        if (button.k == 10) {
            this.x.a(this.y, ((afx)this.h).a);
            this.x.b();
            this.i = this.x.a(this.y, this.l, this.f);
            this.w.c(this.i + 5, this.m / 2 - 49);
        }
    }

    @Override
    protected void a(char typedChar, int keyCode) throws IOException {
        if (!this.x.a(typedChar, keyCode)) {
            super.a(typedChar, keyCode);
        }
    }

    @Override
    public void a(agp slotIn, int slotId, int mouseButton, afu type) {
        super.a(slotIn, slotId, mouseButton, type);
        this.x.a(slotIn);
    }

    @Override
    public void I_() {
        this.x.e();
    }

    @Override
    public void m() {
        this.x.a();
        super.m();
    }

    @Override
    public bnm func_194310_f() {
        return this.x;
    }
}

