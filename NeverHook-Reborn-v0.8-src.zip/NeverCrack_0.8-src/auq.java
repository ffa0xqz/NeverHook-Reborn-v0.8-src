/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;

public class auq
extends aou {
    public static final axd a = axd.a("powered");
    public static final axd b = axd.a("attached");
    public static final axd c = axd.a("disarmed");
    public static final axd d = axd.a("north");
    public static final axd e = axd.a("east");
    public static final axd f = axd.a("south");
    public static final axd g = axd.a("west");
    protected static final bgz B = new bgz(0.0, 0.0625, 0.0, 1.0, 0.15625, 1.0);
    protected static final bgz C = new bgz(0.0, 0.0, 0.0, 1.0, 0.5, 1.0);

    public auq() {
        super(bcx.q);
        this.w(this.A.b().a(a, false).a(b, false).a(c, false).a(d, false).a(e, false).a(f, false).a(g, false));
        this.a(true);
    }

    @Override
    public bgz b(awr awr2, amw amw2, et et2) {
        if (!awr2.c(b).booleanValue()) {
            return C;
        }
        return B;
    }

    @Override
    public awr d(awr awr2, amw amw2, et et2) {
        return awr2.a(d, auq.a(amw2, et2, awr2, fa.c)).a(e, auq.a(amw2, et2, awr2, fa.f)).a(f, auq.a(amw2, et2, awr2, fa.d)).a(g, auq.a(amw2, et2, awr2, fa.e));
    }

    @Override
    @Nullable
    public bgz a(awr awr2, amw amw2, et et2) {
        return k;
    }

    @Override
    public boolean b(awr awr2) {
        return false;
    }

    @Override
    public boolean c(awr awr2) {
        return false;
    }

    @Override
    public amk f() {
        return amk.d;
    }

    @Override
    public ail a(awr awr2, Random random, int n2) {
        return aip.I;
    }

    @Override
    public ain a(ams ams2, et et2, awr awr2) {
        return new ain(aip.I);
    }

    @Override
    public void c(ams ams2, et et2, awr awr2) {
        ams2.a(et2, awr2, 3);
        this.e(ams2, et2, awr2);
    }

    @Override
    public void b(ams ams2, et et2, awr awr2) {
        this.e(ams2, et2, awr2.a(a, true));
    }

    @Override
    public void a(ams ams2, et et2, awr awr2, aeb aeb2) {
        if (ams2.G) {
            return;
        }
        if (!aeb2.co().b() && aeb2.co().c() == aip.bm) {
            ams2.a(et2, awr2.a(c, true), 4);
        }
    }

    private void e(ams ams2, et et2, awr awr2) {
        block0: for (fa fa2 : new fa[]{fa.d, fa.e}) {
            for (int i2 = 1; i2 < 42; ++i2) {
                et et3 = et2.a(fa2, i2);
                awr \u26032 = ams2.o(et3);
                if (\u26032.u() == aov.bR) {
                    if (\u26032.c(aur.a) != fa2.d()) continue block0;
                    aov.bR.a(ams2, et3, \u26032, false, true, i2, awr2);
                    continue block0;
                }
                if (\u26032.u() != aov.bS) continue block0;
            }
        }
    }

    @Override
    public void a(ams ams2, et et2, awr awr2, ve ve2) {
        if (ams2.G) {
            return;
        }
        if (awr2.c(a).booleanValue()) {
            return;
        }
        this.b(ams2, et2);
    }

    @Override
    public void a(ams ams2, et et2, awr awr2, Random random) {
    }

    @Override
    public void b(ams ams2, et et2, awr awr2, Random random) {
        if (ams2.G) {
            return;
        }
        if (!ams2.o(et2).c(a).booleanValue()) {
            return;
        }
        this.b(ams2, et2);
    }

    private void b(ams ams22, et et2) {
        awr awr2 = ams22.o(et2);
        boolean \u26032 = awr2.c(a);
        boolean \u26033 = false;
        List<ve> \u26034 = ams22.b(null, awr2.e(ams22, et2).a(et2));
        if (!\u26034.isEmpty()) {
            for (ve ve2 : \u26034) {
                if (ve2.bk()) continue;
                \u26033 = true;
                break;
            }
        }
        if (\u26033 != \u26032) {
            awr2 = awr2.a(a, \u26033);
            ams22.a(et2, awr2, 3);
            this.e(ams22, et2, awr2);
        }
        if (\u26033) {
            ams ams22;
            ams22.a(new et(et2), (aou)this, this.a(ams22));
        }
    }

    public static boolean a(amw amw2, et et2, awr awr2, fa fa2) {
        et et3 = et2.a(fa2);
        awr \u26032 = amw2.o(et3);
        aou \u26033 = \u26032.u();
        if (\u26033 == aov.bR) {
            fa fa3 = fa2.d();
            return \u26032.c(aur.a) == fa3;
        }
        return \u26033 == aov.bS;
    }

    @Override
    public awr a(int n2) {
        return this.t().a(a, (n2 & 1) > 0).a(b, (n2 & 4) > 0).a(c, (n2 & 8) > 0);
    }

    @Override
    public int e(awr awr2) {
        int n2 = 0;
        if (awr2.c(a).booleanValue()) {
            n2 |= 1;
        }
        if (awr2.c(b).booleanValue()) {
            n2 |= 4;
        }
        if (awr2.c(c).booleanValue()) {
            n2 |= 8;
        }
        return n2;
    }

    @Override
    public awr a(awr awr2, atk atk2) {
        switch (atk2) {
            case c: {
                return awr2.a(d, awr2.c(f)).a(e, awr2.c(g)).a(f, awr2.c(d)).a(g, awr2.c(e));
            }
            case d: {
                return awr2.a(d, awr2.c(e)).a(e, awr2.c(f)).a(f, awr2.c(g)).a(g, awr2.c(d));
            }
            case b: {
                return awr2.a(d, awr2.c(g)).a(e, awr2.c(d)).a(f, awr2.c(e)).a(g, awr2.c(f));
            }
        }
        return awr2;
    }

    @Override
    public awr a(awr awr2, arw arw2) {
        switch (arw2) {
            case b: {
                return awr2.a(d, awr2.c(f)).a(f, awr2.c(d));
            }
            case c: {
                return awr2.a(e, awr2.c(g)).a(g, awr2.c(e));
            }
        }
        return super.a(awr2, arw2);
    }

    @Override
    protected aws b() {
        return new aws((aou)this, a, b, c, d, e, g, f);
    }

    @Override
    public awp a(amw amw2, awr awr2, et et2, fa fa2) {
        return awp.i;
    }
}

