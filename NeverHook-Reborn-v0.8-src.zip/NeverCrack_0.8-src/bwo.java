/*
 * Decompiled with CFR 0.150.
 */
import java.util.Map;

public class bwo
extends bwm {
    @Override
    protected cgb a(awr awr2) {
        return new cgb(aou.h.b(awr2.u()), this.a((Map<axh<?>, Comparable<?>>)awr2.t()));
    }
}

