/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
import com.google.gson.JsonObject;
import java.util.Locale;

public class cct {
    private static cct a;
    private final int b;
    private final int c;
    private final int d;
    private final int e;
    private final int f;
    private final boolean g;
    private final boolean h;

    private cct(boolean bl2, boolean bl3, int n2, int n3, int n4, int n5, int n6) {
        this.g = bl2;
        this.b = n2;
        this.d = n3;
        this.c = n4;
        this.e = n5;
        this.h = bl3;
        this.f = n6;
    }

    public cct() {
        this(false, true, 1, 0, 1, 0, 32774);
    }

    public cct(int n2, int n3, int n4) {
        this(false, false, n2, n3, n2, n3, n4);
    }

    public cct(int n2, int n3, int n4, int n5, int n6) {
        this(true, false, n2, n3, n4, n5, n6);
    }

    public void a() {
        if (this.equals(a)) {
            return;
        }
        if (a == null || this.h != a.b()) {
            a = this;
            if (this.h) {
                buq.l();
                return;
            }
            buq.m();
        }
        buq.d(this.f);
        if (this.g) {
            buq.a(this.b, this.d, this.c, this.e);
        } else {
            buq.b(this.b, this.d);
        }
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof cct)) {
            return false;
        }
        cct cct2 = (cct)object;
        if (this.f != cct2.f) {
            return false;
        }
        if (this.e != cct2.e) {
            return false;
        }
        if (this.d != cct2.d) {
            return false;
        }
        if (this.h != cct2.h) {
            return false;
        }
        if (this.g != cct2.g) {
            return false;
        }
        if (this.c != cct2.c) {
            return false;
        }
        return this.b == cct2.b;
    }

    public int hashCode() {
        int n2 = this.b;
        n2 = 31 * n2 + this.c;
        n2 = 31 * n2 + this.d;
        n2 = 31 * n2 + this.e;
        n2 = 31 * n2 + this.f;
        n2 = 31 * n2 + (this.g ? 1 : 0);
        n2 = 31 * n2 + (this.h ? 1 : 0);
        return n2;
    }

    public boolean b() {
        return this.h;
    }

    public static cct a(JsonObject jsonObject) {
        if (jsonObject == null) {
            return new cct();
        }
        int n2 = 32774;
        \u2603 = 1;
        \u2603 = 0;
        \u2603 = 1;
        \u2603 = 0;
        boolean \u26032 = true;
        boolean \u26033 = false;
        if (ra.a(jsonObject, "func") && (n2 = cct.a(jsonObject.get("func").getAsString())) != 32774) {
            \u26032 = false;
        }
        if (ra.a(jsonObject, "srcrgb") && (\u2603 = cct.b(jsonObject.get("srcrgb").getAsString())) != 1) {
            \u26032 = false;
        }
        if (ra.a(jsonObject, "dstrgb") && (\u2603 = cct.b(jsonObject.get("dstrgb").getAsString())) != 0) {
            \u26032 = false;
        }
        if (ra.a(jsonObject, "srcalpha")) {
            \u2603 = cct.b(jsonObject.get("srcalpha").getAsString());
            if (\u2603 != 1) {
                \u26032 = false;
            }
            \u26033 = true;
        }
        if (ra.a(jsonObject, "dstalpha")) {
            \u2603 = cct.b(jsonObject.get("dstalpha").getAsString());
            if (\u2603 != 0) {
                \u26032 = false;
            }
            \u26033 = true;
        }
        if (\u26032) {
            return new cct();
        }
        if (\u26033) {
            return new cct(\u2603, \u2603, \u2603, \u2603, n2);
        }
        return new cct(\u2603, \u2603, n2);
    }

    private static int a(String string) {
        \u2603 = string.trim().toLowerCase(Locale.ROOT);
        if ("add".equals(\u2603)) {
            return 32774;
        }
        if ("subtract".equals(\u2603)) {
            return 32778;
        }
        if ("reversesubtract".equals(\u2603)) {
            return 32779;
        }
        if ("reverse_subtract".equals(\u2603)) {
            return 32779;
        }
        if ("min".equals(\u2603)) {
            return 32775;
        }
        if ("max".equals(\u2603)) {
            return 32776;
        }
        return 32774;
    }

    private static int b(String string) {
        \u2603 = string.trim().toLowerCase(Locale.ROOT);
        \u2603 = \u2603.replaceAll("_", "");
        \u2603 = \u2603.replaceAll("one", "1");
        \u2603 = \u2603.replaceAll("zero", "0");
        if ("0".equals(\u2603 = \u2603.replaceAll("minus", "-"))) {
            return 0;
        }
        if ("1".equals(\u2603)) {
            return 1;
        }
        if ("srccolor".equals(\u2603)) {
            return 768;
        }
        if ("1-srccolor".equals(\u2603)) {
            return 769;
        }
        if ("dstcolor".equals(\u2603)) {
            return 774;
        }
        if ("1-dstcolor".equals(\u2603)) {
            return 775;
        }
        if ("srcalpha".equals(\u2603)) {
            return 770;
        }
        if ("1-srcalpha".equals(\u2603)) {
            return 771;
        }
        if ("dstalpha".equals(\u2603)) {
            return 772;
        }
        if ("1-dstalpha".equals(\u2603)) {
            return 773;
        }
        return -1;
    }
}

