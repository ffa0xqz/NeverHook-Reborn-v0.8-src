/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.gson.JsonDeserializationContext
 *  com.google.gson.JsonDeserializer
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParseException
 *  com.google.gson.JsonSerializationContext
 *  com.google.gson.JsonSerializer
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.common.collect.Lists;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class bfq {
    private static final Logger b = LogManager.getLogger();
    public static final bfq a = new bfq(new bfo[0]);
    private final bfo[] c;

    public bfq(bfo[] arrbfo) {
        this.c = arrbfo;
    }

    public List<ain> a(Random random, bfr bfr22) {
        ArrayList arrayList = Lists.newArrayList();
        if (bfr22.a(this)) {
            bfr bfr22;
            for (bfo bfo2 : this.c) {
                bfo2.b(arrayList, random, bfr22);
            }
            bfr22.b(this);
        } else {
            b.warn("Detected infinite loop in loot tables");
        }
        return arrayList;
    }

    public void a(tt tt2, Random random, bfr bfr2) {
        List<ain> list = this.a(random, bfr2);
        List<Integer> \u26032 = this.a(tt2, random);
        this.a(list, \u26032.size(), random);
        for (ain ain2 : list) {
            if (\u26032.isEmpty()) {
                b.warn("Tried to over-fill a container");
                return;
            }
            if (ain2.b()) {
                tt2.a((int)\u26032.remove(\u26032.size() - 1), ain.a);
                continue;
            }
            tt2.a((int)\u26032.remove(\u26032.size() - 1), ain2);
        }
    }

    private void a(List<ain> list2, int n2, Random random) {
        List<ain> list2;
        ArrayList arrayList = Lists.newArrayList();
        Object \u26032 = list2.iterator();
        while (\u26032.hasNext()) {
            ain ain2 = \u26032.next();
            if (ain2.b()) {
                \u26032.remove();
                continue;
            }
            if (ain2.E() <= 1) continue;
            arrayList.add(ain2);
            \u26032.remove();
        }
        while ((n2 -= list2.size()) > 0 && !arrayList.isEmpty()) {
            \u26032 = (ain)arrayList.remove(ri.a(random, 0, arrayList.size() - 1));
            int n3 = ri.a(random, 1, ((ain)\u26032).E() / 2);
            ain \u26033 = ((ain)\u26032).a(n3);
            if (((ain)\u26032).E() > 1 && random.nextBoolean()) {
                arrayList.add(\u26032);
            } else {
                list2.add((ain)\u26032);
            }
            if (\u26033.E() > 1 && random.nextBoolean()) {
                arrayList.add(\u26033);
                continue;
            }
            list2.add(\u26033);
        }
        list2.addAll(arrayList);
        Collections.shuffle(list2, random);
    }

    private List<Integer> a(tt tt2, Random random) {
        ArrayList arrayList = Lists.newArrayList();
        for (int i2 = 0; i2 < tt2.w_(); ++i2) {
            if (!tt2.a(i2).b()) continue;
            arrayList.add(i2);
        }
        Collections.shuffle(arrayList, random);
        return arrayList;
    }

    public static class a
    implements JsonDeserializer<bfq>,
    JsonSerializer<bfq> {
        public bfq a(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            JsonObject jsonObject = ra.m(jsonElement, "loot table");
            bfo[] \u26032 = ra.a(jsonObject, "pools", new bfo[0], jsonDeserializationContext, bfo[].class);
            return new bfq(\u26032);
        }

        public JsonElement a(bfq bfq2, Type type, JsonSerializationContext jsonSerializationContext) {
            JsonObject jsonObject = new JsonObject();
            jsonObject.add("pools", jsonSerializationContext.serialize((Object)bfq2.c));
            return jsonObject;
        }

        public /* synthetic */ JsonElement serialize(Object object, Type type, JsonSerializationContext jsonSerializationContext) {
            return this.a((bfq)object, type, jsonSerializationContext);
        }

        public /* synthetic */ Object deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            return this.a(jsonElement, type, jsonDeserializationContext);
        }
    }
}

