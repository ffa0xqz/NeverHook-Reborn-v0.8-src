/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.HashBasedTable
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Maps
 */
import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class cif
extends qj {
    public static final Map<ahn, List<bnq>> e = Maps.newHashMap();
    public static final List<bnq> f = Lists.newArrayList();

    private static bnq a(ahn ahn3) {
        bnq bnq2 = new bnq();
        f.add(bnq2);
        e.computeIfAbsent(ahn3, ahn2 -> new ArrayList()).add(bnq2);
        e.computeIfAbsent(ahn.g, ahn2 -> new ArrayList()).add(bnq2);
        return bnq2;
    }

    private static ahn a(ain ain2) {
        ahn ahn2 = ain2.c().b();
        if (ahn2 == ahn.b || ahn2 == ahn.i || ahn2 == ahn.d) {
            return ahn2;
        }
        if (ahn2 == ahn.j) {
            return ahn.i;
        }
        return ahn.f;
    }

    static {
        HashBasedTable hashBasedTable = HashBasedTable.create();
        for (akr akr2 : aks.a) {
            bnq \u26033;
            if (akr2.c()) continue;
            ahn ahn2 = cif.a(akr2.b());
            String \u26032 = akr2.e();
            if (\u26032.isEmpty()) {
                \u26033 = cif.a(ahn2);
            } else {
                \u26033 = (bnq)hashBasedTable.get((Object)ahn2, (Object)\u26032);
                if (\u26033 == null) {
                    \u26033 = cif.a(ahn2);
                    hashBasedTable.put((Object)ahn2, (Object)\u26032, (Object)\u26033);
                }
            }
            \u26033.b(akr2);
        }
    }
}

