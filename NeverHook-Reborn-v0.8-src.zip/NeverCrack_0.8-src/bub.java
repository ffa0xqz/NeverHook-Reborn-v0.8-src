/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import java.util.List;
import javax.annotation.Nullable;
import top.nhprem.Main;
import top.nhprem.api.event.event.EventMessage;
import top.nhprem.api.event.event.EventMotion;
import top.nhprem.api.event.event.EventPostMotionUpdate;
import top.nhprem.api.event.event.EventPreMotionUpdate;
import top.nhprem.api.event.event.EventPush;
import top.nhprem.api.event.event.EventUpdate;
import top.nhprem.api.utils.combat.LPositionHelper;
import top.nhprem.api.utils.movement.EventMove;
import top.nhprem.client.features.impl.movement.NoSlowDown;
import top.nhprem.client.features.impl.player.FreeCam;
import top.nhprem.client.features.impl.player.NoPush;

public class bub
extends bty {
    public final brx d;
    private final qr cb;
    private final qj cc;
    private int cd = 0;
    private LPositionHelper location;
    private double ce;
    private double cf;
    private double cg;
    private float ch;
    private float ci;
    private boolean cj;
    private boolean ck;
    private boolean cl;
    private int cm;
    private boolean cn;
    private String co;
    public btz e;
    protected bhz f;
    protected int g;
    public int h;
    public float bV;
    public float bW;
    public float bX;
    public float bY;
    private int cp;
    private float cq;
    public float bZ;
    public float ca;
    private boolean cr;
    private tz cs;
    private boolean ct;
    private boolean cu = true;
    private int cv;
    private boolean cw;
    private float PreYaw;
    private float PrePitch;

    public bub(bhz p_i47378_1_, ams p_i47378_2_, brx p_i47378_3_, qr p_i47378_4_, qj p_i47378_5_) {
        super(p_i47378_2_, p_i47378_3_.e());
        this.d = p_i47378_3_;
        this.cb = p_i47378_4_;
        this.cc = p_i47378_5_;
        this.f = p_i47378_1_;
        this.am = 0;
    }

    @Override
    public boolean a(up source, float amount) {
        return false;
    }

    public void setHeadRotations(float yaw, float pitch) {
        this.aP = yaw;
        this.rotationPitchHead = pitch;
    }

    public void setHeadRotations(float[] rotations) {
        this.setHeadRotations(rotations[0], rotations[1]);
    }

    public float[] getRotations() {
        return new float[]{this.v, this.w};
    }

    public float[] getHeadRotations() {
        return new float[]{this.aP, this.rotationPitchHead};
    }

    @Override
    public void b(float healAmount) {
    }

    @Override
    public boolean a(ve entityIn, boolean force) {
        if (!super.a(entityIn, force)) {
            return false;
        }
        if (entityIn instanceof afc) {
            this.f.U().a(new cgm(this, (afc)entityIn));
        }
        if (entityIn instanceof afb) {
            this.x = entityIn.v;
            this.v = entityIn.v;
            this.g(entityIn.v);
        }
        return true;
    }

    @Override
    public void o() {
        super.o();
        this.ct = false;
    }

    @Override
    public bhc e(float partialTicks) {
        return bub.f(this.w, this.v);
    }

    @Override
    public void B_() {
        EventUpdate eventUpdate = new EventUpdate();
        eventUpdate.call();
        if (this.l.e(new et(this.p, 0.0, this.r))) {
            super.B_();
            if (this.aS()) {
                this.d.a(new lk.c(this.v, this.w, this.z));
                this.d.a(new lq(this.be, this.bg, this.e.g, this.e.h));
                ve entity = this.bH();
                if (entity != this && entity.bI()) {
                    this.d.a(new ll(entity));
                }
            } else {
                this.N();
                EventPostMotionUpdate eventPre = new EventPostMotionUpdate(this.v, this.w, this.z, this.q);
                eventPre.call();
                if (!Main.instance.featureDirector.getFeatureByClass(FreeCam.class).isToggled()) {
                    this.v = this.PreYaw;
                    this.w = this.PrePitch;
                }
            }
        }
    }

    private void N() {
        boolean flag1;
        if (Main.instance.featureDirector.getFeatureByClass(FreeCam.class).isToggled()) {
            return;
        }
        EventMotion event2 = new EventMotion(this.f.h.p, this.bw().b, this.f.h.r, this.f.h.v, this.f.h.w, this.aU(), this.f.h.z);
        event2.call();
        EventPreMotionUpdate eventPre = new EventPreMotionUpdate(this.v, this.w, this.p, this.q, this.r, this.z);
        eventPre.call();
        this.PreYaw = this.v;
        this.PrePitch = this.w;
        this.v = eventPre.getYaw();
        this.w = eventPre.getPitch();
        boolean flag = this.aV();
        if (flag != this.cl) {
            if (flag) {
                this.d.a(new lp(this, lp.a.d));
            } else {
                this.d.a(new lp(this, lp.a.e));
            }
            this.cl = flag;
        }
        if ((flag1 = this.aU()) != this.ck) {
            if (flag1) {
                this.d.a(new lp(this, lp.a.a));
            } else {
                this.d.a(new lp(this, lp.a.b));
            }
            this.ck = flag1;
        }
        if (this.K()) {
            boolean flag3;
            bgz axisalignedbb = this.bw();
            double d0 = eventPre.getPosX() - this.ce;
            double d1 = eventPre.getPosY() - this.cf;
            double d2 = eventPre.getPosZ() - this.cg;
            double d3 = eventPre.getYaw() - this.ch;
            double d4 = eventPre.getPitch() - this.ci;
            ++this.cm;
            boolean flag2 = d0 * d0 + d1 * d1 + d2 * d2 > 9.0E-4 || this.cm >= 20;
            boolean bl2 = flag3 = d3 != 0.0 || d4 != 0.0;
            if (!Main.instance.featureDirector.getFeatureByClass(FreeCam.class).isToggled()) {
                if (this.aS()) {
                    this.d.a(new lk.b(this.s, -999.0, this.u, eventPre.getYaw(), eventPre.getPitch(), eventPre.isOnGround()));
                    flag2 = false;
                } else if (flag2 && flag3) {
                    this.d.a(new lk.b(eventPre.getPosX(), eventPre.getPosY(), eventPre.getPosZ(), eventPre.getYaw(), eventPre.getPitch(), eventPre.isOnGround()));
                } else if (flag2) {
                    this.d.a(new lk.a(eventPre.getPosX(), eventPre.getPosY(), eventPre.getPosZ(), eventPre.isOnGround()));
                } else if (flag3) {
                    this.d.a(new lk.c(eventPre.getYaw(), eventPre.getPitch(), eventPre.isOnGround()));
                } else if (this.cj != this.z) {
                    this.d.a(new lk(eventPre.isOnGround()));
                }
            }
            if (flag2) {
                this.ce = eventPre.getPosX();
                this.cf = eventPre.getPosY();
                this.cg = eventPre.getPosZ();
                this.cm = 0;
            }
            if (flag3) {
                this.ch = eventPre.getYaw();
                this.ci = eventPre.getPitch();
            }
            this.cj = eventPre.isOnGround();
            this.cu = this.f.t.R;
        }
        EventMotion post = new EventMotion();
        post.call();
    }

    @Override
    @Nullable
    public acj a(boolean dropAll) {
        lo.a cpacketplayerdigging$action = dropAll ? lo.a.d : lo.a.e;
        this.d.a(new lo(cpacketplayerdigging$action, et.a, fa.a));
        return null;
    }

    @Override
    protected ain a(acj p_184816_1_) {
        return ain.a;
    }

    public void g(String message) {
        EventMessage event = new EventMessage(message);
        event.call();
        if (!event.isCancelled()) {
            this.d.a(new la(message));
        }
    }

    public LPositionHelper getLocation() {
        if (this.location == null) {
            this.location = new LPositionHelper(this.f.h.p, this.f.h.q, this.f.h.r, this.f.h.z);
        }
        this.location.setX(this.f.h.p);
        this.location.setY(this.f.h.q);
        this.location.setZ(this.f.h.r);
        this.location.setOnGround(this.f.h.z);
        return this.location;
    }

    @Override
    public void a(tz hand) {
        super.a(hand);
        this.d.a(new lx(hand));
    }

    @Override
    public void cY() {
        this.d.a(new lb(lb.a.a));
    }

    @Override
    protected void d(up damageSrc, float damageAmount) {
        if (!this.b(damageSrc)) {
            this.c(this.cd() - damageAmount);
        }
    }

    @Override
    public void p() {
        this.d.a(new lg(this.by.d));
        this.x();
    }

    public void x() {
        this.bv.g(ain.a);
        super.p();
        this.f.a((bli)null);
    }

    public void o(float health) {
        if (this.cn) {
            float f2 = this.cd() - health;
            if (f2 <= 0.0f) {
                this.c(health);
                if (f2 < 0.0f) {
                    this.V = this.aI / 2;
                }
            } else {
                this.bc = f2;
                this.c(this.cd());
                this.V = this.aI;
                this.d(up.n, f2);
                this.ay = this.az = 10;
            }
        } else {
            this.c(health);
            this.cn = true;
        }
    }

    @Override
    public void a(qm stat, int amount) {
        if (stat != null && stat.b) {
            super.a(stat, amount);
        }
    }

    @Override
    public void w() {
        this.d.a(new ln(this.bO));
    }

    @Override
    public boolean cZ() {
        return true;
    }

    protected void A() {
        this.d.a(new lp(this, lp.a.f, ri.d(this.J() * 100.0f)));
    }

    public void B() {
        this.d.a(new lp(this, lp.a.h));
    }

    public void h(String brand) {
        this.co = brand;
    }

    public String C() {
        return this.co;
    }

    public qr D() {
        return this.cb;
    }

    public qj E() {
        return this.cc;
    }

    public void a(akr p_193103_1_) {
        if (this.cc.e(p_193103_1_)) {
            this.cc.f(p_193103_1_);
            this.d.a(new lr(p_193103_1_));
        }
    }

    public int F() {
        return this.cd;
    }

    public void n(int p_184839_1_) {
        this.cd = p_184839_1_;
    }

    @Override
    public void a(hh chatComponent, boolean p_146105_2_) {
        if (p_146105_2_) {
            this.f.q.a(chatComponent, false);
        } else {
            this.f.q.d().a(chatComponent);
        }
    }

    @Override
    protected boolean i(double x2, double y2, double z2) {
        EventPush eventPush = new EventPush();
        eventPush.call();
        if (eventPush.isCancelled()) {
            return false;
        }
        if (Main.instance.featureDirector.getFeatureByClass(NoPush.class).isToggled() && NoPush.pushblocks.getBoolValue()) {
            return false;
        }
        if (!this.Q) {
            et blockpos = new et(x2, y2, z2);
            double d0 = x2 - (double)blockpos.p();
            double d1 = z2 - (double)blockpos.r();
            if (!this.f(blockpos)) {
                int i2 = -1;
                double d2 = 9999.0;
                if (this.f(blockpos.e()) && d0 < d2) {
                    d2 = d0;
                    i2 = 0;
                }
                if (this.f(blockpos.f()) && 1.0 - d0 < d2) {
                    d2 = 1.0 - d0;
                    i2 = 1;
                }
                if (this.f(blockpos.c()) && d1 < d2) {
                    d2 = d1;
                    i2 = 4;
                }
                if (this.f(blockpos.d()) && 1.0 - d1 < d2) {
                    d2 = 1.0 - d1;
                    i2 = 5;
                }
                float f2 = 0.1f;
                if (i2 == 0) {
                    this.s = -0.1f;
                }
                if (i2 == 1) {
                    this.s = 0.1f;
                }
                if (i2 == 4) {
                    this.u = -0.1f;
                }
                if (i2 == 5) {
                    this.u = 0.1f;
                }
            }
        }
        return false;
    }

    private boolean f(et pos) {
        return !this.l.o(pos).l() && !this.l.o(pos.a()).l();
    }

    @Override
    public void f(boolean sprinting) {
        super.f(sprinting);
        this.h = 0;
    }

    public void a(float currentXP, int maxXP, int level) {
        this.bR = currentXP;
        this.bQ = maxXP;
        this.bP = level;
    }

    @Override
    public void a(hh component) {
        this.f.q.d().a(component);
    }

    @Override
    public boolean a(int permLevel, String commandName) {
        return permLevel <= this.F();
    }

    @Override
    public void a(byte id2) {
        if (id2 >= 24 && id2 <= 28) {
            this.n(id2 - 24);
        } else {
            super.a(id2);
        }
    }

    @Override
    public et c() {
        return new et(this.p + 0.5, this.q + 0.5, this.r + 0.5);
    }

    @Override
    public void a(qc soundIn, float volume, float pitch) {
        this.l.a(this.p, this.q, this.r, soundIn, this.bK(), volume, pitch, false);
    }

    @Override
    public boolean cC() {
        return true;
    }

    @Override
    public void c(tz hand) {
        ain itemstack = this.b(hand);
        if (!itemstack.b() && !this.cG()) {
            super.c(hand);
            this.cr = true;
            this.cs = hand;
        }
    }

    @Override
    public boolean cG() {
        return this.cr;
    }

    @Override
    public void cN() {
        super.cN();
        this.cr = false;
    }

    @Override
    public tz cH() {
        return this.cs;
    }

    @Override
    public void a(mx<?> key) {
        super.a(key);
        if (at.equals(key)) {
            tz enumhand;
            boolean flag = ((Byte)this.Y.a(at) & 1) > 0;
            tz tz2 = enumhand = ((Byte)this.Y.a(at) & 2) > 0 ? tz.b : tz.a;
            if (flag && !this.cr) {
                this.c(enumhand);
            } else if (!flag && this.cr) {
                this.cN();
            }
        }
        if (Z.equals(key) && this.cP() && !this.cw) {
            this.f.U().a(new cgj(this));
        }
    }

    public boolean H() {
        ve entity = this.bJ();
        return this.aS() && entity instanceof vx && ((vx)((Object)entity)).a();
    }

    public float J() {
        return this.cq;
    }

    @Override
    public void a(awa signTile) {
        this.f.a(new bmz(signTile));
    }

    @Override
    public void a(amh commandBlock) {
        this.f.a(new bmx(commandBlock));
    }

    @Override
    public void a(avk commandBlock) {
        this.f.a(new bmj(commandBlock));
    }

    @Override
    public void a(awc structure) {
        this.f.a(new bna(structure));
    }

    @Override
    public void a(ain stack, tz hand) {
        ail item = stack.c();
        if (item == aip.bX) {
            this.f.a(new bmh(this, stack, true));
        }
    }

    @Override
    public void a(tt chestInventory) {
        String s2;
        String string = s2 = chestInventory instanceof ua ? ((ua)((Object)chestInventory)).l() : "minecraft:container";
        if ("minecraft:chest".equals(s2)) {
            this.f.a(new bmk(this.bv, chestInventory));
        } else if ("minecraft:hopper".equals(s2)) {
            this.f.a(new bmt(this.bv, chestInventory));
        } else if ("minecraft:furnace".equals(s2)) {
            this.f.a(new bms(this.bv, chestInventory));
        } else if ("minecraft:brewing_stand".equals(s2)) {
            this.f.a(new bmi(this.bv, chestInventory));
        } else if ("minecraft:beacon".equals(s2)) {
            this.f.a(new bmg(this.bv, chestInventory));
        } else if (!"minecraft:dispenser".equals(s2) && !"minecraft:dropper".equals(s2)) {
            if ("minecraft:shulker_box".equals(s2)) {
                this.f.a(new bmy(this.bv, chestInventory));
            } else {
                this.f.a(new bmk(this.bv, chestInventory));
            }
        } else {
            this.f.a(new bmo(this.bv, chestInventory));
        }
    }

    @Override
    public void a(aam horse, tt inventoryIn) {
        this.f.a(new bmu(this.bv, inventoryIn, horse));
    }

    @Override
    public void a(ua guiOwner) {
        String s2 = guiOwner.l();
        if ("minecraft:crafting_table".equals(s2)) {
            this.f.a(new bml(this.bv, this.l));
        } else if ("minecraft:enchanting_table".equals(s2)) {
            this.f.a(new bmr(this.bv, this.l, guiOwner));
        } else if ("minecraft:anvil".equals(s2)) {
            this.f.a(new bmf(this.bv, this.l));
        }
    }

    @Override
    public void a(amd villager) {
        this.f.a(new bmw(this.bv, villager, this.l));
    }

    @Override
    public void a(ve entityHit) {
        this.f.j.a(entityHit, fj.j);
    }

    @Override
    public void b(ve entityHit) {
        this.f.j.a(entityHit, fj.k);
    }

    @Override
    public boolean aU() {
        boolean flag = this.e != null && this.e.h;
        return flag && !this.bK;
    }

    @Override
    public void cA() {
        super.cA();
        if (this.K()) {
            this.be = btz.a;
            this.bg = btz.moveForward;
            this.bd = this.e.g;
            this.bX = this.bV;
            this.bY = this.bW;
            this.bW = (float)((double)this.bW + (double)(this.w - this.bW) * 0.5);
            this.bV = (float)((double)this.bV + (double)(this.v - this.bV) * 0.5);
        }
    }

    protected boolean K() {
        return this.f.aa() == this;
    }

    @Override
    public void n() {
        ain itemstack;
        boolean flag4;
        ++this.h;
        if (this.g > 0) {
            --this.g;
        }
        this.ca = this.bZ;
        if (this.ak) {
            if (this.f.m != null && !this.f.m.d()) {
                if (this.f.m instanceof bme) {
                    this.p();
                }
                this.f.a((bli)null);
            }
            if (this.bZ == 0.0f) {
                this.f.U().a(cgn.a(qd.fU, this.S.nextFloat() * 0.4f + 0.8f));
            }
            this.bZ += 0.0125f;
            if (this.bZ >= 1.0f) {
                this.bZ = 1.0f;
            }
            this.ak = false;
        } else if (this.a(uz.i) && this.b(uz.i).b() > 60) {
            this.bZ += 0.006666667f;
            if (this.bZ > 1.0f) {
                this.bZ = 1.0f;
            }
        } else {
            if (this.bZ > 0.0f) {
                this.bZ -= 0.05f;
            }
            if (this.bZ < 0.0f) {
                this.bZ = 0.0f;
            }
        }
        if (this.aj > 0) {
            --this.aj;
        }
        boolean flag = this.e.g;
        boolean flag1 = this.e.h;
        float f2 = 0.8f;
        boolean flag2 = btz.moveForward >= 0.8f;
        this.e.a();
        this.f.ap().a(this.e);
        if (this.cG() && !this.aS()) {
            btz.a *= Main.instance.featureDirector.getFeatureByClass(NoSlowDown.class).isToggled() ? NoSlowDown.percentage.getNumberValue() / 100.0f : 0.2f;
            btz.moveForward *= Main.instance.featureDirector.getFeatureByClass(NoSlowDown.class).isToggled() ? NoSlowDown.percentage.getNumberValue() / 100.0f : 0.2f;
            this.g = 0;
        }
        boolean flag3 = false;
        if (this.cv > 0) {
            --this.cv;
            flag3 = true;
            this.e.g = true;
        }
        bgz axisalignedbb = this.bw();
        this.i(this.p - (double)this.G * 0.35, axisalignedbb.b + 0.5, this.r + (double)this.G * 0.35);
        this.i(this.p - (double)this.G * 0.35, axisalignedbb.b + 0.5, this.r - (double)this.G * 0.35);
        this.i(this.p + (double)this.G * 0.35, axisalignedbb.b + 0.5, this.r - (double)this.G * 0.35);
        this.i(this.p + (double)this.G * 0.35, axisalignedbb.b + 0.5, this.r + (double)this.G * 0.35);
        boolean bl2 = flag4 = (float)this.di().a() > 6.0f || this.bO.c;
        if (this.z && !flag1 && !flag2) {
            if (btz.moveForward >= 0.8f && !this.aV() && flag4 && !this.cG() && !this.a(uz.o)) {
                if (this.g <= 0 && !this.f.t.Z.e()) {
                    this.g = 7;
                } else {
                    this.f(true);
                }
            }
        }
        if (!this.aV()) {
            if (btz.moveForward >= 0.8f && flag4 && !this.cG() && !this.a(uz.o) && this.f.t.Z.e()) {
                this.f(true);
            }
        }
        if (this.aV()) {
            if (btz.moveForward < 0.8f || this.A || !flag4) {
                this.f(false);
            }
        }
        if (this.bO.c) {
            if (this.f.c.k()) {
                if (!this.bO.b) {
                    this.bO.b = true;
                    this.w();
                }
            } else if (!flag && this.e.g && !flag3) {
                if (this.bA == 0) {
                    this.bA = 7;
                } else {
                    this.bO.b = !this.bO.b;
                    this.w();
                    this.bA = 0;
                }
            }
        }
        if (this.e.g && !flag && !this.z && this.t < 0.0 && !this.cP() && !this.bO.b && (itemstack = this.b(vj.e)).c() == aip.cS && ahu.d(itemstack)) {
            this.d.a(new lp(this, lp.a.i));
        }
        this.cw = this.cP();
        if (this.bO.b && this.K()) {
            if (this.e.h) {
                btz.a = (float)((double)btz.a / 0.3);
                btz.moveForward = (float)((double)btz.moveForward / 0.3);
                this.t -= (double)(this.bO.a() * 3.0f);
            }
            if (this.e.g) {
                this.t += (double)(this.bO.a() * 3.0f);
            }
        }
        if (this.H()) {
            vx ijumpingmount = (vx)((Object)this.bJ());
            if (this.cp < 0) {
                ++this.cp;
                if (this.cp == 0) {
                    this.cq = 0.0f;
                }
            }
            if (flag && !this.e.g) {
                this.cp = -10;
                ijumpingmount.a_(ri.d(this.J() * 100.0f));
                this.A();
            } else if (!flag && this.e.g) {
                this.cp = 0;
                this.cq = 0.0f;
            } else if (flag) {
                ++this.cp;
                this.cq = this.cp < 10 ? (float)this.cp * 0.1f : 0.8f + 2.0f / (float)(this.cp - 9) * 0.1f;
            }
        } else {
            this.cq = 0.0f;
        }
        super.n();
        if (this.z && this.bO.b && !this.f.c.k()) {
            this.bO.b = false;
            this.w();
        }
    }

    @Override
    public void aE() {
        super.aE();
        this.ct = false;
        if (this.bJ() instanceof afb) {
            afb entityboat = (afb)this.bJ();
            entityboat.a(this.e.e, this.e.f, this.e.c, this.e.d);
            this.ct |= this.e.e || this.e.f || this.e.c || this.e.d;
        }
    }

    public boolean L() {
        return this.ct;
    }

    @Override
    @Nullable
    public uy c(@Nullable ux potioneffectin) {
        if (potioneffectin == uz.i) {
            this.ca = 0.0f;
            this.bZ = 0.0f;
        }
        return super.c(potioneffectin);
    }

    @Override
    public void a(vt moverType, double d2, double d22, double d3) {
        double d4 = this.p;
        double d5 = this.r;
        EventMove eventMove = new EventMove(d2, d22, d3);
        eventMove.call();
        if (eventMove.isCancelled()) {
            return;
        }
        d2 = eventMove.getX();
        d22 = eventMove.getY();
        d3 = eventMove.getZ();
        super.a(moverType, d2, d22, d3);
        this.h((float)(this.p - d4), (float)(this.r - d5));
    }

    public boolean M() {
        return this.cu;
    }

    protected void h(float p_189810_1_, float p_189810_2_) {
        if (this.M() && this.cv <= 0 && this.z && !this.aU() && !this.aS()) {
            bhb vec2f = this.e.b();
            if (vec2f.i != 0.0f || vec2f.j != 0.0f) {
                awr iblockstate1;
                et blockpos;
                awr iblockstate;
                bhc vec3d = new bhc(this.p, this.bw().b, this.r);
                double d0 = this.p + (double)p_189810_1_;
                double d1 = this.r + (double)p_189810_2_;
                bhc vec3d1 = new bhc(d0, this.bw().b, d1);
                bhc vec3d2 = new bhc(p_189810_1_, 0.0, p_189810_2_);
                float f2 = this.cy();
                float f1 = (float)vec3d2.c();
                if (f1 <= 0.001f) {
                    float f22 = f2 * vec2f.i;
                    float f3 = f2 * vec2f.j;
                    float f4 = ri.a(this.v * ((float)Math.PI / 180));
                    float f5 = ri.b(this.v * ((float)Math.PI / 180));
                    vec3d2 = new bhc(f22 * f5 - f3 * f4, vec3d2.c, f3 * f5 + f22 * f4);
                    f1 = (float)vec3d2.c();
                    if (f1 <= 0.001f) {
                        return;
                    }
                }
                float f12 = (float)ri.i(f1);
                bhc vec3d12 = vec3d2.a((double)f12);
                bhc vec3d13 = this.aL();
                float f13 = (float)(vec3d13.b * vec3d12.b + vec3d13.d * vec3d12.d);
                if (f13 >= -0.15f && (iblockstate = this.l.o(blockpos = new et(this.p, this.bw().e, this.r))).d(this.l, blockpos) == null && (iblockstate1 = this.l.o(blockpos = blockpos.a())).d(this.l, blockpos) == null) {
                    float f14;
                    float f6 = 7.0f;
                    float f7 = 1.2f;
                    if (this.a(uz.h)) {
                        f7 += (float)(this.b(uz.h).c() + 1) * 0.75f;
                    }
                    float f8 = Math.max(f2 * 7.0f, 1.0f / f12);
                    bhc vec3d4 = vec3d1.e(vec3d12.a((double)f8));
                    float f9 = this.G;
                    float f10 = this.H;
                    bgz axisalignedbb = new bgz(vec3d, vec3d4.b(0.0, f10, 0.0)).c((double)f9, 0.0, f9);
                    bhc lvt_19_1_ = vec3d.b(0.0, 0.51f, 0.0);
                    vec3d4 = vec3d4.b(0.0, 0.51f, 0.0);
                    bhc vec3d5 = vec3d12.c(new bhc(0.0, 1.0, 0.0));
                    bhc vec3d6 = vec3d5.a((double)(f9 * 0.5f));
                    bhc vec3d7 = lvt_19_1_.d(vec3d6);
                    bhc vec3d8 = vec3d4.d(vec3d6);
                    bhc vec3d9 = lvt_19_1_.e(vec3d6);
                    bhc vec3d10 = vec3d4.e(vec3d6);
                    List<bgz> list = this.l.a((ve)this, axisalignedbb);
                    if (!list.isEmpty()) {
                        // empty if block
                    }
                    float f11 = Float.MIN_VALUE;
                    for (bgz axisalignedbb2 : list) {
                        if (!axisalignedbb2.a(vec3d7, vec3d8) && !axisalignedbb2.a(vec3d9, vec3d10)) continue;
                        f11 = (float)axisalignedbb2.e;
                        bhc vec3d11 = axisalignedbb2.c();
                        et blockpos1 = new et(vec3d11);
                        int i2 = 1;
                        while (!((float)i2 >= f7)) {
                            awr iblockstate3;
                            et blockpos2 = blockpos1.b(i2);
                            awr iblockstate2 = this.l.o(blockpos2);
                            bgz axisalignedbb1 = iblockstate2.d(this.l, blockpos2);
                            if (axisalignedbb1 != null && (double)(f11 = (float)axisalignedbb1.e + (float)blockpos2.q()) - this.bw().b > (double)f7) {
                                return;
                            }
                            if (i2 > 1 && (iblockstate3 = this.l.o(blockpos = blockpos.a())).d(this.l, blockpos) != null) {
                                return;
                            }
                            ++i2;
                        }
                        break block0;
                    }
                    if (f11 != Float.MIN_VALUE && (f14 = (float)((double)f11 - this.bw().b)) > 0.5f && f14 <= f7) {
                        this.cv = 1;
                    }
                }
            }
        }
    }

    public boolean killaurachecks() {
        return this.f.h.au() || this.f.h.ao() || this.f.h.m_() || this.f.h.E;
    }

    public boolean isInLiquid() {
        return this.f.h.au() || this.f.h.ao();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean isMoving() {
        if (this.aU()) return false;
        if (btz.moveForward != 0.0f) return true;
        if (btz.a == 0.0f) return false;
        return true;
    }
}

