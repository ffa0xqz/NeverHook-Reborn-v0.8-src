/*
 * Decompiled with CFR 0.150.
 */
public class aib
extends ail {
    public aib() {
        this.b(ahn.f);
    }

    @Override
    public ub a(aeb aeb2, ams ams2, et et2, tz tz2, fa fa2, float f2, float f3, float f4) {
        if (ams2.G) {
            return ub.a;
        }
        if (!aeb2.a(et2 = et2.a(fa2), fa2, \u2603 = aeb2.b(tz2))) {
            return ub.c;
        }
        if (ams2.o(et2).a() == bcx.a) {
            ams2.a(null, et2, qd.bD, qe.e, 1.0f, (j.nextFloat() - j.nextFloat()) * 0.2f + 1.0f);
            ams2.a(et2, aov.ab.t());
        }
        if (!aeb2.bO.d) {
            \u2603.g(1);
        }
        return ub.a;
    }
}

