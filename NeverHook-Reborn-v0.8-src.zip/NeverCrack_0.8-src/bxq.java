/*
 * Decompiled with CFR 0.150.
 */
public interface bxq {
    public bxp a(ams var1, buw var2, int var3);
}

