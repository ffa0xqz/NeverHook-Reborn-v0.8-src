/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import javax.annotation.Nullable;

public interface bcg {
    @Nullable
    public bch.b a(ams var1, et var2, bch.b var3);
}

