/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 *  com.google.common.collect.Lists
 *  com.mojang.authlib.GameProfile
 *  javax.annotation.Nullable
 */
import com.google.common.base.Predicate;
import com.google.common.collect.Lists;
import com.mojang.authlib.GameProfile;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import top.nhprem.Main;
import top.nhprem.api.event.event.EventUpdateLiving;
import top.nhprem.client.features.impl.player.FreeCam;
import top.nhprem.client.features.impl.player.NoClip;
import top.nhprem.client.features.impl.player.NoPush;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public abstract class aeb
extends vn {
    private static final mx<Float> a = na.a(aeb.class, mz.c);
    private static final mx<Integer> b = na.a(aeb.class, mz.b);
    protected static final mx<Byte> br = na.a(aeb.class, mz.a);
    protected static final mx<Byte> bs = na.a(aeb.class, mz.a);
    protected static final mx<fy> bt = na.a(aeb.class, mz.n);
    protected static final mx<fy> bu = na.a(aeb.class, mz.n);
    public aea bv = new aea(this);
    protected agk bw = new agk();
    public afp bx;
    public afp by;
    protected afn bz = new afn();
    protected int bA;
    public float bB;
    public float bC;
    public int bD;
    public double bE;
    public double bF;
    public double bG;
    public double bH;
    public double bI;
    public double bJ;
    protected boolean bK;
    public et bL;
    private int c;
    public float bM;
    public float cx;
    public float bN;
    private et d;
    private boolean e;
    public adz bO = new adz();
    public int bP;
    public int bQ;
    public float bR;
    protected int bS;
    public float bT = 0.02f;
    private int f;
    private final GameProfile g;
    private boolean h;
    private ain bV = ain.a;
    private final aim bW = this.l();
    @Nullable
    public acd bU;

    protected aim l() {
        return new aim();
    }

    public aeb(ams worldIn, GameProfile gameProfileIn) {
        super(worldIn);
        this.a(aeb.a(gameProfileIn));
        this.g = gameProfileIn;
        this.by = this.bx = new agg(this.bv, !worldIn.G, this);
        et blockpos = worldIn.T();
        this.b((double)blockpos.p() + 0.5, blockpos.q() + 1, (double)blockpos.r() + 0.5, 0.0f, 0.0f);
        this.ba = 180.0f;
    }

    @Override
    protected void bM() {
        super.bM();
        this.cm().b(adf.f).a(1.0);
        this.a(adf.d).a(0.1f);
        this.cm().b(adf.g);
        this.cm().b(adf.j);
    }

    @Override
    protected void i() {
        super.i();
        this.Y.a(a, Float.valueOf(0.0f));
        this.Y.a(b, 0);
        this.Y.a(br, (byte)0);
        this.Y.a(bs, (byte)1);
        this.Y.a(bt, new fy());
        this.Y.a(bu, new fy());
    }

    @Override
    public void B_() {
        this.Q = Main.instance.featureDirector.getFeatureByClass(FreeCam.class).isToggled() || Main.instance.featureDirector.getFeatureByClass(NoClip.class).isToggled() || this.y();
        EventUpdateLiving event = new EventUpdateLiving();
        event.call();
        if (event.isCancelled()) {
            return;
        }
        if (this.y()) {
            this.z = false;
        }
        if (this.bD > 0) {
            --this.bD;
        }
        if (this.cz()) {
            ++this.c;
            if (this.c > 100) {
                this.c = 100;
            }
            if (!this.l.G) {
                if (!this.s()) {
                    this.a(true, true, false);
                } else if (this.l.D()) {
                    this.a(false, true, true);
                }
            }
        } else if (this.c > 0) {
            ++this.c;
            if (this.c >= 110) {
                this.c = 0;
            }
        }
        super.B_();
        if (!this.l.G && this.by != null && !this.by.a(this)) {
            this.p();
            this.by = this.bx;
        }
        if (this.aR() && this.bO.a) {
            this.ab();
        }
        this.r();
        if (!this.l.G) {
            this.bz.a(this);
            this.b(qq.g);
            if (this.aC()) {
                this.b(qq.h);
            }
            if (this.aU()) {
                this.b(qq.i);
            }
        }
        int i2 = 29999999;
        double d0 = ri.a(this.p, -2.9999999E7, 2.9999999E7);
        double d1 = ri.a(this.r, -2.9999999E7, 2.9999999E7);
        if (d0 != this.p || d1 != this.r) {
            this.b(d0, this.q, d1);
        }
        ++this.aE;
        ain itemstack = this.co();
        if (!ain.b(this.bV, itemstack)) {
            if (!ain.d(this.bV, itemstack)) {
                this.ds();
            }
            this.bV = itemstack.b() ? ain.a : itemstack.l();
        }
        this.bW.a();
        this.cT();
    }

    private void r() {
        this.bE = this.bH;
        this.bF = this.bI;
        this.bG = this.bJ;
        double d0 = this.p - this.bH;
        double d1 = this.q - this.bI;
        double d2 = this.r - this.bJ;
        double d3 = 10.0;
        if (d0 > 10.0) {
            this.bE = this.bH = this.p;
        }
        if (d2 > 10.0) {
            this.bG = this.bJ = this.r;
        }
        if (d1 > 10.0) {
            this.bF = this.bI = this.q;
        }
        if (d0 < -10.0) {
            this.bE = this.bH = this.p;
        }
        if (d2 < -10.0) {
            this.bG = this.bJ = this.r;
        }
        if (d1 < -10.0) {
            this.bF = this.bI = this.q;
        }
        this.bH += d0 * 0.25;
        this.bJ += d2 * 0.25;
        this.bI += d1 * 0.25;
    }

    protected void cT() {
        float f1;
        float f2;
        if (this.cP()) {
            f2 = 0.6f;
            f1 = 0.6f;
        } else if (this.cz()) {
            f2 = 0.2f;
            f1 = 0.2f;
        } else if (this.aU()) {
            f2 = 0.6f;
            f1 = 1.65f;
        } else {
            f2 = 0.6f;
            f1 = 1.8f;
        }
        if (f2 != this.G || f1 != this.H) {
            bgz axisalignedbb = this.bw();
            axisalignedbb = new bgz(axisalignedbb.a, axisalignedbb.b, axisalignedbb.c, axisalignedbb.a + (double)f2, axisalignedbb.b + (double)f1, axisalignedbb.c + (double)f2);
            if (!this.l.a(axisalignedbb)) {
                this.a(f2, f1);
            }
        }
    }

    @Override
    public int Z() {
        return this.bO.a ? 1 : 80;
    }

    @Override
    protected qc ae() {
        return qd.fL;
    }

    @Override
    protected qc af() {
        return qd.fK;
    }

    @Override
    public int aM() {
        return 10;
    }

    @Override
    public void a(qc soundIn, float volume, float pitch) {
        this.l.a(this, this.p, this.q, this.r, soundIn, this.bK(), volume, pitch);
    }

    @Override
    public qe bK() {
        return qe.h;
    }

    @Override
    protected int bL() {
        return 20;
    }

    @Override
    public void a(byte id2) {
        if (id2 == 9) {
            this.v();
        } else if (id2 == 23) {
            this.h = false;
        } else if (id2 == 22) {
            this.h = true;
        } else {
            super.a(id2);
        }
    }

    @Override
    protected boolean cs() {
        return this.cd() <= 0.0f || this.cz();
    }

    protected void p() {
        this.by = this.bx;
    }

    @Override
    public void aE() {
        if (!this.l.G && this.aU() && this.aS()) {
            this.o();
            this.e(false);
        } else {
            double d0 = this.p;
            double d1 = this.q;
            double d2 = this.r;
            float f2 = this.v;
            float f1 = this.w;
            super.aE();
            this.bB = this.bC;
            this.bC = 0.0f;
            this.l(this.p - d0, this.q - d1, this.r - d2);
            if (this.bJ() instanceof aab) {
                this.w = f1;
                this.v = f2;
                this.aN = ((aab)this.bJ()).aN;
            }
        }
    }

    @Override
    public void W() {
        this.a(0.6f, 1.8f);
        super.W();
        this.c(this.cj());
        this.aB = 0;
    }

    @Override
    protected void cA() {
        super.cA();
        this.cl();
        this.rotationPitchHead = this.w;
        this.aP = this.v;
    }

    @Override
    public void n() {
        if (this.bA > 0) {
            --this.bA;
        }
        if (this.l.ag() == tx.a && this.l.W().b("naturalRegeneration")) {
            if (this.cd() < this.cj() && this.T % 20 == 0) {
                this.b(1.0f);
            }
            if (this.bz.c() && this.T % 10 == 0) {
                this.bz.a(this.bz.a() + 1);
            }
        }
        this.bv.n();
        this.bB = this.bC;
        super.n();
        wb iattributeinstance = this.a(adf.d);
        if (!this.l.G) {
            iattributeinstance.a(this.bO.b());
        }
        this.aR = this.bT;
        if (this.aV()) {
            this.aR = (float)((double)this.aR + (double)this.bT * 0.3);
        }
        this.k((float)iattributeinstance.e());
        float f2 = ri.a(this.s * this.s + this.u * this.u);
        float f1 = (float)(Math.atan(-this.t * (double)0.2f) * 15.0);
        if (f2 > 0.1f) {
            f2 = 0.1f;
        }
        if (!this.z || this.cd() <= 0.0f) {
            f2 = 0.0f;
        }
        if (this.z || this.cd() <= 0.0f) {
            f1 = 0.0f;
        }
        this.bC += (f2 - this.bC) * 0.4f;
        this.aK += (f1 - this.aK) * 0.8f;
        if (this.cd() > 0.0f && !this.y()) {
            bgz axisalignedbb = this.aS() && !this.bJ().F ? this.bw().b(this.bJ().bw()).c(1.0, 0.0, 1.0) : this.bw().c(1.0, 0.5, 1.0);
            List<ve> list = this.l.b((ve)this, axisalignedbb);
            for (int i2 = 0; i2 < list.size(); ++i2) {
                ve entity = list.get(i2);
                if (entity.F) continue;
                this.c(entity);
            }
        }
        this.j(this.dp());
        this.j(this.dq());
        if (!this.l.G && (this.L > 0.5f || this.ao() || this.aS()) || this.bO.b) {
            this.dm();
        }
    }

    private void j(@Nullable fy p_192028_1_) {
        String s2;
        if ((p_192028_1_ != null && !p_192028_1_.e("Silent") || !p_192028_1_.q("Silent")) && (s2 = p_192028_1_.l("id")).equals(vg.a(aaa.class).toString())) {
            aaa.a(this.l, this);
        }
    }

    private void c(ve entityIn) {
        entityIn.d(this);
    }

    public int cU() {
        return this.Y.a(b);
    }

    public void c(int scoreIn) {
        this.Y.b(b, scoreIn);
    }

    public void g(int scoreIn) {
        int i2 = this.cU();
        this.Y.b(b, i2 + scoreIn);
    }

    @Override
    public void a(up cause) {
        super.a(cause);
        this.a(0.2f, 0.2f);
        this.b(this.p, this.q, this.r);
        this.t = 0.1f;
        if ("Notch".equals(this.h_())) {
            this.a(new ain(aip.f, 1), true, false);
        }
        if (!this.l.W().b("keepInventory") && !this.y()) {
            this.cV();
            this.bv.o();
        }
        if (cause != null) {
            this.s = -ri.b((this.aA + this.v) * ((float)Math.PI / 180)) * 0.1f;
            this.u = -ri.a((this.aA + this.v) * ((float)Math.PI / 180)) * 0.1f;
        } else {
            this.s = 0.0;
            this.u = 0.0;
        }
        this.b(qq.A);
        this.a(qq.h);
        this.ab();
        this.b(0, false);
    }

    protected void cV() {
        for (int i2 = 0; i2 < this.bv.w_(); ++i2) {
            ain itemstack = this.bv.a(i2);
            if (itemstack.isEmpty() || !alk.e(itemstack)) continue;
            this.bv.c_(i2);
        }
    }

    @Override
    protected qc d(up p_184601_1_) {
        if (p_184601_1_ == up.c) {
            return qd.fH;
        }
        return p_184601_1_ == up.h ? qd.fG : qd.fF;
    }

    @Override
    protected qc cf() {
        return qd.fE;
    }

    @Nullable
    public acj a(boolean dropAll) {
        return this.a(this.bv.a(this.bv.d, dropAll && !this.bv.i().isEmpty() ? this.bv.i().getCount() : 1), false, true);
    }

    @Nullable
    public acj a(ain itemStackIn, boolean unused) {
        return this.a(itemStackIn, false, unused);
    }

    @Nullable
    public acj a(ain droppedItem, boolean dropAround, boolean traceItem) {
        if (droppedItem.isEmpty()) {
            return null;
        }
        double d0 = this.q - (double)0.3f + (double)this.by();
        acj entityitem = new acj(this.l, this.p, d0, this.r, droppedItem);
        entityitem.a(40);
        if (traceItem) {
            entityitem.e(this.h_());
        }
        if (dropAround) {
            float f2 = this.S.nextFloat() * 0.5f;
            float f1 = this.S.nextFloat() * ((float)Math.PI * 2);
            entityitem.s = -ri.a(f1) * f2;
            entityitem.u = ri.b(f1) * f2;
            entityitem.t = 0.2f;
        } else {
            float f2 = 0.3f;
            entityitem.s = -ri.a(this.v * ((float)Math.PI / 180)) * ri.b(this.w * ((float)Math.PI / 180)) * f2;
            entityitem.u = ri.b(this.v * ((float)Math.PI / 180)) * ri.b(this.w * ((float)Math.PI / 180)) * f2;
            entityitem.t = -ri.a(this.w * ((float)Math.PI / 180)) * f2 + 0.1f;
            float f3 = this.S.nextFloat() * ((float)Math.PI * 2);
            f2 = 0.02f * this.S.nextFloat();
            entityitem.s += Math.cos(f3) * (double)f2;
            entityitem.t += (double)((this.S.nextFloat() - this.S.nextFloat()) * 0.1f);
            entityitem.u += Math.sin(f3) * (double)f2;
        }
        ain itemstack = this.a(entityitem);
        if (traceItem) {
            if (!itemstack.isEmpty()) {
                this.a(qq.e(itemstack.c()), droppedItem.getCount());
            }
            this.b(qq.x);
        }
        return entityitem;
    }

    protected ain a(acj p_184816_1_) {
        this.l.a(p_184816_1_);
        return p_184816_1_.k();
    }

    public float b(awr state) {
        float f2 = this.bv.a(state);
        if (f2 > 1.0f) {
            int i2 = alk.f(this);
            ain itemstack = this.co();
            if (i2 > 0 && !itemstack.isEmpty()) {
                f2 += (float)(i2 * i2 + 1);
            }
        }
        if (this.a(uz.c)) {
            f2 *= 1.0f + (float)(this.b(uz.c).c() + 1) * 0.2f;
        }
        if (this.a(uz.d)) {
            float f1;
            switch (this.b(uz.d).c()) {
                case 0: {
                    f1 = 0.3f;
                    break;
                }
                case 1: {
                    f1 = 0.09f;
                    break;
                }
                case 2: {
                    f1 = 0.0027f;
                    break;
                }
                default: {
                    f1 = 8.1E-4f;
                }
            }
            f2 *= f1;
        }
        if (this.a(bcx.h) && !alk.h(this)) {
            f2 /= 5.0f;
        }
        if (!this.z) {
            f2 /= 5.0f;
        }
        return f2;
    }

    public boolean c(awr state) {
        return this.bv.b(state);
    }

    public static void c(rw fixer) {
        fixer.a(ru.b, new ry(){

            @Override
            public fy a(rv fixer, fy compound, int versionIn) {
                rx.b(fixer, compound, versionIn, "Inventory");
                rx.b(fixer, compound, versionIn, "EnderItems");
                if (compound.b("ShoulderEntityLeft", 10)) {
                    compound.a("ShoulderEntityLeft", fixer.a(ru.e, compound.p("ShoulderEntityLeft"), versionIn));
                }
                if (compound.b("ShoulderEntityRight", 10)) {
                    compound.a("ShoulderEntityRight", fixer.a(ru.e, compound.p("ShoulderEntityRight"), versionIn));
                }
                return compound;
            }
        });
    }

    @Override
    public void a(fy compound) {
        super.a(compound);
        this.a(aeb.a(this.g));
        ge nbttaglist = compound.c("Inventory", 10);
        this.bv.b(nbttaglist);
        this.bv.d = compound.h("SelectedItemSlot");
        this.bK = compound.q("Sleeping");
        this.c = compound.g("SleepTimer");
        this.bR = compound.j("XpP");
        this.bP = compound.h("XpLevel");
        this.bQ = compound.h("XpTotal");
        this.bS = compound.h("XpSeed");
        if (this.bS == 0) {
            this.bS = this.S.nextInt();
        }
        this.c(compound.h("Score"));
        if (this.bK) {
            this.bL = new et(this);
            this.a(true, true, false);
        }
        if (compound.b("SpawnX", 99) && compound.b("SpawnY", 99) && compound.b("SpawnZ", 99)) {
            this.d = new et(compound.h("SpawnX"), compound.h("SpawnY"), compound.h("SpawnZ"));
            this.e = compound.q("SpawnForced");
        }
        this.bz.a(compound);
        this.bO.b(compound);
        if (compound.b("EnderItems", 9)) {
            ge nbttaglist1 = compound.c("EnderItems", 10);
            this.bw.a(nbttaglist1);
        }
        if (compound.b("ShoulderEntityLeft", 10)) {
            this.h(compound.p("ShoulderEntityLeft"));
        }
        if (compound.b("ShoulderEntityRight", 10)) {
            this.i(compound.p("ShoulderEntityRight"));
        }
    }

    @Override
    public void b(fy compound) {
        super.b(compound);
        compound.a("DataVersion", 1343);
        compound.a("Inventory", this.bv.a(new ge()));
        compound.a("SelectedItemSlot", this.bv.d);
        compound.a("Sleeping", this.bK);
        compound.a("SleepTimer", (short)this.c);
        compound.a("XpP", this.bR);
        compound.a("XpLevel", this.bP);
        compound.a("XpTotal", this.bQ);
        compound.a("XpSeed", this.bS);
        compound.a("Score", this.cU());
        if (this.d != null) {
            compound.a("SpawnX", this.d.p());
            compound.a("SpawnY", this.d.q());
            compound.a("SpawnZ", this.d.r());
            compound.a("SpawnForced", this.e);
        }
        this.bz.b(compound);
        this.bO.a(compound);
        compound.a("EnderItems", this.bw.i());
        if (!this.dp().b_()) {
            compound.a("ShoulderEntityLeft", this.dp());
        }
        if (!this.dq().b_()) {
            compound.a("ShoulderEntityRight", this.dq());
        }
    }

    @Override
    public boolean a(up source, float amount) {
        if (this.b(source)) {
            return false;
        }
        if (this.bO.a && !source.g()) {
            return false;
        }
        this.aV = 0;
        if (this.cd() <= 0.0f) {
            return false;
        }
        if (this.cz() && !this.l.G) {
            this.a(true, true, false);
        }
        this.dm();
        if (source.r()) {
            if (this.l.ag() == tx.a) {
                amount = 0.0f;
            }
            if (this.l.ag() == tx.b) {
                amount = Math.min(amount / 2.0f + 1.0f, amount);
            }
            if (this.l.ag() == tx.d) {
                amount = amount * 3.0f / 2.0f;
            }
        }
        return amount == 0.0f ? false : super.a(source, amount);
    }

    @Override
    protected void c(vn p_190629_1_) {
        super.c(p_190629_1_);
        if (p_190629_1_.co().c() instanceof agw) {
            this.m(true);
        }
    }

    public boolean a(aeb other) {
        bhk team = this.aY();
        bhk team1 = other.aY();
        if (team == null) {
            return true;
        }
        return !team.a(team1) ? true : team.g();
    }

    @Override
    protected void i(float damage) {
        this.bv.a(damage);
    }

    @Override
    protected void j(float damage) {
        if (damage >= 3.0f && this.bo.c() == aip.cR) {
            int i2 = 1 + ri.d(damage);
            this.bo.a(i2, (vn)this);
            if (this.bo.isEmpty()) {
                tz enumhand = this.cH();
                if (enumhand == tz.a) {
                    this.a(vj.a, ain.a);
                } else {
                    this.a(vj.b, ain.a);
                }
                this.bo = ain.a;
                this.a(qd.gy, 0.8f, 0.8f + this.l.r.nextFloat() * 0.4f);
            }
        }
    }

    public float cW() {
        int i2 = 0;
        for (ain itemstack : this.bv.b) {
            if (itemstack.isEmpty()) continue;
            ++i2;
        }
        return (float)i2 / (float)this.bv.b.size();
    }

    @Override
    protected void d(up damageSrc, float damageAmount) {
        if (!this.b(damageSrc)) {
            damageAmount = this.b(damageSrc, damageAmount);
            float f2 = damageAmount = this.c(damageSrc, damageAmount);
            damageAmount = Math.max(damageAmount - this.cD(), 0.0f);
            this.m(this.cD() - (f2 - damageAmount));
            if (damageAmount != 0.0f) {
                this.a(damageSrc.f());
                float f1 = this.cd();
                this.c(this.cd() - damageAmount);
                this.ch().a(damageSrc, f1, damageAmount);
                if (damageAmount < 3.4028235E37f) {
                    this.a(qq.z, Math.round(damageAmount * 10.0f));
                }
            }
        }
    }

    public void a(awa signTile) {
    }

    public void a(amh commandBlock) {
    }

    public void a(avk commandBlock) {
    }

    public void a(awc structure) {
    }

    public void a(amd villager) {
    }

    public void a(tt chestInventory) {
    }

    public void a(aam horse, tt inventoryIn) {
    }

    public void a(ua guiOwner) {
    }

    public void a(ain stack, tz hand) {
    }

    public ub a(ve p_190775_1_, tz p_190775_2_) {
        ain itemstack1;
        if (this.y()) {
            if (p_190775_1_ instanceof tt) {
                this.a((tt)((Object)p_190775_1_));
            }
            return ub.b;
        }
        ain itemstack = this.b(p_190775_2_);
        ain ain2 = itemstack1 = itemstack.isEmpty() ? ain.a : itemstack.l();
        if (p_190775_1_.b(this, p_190775_2_)) {
            if (this.bO.d && itemstack == this.b(p_190775_2_) && itemstack.getCount() < itemstack1.getCount()) {
                itemstack.e(itemstack1.getCount());
            }
            return ub.a;
        }
        if (!itemstack.isEmpty() && p_190775_1_ instanceof vn) {
            if (this.bO.d) {
                itemstack = itemstack1;
            }
            if (itemstack.a(this, (vn)p_190775_1_, p_190775_2_)) {
                if (itemstack.isEmpty() && !this.bO.d) {
                    this.a(p_190775_2_, ain.a);
                }
                return ub.a;
            }
        }
        return ub.b;
    }

    @Override
    public double aF() {
        return -0.35;
    }

    @Override
    public void o() {
        super.o();
        this.j = 0;
    }

    public void f(ve targetEntity) {
        if (targetEntity.bd() && !targetEntity.t(this)) {
            float f2 = (float)this.a(adf.f).e();
            float f1 = targetEntity instanceof vn ? alk.a(this.co(), ((vn)targetEntity).cn()) : alk.a(this.co(), vs.a);
            float f22 = this.n(0.5f);
            f1 *= f22;
            this.ds();
            if ((f2 *= 0.2f + f22 * f22 * 0.8f) > 0.0f || f1 > 0.0f) {
                ain itemstack;
                boolean flag = f22 > 0.9f;
                boolean flag1 = false;
                int i2 = 0;
                i2 += alk.b(this);
                if (this.aV() && flag) {
                    this.l.a((aeb)null, this.p, this.q, this.r, qd.fw, this.bK(), 1.0f, 1.0f);
                    ++i2;
                    flag1 = true;
                }
                boolean flag2 = flag && this.L > 0.0f && !this.z && !this.m_() && !this.ao() && !this.a(uz.o) && !this.aS() && targetEntity instanceof vn;
                boolean bl2 = flag2 = flag2 && !this.aV();
                if (flag2) {
                    f2 *= 1.5f;
                }
                f2 += f1;
                boolean flag3 = false;
                double d0 = this.J - this.I;
                if (flag && !flag2 && !flag1 && this.z && d0 < (double)this.cy() && (itemstack = this.b(tz.a)).c() instanceof ajw) {
                    flag3 = true;
                }
                float f4 = 0.0f;
                boolean flag4 = false;
                int j2 = alk.c(this);
                if (targetEntity instanceof vn) {
                    f4 = ((vn)targetEntity).cd();
                    if (j2 > 0 && !targetEntity.aR()) {
                        flag4 = true;
                        targetEntity.i(1);
                    }
                }
                double d1 = targetEntity.s;
                double d2 = targetEntity.t;
                double d3 = targetEntity.u;
                boolean flag5 = targetEntity.a(up.a(this), f2);
                if (flag5) {
                    aay ientitymultipart;
                    if (i2 > 0) {
                        if (targetEntity instanceof vn) {
                            ((vn)targetEntity).a(this, (float)i2 * 0.5f, (double)ri.a(this.v * ((float)Math.PI / 180)), (double)(-ri.b(this.v * ((float)Math.PI / 180))));
                        } else {
                            targetEntity.f(-ri.a(this.v * ((float)Math.PI / 180)) * (float)i2 * 0.5f, 0.1, ri.b(this.v * ((float)Math.PI / 180)) * (float)i2 * 0.5f);
                        }
                        this.s *= 0.6;
                        this.u *= 0.6;
                        this.f(false);
                    }
                    if (flag3) {
                        float f3 = 1.0f + alk.a(this) * f2;
                        for (vn entitylivingbase : this.l.a(vn.class, targetEntity.bw().c(1.0, 0.25, 1.0))) {
                            if (entitylivingbase == this || entitylivingbase == targetEntity || this.r(entitylivingbase) || !(this.h(entitylivingbase) < 9.0)) continue;
                            entitylivingbase.a(this, 0.4f, (double)ri.a(this.v * ((float)Math.PI / 180)), (double)(-ri.b(this.v * ((float)Math.PI / 180))));
                            entitylivingbase.a(up.a(this), f3);
                        }
                        this.l.a((aeb)null, this.p, this.q, this.r, qd.fz, this.bK(), 1.0f, 1.0f);
                        this.cX();
                    }
                    if (targetEntity instanceof oo && targetEntity.D) {
                        ((oo)targetEntity).a.a(new ke(targetEntity));
                        targetEntity.D = false;
                        targetEntity.s = d1;
                        targetEntity.t = d2;
                        targetEntity.u = d3;
                    }
                    if (flag2) {
                        this.l.a((aeb)null, this.p, this.q, this.r, qd.fv, this.bK(), 1.0f, 1.0f);
                        this.a(targetEntity);
                    }
                    if (!flag2 && !flag3) {
                        if (flag) {
                            this.l.a((aeb)null, this.p, this.q, this.r, qd.fy, this.bK(), 1.0f, 1.0f);
                        } else {
                            this.l.a((aeb)null, this.p, this.q, this.r, qd.fA, this.bK(), 1.0f, 1.0f);
                        }
                    }
                    if (f1 > 0.0f) {
                        this.b(targetEntity);
                    }
                    this.z(targetEntity);
                    if (targetEntity instanceof vn) {
                        alk.a((vn)targetEntity, (ve)this);
                    }
                    alk.b(this, targetEntity);
                    ain itemstack1 = this.co();
                    ve entity = targetEntity;
                    if (targetEntity instanceof aaz && (ientitymultipart = ((aaz)targetEntity).a) instanceof vn) {
                        entity = (vn)((Object)ientitymultipart);
                    }
                    if (!itemstack1.b() && entity instanceof vn) {
                        itemstack1.a((vn)entity, this);
                        if (itemstack1.b()) {
                            this.a(tz.a, ain.a);
                        }
                    }
                    if (targetEntity instanceof vn) {
                        float f5 = f4 - ((vn)targetEntity).cd();
                        this.a(qq.y, Math.round(f5 * 10.0f));
                        if (j2 > 0) {
                            targetEntity.i(j2 * 4);
                        }
                        if (this.l instanceof om && f5 > 2.0f) {
                            int k2 = (int)((double)f5 * 0.5);
                            ((om)this.l).a(fj.S, targetEntity.p, targetEntity.q + (double)(targetEntity.H * 0.5f), targetEntity.r, k2, 0.1, 0.0, 0.1, 0.2, new int[0]);
                        }
                    }
                    this.a(0.1f);
                } else {
                    this.l.a((aeb)null, this.p, this.q, this.r, qd.fx, this.bK(), 1.0f, 1.0f);
                    if (flag4) {
                        targetEntity.ab();
                    }
                }
            }
        }
    }

    public void m(boolean p_190777_1_) {
        float f2 = 0.25f + (float)alk.f(this) * 0.05f;
        if (p_190777_1_) {
            f2 += 0.75f;
        }
        if (this.S.nextFloat() < f2) {
            this.dt().a(aip.cR, 100);
            this.cN();
            this.l.a((ve)this, (byte)30);
        }
    }

    public void a(ve entityHit) {
    }

    public void b(ve entityHit) {
    }

    public void cX() {
        double d0 = -ri.a(this.v * ((float)Math.PI / 180));
        double d1 = ri.b(this.v * ((float)Math.PI / 180));
        if (this.l instanceof om) {
            ((om)this.l).a(fj.T, this.p + d0, this.q + (double)this.H * 0.5, this.r + d1, 0, d0, 0.0, d1, 0.0, new int[0]);
        }
    }

    public void cY() {
    }

    @Override
    public void X() {
        super.X();
        this.bx.b(this);
        if (this.by != null) {
            this.by.b(this);
        }
    }

    @Override
    public boolean aD() {
        return !this.bK && super.aD();
    }

    public boolean cZ() {
        return false;
    }

    public GameProfile da() {
        return this.g;
    }

    public a a(et bedLocation) {
        fa enumfacing = this.l.o(bedLocation).c(ark.D);
        if (!this.l.G) {
            if (this.cz() || !this.aC()) {
                return aeb$a.e;
            }
            if (!this.l.s.d()) {
                return aeb$a.b;
            }
            if (this.l.D()) {
                return aeb$a.c;
            }
            if (!this.a(bedLocation, enumfacing)) {
                return aeb$a.d;
            }
            double d0 = 8.0;
            double d1 = 5.0;
            c list = this.l.a(adc.class, new bgz((double)bedLocation.p() - 8.0, (double)bedLocation.q() - 5.0, (double)bedLocation.r() - 8.0, (double)bedLocation.p() + 8.0, (double)bedLocation.q() + 5.0, (double)bedLocation.r() + 8.0), new c(this));
            if (!list.isEmpty()) {
                return aeb$a.f;
            }
        }
        if (this.aS()) {
            this.o();
        }
        this.dm();
        this.a(0.2f, 0.2f);
        if (this.l.e(bedLocation)) {
            float f1 = 0.5f + (float)enumfacing.g() * 0.4f;
            float f2 = 0.5f + (float)enumfacing.i() * 0.4f;
            this.a(enumfacing);
            this.b((float)bedLocation.p() + f1, (float)bedLocation.q() + 0.6875f, (float)bedLocation.r() + f2);
        } else {
            this.b((float)bedLocation.p() + 0.5f, (float)bedLocation.q() + 0.6875f, (float)bedLocation.r() + 0.5f);
        }
        this.bK = true;
        this.c = 0;
        this.bL = bedLocation;
        this.s = 0.0;
        this.t = 0.0;
        this.u = 0.0;
        if (!this.l.G) {
            this.l.e();
        }
        return aeb$a.a;
    }

    private boolean a(et p_190774_1_, fa p_190774_2_) {
        if (Math.abs(this.p - (double)p_190774_1_.p()) <= 3.0 && Math.abs(this.q - (double)p_190774_1_.q()) <= 2.0 && Math.abs(this.r - (double)p_190774_1_.r()) <= 3.0) {
            return true;
        }
        et blockpos = p_190774_1_.a(p_190774_2_.d());
        return Math.abs(this.p - (double)blockpos.p()) <= 3.0 && Math.abs(this.q - (double)blockpos.q()) <= 2.0 && Math.abs(this.r - (double)blockpos.r()) <= 3.0;
    }

    private void a(fa p_175139_1_) {
        this.bM = -1.8f * (float)p_175139_1_.g();
        this.bN = -1.8f * (float)p_175139_1_.i();
    }

    public void a(boolean immediately, boolean updateWorldFlag, boolean setSpawn) {
        this.a(0.6f, 1.8f);
        awr iblockstate = this.l.o(this.bL);
        if (this.bL != null && iblockstate.u() == aov.C) {
            this.l.a(this.bL, iblockstate.a(aos.b, false), 4);
            et blockpos = aos.a(this.l, this.bL, 0);
            if (blockpos == null) {
                blockpos = this.bL.a();
            }
            this.b((float)blockpos.p() + 0.5f, (float)blockpos.q() + 0.1f, (float)blockpos.r() + 0.5f);
        }
        this.bK = false;
        if (!this.l.G && updateWorldFlag) {
            this.l.e();
        }
        int n2 = this.c = immediately ? 0 : 100;
        if (setSpawn) {
            this.b(this.bL, false);
        }
    }

    private boolean s() {
        return this.l.o(this.bL).u() == aov.C;
    }

    @Nullable
    public static et a(ams worldIn, et bedLocation, boolean forceSpawn) {
        aou block = worldIn.o(bedLocation).u();
        if (block != aov.C) {
            if (!forceSpawn) {
                return null;
            }
            boolean flag = block.d();
            boolean flag1 = worldIn.o(bedLocation.a()).u().d();
            return flag && flag1 ? bedLocation : null;
        }
        return aos.a(worldIn, bedLocation, 0);
    }

    public float db() {
        if (this.bL != null) {
            fa enumfacing = this.l.o(this.bL).c(ark.D);
            switch (enumfacing) {
                case d: {
                    return 90.0f;
                }
                case e: {
                    return 0.0f;
                }
                case c: {
                    return 270.0f;
                }
                case f: {
                    return 180.0f;
                }
            }
        }
        return 0.0f;
    }

    @Override
    public boolean cz() {
        return this.bK;
    }

    public boolean dc() {
        return this.bK && this.c >= 100;
    }

    public int dd() {
        return this.c;
    }

    public void a(hh chatComponent, boolean p_146105_2_) {
    }

    public et de() {
        return this.d;
    }

    public boolean df() {
        return this.e;
    }

    public void b(et pos, boolean forced) {
        if (pos != null) {
            this.d = pos;
            this.e = forced;
        } else {
            this.d = null;
            this.e = false;
        }
    }

    public void b(qm stat) {
        this.a(stat, 1);
    }

    public void a(qm stat, int amount) {
    }

    public void a(qm stat) {
    }

    public void a(List<akr> p_192021_1_) {
    }

    public void a(nd[] p_193102_1_) {
    }

    public void b(List<akr> p_192022_1_) {
    }

    @Override
    public void cu() {
        super.cu();
        this.b(qq.w);
        if (this.aV()) {
            this.a(0.2f);
        } else {
            this.a(0.05f);
        }
    }

    @Override
    public void a(float p_191986_1_, float p_191986_2_, float p_191986_3_) {
        double d0 = this.p;
        double d1 = this.q;
        double d2 = this.r;
        if (this.bO.b && !this.aS()) {
            double d3 = this.t;
            float f2 = this.aR;
            this.aR = this.bO.a() * (float)(this.aV() ? 2 : 1);
            super.a(p_191986_1_, p_191986_2_, p_191986_3_);
            this.t = d3 * 0.6;
            this.aR = f2;
            this.L = 0.0f;
            this.b(7, false);
        } else {
            super.a(p_191986_1_, p_191986_2_, p_191986_3_);
        }
        this.k(this.p - d0, this.q - d1, this.r - d2);
    }

    @Override
    public float cy() {
        return (float)this.a(adf.d).e();
    }

    public void k(double p_71000_1_, double p_71000_3_, double p_71000_5_) {
        if (!this.aS()) {
            if (this.a(bcx.h)) {
                int i2 = Math.round(ri.a(p_71000_1_ * p_71000_1_ + p_71000_3_ * p_71000_3_ + p_71000_5_ * p_71000_5_) * 100.0f);
                if (i2 > 0) {
                    this.a(qq.q, i2);
                    this.a(0.01f * (float)i2 * 0.01f);
                }
            } else if (this.ao()) {
                int j2 = Math.round(ri.a(p_71000_1_ * p_71000_1_ + p_71000_5_ * p_71000_5_) * 100.0f);
                if (j2 > 0) {
                    this.a(qq.m, j2);
                    this.a(0.01f * (float)j2 * 0.01f);
                }
            } else if (this.m_()) {
                if (p_71000_3_ > 0.0) {
                    this.a(qq.o, (int)Math.round(p_71000_3_ * 100.0));
                }
            } else if (this.z) {
                int k2 = Math.round(ri.a(p_71000_1_ * p_71000_1_ + p_71000_5_ * p_71000_5_) * 100.0f);
                if (k2 > 0) {
                    if (this.aV()) {
                        this.a(qq.l, k2);
                        this.a(0.1f * (float)k2 * 0.01f);
                    } else if (this.aU()) {
                        this.a(qq.k, k2);
                        this.a(0.0f * (float)k2 * 0.01f);
                    } else {
                        this.a(qq.j, k2);
                        this.a(0.0f * (float)k2 * 0.01f);
                    }
                }
            } else if (this.cP()) {
                int l2 = Math.round(ri.a(p_71000_1_ * p_71000_1_ + p_71000_3_ * p_71000_3_ + p_71000_5_ * p_71000_5_) * 100.0f);
                this.a(qq.v, l2);
            } else {
                int i1 = Math.round(ri.a(p_71000_1_ * p_71000_1_ + p_71000_5_ * p_71000_5_) * 100.0f);
                if (i1 > 25) {
                    this.a(qq.p, i1);
                }
            }
        }
    }

    private void l(double p_71015_1_, double p_71015_3_, double p_71015_5_) {
        int i2;
        if (this.aS() && (i2 = Math.round(ri.a(p_71015_1_ * p_71015_1_ + p_71015_3_ * p_71015_3_ + p_71015_5_ * p_71015_5_) * 100.0f)) > 0) {
            if (this.bJ() instanceof afc) {
                this.a(qq.r, i2);
            } else if (this.bJ() instanceof afb) {
                this.a(qq.s, i2);
            } else if (this.bJ() instanceof aab) {
                this.a(qq.t, i2);
            } else if (this.bJ() instanceof aam) {
                this.a(qq.u, i2);
            }
        }
    }

    @Override
    public void e(float distance, float damageMultiplier) {
        if (!this.bO.c) {
            if (distance >= 2.0f) {
                this.a(qq.n, (int)Math.round((double)distance * 100.0));
            }
            super.e(distance, damageMultiplier);
        }
    }

    @Override
    protected void ar() {
        if (!this.y()) {
            super.ar();
        }
    }

    @Override
    protected qc e(int heightIn) {
        return heightIn > 4 ? qd.fB : qd.fJ;
    }

    @Override
    public void b(vn entityLivingIn) {
        vg.a entitylist$entityegginfo = vg.c.get(vg.a(entityLivingIn));
        if (entitylist$entityegginfo != null) {
            this.b(entitylist$entityegginfo.d);
        }
    }

    @Override
    public void ba() {
        if (!this.bO.b) {
            super.ba();
        }
    }

    public void m(int amount) {
        this.g(amount);
        int i2 = Integer.MAX_VALUE - this.bQ;
        if (amount > i2) {
            amount = i2;
        }
        this.bR += (float)amount / (float)this.dh();
        this.bQ += amount;
        while (this.bR >= 1.0f) {
            this.bR = (this.bR - 1.0f) * (float)this.dh();
            this.a(1);
            this.bR /= (float)this.dh();
        }
    }

    public int dg() {
        return this.bS;
    }

    public void a(ain p_192024_1_, int p_192024_2_) {
        this.bP -= p_192024_2_;
        if (this.bP < 0) {
            this.bP = 0;
            this.bR = 0.0f;
            this.bQ = 0;
        }
        this.bS = this.S.nextInt();
    }

    public void a(int levels) {
        this.bP += levels;
        if (this.bP < 0) {
            this.bP = 0;
            this.bR = 0.0f;
            this.bQ = 0;
        }
        if (levels > 0 && this.bP % 5 == 0 && (float)this.f < (float)this.T - 100.0f) {
            float f2 = this.bP > 30 ? 1.0f : (float)this.bP / 30.0f;
            this.l.a((aeb)null, this.p, this.q, this.r, qd.fI, this.bK(), f2 * 0.75f, 1.0f);
            this.f = this.T;
        }
    }

    public int dh() {
        if (this.bP >= 30) {
            return 112 + (this.bP - 30) * 9;
        }
        return this.bP >= 15 ? 37 + (this.bP - 15) * 5 : 7 + this.bP * 2;
    }

    public void a(float exhaustion) {
        if (!this.bO.a && !this.l.G) {
            this.bz.a(exhaustion);
        }
    }

    public afn di() {
        return this.bz;
    }

    public boolean n(boolean ignoreHunger) {
        return (ignoreHunger || this.bz.c()) && !this.bO.a;
    }

    public boolean dj() {
        return this.cd() > 0.0f && this.cd() < this.cj();
    }

    public boolean dk() {
        return this.bO.e;
    }

    public boolean a(et pos, fa facing, ain stack) {
        if (this.bO.e) {
            return true;
        }
        if (stack.isEmpty()) {
            return false;
        }
        et blockpos = pos.a(facing.d());
        aou block = this.l.o(blockpos).u();
        return stack.b(block) || stack.y();
    }

    @Override
    protected int b(aeb player) {
        if (!this.l.W().b("keepInventory") && !this.y()) {
            int i2 = this.bP * 7;
            return i2 > 100 ? 100 : i2;
        }
        return 0;
    }

    @Override
    protected boolean bQ() {
        return true;
    }

    @Override
    public boolean bs() {
        return true;
    }

    @Override
    protected boolean ak() {
        return !this.bO.b;
    }

    public void w() {
    }

    public void a(amq gameType) {
    }

    @Override
    public String h_() {
        return this.g.getName();
    }

    public agk dl() {
        return this.bw;
    }

    @Override
    public ain b(vj slotIn) {
        if (slotIn == vj.a) {
            return this.bv.i();
        }
        if (slotIn == vj.b) {
            return this.bv.c.get(0);
        }
        return slotIn.a() == vj.a.b ? this.bv.b.get(slotIn.b()) : ain.a;
    }

    @Override
    public void a(vj slotIn, ain stack) {
        if (slotIn == vj.a) {
            this.a_(stack);
            this.bv.a.set(this.bv.d, stack);
        } else if (slotIn == vj.b) {
            this.a_(stack);
            this.bv.c.set(0, stack);
        } else if (slotIn.a() == vj.a.b) {
            this.a_(stack);
            this.bv.b.set(slotIn.b(), stack);
        }
    }

    public boolean c(ain p_191521_1_) {
        this.a_(p_191521_1_);
        return this.bv.e(p_191521_1_);
    }

    @Override
    public Iterable<ain> aO() {
        return Lists.newArrayList((Object[])new ain[]{this.co(), this.cp()});
    }

    @Override
    public Iterable<ain> aP() {
        return this.bv.b;
    }

    public boolean g(fy p_192027_1_) {
        if (!this.aS() && this.z && !this.ao()) {
            if (this.dp().b_()) {
                this.h(p_192027_1_);
                return true;
            }
            if (this.dq().b_()) {
                this.i(p_192027_1_);
                return true;
            }
            return false;
        }
        return false;
    }

    protected void dm() {
        this.k(this.dp());
        this.h(new fy());
        this.k(this.dq());
        this.i(new fy());
    }

    private void k(@Nullable fy p_192026_1_) {
        if (!this.l.G && !p_192026_1_.b_()) {
            ve entity = vg.a(p_192026_1_, this.l);
            if (entity instanceof vz) {
                ((vz)entity).b(this.aq);
            }
            entity.b(this.p, this.q + (double)0.7f, this.r);
            this.l.a(entity);
        }
    }

    @Override
    public boolean e(aeb player) {
        if (!this.aX()) {
            return false;
        }
        if (player.y()) {
            return false;
        }
        bhk team = this.aY();
        return team == null || player == null || player.aY() != team || !team.h();
    }

    public abstract boolean y();

    public abstract boolean z();

    @Override
    public boolean bo() {
        if (Main.instance.featureDirector.getFeatureByClass(NoPush.class).isToggled() && NoPush.pushwater.getBoolValue()) {
            return false;
        }
        return !this.bO.b;
    }

    public bhi dn() {
        return this.l.af();
    }

    @Override
    public bhk aY() {
        return this.dn().g(this.h_());
    }

    @Override
    public hh i_() {
        ho itextcomponent = new ho(bhf.a(this.aY(), this.h_()));
        itextcomponent.b().a(new hg(hg.a.d, "/msg " + this.h_() + " "));
        itextcomponent.b().a(this.bv());
        itextcomponent.b().a(this.h_());
        return itextcomponent;
    }

    @Override
    public float by() {
        float f2 = 1.62f;
        if (this.cz()) {
            f2 = 0.2f;
        } else if (!this.aU() && this.H != 1.65f) {
            if (this.cP() || this.H == 0.6f) {
                f2 = 0.4f;
            }
        } else {
            f2 -= 0.08f;
        }
        return f2;
    }

    @Override
    public void m(float amount) {
        if (amount < 0.0f) {
            amount = 0.0f;
        }
        this.V().b(a, Float.valueOf(amount));
    }

    @Override
    public float cD() {
        return this.V().a(a).floatValue();
    }

    public static UUID a(GameProfile profile) {
        UUID uuid = profile.getId();
        if (uuid == null) {
            uuid = aeb.d(profile.getName());
        }
        return uuid;
    }

    public static UUID d(String username) {
        return UUID.nameUUIDFromBytes(("OfflinePlayer:" + username).getBytes(StandardCharsets.UTF_8));
    }

    public boolean a(ue code) {
        if (code.a()) {
            return true;
        }
        ain itemstack = this.co();
        return !itemstack.isEmpty() && itemstack.t() ? itemstack.r().equals(code.b()) : false;
    }

    public boolean a(aec part) {
        return (this.V().a(br) & part.a()) == part.a();
    }

    @Override
    public boolean g() {
        return this.C_().d[0].W().b("sendCommandFeedback");
    }

    @Override
    public boolean c(int inventorySlot, ain itemStackIn) {
        if (inventorySlot >= 0 && inventorySlot < this.bv.a.size()) {
            this.bv.a(inventorySlot, itemStackIn);
            return true;
        }
        vj entityequipmentslot = inventorySlot == 100 + vj.f.b() ? vj.f : (inventorySlot == 100 + vj.e.b() ? vj.e : (inventorySlot == 100 + vj.d.b() ? vj.d : (inventorySlot == 100 + vj.c.b() ? vj.c : null)));
        if (inventorySlot == 98) {
            this.a(vj.a, itemStackIn);
            return true;
        }
        if (inventorySlot == 99) {
            this.a(vj.b, itemStackIn);
            return true;
        }
        if (entityequipmentslot == null) {
            int i2 = inventorySlot - 200;
            if (i2 >= 0 && i2 < this.bw.w_()) {
                this.bw.a(i2, itemStackIn);
                return true;
            }
            return false;
        }
        if (!itemStackIn.isEmpty() && (!(itemStackIn.c() instanceof agt) && !(itemStackIn.c() instanceof ahu) ? entityequipmentslot != vj.f : vo.d(itemStackIn) != entityequipmentslot)) {
            return false;
        }
        this.bv.a(entityequipmentslot.b() + this.bv.a.size(), itemStackIn);
        return true;
    }

    public boolean do() {
        return this.h;
    }

    public void o(boolean reducedDebug) {
        this.h = reducedDebug;
    }

    @Override
    public vm cF() {
        return this.Y.a(bs) == 0 ? vm.a : vm.b;
    }

    public void a(vm hand) {
        this.Y.b(bs, (byte)(hand != vm.a ? 1 : 0));
    }

    public fy dp() {
        return this.Y.a(bt);
    }

    protected void h(fy p_192029_1_) {
        this.Y.b(bt, p_192029_1_);
    }

    public fy dq() {
        return this.Y.a(bu);
    }

    protected void i(fy p_192031_1_) {
        this.Y.b(bu, p_192031_1_);
    }

    public float dr() {
        return (float)(1.0 / this.a(adf.g).e() * 20.0);
    }

    public float n(float adjustTicks) {
        return ri.a(((float)this.aE + adjustTicks) / this.dr(), 0.0f, 1.0f);
    }

    public void ds() {
        this.aE = 0;
    }

    public aim dt() {
        return this.bW;
    }

    @Override
    public void i(ve entityIn) {
        if (!this.cz()) {
            super.i(entityIn);
        }
    }

    public float du() {
        return (float)this.a(adf.j).e();
    }

    public boolean dv() {
        return this.bO.d && this.a(2, "");
    }

    public ain getEquipmentInSlot(int item) {
        return item == 0 ? this.bv.i() : this.bv.b.get(item - 1);
    }

    public static enum a {
        a,
        b,
        c,
        d,
        e,
        f;

    }

    static class c
    implements Predicate<adc> {
        private final aeb a;

        private c(aeb p_i47461_1_) {
            this.a = p_i47461_1_;
        }

        public boolean a(@Nullable adc p_apply_1_) {
            return p_apply_1_.c(this.a);
        }
    }

    public static enum b {
        a(0, "options.chat.visibility.full"),
        b(1, "options.chat.visibility.system"),
        c(2, "options.chat.visibility.hidden");

        private static final b[] d;
        private final int e;
        private final String f;

        private b(int id2, String resourceKey) {
            this.e = id2;
            this.f = resourceKey;
        }

        public int a() {
            return this.e;
        }

        public static b a(int id2) {
            return d[id2 % d.length];
        }

        public String b() {
            return this.f;
        }

        static {
            d = new b[aeb$b.values().length];
            b[] arrb = aeb$b.values();
            int n2 = arrb.length;
            for (int i2 = 0; i2 < n2; ++i2) {
                b entityplayer$enumchatvisibility;
                aeb$b.d[entityplayer$enumchatvisibility.e] = entityplayer$enumchatvisibility = arrb[i2];
            }
        }
    }
}

