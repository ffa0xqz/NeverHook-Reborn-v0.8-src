/*
 * Decompiled with CFR 0.150.
 */
public class bpc
extends bpb {
    public brq a;
    public brq b;
    public brq c;
    public brq d;

    public bpc() {
        this(0.0f);
    }

    public bpc(float f2) {
        super(f2, 64, 64);
        this.e = new brq(this, 0, 0);
        this.e.a(-1.0f, -7.0f, -1.0f, 2, 7, 2, f2);
        this.e.a(0.0f, 0.0f, 0.0f);
        this.g = new brq(this, 0, 26);
        this.g.a(-6.0f, 0.0f, -1.5f, 12, 3, 3, f2);
        this.g.a(0.0f, 0.0f, 0.0f);
        this.h = new brq(this, 24, 0);
        this.h.a(-2.0f, -2.0f, -1.0f, 2, 12, 2, f2);
        this.h.a(-5.0f, 2.0f, 0.0f);
        this.i = new brq(this, 32, 16);
        this.i.i = true;
        this.i.a(0.0f, -2.0f, -1.0f, 2, 12, 2, f2);
        this.i.a(5.0f, 2.0f, 0.0f);
        this.j = new brq(this, 8, 0);
        this.j.a(-1.0f, 0.0f, -1.0f, 2, 11, 2, f2);
        this.j.a(-1.9f, 12.0f, 0.0f);
        this.k = new brq(this, 40, 16);
        this.k.i = true;
        this.k.a(-1.0f, 0.0f, -1.0f, 2, 11, 2, f2);
        this.k.a(1.9f, 12.0f, 0.0f);
        this.a = new brq(this, 16, 0);
        this.a.a(-3.0f, 3.0f, -1.0f, 2, 7, 2, f2);
        this.a.a(0.0f, 0.0f, 0.0f);
        this.a.j = true;
        this.b = new brq(this, 48, 16);
        this.b.a(1.0f, 3.0f, -1.0f, 2, 7, 2, f2);
        this.b.a(0.0f, 0.0f, 0.0f);
        this.c = new brq(this, 0, 48);
        this.c.a(-4.0f, 10.0f, -1.0f, 8, 2, 2, f2);
        this.c.a(0.0f, 0.0f, 0.0f);
        this.d = new brq(this, 0, 32);
        this.d.a(-6.0f, 11.0f, -6.0f, 12, 1, 12, f2);
        this.d.a(0.0f, 12.0f, 0.0f);
        this.f.j = false;
    }

    @Override
    public void a(float f2, float f3, float f4, float f5, float f6, float f7, ve ve2) {
        super.a(f2, f3, f4, f5, f6, f7, ve2);
        if (!(ve2 instanceof abx)) {
            return;
        }
        abx abx2 = (abx)ve2;
        this.i.j = abx2.r();
        this.h.j = abx2.r();
        this.d.j = !abx2.s();
        this.k.a(1.9f, 12.0f, 0.0f);
        this.j.a(-1.9f, 12.0f, 0.0f);
        this.a.f = (float)Math.PI / 180 * abx2.w().b();
        this.a.g = (float)Math.PI / 180 * abx2.w().c();
        this.a.h = (float)Math.PI / 180 * abx2.w().d();
        this.b.f = (float)Math.PI / 180 * abx2.w().b();
        this.b.g = (float)Math.PI / 180 * abx2.w().c();
        this.b.h = (float)Math.PI / 180 * abx2.w().d();
        this.c.f = (float)Math.PI / 180 * abx2.w().b();
        this.c.g = (float)Math.PI / 180 * abx2.w().c();
        this.c.h = (float)Math.PI / 180 * abx2.w().d();
        this.d.f = 0.0f;
        this.d.g = (float)Math.PI / 180 * -ve2.v;
        this.d.h = 0.0f;
    }

    @Override
    public void a(ve ve2, float f2, float f3, float f4, float f5, float f6, float f7) {
        super.a(ve2, f2, f3, f4, f5, f6, f7);
        buq.G();
        if (this.q) {
            \u2603 = 2.0f;
            buq.b(0.5f, 0.5f, 0.5f);
            buq.c(0.0f, 24.0f * f7, 0.0f);
            this.a.a(f7);
            this.b.a(f7);
            this.c.a(f7);
            this.d.a(f7);
        } else {
            if (ve2.aU()) {
                buq.c(0.0f, 0.2f, 0.0f);
            }
            this.a.a(f7);
            this.b.a(f7);
            this.c.a(f7);
            this.d.a(f7);
        }
        buq.H();
    }

    @Override
    public void a(float f2, vm vm2) {
        brq brq2 = this.a(vm2);
        boolean \u26032 = brq2.j;
        brq2.j = true;
        super.a(f2, vm2);
        brq2.j = \u26032;
    }
}

