/*
 * Decompiled with CFR 0.150.
 */
public class als
extends ali {
    public als(ali.a a2, vj ... arrvj) {
        super(a2, alj.j, arrvj);
        this.c("mending");
    }

    @Override
    public int a(int n2) {
        return n2 * 25;
    }

    @Override
    public int b(int n2) {
        return this.a(n2) + 50;
    }

    @Override
    public boolean c() {
        return true;
    }

    @Override
    public int b() {
        return 1;
    }
}

