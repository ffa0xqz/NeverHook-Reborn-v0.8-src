/*
 * Decompiled with CFR 0.150.
 */
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class gl
extends gk {
    private short b;

    public gl() {
    }

    public gl(short s2) {
        this.b = s2;
    }

    @Override
    void a(DataOutput dataOutput) throws IOException {
        dataOutput.writeShort(this.b);
    }

    @Override
    void a(DataInput dataInput, int n2, gh gh2) throws IOException {
        gh2.a(80L);
        this.b = dataInput.readShort();
    }

    @Override
    public byte a() {
        return 2;
    }

    @Override
    public String toString() {
        return this.b + "s";
    }

    public gl c() {
        return new gl(this.b);
    }

    @Override
    public boolean equals(Object object) {
        return super.equals(object) && this.b == ((gl)object).b;
    }

    @Override
    public int hashCode() {
        return super.hashCode() ^ this.b;
    }

    @Override
    public long d() {
        return this.b;
    }

    @Override
    public int e() {
        return this.b;
    }

    @Override
    public short f() {
        return this.b;
    }

    @Override
    public byte g() {
        return (byte)(this.b & 0xFF);
    }

    @Override
    public double h() {
        return this.b;
    }

    @Override
    public float i() {
        return this.b;
    }

    @Override
    public /* synthetic */ gn b() {
        return this.c();
    }
}

