/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 *  javax.annotation.Nullable
 */
import com.google.common.base.Predicate;
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;

public class axr
extends axu {
    public axr(ams ams2, int n2, int n3) {
        super(ams2, n2, n3);
    }

    @Override
    public boolean a(int n2, int n3) {
        return n2 == this.b && n3 == this.c;
    }

    @Override
    public int b(int n2, int n3) {
        return 0;
    }

    @Override
    public void a() {
    }

    @Override
    public void b() {
    }

    @Override
    public awr a(et et2) {
        return aov.a.t();
    }

    @Override
    public int b(et et2) {
        return 255;
    }

    @Override
    public int a(amy amy2, et et2) {
        return amy2.c;
    }

    @Override
    public void a(amy amy2, et et2, int n2) {
    }

    @Override
    public int a(et et2, int n2) {
        return 0;
    }

    @Override
    public void a(ve ve2) {
    }

    @Override
    public void b(ve ve2) {
    }

    @Override
    public void a(ve ve2, int n2) {
    }

    @Override
    public boolean c(et et2) {
        return false;
    }

    @Override
    @Nullable
    public avh a(et et2, axu.a a2) {
        return null;
    }

    @Override
    public void a(avh avh2) {
    }

    @Override
    public void a(et et2, avh avh2) {
    }

    @Override
    public void d(et et2) {
    }

    @Override
    public void c() {
    }

    @Override
    public void d() {
    }

    @Override
    public void e() {
    }

    @Override
    public void a(@Nullable ve ve2, bgz bgz2, List<ve> list, Predicate<? super ve> predicate) {
    }

    @Override
    public <T extends ve> void a(Class<? extends T> class_, bgz bgz2, List<T> list, Predicate<? super T> predicate) {
    }

    @Override
    public boolean a(boolean bl2) {
        return false;
    }

    @Override
    public Random a(long l2) {
        return new Random(this.q().Q() + (long)(this.b * this.b * 4987142) + (long)(this.b * 5947611) + (long)(this.c * this.c) * 4392871L + (long)(this.c * 389711) ^ l2);
    }

    @Override
    public boolean f() {
        return true;
    }

    @Override
    public boolean c(int n2, int n3) {
        return true;
    }
}

