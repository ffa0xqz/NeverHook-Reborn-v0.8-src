/*
 * Decompiled with CFR 0.150.
 */
import java.io.IOException;
import java.util.UUID;

public class ik
implements ht<hw> {
    private UUID a;
    private a b;
    private hh c;
    private float d;
    private tr.a e;
    private tr.b f;
    private boolean g;
    private boolean h;
    private boolean i;

    public ik() {
    }

    public ik(a a2, tr tr2) {
        this.b = a2;
        this.a = tr2.d();
        this.c = tr2.e();
        this.d = tr2.f();
        this.e = tr2.g();
        this.f = tr2.h();
        this.g = tr2.i();
        this.h = tr2.j();
        this.i = tr2.k();
    }

    @Override
    public void a(gy gy2) throws IOException {
        this.a = gy2.i();
        this.b = gy2.a(a.class);
        switch (this.b) {
            case a: {
                this.c = gy2.f();
                this.d = gy2.readFloat();
                this.e = gy2.a(tr.a.class);
                this.f = gy2.a(tr.b.class);
                this.a(gy2.readUnsignedByte());
                break;
            }
            case b: {
                break;
            }
            case c: {
                this.d = gy2.readFloat();
                break;
            }
            case d: {
                this.c = gy2.f();
                break;
            }
            case e: {
                this.e = gy2.a(tr.a.class);
                this.f = gy2.a(tr.b.class);
                break;
            }
            case f: {
                this.a(gy2.readUnsignedByte());
            }
        }
    }

    @Override
    private void a(int n2) {
        this.g = (n2 & 1) > 0;
        this.h = (n2 & 2) > 0;
        this.i = (n2 & 2) > 0;
    }

    @Override
    public void b(gy gy2) throws IOException {
        gy2.a(this.a);
        gy2.a(this.b);
        switch (this.b) {
            case a: {
                gy2.a(this.c);
                gy2.writeFloat(this.d);
                gy2.a(this.e);
                gy2.a(this.f);
                gy2.writeByte(this.j());
                break;
            }
            case b: {
                break;
            }
            case c: {
                gy2.writeFloat(this.d);
                break;
            }
            case d: {
                gy2.a(this.c);
                break;
            }
            case e: {
                gy2.a(this.e);
                gy2.a(this.f);
                break;
            }
            case f: {
                gy2.writeByte(this.j());
            }
        }
    }

    private int j() {
        int n2 = 0;
        if (this.g) {
            n2 |= 1;
        }
        if (this.h) {
            n2 |= 2;
        }
        if (this.i) {
            n2 |= 2;
        }
        return n2;
    }

    @Override
    public void a(hw hw2) {
        hw2.a(this);
    }

    public UUID a() {
        return this.a;
    }

    public a b() {
        return this.b;
    }

    public hh c() {
        return this.c;
    }

    public float d() {
        return this.d;
    }

    public tr.a e() {
        return this.e;
    }

    public tr.b f() {
        return this.f;
    }

    public boolean g() {
        return this.g;
    }

    public boolean h() {
        return this.h;
    }

    public boolean i() {
        return this.i;
    }

    public static enum a {
        a,
        b,
        c,
        d,
        e,
        f;

    }
}

