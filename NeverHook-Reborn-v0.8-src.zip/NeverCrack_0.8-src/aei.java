/*
 * Decompiled with CFR 0.150.
 */
public class aei
extends ve {
    private double a;
    private double b;
    private double c;
    private int d;
    private boolean e;

    public aei(ams ams2) {
        super(ams2);
        this.a(0.25f, 0.25f);
    }

    @Override
    protected void i() {
    }

    @Override
    public boolean a(double d2) {
        \u2603 = this.bw().a() * 4.0;
        if (Double.isNaN(\u2603)) {
            \u2603 = 4.0;
        }
        return d2 < (\u2603 *= 64.0) * \u2603;
    }

    public aei(ams ams2, double d2, double d3, double d4) {
        super(ams2);
        this.d = 0;
        this.a(0.25f, 0.25f);
        this.b(d2, d3, d4);
    }

    public void a(et et2) {
        double d2 = et2.p();
        int \u26032 = et2.q();
        \u2603 = d2 - this.p;
        \u2603 = et2.r();
        \u2603 = \u2603 - this.r;
        float \u26033 = ri.a(\u2603 * \u2603 + \u2603 * \u2603);
        if (\u26033 > 12.0f) {
            this.a = this.p + \u2603 / (double)\u26033 * 12.0;
            this.c = this.r + \u2603 / (double)\u26033 * 12.0;
            this.b = this.q + 8.0;
        } else {
            this.a = d2;
            this.b = \u26032;
            this.c = \u2603;
        }
        this.d = 0;
        this.e = this.S.nextInt(5) > 0;
    }

    @Override
    public void h(double d2, double d3, double d4) {
        this.s = d2;
        this.t = d3;
        this.u = d4;
        if (this.y == 0.0f && this.x == 0.0f) {
            float f2 = ri.a(d2 * d2 + d4 * d4);
            this.v = (float)(ri.c(d2, d4) * 57.2957763671875);
            this.w = (float)(ri.c(d3, f2) * 57.2957763671875);
            this.x = this.v;
            this.y = this.w;
        }
    }

    @Override
    public void B_() {
        this.M = this.p;
        this.N = this.q;
        this.O = this.r;
        super.B_();
        this.p += this.s;
        this.q += this.t;
        this.r += this.u;
        float f2 = ri.a(this.s * this.s + this.u * this.u);
        this.v = (float)(ri.c(this.s, this.u) * 57.2957763671875);
        this.w = (float)(ri.c(this.t, f2) * 57.2957763671875);
        while (this.w - this.y < -180.0f) {
            this.y -= 360.0f;
        }
        while (this.w - this.y >= 180.0f) {
            this.y += 360.0f;
        }
        while (this.v - this.x < -180.0f) {
            this.x -= 360.0f;
        }
        while (this.v - this.x >= 180.0f) {
            this.x += 360.0f;
        }
        this.w = this.y + (this.w - this.y) * 0.2f;
        this.v = this.x + (this.v - this.x) * 0.2f;
        if (!this.l.G) {
            double d2 = this.a - this.p;
            \u2603 = this.c - this.r;
            float \u26032 = (float)Math.sqrt(d2 * d2 + \u2603 * \u2603);
            float \u26033 = (float)ri.c(\u2603, d2);
            \u2603 = (double)f2 + (double)(\u26032 - f2) * 0.0025;
            if (\u26032 < 1.0f) {
                \u2603 *= 0.8;
                this.t *= 0.8;
            }
            this.s = Math.cos(\u26033) * \u2603;
            this.u = Math.sin(\u26033) * \u2603;
            this.t = this.q < this.b ? (this.t += (1.0 - this.t) * (double)0.015f) : (this.t += (-1.0 - this.t) * (double)0.015f);
        }
        float f3 = 0.25f;
        if (this.ao()) {
            for (int i2 = 0; i2 < 4; ++i2) {
                this.l.a(fj.e, this.p - this.s * 0.25, this.q - this.t * 0.25, this.r - this.u * 0.25, this.s, this.t, this.u, new int[0]);
            }
        } else {
            this.l.a(fj.y, this.p - this.s * 0.25 + this.S.nextDouble() * 0.6 - 0.3, this.q - this.t * 0.25 - 0.5, this.r - this.u * 0.25 + this.S.nextDouble() * 0.6 - 0.3, this.s, this.t, this.u, new int[0]);
        }
        if (!this.l.G) {
            this.b(this.p, this.q, this.r);
            ++this.d;
            if (this.d > 80 && !this.l.G) {
                this.a(qd.bb, 1.0f, 1.0f);
                this.X();
                if (this.e) {
                    this.l.a(new acj(this.l, this.p, this.q, this.r, new ain(aip.bS)));
                } else {
                    this.l.b(2003, new et(this), 0);
                }
            }
        }
    }

    @Override
    public void b(fy fy2) {
    }

    @Override
    public void a(fy fy2) {
    }

    @Override
    public float aw() {
        return 1.0f;
    }

    @Override
    public int av() {
        return 0xF000F0;
    }

    @Override
    public boolean bd() {
        return false;
    }
}

