/*
 * Decompiled with CFR 0.150.
 */
import java.util.Random;

public class aqw
extends arf {
    public aqw(bcx bcx2, boolean bl2) {
        super(bcx2, bl2);
        this.a(ahn.b);
    }

    @Override
    public int a(Random random) {
        return 0;
    }

    @Override
    public amk f() {
        return amk.c;
    }

    @Override
    public boolean c(awr awr2) {
        return false;
    }

    @Override
    protected boolean n() {
        return true;
    }
}

