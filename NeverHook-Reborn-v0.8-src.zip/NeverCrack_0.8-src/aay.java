/*
 * Decompiled with CFR 0.150.
 */
public interface aay {
    public ams a();

    public boolean a(aaz var1, up var2, float var3);
}

