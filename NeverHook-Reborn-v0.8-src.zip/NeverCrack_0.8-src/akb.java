/*
 * Decompiled with CFR 0.150.
 */
public class akb
extends ajx {
    public akb(aou aou2) {
        super(aou2, false);
    }

    @Override
    public uc<ain> a(ams ams2, aeb aeb2, tz tz2) {
        ain ain2 = aeb2.b(tz2);
        bha \u26032 = this.a(ams2, aeb2, true);
        if (\u26032 == null) {
            return new uc<ain>(ub.b, ain2);
        }
        if (\u26032.a == bha.a.b) {
            et et2 = \u26032.a();
            if (!ams2.a(aeb2, et2) || !aeb2.a(et2.a(\u26032.b), \u26032.b, ain2)) {
                return new uc<ain>(ub.c, ain2);
            }
            \u2603 = et2.a();
            awr \u26033 = ams2.o(et2);
            if (\u26033.a() == bcx.h && \u26033.c(ars.b) == 0 && ams2.d(\u2603)) {
                ams2.a(\u2603, aov.bx.t(), 11);
                if (aeb2 instanceof oo) {
                    m.x.a((oo)aeb2, \u2603, ain2);
                }
                if (!aeb2.bO.d) {
                    ain2.g(1);
                }
                aeb2.b(qq.b(this));
                ams2.a(aeb2, et2, qd.it, qe.e, 1.0f, 1.0f);
                return new uc<ain>(ub.a, ain2);
            }
        }
        return new uc<ain>(ub.c, ain2);
    }
}

