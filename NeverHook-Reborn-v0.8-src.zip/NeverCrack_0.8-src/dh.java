/*
 * Decompiled with CFR 0.150.
 */
import net.minecraft.server.MinecraftServer;

public class dh
extends bj
implements bh {
    private final MinecraftServer a;

    public dh(MinecraftServer minecraftServer) {
        this.a = minecraftServer;
        this.a(new dz());
        this.a(new ck());
        this.a(new cj());
        this.a(new ca());
        this.a(new cp());
        this.a(new eb());
        this.a(new ee());
        this.a(new cg());
        this.a(new ec());
        this.a(new dt());
        this.a(new cm());
        this.a(new db());
        this.a(new dp());
        this.a(new cb());
        this.a(new cd());
        this.a(new cw());
        this.a(new cc());
        this.a(new dm());
        this.a(new cn());
        this.a(new bz());
        this.a(new cs());
        this.a(new df());
        this.a(new dk());
        this.a(new dl());
        this.a(new cl());
        this.a(new bw());
        this.a(new dy());
        this.a(new dn());
        this.a(new cx());
        this.a(new dg());
        this.a(new cf());
        this.a(new ed());
        this.a(new br());
        this.a(new cz());
        this.a(new ds());
        this.a(new di());
        this.a(new ch());
        this.a(new bx());
        this.a(new dx());
        this.a(new bv());
        this.a(new dw());
        this.a(new du());
        this.a(new eg());
        this.a(new ea());
        this.a(new ce());
        this.a(new dr());
        this.a(new cr());
        this.a(new da());
        this.a(new ci());
        if (minecraftServer.aa()) {
            this.a(new ct());
            this.a(new by());
            this.a(new dq());
            this.a(new dc());
            this.a(new dd());
            this.a(new de());
            this.a(new bs());
            this.a(new cu());
            this.a(new bu());
            this.a(new bt());
            this.a(new cv());
            this.a(new co());
            this.a(new cq());
            this.a(new ef());
            this.a(new dj());
        } else {
            this.a(new cy());
        }
        bi.a(this);
    }

    @Override
    public void a(bn bn22, bk bk2, int n2, String string, Object ... arrobject) {
        boolean bl2 = true;
        MinecraftServer \u26032 = this.a;
        if (!bn22.g()) {
            bl2 = false;
        }
        hp \u26033 = new hp("chat.type.admin", bn22.h_(), new hp(string, arrobject));
        \u26033.b().a(a.h);
        \u26033.b().b(true);
        if (bl2) {
            for (aeb aeb2 : \u26032.am().v()) {
                boolean bl3;
                if (aeb2 == bn22 || !\u26032.am().h(aeb2.da()) || !bk2.a(this.a, bn22)) continue;
                boolean bl32 = bn22 instanceof MinecraftServer && this.a.s();
                boolean bl4 = bl3 = bn22 instanceof pv && this.a.r();
                if (!bl32 && !bl3 && (bn22 instanceof pv || bn22 instanceof MinecraftServer)) continue;
                aeb2.a(\u26033);
            }
        }
        if (bn22 != \u26032 && \u26032.d[0].W().b("logAdminCommands")) {
            \u26032.a(\u26033);
        }
        boolean \u26034 = \u26032.d[0].W().b("sendCommandFeedback");
        if (bn22 instanceof amh) {
            \u26034 = ((amh)bn22).n();
        }
        if ((n2 & 1) != 1 && \u26034 || bn22 instanceof MinecraftServer) {
            bn22.a(new hp(string, arrobject));
        }
    }

    @Override
    protected MinecraftServer a() {
        return this.a;
    }
}

