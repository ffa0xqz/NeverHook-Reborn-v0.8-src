/*
 * Decompiled with CFR 0.150.
 */
public abstract class nf
extends ex {
    @Override
    public ain b(eu eu2, ain ain2) {
        ams ams2 = eu2.h();
        fk \u26032 = apx.a(eu2);
        fa \u26033 = eu2.e().c(apx.a);
        aen \u26034 = this.a(ams2, \u26032, ain2);
        \u26034.c(\u26033.g(), (float)\u26033.h() + 0.1f, \u26033.i(), this.b(), this.a());
        ams2.a((ve)((Object)\u26034));
        ain2.g(1);
        return ain2;
    }

    @Override
    protected void a(eu eu2) {
        eu2.h().b(1002, eu2.d(), 0);
    }

    protected abstract aen a(ams var1, fk var2, ain var3);

    protected float a() {
        return 6.0f;
    }

    protected float b() {
        return 1.1f;
    }
}

