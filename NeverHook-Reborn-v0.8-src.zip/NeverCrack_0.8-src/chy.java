/*
 * Decompiled with CFR 0.150.
 */
public interface chy {
    default public void b() {
    }

    default public void a() {
    }

    default public void a(btz btz2) {
    }

    default public void a(bia bia2) {
    }

    default public void a(brz brz2, bha bha2) {
    }

    default public void a(brz brz2, et et2, awr awr2, float f2) {
    }

    default public void c() {
    }

    default public void a(ain ain2) {
    }
}

