/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  com.mojang.authlib.exceptions.AuthenticationException
 *  com.mojang.authlib.exceptions.AuthenticationUnavailableException
 *  com.mojang.authlib.exceptions.InvalidCredentialsException
 *  com.mojang.authlib.minecraft.MinecraftSessionService
 *  javax.annotation.Nullable
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.exceptions.AuthenticationException;
import com.mojang.authlib.exceptions.AuthenticationUnavailableException;
import com.mojang.authlib.exceptions.InvalidCredentialsException;
import com.mojang.authlib.minecraft.MinecraftSessionService;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;
import java.math.BigInteger;
import java.security.PublicKey;
import javax.annotation.Nullable;
import javax.crypto.SecretKey;
import net.minecraft.realms.DisconnectedRealmsScreen;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class brw
implements mf {
    private static final Logger a = LogManager.getLogger();
    private final bhz b;
    @Nullable
    private final bli c;
    private final gw d;
    private GameProfile e;

    public brw(gw gw2, bhz bhz2, @Nullable bli bli2) {
        this.d = gw2;
        this.b = bhz2;
        this.c = bli2;
    }

    @Override
    public void a(mh mh2) {
        final SecretKey secretKey = qy.a();
        String \u26032 = mh2.a();
        PublicKey \u26033 = mh2.b();
        String \u26034 = new BigInteger(qy.a(\u26032, \u26033, secretKey)).toString(16);
        if (this.b.C() != null && this.b.C().d()) {
            try {
                this.b().joinServer(this.b.K().e(), this.b.K().d(), \u26034);
            }
            catch (AuthenticationException authenticationException) {
                a.warn("Couldn't connect to auth servers but will continue to join LAN");
            }
        } else {
            try {
                this.b().joinServer(this.b.K().e(), this.b.K().d(), \u26034);
            }
            catch (AuthenticationUnavailableException authenticationUnavailableException) {
                this.d.a(new hp("disconnect.loginFailedInfo", new hp("disconnect.loginFailedInfo.serversUnavailable", new Object[0])));
                return;
            }
            catch (InvalidCredentialsException invalidCredentialsException) {
                this.d.a(new hp("disconnect.loginFailedInfo", new hp("disconnect.loginFailedInfo.invalidSession", new Object[0])));
                return;
            }
            catch (AuthenticationException authenticationException) {
                this.d.a(new hp("disconnect.loginFailedInfo", authenticationException.getMessage()));
                return;
            }
        }
        this.d.a(new mm(secretKey, \u26033, mh2.c()), (GenericFutureListener<? extends Future<? super Void>>)new GenericFutureListener<Future<? super Void>>(){

            @Override
            public void operationComplete(Future<? super Void> future) throws Exception {
                brw.this.d.a(secretKey);
            }
        }, new GenericFutureListener[0]);
    }

    private MinecraftSessionService b() {
        return this.b.X();
    }

    @Override
    public void a(mg mg2) {
        this.e = mg2.a();
        this.d.a(gx.b);
        this.d.a(new brx(this.b, this.c, this.d, this.e));
    }

    @Override
    public void a(hh hh2) {
        if (this.c != null && this.c instanceof bkg) {
            this.b.a(new DisconnectedRealmsScreen(((bkg)this.c).a(), "connect.failed", hh2).getProxy());
        } else {
            this.b.a(new bkw(this.c, "connect.failed", hh2));
        }
    }

    @Override
    public void a(mj mj2) {
        this.d.a(mj2.a());
    }

    @Override
    public void a(mi mi2) {
        if (!this.d.c()) {
            this.d.a(mi2.a());
        }
    }
}

