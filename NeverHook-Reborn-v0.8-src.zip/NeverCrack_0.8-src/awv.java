/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.base.MoreObjects
 *  com.google.common.base.Predicate
 *  com.google.common.cache.CacheBuilder
 *  com.google.common.cache.CacheLoader
 *  com.google.common.cache.LoadingCache
 *  javax.annotation.Nullable
 */
import com.google.common.base.MoreObjects;
import com.google.common.base.Predicate;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import javax.annotation.Nullable;

public class awv {
    private final Predicate<awu>[][][] a;
    private final int b;
    private final int c;
    private final int d;

    public awv(Predicate<awu>[][][] arrpredicate) {
        this.a = arrpredicate;
        this.b = arrpredicate.length;
        if (this.b > 0) {
            this.c = arrpredicate[0].length;
            this.d = this.c > 0 ? arrpredicate[0][0].length : 0;
        } else {
            this.c = 0;
            this.d = 0;
        }
    }

    public int a() {
        return this.b;
    }

    public int b() {
        return this.c;
    }

    public int c() {
        return this.d;
    }

    @Nullable
    private b a(et et22, fa fa2, fa fa3, LoadingCache<et, awu> loadingCache) {
        et et22;
        for (int i2 = 0; i2 < this.d; ++i2) {
            for (\u2603 = 0; \u2603 < this.c; ++\u2603) {
                for (\u2603 = 0; \u2603 < this.b; ++\u2603) {
                    if (this.a[\u2603][\u2603][i2].apply(loadingCache.getUnchecked((Object)awv.a(et22, fa2, fa3, i2, \u2603, \u2603)))) continue;
                    return null;
                }
            }
        }
        return new b(et22, fa2, fa3, loadingCache, this.d, this.c, this.b);
    }

    @Nullable
    public b a(ams ams2, et et2) {
        LoadingCache<et, awu> loadingCache = awv.a(ams2, false);
        int \u26032 = Math.max(Math.max(this.d, this.c), this.b);
        for (et et3 : et.a(et2, et2.a(\u26032 - 1, \u26032 - 1, \u26032 - 1))) {
            for (fa fa2 : fa.values()) {
                for (fa fa3 : fa.values()) {
                    if (fa3 == fa2 || fa3 == fa2.d() || (\u2603 = this.a(et3, fa2, fa3, loadingCache)) == null) continue;
                    return \u2603;
                }
            }
        }
        return null;
    }

    public static LoadingCache<et, awu> a(ams ams2, boolean bl2) {
        return CacheBuilder.newBuilder().build((CacheLoader)new a(ams2, bl2));
    }

    protected static et a(et et2, fa fa2, fa fa3, int n2, int n3, int n4) {
        if (fa2 == fa3 || fa2 == fa3.d()) {
            throw new IllegalArgumentException("Invalid forwards & up combination");
        }
        fq fq2 = new fq(fa2.g(), fa2.h(), fa2.i());
        \u2603 = new fq(fa3.g(), fa3.h(), fa3.i());
        \u2603 = fq2.d(\u2603);
        return et2.a(\u2603.p() * -n3 + \u2603.p() * n2 + fq2.p() * n4, \u2603.q() * -n3 + \u2603.q() * n2 + fq2.q() * n4, \u2603.r() * -n3 + \u2603.r() * n2 + fq2.r() * n4);
    }

    public static class b {
        private final et a;
        private final fa b;
        private final fa c;
        private final LoadingCache<et, awu> d;
        private final int e;
        private final int f;
        private final int g;

        public b(et et2, fa fa2, fa fa3, LoadingCache<et, awu> loadingCache, int n2, int n3, int n4) {
            this.a = et2;
            this.b = fa2;
            this.c = fa3;
            this.d = loadingCache;
            this.e = n2;
            this.f = n3;
            this.g = n4;
        }

        public et a() {
            return this.a;
        }

        public fa b() {
            return this.b;
        }

        public fa c() {
            return this.c;
        }

        public int d() {
            return this.e;
        }

        public int e() {
            return this.f;
        }

        public awu a(int n2, int n3, int n4) {
            return (awu)this.d.getUnchecked((Object)awv.a(this.a, this.b(), this.c(), n2, n3, n4));
        }

        public String toString() {
            return MoreObjects.toStringHelper((Object)this).add("up", (Object)this.c).add("forwards", (Object)this.b).add("frontTopLeft", (Object)this.a).toString();
        }
    }

    static class a
    extends CacheLoader<et, awu> {
        private final ams a;
        private final boolean b;

        public a(ams ams2, boolean bl2) {
            this.a = ams2;
            this.b = bl2;
        }

        public awu a(et et2) throws Exception {
            return new awu(this.a, et2, this.b);
        }

        public /* synthetic */ Object load(Object object) throws Exception {
            return this.a((et)object);
        }
    }
}

