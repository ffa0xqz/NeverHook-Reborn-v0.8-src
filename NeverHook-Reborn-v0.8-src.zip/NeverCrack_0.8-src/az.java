/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Maps
 *  com.google.common.collect.Sets
 *  com.google.gson.JsonDeserializationContext
 *  com.google.gson.JsonObject
 */
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class az
implements p<b> {
    private static final nd a = new nd("summoned_entity");
    private final Map<nn, a> b = Maps.newHashMap();

    @Override
    public nd a() {
        return a;
    }

    @Override
    public void a(nn nn2, p.a<b> a2) {
        a a3 = this.b.get(nn2);
        if (a3 == null) {
            a3 = new a(nn2);
            this.b.put(nn2, a3);
        }
        a3.a(a2);
    }

    @Override
    public void b(nn nn2, p.a<b> a2) {
        a a3 = this.b.get(nn2);
        if (a3 != null) {
            a3.b(a2);
            if (a3.a()) {
                this.b.remove(nn2);
            }
        }
    }

    @Override
    public void a(nn nn2) {
        this.b.remove(nn2);
    }

    public b b(JsonObject jsonObject, JsonDeserializationContext jsonDeserializationContext) {
        aj aj2 = aj.a(jsonObject.get("entity"));
        return new b(aj2);
    }

    public void a(oo oo2, ve ve2) {
        a a2 = this.b.get(oo2.P());
        if (a2 != null) {
            a2.a(oo2, ve2);
        }
    }

    @Override
    public /* synthetic */ q a(JsonObject jsonObject, JsonDeserializationContext jsonDeserializationContext) {
        return this.b(jsonObject, jsonDeserializationContext);
    }

    static class a {
        private final nn a;
        private final Set<p.a<b>> b = Sets.newHashSet();

        public a(nn nn2) {
            this.a = nn2;
        }

        public boolean a() {
            return this.b.isEmpty();
        }

        public void a(p.a<b> a2) {
            this.b.add(a2);
        }

        public void b(p.a<b> a2) {
            this.b.remove(a2);
        }

        public void a(oo oo2, ve ve2) {
            List list = null;
            for (p.a<b> a2 : this.b) {
                if (!a2.a().a(oo2, ve2)) continue;
                if (list == null) {
                    list = Lists.newArrayList();
                }
                list.add(a2);
            }
            if (list != null) {
                for (p.a<b> a2 : list) {
                    a2.a(this.a);
                }
            }
        }
    }

    public static class b
    extends u {
        private final aj a;

        public b(aj aj2) {
            super(a);
            this.a = aj2;
        }

        public boolean a(oo oo2, ve ve2) {
            return this.a.a(oo2, ve2);
        }
    }
}

