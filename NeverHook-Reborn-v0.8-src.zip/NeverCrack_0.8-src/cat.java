/*
 * Decompiled with CFR 0.150.
 */
public class cat
extends byo<aes> {
    public static final nd a = new nd("textures/entity/projectiles/spectral_arrow.png");

    public cat(bzd bzd2) {
        super(bzd2);
    }

    @Override
    protected nd a(aes aes2) {
        return a;
    }
}

