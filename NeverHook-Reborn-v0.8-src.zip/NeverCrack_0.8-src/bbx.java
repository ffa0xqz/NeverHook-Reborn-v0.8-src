/*
 * Decompiled with CFR 0.150.
 */
import java.util.Map;
import java.util.Random;

public abstract class bbx
extends bbv {
    private static final bcf d = new bcf();
    protected bch a;
    protected bcf b = d.a(true).a(aov.a);
    protected et c;

    public bbx() {
    }

    public bbx(int n2) {
        super(n2);
    }

    protected void a(bch bch2, et et2, bcf bcf2) {
        this.a = bch2;
        this.a(fa.c);
        this.c = et2;
        this.b = bcf2;
        this.b();
    }

    @Override
    protected void a(fy fy2) {
        fy2.a("TPX", this.c.p());
        fy2.a("TPY", this.c.q());
        fy2.a("TPZ", this.c.r());
    }

    @Override
    protected void a(fy fy2, bce bce2) {
        this.c = new et(fy2.h("TPX"), fy2.h("TPY"), fy2.h("TPZ"));
    }

    @Override
    public boolean a(ams ams2, Random random, bbe bbe2) {
        this.b.a(bbe2);
        this.a.a(ams2, this.c, this.b, 18);
        Map<et, String> map = this.a.a(this.c, this.b);
        for (Map.Entry<et, String> entry : map.entrySet()) {
            String string = entry.getValue();
            this.a(string, entry.getKey(), ams2, random, bbe2);
        }
        return true;
    }

    protected abstract void a(String var1, et var2, ams var3, Random var4, bbe var5);

    private void b() {
        atk atk2 = this.b.c();
        et \u26032 = this.a.a(atk2);
        arw \u26033 = this.b.b();
        this.l = new bbe(0, 0, 0, \u26032.p(), \u26032.q() - 1, \u26032.r());
        switch (atk2) {
            case a: {
                break;
            }
            case b: {
                this.l.a(-\u26032.p(), 0, 0);
                break;
            }
            case d: {
                this.l.a(0, 0, -\u26032.r());
                break;
            }
            case c: {
                this.l.a(-\u26032.p(), 0, -\u26032.r());
            }
        }
        switch (\u26033) {
            case a: {
                break;
            }
            case c: {
                et et2 = et.a;
                et2 = atk2 == atk.b || atk2 == atk.d ? et2.a(atk2.a(fa.e), \u26032.r()) : (atk2 == atk.c ? et2.a(fa.f, \u26032.p()) : et2.a(fa.e, \u26032.p()));
                this.l.a(et2.p(), 0, et2.r());
                break;
            }
            case b: {
                et et3 = et.a;
                et3 = atk2 == atk.b || atk2 == atk.d ? et3.a(atk2.a(fa.c), \u26032.p()) : (atk2 == atk.c ? et3.a(fa.d, \u26032.r()) : et3.a(fa.c, \u26032.r()));
                this.l.a(et3.p(), 0, et3.r());
            }
        }
        this.l.a(this.c.p(), this.c.q(), this.c.r());
    }

    @Override
    public void a(int n2, int n3, int n4) {
        super.a(n2, n3, n4);
        this.c = this.c.a(n2, n3, n4);
    }
}

