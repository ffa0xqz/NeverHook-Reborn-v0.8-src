/*
 * Decompiled with CFR 0.150.
 */
import java.io.IOException;

public class js
implements ht<hw> {
    private int[] a;

    public js() {
    }

    public js(int ... arrn) {
        this.a = arrn;
    }

    @Override
    public void a(gy gy2) throws IOException {
        this.a = new int[gy2.g()];
        for (int i2 = 0; i2 < this.a.length; ++i2) {
            this.a[i2] = gy2.g();
        }
    }

    @Override
    public void b(gy gy2) throws IOException {
        gy2.d(this.a.length);
        for (int n2 : this.a) {
            gy2.d(n2);
        }
    }

    @Override
    public void a(hw hw2) {
        hw2.a(this);
    }

    public int[] a() {
        return this.a;
    }
}

