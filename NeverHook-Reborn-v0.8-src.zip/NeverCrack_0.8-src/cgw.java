/*
 * Decompiled with CFR 0.150.
 */
import java.util.List;

public interface cgw<T> {
    public List<T> a(String var1);
}

