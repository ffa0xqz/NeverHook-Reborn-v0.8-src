/*
 * Decompiled with CFR 0.150.
 */
public class alx
extends ali {
    protected alx(ali.a a2, vj ... arrvj) {
        super(a2, alj.h, arrvj);
        this.c("untouching");
    }

    @Override
    public int a(int n2) {
        return 15;
    }

    @Override
    public int b(int n2) {
        return super.a(n2) + 50;
    }

    @Override
    public int b() {
        return 1;
    }

    @Override
    public boolean a(ali ali2) {
        return super.a(ali2) && ali2 != alm.v;
    }
}

