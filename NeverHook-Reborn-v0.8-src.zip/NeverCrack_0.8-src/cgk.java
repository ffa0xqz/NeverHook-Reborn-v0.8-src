/*
 * Decompiled with CFR 0.150.
 */
public class cgk
extends cgi {
    private final acy m;

    public cgk(acy acy2) {
        super(qd.cy, qe.f);
        this.m = acy2;
        this.k = cgr.a.a;
        this.i = true;
        this.j = 0;
    }

    @Override
    public void e() {
        if (this.m.F || !this.m.dp()) {
            this.l = true;
            return;
        }
        this.f = (float)this.m.p;
        this.g = (float)this.m.q;
        this.h = (float)this.m.r;
        float f2 = this.m.s(0.0f);
        this.d = 0.0f + 1.0f * f2 * f2;
        this.e = 0.7f + 0.5f * f2;
    }
}

