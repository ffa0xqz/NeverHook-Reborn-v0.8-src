/*
 * Decompiled with CFR 0.150.
 */
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import org.lwjgl.util.glu.GLU;

public class bhy {
    public static synchronized int a(int n2) {
        int n3;
        n3 = buq.t(n2);
        if (n3 == 0) {
            \u2603 = buq.L();
            String string = "No error code reported";
            if (\u2603 != 0) {
                string = GLU.gluErrorString(\u2603);
            }
            throw new IllegalStateException("glGenLists returned an ID of 0 for a count of " + n2 + ", GL error (" + \u2603 + "): " + string);
        }
        return n3;
    }

    public static synchronized void a(int n2, int n3) {
        buq.e(n2, n3);
    }

    public static synchronized void b(int n2) {
        bhy.a(n2, 1);
    }

    public static synchronized ByteBuffer c(int n2) {
        return ByteBuffer.allocateDirect(n2).order(ByteOrder.nativeOrder());
    }

    public static IntBuffer f(int n2) {
        return bhy.c(n2 << 2).asIntBuffer();
    }

    public static FloatBuffer h(int n2) {
        return bhy.c(n2 << 2).asFloatBuffer();
    }
}

