/*
 * Decompiled with CFR 0.150.
 */
public class ahi
extends aih {
    public ahi(int n2, float f2) {
        super(n2, f2, false);
    }

    @Override
    public ain a(ain ain2, ams ams2, vn vn22) {
        ain ain3 = super.a(ain2, ams2, vn22);
        if (!ams2.G) {
            vn vn22;
            double d2 = vn22.p;
            \u2603 = vn22.q;
            \u2603 = vn22.r;
            for (int i2 = 0; i2 < 16; ++i2) {
                double d3 = vn22.p + (vn22.bR().nextDouble() - 0.5) * 16.0;
                \u2603 = ri.a(vn22.q + (double)(vn22.bR().nextInt(16) - 8), 0.0, (double)(ams2.ab() - 1));
                \u2603 = vn22.r + (vn22.bR().nextDouble() - 0.5) * 16.0;
                if (vn22.aS()) {
                    vn22.o();
                }
                if (!vn22.j(d3, \u2603, \u2603)) continue;
                ams2.a(null, d2, \u2603, \u2603, qd.ak, qe.h, 1.0f, 1.0f);
                vn22.a(qd.ak, 1.0f, 1.0f);
                break;
            }
            if (vn22 instanceof aeb) {
                ((aeb)vn22).dt().a((ail)this, 20);
            }
        }
        return ain3;
    }
}

