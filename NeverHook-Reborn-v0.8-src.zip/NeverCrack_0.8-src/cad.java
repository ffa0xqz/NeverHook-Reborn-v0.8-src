/*
 * Decompiled with CFR 0.150.
 */
import optifine.Config;
import shadersmod.client.Shaders;

public abstract class cad<T extends vo>
extends bzy<T> {
    public cad(bzd rendermanagerIn, bqd modelbaseIn, float shadowsizeIn) {
        super(rendermanagerIn, modelbaseIn, shadowsizeIn);
    }

    @Override
    protected boolean b(T entity) {
        return super.a(entity) && (((vn)entity).bs() || ((ve)entity).n_() && entity == this.b.d);
    }

    @Override
    public boolean a(T livingEntity, bxw camera, double camX, double camY, double camZ) {
        if (super.a(livingEntity, camera, camX, camY, camZ)) {
            return true;
        }
        if (((vo)livingEntity).da() && ((vo)livingEntity).db() != null) {
            ve entity = ((vo)livingEntity).db();
            return camera.a(entity.bx());
        }
        return false;
    }

    @Override
    public void a(T entity, double x2, double y2, double z2, float entityYaw, float partialTicks) {
        super.a(entity, x2, y2, z2, entityYaw, partialTicks);
        if (!this.e) {
            this.b(entity, x2, y2, z2, entityYaw, partialTicks);
        }
    }

    public void c(T entityLivingIn) {
        int i2 = ((ve)entityLivingIn).av();
        int j2 = i2 % 65536;
        int k2 = i2 / 65536;
        cig.a(cig.r, j2, (float)k2);
    }

    private double a(double start, double end, double pct) {
        return start + (end - start) * pct;
    }

    @Override
    protected void b(T entityLivingIn, double x2, double y2, double z2, float entityYaw, float partialTicks) {
        ve entity;
        if (!(Config.isShaders() && Shaders.isShadowPass || (entity = ((vo)entityLivingIn).db()) == null)) {
            y2 -= (1.6 - (double)((vo)entityLivingIn).H) * 0.5;
            bvc tessellator = bvc.a();
            bui bufferbuilder = tessellator.c();
            double d0 = this.a((double)entity.x, (double)entity.v, (double)(partialTicks * 0.5f)) * 0.01745329238474369;
            double d1 = this.a((double)entity.y, (double)entity.w, (double)(partialTicks * 0.5f)) * 0.01745329238474369;
            double d2 = Math.cos(d0);
            double d3 = Math.sin(d0);
            double d4 = Math.sin(d1);
            if (entity instanceof aby) {
                d2 = 0.0;
                d3 = 0.0;
                d4 = -1.0;
            }
            double d5 = Math.cos(d1);
            double d6 = this.a(entity.m, entity.p, (double)partialTicks) - d2 * 0.7 - d3 * 0.5 * d5;
            double d7 = this.a(entity.n + (double)entity.by() * 0.7, entity.q + (double)entity.by() * 0.7, (double)partialTicks) - d4 * 0.5 - 0.25;
            double d8 = this.a(entity.o, entity.r, (double)partialTicks) - d3 * 0.7 + d2 * 0.5 * d5;
            double d9 = this.a((double)((vo)entityLivingIn).aO, (double)((vo)entityLivingIn).aN, (double)partialTicks) * 0.01745329238474369 + 1.5707963267948966;
            d2 = Math.cos(d9) * (double)((vo)entityLivingIn).G * 0.4;
            d3 = Math.sin(d9) * (double)((vo)entityLivingIn).G * 0.4;
            double d10 = this.a(((vo)entityLivingIn).m, ((vo)entityLivingIn).p, (double)partialTicks) + d2;
            double d11 = this.a(((vo)entityLivingIn).n, ((vo)entityLivingIn).q, (double)partialTicks);
            double d12 = this.a(((vo)entityLivingIn).o, ((vo)entityLivingIn).r, (double)partialTicks) + d3;
            x2 += d2;
            z2 += d3;
            double d13 = (float)(d6 - d10);
            double d14 = (float)(d7 - d11);
            double d15 = (float)(d8 - d12);
            buq.z();
            buq.g();
            buq.r();
            if (Config.isShaders()) {
                Shaders.beginLeash();
            }
            int i2 = 24;
            double d16 = 0.025;
            bufferbuilder.a(5, cdw.f);
            for (int j2 = 0; j2 <= 24; ++j2) {
                float f2 = 0.5f;
                float f1 = 0.4f;
                float f22 = 0.3f;
                if (j2 % 2 == 0) {
                    f2 *= 0.7f;
                    f1 *= 0.7f;
                    f22 *= 0.7f;
                }
                float f3 = (float)j2 / 24.0f;
                bufferbuilder.b(x2 + d13 * (double)f3 + 0.0, y2 + d14 * (double)(f3 * f3 + f3) * 0.5 + (double)((24.0f - (float)j2) / 18.0f + 0.125f), z2 + d15 * (double)f3).a(f2, f1, f22, 1.0f).d();
                bufferbuilder.b(x2 + d13 * (double)f3 + 0.025, y2 + d14 * (double)(f3 * f3 + f3) * 0.5 + (double)((24.0f - (float)j2) / 18.0f + 0.125f) + 0.025, z2 + d15 * (double)f3).a(f2, f1, f22, 1.0f).d();
            }
            tessellator.b();
            bufferbuilder.a(5, cdw.f);
            for (int k2 = 0; k2 <= 24; ++k2) {
                float f4 = 0.5f;
                float f5 = 0.4f;
                float f6 = 0.3f;
                if (k2 % 2 == 0) {
                    f4 *= 0.7f;
                    f5 *= 0.7f;
                    f6 *= 0.7f;
                }
                float f7 = (float)k2 / 24.0f;
                bufferbuilder.b(x2 + d13 * (double)f7 + 0.0, y2 + d14 * (double)(f7 * f7 + f7) * 0.5 + (double)((24.0f - (float)k2) / 18.0f + 0.125f) + 0.025, z2 + d15 * (double)f7).a(f4, f5, f6, 1.0f).d();
                bufferbuilder.b(x2 + d13 * (double)f7 + 0.025, y2 + d14 * (double)(f7 * f7 + f7) * 0.5 + (double)((24.0f - (float)k2) / 18.0f + 0.125f), z2 + d15 * (double)f7 + 0.025).a(f4, f5, f6, 1.0f).d();
            }
            tessellator.b();
            if (Config.isShaders()) {
                Shaders.endLeash();
            }
            buq.f();
            buq.y();
            buq.q();
        }
    }
}

