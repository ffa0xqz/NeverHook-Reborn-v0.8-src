/*
 * Decompiled with CFR 0.150.
 */
public class bth
extends btd {
    private final float a;
    private final double b;
    private final double L;
    private final double M;

    protected bth(ams ams2, double d2, double d3, double d4, double d5, double d6, double d7) {
        super(ams2, d2, d3, d4, d5, d6, d7);
        this.j = d5;
        this.k = d6;
        this.l = d7;
        this.g = d2;
        this.h = d3;
        this.i = d4;
        this.b = this.g;
        this.L = this.h;
        this.M = this.i;
        float f2 = this.r.nextFloat() * 0.6f + 0.4f;
        this.a = this.y = this.r.nextFloat() * 0.2f + 0.5f;
        this.A = f2 * 0.9f;
        this.B = f2 * 0.3f;
        this.C = f2;
        this.x = (int)(Math.random() * 10.0) + 40;
        this.b((int)(Math.random() * 8.0));
    }

    @Override
    public void a(double d2, double d3, double d4) {
        this.a(this.l().d(d2, d3, d4));
        this.j();
    }

    @Override
    public void a(bui bui2, ve ve2, float f2, float f3, float f4, float f5, float f6, float f7) {
        \u2603 = ((float)this.w + f2) / (float)this.x;
        \u2603 = 1.0f - \u2603;
        \u2603 *= \u2603;
        \u2603 = 1.0f - \u2603;
        this.y = this.a * \u2603;
        super.a(bui2, ve2, f2, f3, f4, f5, f6, f7);
    }

    @Override
    public int a(float f2) {
        int n2 = super.a(f2);
        float \u26032 = (float)this.w / (float)this.x;
        \u26032 *= \u26032;
        \u26032 *= \u26032;
        \u2603 = n2 & 0xFF;
        \u2603 = n2 >> 16 & 0xFF;
        if ((\u2603 += (int)(\u26032 * 15.0f * 16.0f)) > 240) {
            \u2603 = 240;
        }
        return \u2603 | \u2603 << 16;
    }

    @Override
    public void a() {
        float f2;
        this.d = this.g;
        this.e = this.h;
        this.f = this.i;
        \u2603 = f2 = (float)this.w / (float)this.x;
        f2 = -f2 + f2 * f2 * 2.0f;
        f2 = 1.0f - f2;
        this.g = this.b + this.j * (double)f2;
        this.h = this.L + this.k * (double)f2 + (double)(1.0f - \u2603);
        this.i = this.M + this.l * (double)f2;
        if (this.w++ >= this.x) {
            this.i();
        }
    }

    public static class a
    implements btf {
        @Override
        public btd a(int n2, ams ams2, double d2, double d3, double d4, double d5, double d6, double d7, int ... arrn) {
            return new bth(ams2, d2, d3, d4, d5, d6, d7);
        }
    }
}

