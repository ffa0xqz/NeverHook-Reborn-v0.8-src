/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class awd
extends awe
implements nv {
    private static final Logger a = LogManager.getLogger();
    private long f;
    private int g;
    private et h;
    private boolean i;

    @Override
    public fy b(fy fy2) {
        super.b(fy2);
        fy2.a("Age", this.f);
        if (this.h != null) {
            fy2.a("ExitPortal", gj.a(this.h));
        }
        if (this.i) {
            fy2.a("ExactTeleport", this.i);
        }
        return fy2;
    }

    @Override
    public void a(fy fy2) {
        super.a(fy2);
        this.f = fy2.i("Age");
        if (fy2.b("ExitPortal", 10)) {
            this.h = gj.c(fy2.p("ExitPortal"));
        }
        this.i = fy2.q("ExactTeleport");
    }

    @Override
    public double t() {
        return 65536.0;
    }

    @Override
    public void e() {
        boolean bl2 = this.a();
        \u2603 = this.f();
        ++this.f;
        if (\u2603) {
            --this.g;
        } else if (!this.b.G) {
            List<ve> list = this.b.a(ve.class, new bgz(this.w()));
            if (!list.isEmpty()) {
                this.a(list.get(0));
            }
            if (this.f % 2400L == 0L) {
                this.h();
            }
        }
        if (bl2 != this.a() || \u2603 != this.f()) {
            this.y_();
        }
    }

    public boolean a() {
        return this.f < 200L;
    }

    public boolean f() {
        return this.g > 0;
    }

    public float a(float f2) {
        return ri.a(((float)this.f + f2) / 200.0f, 0.0f, 1.0f);
    }

    public float b(float f2) {
        return 1.0f - ri.a(((float)this.g - f2) / 40.0f, 0.0f, 1.0f);
    }

    @Override
    @Nullable
    public ih c() {
        return new ih(this.c, 8, this.d());
    }

    @Override
    public fy d() {
        return this.b(new fy());
    }

    public void h() {
        if (!this.b.G) {
            this.g = 40;
            this.b.c(this.w(), this.x(), 1, 0);
            this.y_();
        }
    }

    @Override
    public boolean c(int n2, int n3) {
        if (n2 == 1) {
            this.g = 40;
            return true;
        }
        return super.c(n2, n3);
    }

    public void a(ve ve2) {
        if (this.b.G || this.f()) {
            return;
        }
        this.g = 100;
        if (this.h == null && this.b.s instanceof ayq) {
            this.k();
        }
        if (this.h != null) {
            et et2 = this.i ? this.h : this.j();
            ve2.a((double)et2.p() + 0.5, (double)et2.q() + 0.5, (double)et2.r() + 0.5);
        }
        this.h();
    }

    private et j() {
        et et2 = awd.a(this.b, this.h, 5, false);
        a.debug("Best exit position for portal at {} is {}", (Object)this.h, (Object)et2);
        return et2.a();
    }

    private void k() {
        bhc bhc2 = new bhc(this.w().p(), 0.0, this.w().r()).a();
        \u2603 = bhc2.a(1024.0);
        int \u26032 = 16;
        while (awd.a(this.b, \u2603).g() > 0 && \u26032-- > 0) {
            a.debug("Skipping backwards past nonempty chunk at {}", (Object)\u2603);
            \u2603 = \u2603.e(bhc2.a(-16.0));
        }
        \u26032 = 16;
        while (awd.a(this.b, \u2603).g() == 0 && \u26032-- > 0) {
            a.debug("Skipping forward past empty chunk at {}", (Object)\u2603);
            \u2603 = \u2603.e(bhc2.a(16.0));
        }
        a.debug("Found chunk at {}", (Object)\u2603);
        axu \u26033 = awd.a(this.b, \u2603);
        this.h = awd.a(\u26033);
        if (this.h == null) {
            this.h = new et(\u2603.b + 0.5, 75.0, \u2603.d + 0.5);
            a.debug("Failed to find suitable block, settling on {}", (Object)this.h);
            new azq().b(this.b, new Random(this.h.g()), this.h);
        } else {
            a.debug("Found block at {}", (Object)this.h);
        }
        this.h = awd.a(this.b, this.h, 16, true);
        a.debug("Creating portal at {}", (Object)this.h);
        this.h = this.h.b(10);
        this.c(this.h);
        this.y_();
    }

    private static et a(ams ams2, et et2, int n2, boolean bl2) {
        fq \u26033 = null;
        for (int i2 = -n2; i2 <= n2; ++i2) {
            block1: for (\u2603 = -n2; \u2603 <= n2; ++\u2603) {
                if (i2 == 0 && \u2603 == 0 && !bl2) continue;
                for (\u2603 = 255; \u2603 > (\u26033 == null ? 0 : \u26033.q()); --\u2603) {
                    et et3 = new et(et2.p() + i2, \u2603, et2.r() + \u2603);
                    awr \u26032 = ams2.o(et3);
                    if (!\u26032.k() || !bl2 && \u26032.u() == aov.h) continue;
                    \u26033 = et3;
                    continue block1;
                }
            }
        }
        return \u26033 == null ? et2 : \u26033;
    }

    private static axu a(ams ams2, bhc bhc2) {
        return ams2.a(ri.c(bhc2.b / 16.0), ri.c(bhc2.d / 16.0));
    }

    @Nullable
    private static et a(axu axu2) {
        et \u26035;
        et et2 = new et(axu2.b * 16, 30, axu2.c * 16);
        int \u26032 = axu2.g() + 16 - 1;
        \u2603 = new et(axu2.b * 16 + 16 - 1, \u26032, axu2.c * 16 + 16 - 1);
        \u26035 = null;
        double \u26033 = 0.0;
        for (et et3 : et.a(et2, \u2603)) {
            awr awr2 = axu2.a(et3);
            if (awr2.u() != aov.bH || axu2.a(et3.b(1)).k() || axu2.a(et3.b(2)).k()) continue;
            double \u26034 = et3.g(0.0, 0.0, 0.0);
            if (\u26035 != null && !(\u26034 < \u26033)) continue;
            \u26035 = et3;
            \u26033 = \u26034;
        }
        return \u26035;
    }

    private void c(et et22) {
        new azp().b(this.b, new Random(), et22);
        avh avh2 = this.b.r(et22);
        if (avh2 instanceof awd) {
            awd awd2 = (awd)avh2;
            awd2.h = new et(this.w());
            awd2.y_();
        } else {
            et et22;
            a.warn("Couldn't save exit portal at {}", (Object)et22);
        }
    }

    @Override
    public boolean a(fa fa2) {
        return this.x().t().c(this.b, this.w(), fa2);
    }

    public int i() {
        int n2 = 0;
        for (fa fa2 : fa.values()) {
            n2 += this.a(fa2) ? 1 : 0;
        }
        return n2;
    }

    public void b(et et2) {
        this.i = true;
        this.h = et2;
    }
}

