/*
 * Decompiled with CFR 0.150.
 */
public class bzj
extends bze<aej> {
    private final float a;

    public bzj(bzd renderManagerIn, float scaleIn) {
        super(renderManagerIn);
        this.a = scaleIn;
    }

    @Override
    public void a(aej entity, double x2, double y2, double z2, float entityYaw, float partialTicks) {
        buq.G();
        this.d(entity);
        buq.c((float)x2, (float)y2, (float)z2);
        buq.D();
        buq.b(this.a, this.a, this.a);
        cdo textureatlassprite = bhz.z().ad().a().a(aip.bW);
        bvc tessellator = bvc.a();
        bui bufferbuilder = tessellator.c();
        float f2 = textureatlassprite.e();
        float f1 = textureatlassprite.f();
        float f22 = textureatlassprite.g();
        float f3 = textureatlassprite.h();
        float f4 = 1.0f;
        float f5 = 0.5f;
        float f6 = 0.25f;
        buq.b(180.0f - bzd.e, 0.0f, 1.0f, 0.0f);
        buq.b((float)(this.b.g.aw == 2 ? -1 : 1) * -bzd.f, 1.0f, 0.0f, 0.0f);
        if (this.e) {
            buq.h();
            buq.e(this.c(entity));
        }
        bufferbuilder.a(7, cdw.j);
        bufferbuilder.b(-0.5, -0.25, 0.0).a(f2, f3).c(0.0f, 1.0f, 0.0f).d();
        bufferbuilder.b(0.5, -0.25, 0.0).a(f1, f3).c(0.0f, 1.0f, 0.0f).d();
        bufferbuilder.b(0.5, 0.75, 0.0).a(f1, f22).c(0.0f, 1.0f, 0.0f).d();
        bufferbuilder.b(-0.5, 0.75, 0.0).a(f2, f22).c(0.0f, 1.0f, 0.0f).d();
        tessellator.b();
        if (this.e) {
            buq.n();
            buq.i();
        }
        buq.E();
        buq.H();
        super.a(entity, x2, y2, z2, entityYaw, partialTicks);
    }

    @Override
    protected nd a(aej entity) {
        return cdn.g;
    }
}

