/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 */
import java.util.Locale;
import org.apache.commons.lang3.StringUtils;

public class cgb
extends nd {
    private final String c;

    protected cgb(int n2, String ... arrstring) {
        super(0, arrstring[0], arrstring[1]);
        this.c = StringUtils.isEmpty((CharSequence)arrstring[2]) ? "normal" : arrstring[2].toLowerCase(Locale.ROOT);
    }

    public cgb(String string) {
        this(0, cgb.b(string));
    }

    public cgb(nd nd2, String string) {
        this(nd2.toString(), string);
    }

    public cgb(String string, String string2) {
        this(0, cgb.b(string + '#' + (string2 == null ? "normal" : string2)));
    }

    protected static String[] b(String string) {
        String[] arrstring = new String[]{null, string, null};
        int \u26032 = string.indexOf(35);
        String \u26033 = string;
        if (\u26032 >= 0) {
            arrstring[2] = string.substring(\u26032 + 1, string.length());
            if (\u26032 > 1) {
                \u26033 = string.substring(0, \u26032);
            }
        }
        System.arraycopy(nd.a(\u26033), 0, arrstring, 0, 2);
        return arrstring;
    }

    public String c() {
        return this.c;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object instanceof cgb && super.equals(object)) {
            cgb cgb2 = (cgb)object;
            return this.c.equals(cgb2.c);
        }
        return false;
    }

    @Override
    public int hashCode() {
        return 31 * super.hashCode() + this.c.hashCode();
    }

    @Override
    public String toString() {
        return super.toString() + '#' + this.c;
    }
}

