/*
 * Decompiled with CFR 0.150.
 */
public class bzg
extends cad<adc> {
    private static final nd a = new nd("textures/entity/illager/evoker.png");

    public bzg(bzd bzd2) {
        super(bzd2, new bpw(0.0f, 0.0f, 64, 64), 0.5f);
        this.a(new cca(this){

            @Override
            public void a(vn vn2, float f2, float f3, float f4, float f5, float f6, float f7, float f8) {
                if (((adk)vn2).dn()) {
                    super.a(vn2, f2, f3, f4, f5, f6, f7, f8);
                }
            }

            @Override
            protected void a(vm vm2) {
                ((bpw)this.b.b()).a(vm2).c(0.0625f);
            }
        });
    }

    @Override
    protected nd a(adc adc2) {
        return a;
    }

    @Override
    protected void a(adc adc2, float f2) {
        \u2603 = 0.9375f;
        buq.b(0.9375f, 0.9375f, 0.9375f);
    }
}

