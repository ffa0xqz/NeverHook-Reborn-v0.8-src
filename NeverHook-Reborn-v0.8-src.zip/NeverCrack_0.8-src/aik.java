/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Multimap
 */
import com.google.common.collect.Multimap;

public class aik
extends ail {
    private final float b;
    protected ail.a a;

    public aik(ail.a a2) {
        this.a = a2;
        this.k = 1;
        this.e(a2.a());
        this.b(ahn.i);
        this.b = a2.c() + 1.0f;
    }

    @Override
    public ub a(aeb aeb2, ams ams2, et et2, tz tz2, fa fa2, float f2, float f3, float f4) {
        ain ain2 = aeb2.b(tz2);
        if (!aeb2.a(et2.a(fa2), fa2, ain2)) {
            return ub.c;
        }
        awr \u26032 = ams2.o(et2);
        aou \u26033 = \u26032.u();
        if (fa2 != fa.a && ams2.o(et2.a()).a() == bcx.a) {
            if (\u26033 == aov.c || \u26033 == aov.da) {
                this.a(ain2, aeb2, ams2, et2, aov.ak.t());
                return ub.a;
            }
            if (\u26033 == aov.d) {
                switch (\u26032.c(apw.a)) {
                    case a: {
                        this.a(ain2, aeb2, ams2, et2, aov.ak.t());
                        return ub.a;
                    }
                    case b: {
                        this.a(ain2, aeb2, ams2, et2, aov.d.t().a(apw.a, apw.a.a));
                        return ub.a;
                    }
                }
            }
        }
        return ub.b;
    }

    @Override
    public boolean a(ain ain2, vn vn2, vn vn3) {
        ain2.a(1, vn3);
        return true;
    }

    protected void a(ain ain2, aeb aeb2, ams ams2, et et2, awr awr2) {
        ams2.a(aeb2, et2, qd.cE, qe.e, 1.0f, 1.0f);
        if (!ams2.G) {
            ams2.a(et2, awr2, 11);
            ain2.a(1, (vn)aeb2);
        }
    }

    @Override
    public boolean D_() {
        return true;
    }

    public String g() {
        return this.a.toString();
    }

    @Override
    public Multimap<String, wc> a(vj vj2) {
        Multimap<String, wc> multimap = super.a(vj2);
        if (vj2 == vj.a) {
            multimap.put((Object)adf.f.a(), (Object)new wc(h, "Weapon modifier", 0.0, 0));
            multimap.put((Object)adf.g.a(), (Object)new wc(i, "Weapon modifier", this.b - 4.0f, 0));
        }
        return multimap;
    }
}

