/*
 * Decompiled with CFR 0.150.
 */
public class ho
extends he {
    private final String b;

    public ho(String string) {
        this.b = string;
    }

    public String g() {
        return this.b;
    }

    @Override
    public String e() {
        return this.b;
    }

    public ho h() {
        ho ho2 = new ho(this.b);
        ho2.a(this.b().m());
        for (hh hh2 : this.a()) {
            ho2.a(hh2.f());
        }
        return ho2;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object instanceof ho) {
            ho ho2 = (ho)object;
            return this.b.equals(ho2.g()) && super.equals(object);
        }
        return false;
    }

    @Override
    public String toString() {
        return "TextComponent{text='" + this.b + '\'' + ", siblings=" + this.a + ", style=" + this.b() + '}';
    }

    @Override
    public /* synthetic */ hh f() {
        return this.h();
    }
}

