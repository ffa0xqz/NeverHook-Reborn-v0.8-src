/*
 * Decompiled with CFR 0.150.
 */
import java.util.Random;

public class aqy
extends aou {
    public aqy(bcx bcx2) {
        super(bcx2);
        this.a(ahn.b);
    }

    @Override
    public int a(int n2, Random random) {
        return ri.a(this.a(random) + random.nextInt(n2 + 1), 1, 4);
    }

    @Override
    public int a(Random random) {
        return 2 + random.nextInt(3);
    }

    @Override
    public ail a(awr awr2, Random random, int n2) {
        return aip.bb;
    }

    @Override
    public bcy c(awr awr2, amw amw2, et et2) {
        return bcy.e;
    }
}

