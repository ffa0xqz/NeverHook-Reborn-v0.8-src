/*
 * Decompiled with CFR 0.150.
 */
public class ayn
extends ayk {
    @Override
    public ayl q() {
        return ayl.a;
    }

    @Override
    public boolean c(int n2, int n3) {
        return !this.b.e(n2, n3);
    }
}

