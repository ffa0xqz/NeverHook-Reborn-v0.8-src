/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonDeserializationContext
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonSerializationContext
 */
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonSerializationContext;
import java.util.Random;

public interface bgr {
    public boolean a(Random var1, ve var2);

    public static abstract class a<T extends bgr> {
        private final nd a;
        private final Class<T> b;

        protected a(nd nd2, Class<T> class_) {
            this.a = nd2;
            this.b = class_;
        }

        public nd a() {
            return this.a;
        }

        public Class<T> b() {
            return this.b;
        }

        public abstract JsonElement a(T var1, JsonSerializationContext var2);

        public abstract T a(JsonElement var1, JsonDeserializationContext var2);
    }
}

