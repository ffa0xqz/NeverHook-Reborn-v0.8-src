/*
 * Decompiled with CFR 0.150.
 */
public class xa
extends xc {
    private final vz d;
    private vn e;
    ams a;
    private final double f;
    private final zc g;
    private int h;
    float b;
    float c;
    private float i;

    public xa(vz vz2, double d2, float f2, float f3) {
        this.d = vz2;
        this.a = vz2.l;
        this.f = d2;
        this.g = vz2.x();
        this.c = f2;
        this.b = f3;
        this.a(3);
        if (!(vz2.x() instanceof zb) && !(vz2.x() instanceof za)) {
            throw new IllegalArgumentException("Unsupported mob type for FollowOwnerGoal");
        }
    }

    @Override
    public boolean a() {
        vn vn2 = this.d.do();
        if (vn2 == null) {
            return false;
        }
        if (vn2 instanceof aeb && ((aeb)vn2).y()) {
            return false;
        }
        if (this.d.dn()) {
            return false;
        }
        if (this.d.h(vn2) < (double)(this.c * this.c)) {
            return false;
        }
        this.e = vn2;
        return true;
    }

    @Override
    public boolean b() {
        return !this.g.o() && this.d.h(this.e) > (double)(this.b * this.b) && !this.d.dn();
    }

    @Override
    public void c() {
        this.h = 0;
        this.i = this.d.a(bef.g);
        this.d.a(bef.g, 0.0f);
    }

    @Override
    public void d() {
        this.e = null;
        this.g.p();
        this.d.a(bef.g, this.i);
    }

    @Override
    public void e() {
        this.d.t().a(this.e, 10.0f, (float)this.d.N());
        if (this.d.dn()) {
            return;
        }
        if (--this.h > 0) {
            return;
        }
        this.h = 10;
        if (this.g.a(this.e, this.f)) {
            return;
        }
        if (this.d.da() || this.d.aS()) {
            return;
        }
        if (this.d.h(this.e) < 144.0) {
            return;
        }
        int n2 = ri.c(this.e.p) - 2;
        \u2603 = ri.c(this.e.r) - 2;
        \u2603 = ri.c(this.e.bw().b);
        for (\u2603 = 0; \u2603 <= 4; ++\u2603) {
            for (\u2603 = 0; \u2603 <= 4; ++\u2603) {
                if (\u2603 >= 1 && \u2603 >= 1 && \u2603 <= 3 && \u2603 <= 3 || !this.a(n2, \u2603, \u2603, \u2603, \u2603)) continue;
                this.d.b((float)(n2 + \u2603) + 0.5f, \u2603, (float)(\u2603 + \u2603) + 0.5f, this.d.v, this.d.w);
                this.g.p();
                return;
            }
        }
    }

    protected boolean a(int n2, int n3, int n4, int n5, int n6) {
        et et2 = new et(n2 + n5, n4 - 1, n3 + n6);
        awr \u26032 = this.a.o(et2);
        return \u26032.d(this.a, et2, fa.a) == awp.a && \u26032.a(this.d) && this.a.d(et2.a()) && this.a.d(et2.b(2));
    }
}

