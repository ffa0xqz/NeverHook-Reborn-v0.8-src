/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import javax.annotation.Nullable;

public class bvf {
    protected final buw a;
    protected final ams b;
    protected int c;
    protected int d;
    protected int e;
    public bxp[] f;

    public bvf(ams worldIn, int renderDistanceChunks, buw renderGlobalIn, bxq renderChunkFactory) {
        this.a = renderGlobalIn;
        this.b = worldIn;
        this.a(renderDistanceChunks);
        this.a(renderChunkFactory);
    }

    protected void a(bxq renderChunkFactory) {
        int i2 = this.d * this.c * this.e;
        this.f = new bxp[i2];
        int j2 = 0;
        for (int k2 = 0; k2 < this.d; ++k2) {
            for (int l2 = 0; l2 < this.c; ++l2) {
                for (int i1 = 0; i1 < this.e; ++i1) {
                    int j1 = (i1 * this.c + l2) * this.d + k2;
                    this.f[j1] = renderChunkFactory.a(this.b, this.a, j2++);
                    this.f[j1].a(k2 * 16, l2 * 16, i1 * 16);
                }
            }
        }
    }

    public void a() {
        for (bxp renderchunk : this.f) {
            renderchunk.a();
        }
    }

    protected void a(int renderDistanceChunks) {
        int i2;
        this.d = i2 = renderDistanceChunks * 2 + 1;
        this.c = 16;
        this.e = i2;
    }

    public void a(double viewEntityX, double viewEntityZ) {
        int i2 = ri.c(viewEntityX) - 8;
        int j2 = ri.c(viewEntityZ) - 8;
        int k2 = this.d * 16;
        for (int l2 = 0; l2 < this.d; ++l2) {
            int i1 = this.a(i2, k2, l2);
            for (int j1 = 0; j1 < this.e; ++j1) {
                int k1 = this.a(j2, k2, j1);
                for (int l1 = 0; l1 < this.c; ++l1) {
                    int i22 = l1 * 16;
                    bxp renderchunk = this.f[(j1 * this.c + l1) * this.d + l2];
                    renderchunk.a(i1, i22, k1);
                }
            }
        }
    }

    private int a(int p_178157_1_, int p_178157_2_, int p_178157_3_) {
        int i2 = p_178157_3_ * 16;
        int j2 = i2 - p_178157_1_ + p_178157_2_ / 2;
        if (j2 < 0) {
            j2 -= p_178157_2_ - 1;
        }
        return i2 - j2 / p_178157_2_ * p_178157_2_;
    }

    public void a(int p_187474_1_, int p_187474_2_, int p_187474_3_, int p_187474_4_, int p_187474_5_, int p_187474_6_, boolean p_187474_7_) {
        int i2 = ri.a(p_187474_1_, 16);
        int j2 = ri.a(p_187474_2_, 16);
        int k2 = ri.a(p_187474_3_, 16);
        int l2 = ri.a(p_187474_4_, 16);
        int i1 = ri.a(p_187474_5_, 16);
        int j1 = ri.a(p_187474_6_, 16);
        for (int k1 = i2; k1 <= l2; ++k1) {
            int l1 = k1 % this.d;
            if (l1 < 0) {
                l1 += this.d;
            }
            for (int i22 = j2; i22 <= i1; ++i22) {
                int j22 = i22 % this.c;
                if (j22 < 0) {
                    j22 += this.c;
                }
                for (int k22 = k2; k22 <= j1; ++k22) {
                    int l22 = k22 % this.e;
                    if (l22 < 0) {
                        l22 += this.e;
                    }
                    int i3 = (l22 * this.c + j22) * this.d + l1;
                    bxp renderchunk = this.f[i3];
                    renderchunk.a(p_187474_7_);
                }
            }
        }
    }

    @Nullable
    public bxp a(et pos) {
        int i2 = pos.p() >> 4;
        int j2 = pos.q() >> 4;
        int k2 = pos.r() >> 4;
        if (j2 >= 0 && j2 < this.c) {
            if ((i2 %= this.d) < 0) {
                i2 += this.d;
            }
            if ((k2 %= this.e) < 0) {
                k2 += this.e;
            }
            int l2 = (k2 * this.c + j2) * this.d + i2;
            return this.f[l2];
        }
        return null;
    }
}

