/*
 * Decompiled with CFR 0.150.
 */
public class bqu
extends bpv {
    public bqu() {
        this(0.0f, false);
    }

    public bqu(float f2, boolean bl2) {
        super(f2, 0.0f, 64, 32);
        if (!bl2) {
            this.h = new brq(this, 40, 16);
            this.h.a(-1.0f, -2.0f, -1.0f, 2, 12, 2, f2);
            this.h.a(-5.0f, 2.0f, 0.0f);
            this.i = new brq(this, 40, 16);
            this.i.i = true;
            this.i.a(-1.0f, -2.0f, -1.0f, 2, 12, 2, f2);
            this.i.a(5.0f, 2.0f, 0.0f);
            this.j = new brq(this, 0, 16);
            this.j.a(-1.0f, 0.0f, -1.0f, 2, 12, 2, f2);
            this.j.a(-2.0f, 12.0f, 0.0f);
            this.k = new brq(this, 0, 16);
            this.k.i = true;
            this.k.a(-1.0f, 0.0f, -1.0f, 2, 12, 2, f2);
            this.k.a(2.0f, 12.0f, 0.0f);
        }
    }

    @Override
    public void a(vn vn2, float f2, float f3, float f4) {
        this.m = bpv.a.a;
        this.l = bpv.a.a;
        ain ain2 = vn2.b(tz.a);
        if (ain2.c() == aip.g && ((acn)vn2).dl()) {
            if (vn2.cF() == vm.b) {
                this.m = bpv.a.d;
            } else {
                this.l = bpv.a.d;
            }
        }
        super.a(vn2, f2, f3, f4);
    }

    @Override
    public void a(float f2, float f3, float f4, float f5, float f6, float f7, ve ve2) {
        super.a(f2, f3, f4, f5, f6, f7, ve2);
        ain ain2 = ((vn)ve2).co();
        acn \u26032 = (acn)ve2;
        if (\u26032.dl() && (ain2.b() || ain2.c() != aip.g)) {
            float f8 = ri.a(this.o * (float)Math.PI);
            \u2603 = ri.a((1.0f - (1.0f - this.o) * (1.0f - this.o)) * (float)Math.PI);
            this.h.h = 0.0f;
            this.i.h = 0.0f;
            this.h.g = -(0.1f - f8 * 0.6f);
            this.i.g = 0.1f - f8 * 0.6f;
            this.h.f = -1.5707964f;
            this.i.f = -1.5707964f;
            this.h.f -= f8 * 1.2f - \u2603 * 0.4f;
            this.i.f -= f8 * 1.2f - \u2603 * 0.4f;
            this.h.h += ri.b(f4 * 0.09f) * 0.05f + 0.05f;
            this.i.h -= ri.b(f4 * 0.09f) * 0.05f + 0.05f;
            this.h.f += ri.a(f4 * 0.067f) * 0.05f;
            this.i.f -= ri.a(f4 * 0.067f) * 0.05f;
        }
    }

    @Override
    public void a(float f2, vm vm2) {
        float f3 = vm2 == vm.b ? 1.0f : -1.0f;
        brq \u26032 = this.a(vm2);
        \u26032.c += f3;
        \u26032.c(f2);
        \u26032.c -= f3;
    }
}

