/*
 * Decompiled with CFR 0.150.
 */
public class xs
extends xc {
    ams a;
    vo b;
    vn c;
    int d;

    public xs(vo vo2) {
        this.b = vo2;
        this.a = vo2.l;
        this.a(3);
    }

    @Override
    public boolean a() {
        vn vn2 = this.b.z();
        if (vn2 == null) {
            return false;
        }
        this.c = vn2;
        return true;
    }

    @Override
    public boolean b() {
        if (!this.c.aC()) {
            return false;
        }
        if (this.b.h(this.c) > 225.0) {
            return false;
        }
        return !this.b.x().o() || this.a();
    }

    @Override
    public void d() {
        this.c = null;
        this.b.x().p();
    }

    @Override
    public void e() {
        this.b.t().a(this.c, 30.0f, 30.0f);
        double d2 = this.b.G * 2.0f * (this.b.G * 2.0f);
        \u2603 = this.b.d(this.c.p, this.c.bw().b, this.c.r);
        \u2603 = 0.8;
        if (\u2603 > d2 && \u2603 < 16.0) {
            \u2603 = 1.33;
        } else if (\u2603 < 225.0) {
            \u2603 = 0.6;
        }
        this.b.x().a(this.c, \u2603);
        this.d = Math.max(this.d - 1, 0);
        if (\u2603 > d2) {
            return;
        }
        if (this.d > 0) {
            return;
        }
        this.d = 20;
        this.b.B(this.c);
    }
}

