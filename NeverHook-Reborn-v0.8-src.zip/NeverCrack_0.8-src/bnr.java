/*
 * Decompiled with CFR 0.150.
 */
import java.util.List;

public interface bnr {
    public void a(List<akr> var1);
}

