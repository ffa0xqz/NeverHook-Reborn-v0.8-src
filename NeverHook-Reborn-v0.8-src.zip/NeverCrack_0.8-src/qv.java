/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Iterators
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Maps
 *  com.google.common.collect.Sets
 */
import com.google.common.collect.Iterators;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import java.util.AbstractSet;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class qv<T>
extends AbstractSet<T> {
    private static final Set<Class<?>> a = Sets.newHashSet();
    private final Map<Class<?>, List<T>> b = Maps.newHashMap();
    private final Set<Class<?>> c = Sets.newIdentityHashSet();
    private final Class<T> d;
    private final List<T> e = Lists.newArrayList();

    public qv(Class<T> class_) {
        this.d = class_;
        this.c.add(class_);
        this.b.put(class_, this.e);
        for (Class<?> class_2 : a) {
            this.a(class_2);
        }
    }

    protected void a(Class<?> class_2) {
        Class<?> class_2;
        a.add(class_2);
        for (T t2 : this.e) {
            if (!class_2.isAssignableFrom(t2.getClass())) continue;
            this.a(t2, class_2);
        }
        this.c.add(class_2);
    }

    protected Class<?> b(Class<?> class_) {
        if (this.d.isAssignableFrom(class_)) {
            if (!this.c.contains(class_)) {
                this.a(class_);
            }
            return class_;
        }
        throw new IllegalArgumentException("Don't know how to search for " + class_);
    }

    @Override
    public boolean add(T t2) {
        for (Class<?> class_ : this.c) {
            if (!class_.isAssignableFrom(t2.getClass())) continue;
            this.a(t2, class_);
        }
        return true;
    }

    private void a(T t2, Class<?> class_) {
        List<T> list = this.b.get(class_);
        if (list == null) {
            this.b.put(class_, Lists.newArrayList((Object[])new Object[]{t2}));
        } else {
            list.add(t2);
        }
    }

    @Override
    public boolean remove(Object object) {
        \u2603 = object;
        boolean bl2 = false;
        for (Class<?> class_ : this.c) {
            if (!class_.isAssignableFrom(\u2603.getClass()) || (\u2603 = this.b.get(class_)) == null || !\u2603.remove(\u2603)) continue;
            bl2 = true;
        }
        return bl2;
    }

    @Override
    public boolean contains(Object object) {
        return Iterators.contains(this.c(object.getClass()).iterator(), (Object)object);
    }

    public <S> Iterable<S> c(final Class<S> class_) {
        return new Iterable<S>(){

            @Override
            public Iterator<S> iterator() {
                List list = (List)qv.this.b.get(qv.this.b(class_));
                if (list == null) {
                    return Collections.emptyIterator();
                }
                Iterator \u26032 = list.iterator();
                return Iterators.filter(\u26032, (Class)class_);
            }
        };
    }

    @Override
    public Iterator<T> iterator() {
        if (this.e.isEmpty()) {
            return Collections.emptyIterator();
        }
        return Iterators.unmodifiableIterator(this.e.iterator());
    }

    @Override
    public int size() {
        return this.e.size();
    }
}

