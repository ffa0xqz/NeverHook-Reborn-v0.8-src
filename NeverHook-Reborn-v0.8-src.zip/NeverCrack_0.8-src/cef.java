/*
 * Decompiled with CFR 0.150.
 */
import java.io.File;

public class cef
extends cec {
    private final File a;

    public cef(File file) {
        this.a = file;
    }

    @Override
    public File a(nd nd2) {
        return new File(this.a, nd2.toString().replace(':', '/'));
    }

    @Override
    public File a() {
        return new File(this.a, "pack.mcmeta");
    }
}

