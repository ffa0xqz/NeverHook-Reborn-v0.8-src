/*
 * Decompiled with CFR 0.150.
 */
import java.util.Random;

public class anz
extends anf {
    protected boolean x;

    protected anz(boolean bl2, anf.a a2) {
        super(a2);
        this.x = bl2;
        this.u.add(new anf.c(aao.class, 5, 2, 6));
        this.u.add(new anf.c(aan.class, 1, 1, 3));
        this.s.z = 0;
        this.s.A = 0.05f;
        this.s.B = 4;
        this.s.C = 10;
    }

    @Override
    public aqp.a a(Random random2, et et2) {
        Random random2;
        double d2 = k.a((double)et2.p() / 200.0, (double)et2.r() / 200.0);
        if (d2 < -0.8) {
            int n2 = random2.nextInt(4);
            switch (n2) {
                case 0: {
                    return aqp.a.g;
                }
                case 1: {
                    return aqp.a.f;
                }
                case 2: {
                    return aqp.a.i;
                }
            }
            return aqp.a.h;
        }
        if (random2.nextInt(3) > 0) {
            int n3 = random2.nextInt(3);
            if (n3 == 0) {
                return aqp.a.b;
            }
            if (n3 == 1) {
                return aqp.a.e;
            }
            return aqp.a.j;
        }
        return aqp.a.a;
    }

    @Override
    public void a(ams ams22, Random random, et et2) {
        ams ams22;
        int n2;
        double d2 = k.a((double)(et2.p() + 8) / 200.0, (double)(et2.r() + 8) / 200.0);
        if (d2 < -0.8) {
            this.s.B = 15;
            this.s.C = 5;
        } else {
            this.s.B = 4;
            this.s.C = 10;
            l.a(apz.b.c);
            for (n2 = 0; n2 < 7; ++n2) {
                \u2603 = random.nextInt(16) + 8;
                \u2603 = random.nextInt(16) + 8;
                \u2603 = random.nextInt(ams22.l(et2.a(\u2603, 0, \u2603)).q() + 32);
                l.b(ams22, random, et2.a(\u2603, \u2603, \u2603));
            }
        }
        if (this.x) {
            l.a(apz.b.a);
            for (n2 = 0; n2 < 10; ++n2) {
                \u2603 = random.nextInt(16) + 8;
                \u2603 = random.nextInt(16) + 8;
                \u2603 = random.nextInt(ams22.l(et2.a(\u2603, 0, \u2603)).q() + 32);
                l.b(ams22, random, et2.a(\u2603, \u2603, \u2603));
            }
        }
        super.a(ams22, random, et2);
    }

    @Override
    public aze a(Random random) {
        if (random.nextInt(3) == 0) {
            return n;
        }
        return m;
    }
}

