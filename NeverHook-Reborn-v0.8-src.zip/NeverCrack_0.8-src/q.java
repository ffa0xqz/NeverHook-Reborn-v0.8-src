/*
 * Decompiled with CFR 0.150.
 */
public interface q {
    public nd a();
}

