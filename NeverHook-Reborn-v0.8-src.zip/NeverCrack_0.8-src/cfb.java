/*
 * Decompiled with CFR 0.150.
 */
public abstract class cfb<T extends cfc>
implements cfd<T> {
}

