/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

public class cu
extends bi {
    @Override
    public String c() {
        return "pardon-ip";
    }

    @Override
    public int a() {
        return 3;
    }

    @Override
    public boolean a(MinecraftServer minecraftServer, bn bn2) {
        return minecraftServer.am().i().b() && super.a(minecraftServer, bn2);
    }

    @Override
    public String b(bn bn2) {
        return "commands.unbanip.usage";
    }

    @Override
    public void a(MinecraftServer minecraftServer, bn bn2, String[] arrstring) throws ei {
        if (arrstring.length != 1 || arrstring[0].length() <= 1) {
            throw new ep("commands.unbanip.usage", new Object[0]);
        }
        Matcher matcher = bs.a.matcher(arrstring[0]);
        if (!matcher.matches()) {
            throw new em("commands.unbanip.invalid", new Object[0]);
        }
        minecraftServer.am().i().c(arrstring[0]);
        cu.a(bn2, (bk)this, "commands.unbanip.success", arrstring[0]);
    }

    @Override
    public List<String> a(MinecraftServer minecraftServer, bn bn2, String[] arrstring, @Nullable et et2) {
        if (arrstring.length == 1) {
            return cu.a(arrstring, minecraftServer.am().i().a());
        }
        return Collections.emptyList();
    }
}

