/*
 * Decompiled with CFR 0.150.
 */
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class gg
extends gk {
    private long b;

    gg() {
    }

    public gg(long l2) {
        this.b = l2;
    }

    @Override
    void a(DataOutput dataOutput) throws IOException {
        dataOutput.writeLong(this.b);
    }

    @Override
    void a(DataInput dataInput, int n2, gh gh2) throws IOException {
        gh2.a(128L);
        this.b = dataInput.readLong();
    }

    @Override
    public byte a() {
        return 4;
    }

    @Override
    public String toString() {
        return this.b + "L";
    }

    public gg c() {
        return new gg(this.b);
    }

    @Override
    public boolean equals(Object object) {
        return super.equals(object) && this.b == ((gg)object).b;
    }

    @Override
    public int hashCode() {
        return super.hashCode() ^ (int)(this.b ^ this.b >>> 32);
    }

    @Override
    public long d() {
        return this.b;
    }

    @Override
    public int e() {
        return (int)(this.b & 0xFFFFFFFFFFFFFFFFL);
    }

    @Override
    public short f() {
        return (short)(this.b & 0xFFFFL);
    }

    @Override
    public byte g() {
        return (byte)(this.b & 0xFFL);
    }

    @Override
    public double h() {
        return this.b;
    }

    @Override
    public float i() {
        return this.b;
    }

    @Override
    public /* synthetic */ gn b() {
        return this.c();
    }
}

