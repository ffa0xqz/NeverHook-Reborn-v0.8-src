/*
 * Decompiled with CFR 0.150.
 */
public class bpn
extends bqd {
    private final brq a;
    private final brq b = new brq(this, 22, 0);

    public bpn() {
        this.b.a(-10.0f, 0.0f, 0.0f, 10, 20, 2, 1.0f);
        this.a = new brq(this, 22, 0);
        this.a.i = true;
        this.a.a(0.0f, 0.0f, 0.0f, 10, 20, 2, 1.0f);
    }

    @Override
    public void a(ve ve2, float f2, float f3, float f4, float f5, float f6, float f7) {
        buq.E();
        buq.r();
        if (ve2 instanceof vn && ((vn)ve2).l_()) {
            buq.G();
            buq.b(0.5f, 0.5f, 0.5f);
            buq.c(0.0f, 1.5f, -0.1f);
            this.b.a(f7);
            this.a.a(f7);
            buq.H();
        } else {
            this.b.a(f7);
            this.a.a(f7);
        }
    }

    @Override
    public void a(float f2, float f3, float f4, float f5, float f6, float f7, ve ve22) {
        float f8;
        ve ve22;
        super.a(f2, f3, f4, f5, f6, f7, ve22);
        float f9 = 0.2617994f;
        \u2603 = -0.2617994f;
        f8 = 0.0f;
        \u2603 = 0.0f;
        if (ve22 instanceof vn && ((vn)ve22).cP()) {
            float \u26032;
            \u26032 = 1.0f;
            if (ve22.t < 0.0) {
                bhc bhc2 = new bhc(ve22.s, ve22.t, ve22.u).a();
                \u26032 = 1.0f - (float)Math.pow(-bhc2.c, 1.5);
            }
            f9 = \u26032 * 0.34906584f + (1.0f - \u26032) * f9;
            \u2603 = \u26032 * -1.5707964f + (1.0f - \u26032) * \u2603;
        } else if (ve22.aU()) {
            f9 = 0.6981317f;
            \u2603 = -0.7853982f;
            f8 = 3.0f;
            \u2603 = 0.08726646f;
        }
        this.b.c = 5.0f;
        this.b.d = f8;
        if (ve22 instanceof bty) {
            bty bty2 = (bty)ve22;
            bty2.a = (float)((double)bty2.a + (double)(f9 - bty2.a) * 0.1);
            bty2.b = (float)((double)bty2.b + (double)(\u2603 - bty2.b) * 0.1);
            bty2.c = (float)((double)bty2.c + (double)(\u2603 - bty2.c) * 0.1);
            this.b.f = bty2.a;
            this.b.g = bty2.b;
            this.b.h = bty2.c;
        } else {
            this.b.f = f9;
            this.b.h = \u2603;
            this.b.g = \u2603;
        }
        this.a.c = -this.b.c;
        this.a.g = -this.b.g;
        this.a.d = this.b.d;
        this.a.f = this.b.f;
        this.a.h = -this.b.h;
    }
}

