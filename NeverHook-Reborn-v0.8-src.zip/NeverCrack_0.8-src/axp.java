/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import javax.annotation.Nullable;

public interface axp {
    @Nullable
    public axu a(int var1, int var2);

    public axu c(int var1, int var2);

    public boolean d();

    public String f();

    public boolean e(int var1, int var2);
}

