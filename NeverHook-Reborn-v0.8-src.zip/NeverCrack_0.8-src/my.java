/*
 * Decompiled with CFR 0.150.
 */
public interface my<T> {
    public void a(gy var1, T var2);

    public T a(gy var1);

    public mx<T> a(int var1);

    public T a(T var1);
}

