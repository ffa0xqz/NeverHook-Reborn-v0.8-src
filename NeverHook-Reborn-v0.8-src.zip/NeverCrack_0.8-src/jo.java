/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.base.MoreObjects
 *  com.google.common.collect.Lists
 *  com.mojang.authlib.GameProfile
 *  com.mojang.authlib.properties.Property
 *  javax.annotation.Nullable
 */
import com.google.common.base.MoreObjects;
import com.google.common.collect.Lists;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import java.io.IOException;
import java.util.List;
import javax.annotation.Nullable;

public class jo
implements ht<hw> {
    private a a;
    private final List<b> b = Lists.newArrayList();

    public jo() {
    }

    public jo(a actionIn, oo ... playersIn) {
        this.a = actionIn;
        for (oo entityplayermp : playersIn) {
            this.b.add(new b(entityplayermp.da(), entityplayermp.g, entityplayermp.c.b(), entityplayermp.K()));
        }
    }

    public jo(a actionIn, Iterable<oo> playersIn) {
        this.a = actionIn;
        for (oo entityplayermp : playersIn) {
            this.b.add(new b(entityplayermp.da(), entityplayermp.g, entityplayermp.c.b(), entityplayermp.K()));
        }
    }

    @Override
    public void a(gy buf2) throws IOException {
        this.a = buf2.a(a.class);
        int i2 = buf2.g();
        for (int j2 = 0; j2 < i2; ++j2) {
            GameProfile gameprofile = null;
            int k2 = 0;
            amq gametype = null;
            hh itextcomponent = null;
            switch (this.a) {
                case a: {
                    gameprofile = new GameProfile(buf2.i(), buf2.e(16));
                    int l2 = buf2.g();
                    for (int i1 = 0; i1 < l2; ++i1) {
                        String s2 = buf2.e(32767);
                        String s1 = buf2.e(32767);
                        if (buf2.readBoolean()) {
                            gameprofile.getProperties().put((Object)s2, (Object)new Property(s2, s1, buf2.e(32767)));
                            continue;
                        }
                        gameprofile.getProperties().put((Object)s2, (Object)new Property(s2, s1));
                    }
                    gametype = amq.a(buf2.g());
                    k2 = buf2.g();
                    if (!buf2.readBoolean()) break;
                    itextcomponent = buf2.f();
                    break;
                }
                case b: {
                    gameprofile = new GameProfile(buf2.i(), null);
                    gametype = amq.a(buf2.g());
                    break;
                }
                case c: {
                    gameprofile = new GameProfile(buf2.i(), null);
                    k2 = buf2.g();
                    break;
                }
                case d: {
                    gameprofile = new GameProfile(buf2.i(), null);
                    if (!buf2.readBoolean()) break;
                    itextcomponent = buf2.f();
                    break;
                }
                case e: {
                    gameprofile = new GameProfile(buf2.i(), null);
                }
            }
            this.b.add(new b(gameprofile, k2, gametype, itextcomponent));
        }
    }

    @Override
    public void b(gy buf2) throws IOException {
        buf2.a(this.a);
        buf2.d(this.b.size());
        for (b spacketplayerlistitem$addplayerdata : this.b) {
            switch (this.a) {
                case a: {
                    buf2.a(spacketplayerlistitem$addplayerdata.a().getId());
                    buf2.a(spacketplayerlistitem$addplayerdata.a().getName());
                    buf2.d(spacketplayerlistitem$addplayerdata.a().getProperties().size());
                    for (Property property : spacketplayerlistitem$addplayerdata.a().getProperties().values()) {
                        buf2.a(property.getName());
                        buf2.a(property.getValue());
                        if (property.hasSignature()) {
                            buf2.writeBoolean(true);
                            buf2.a(property.getSignature());
                            continue;
                        }
                        buf2.writeBoolean(false);
                    }
                    buf2.d(spacketplayerlistitem$addplayerdata.c().a());
                    buf2.d(spacketplayerlistitem$addplayerdata.b());
                    if (spacketplayerlistitem$addplayerdata.d() == null) {
                        buf2.writeBoolean(false);
                        break;
                    }
                    buf2.writeBoolean(true);
                    buf2.a(spacketplayerlistitem$addplayerdata.d());
                    break;
                }
                case b: {
                    buf2.a(spacketplayerlistitem$addplayerdata.a().getId());
                    buf2.d(spacketplayerlistitem$addplayerdata.c().a());
                    break;
                }
                case c: {
                    buf2.a(spacketplayerlistitem$addplayerdata.a().getId());
                    buf2.d(spacketplayerlistitem$addplayerdata.b());
                    break;
                }
                case d: {
                    buf2.a(spacketplayerlistitem$addplayerdata.a().getId());
                    if (spacketplayerlistitem$addplayerdata.d() == null) {
                        buf2.writeBoolean(false);
                        break;
                    }
                    buf2.writeBoolean(true);
                    buf2.a(spacketplayerlistitem$addplayerdata.d());
                    break;
                }
                case e: {
                    buf2.a(spacketplayerlistitem$addplayerdata.a().getId());
                }
            }
        }
    }

    @Override
    public void a(hw handler) {
        handler.a(this);
    }

    public List<b> a() {
        return this.b;
    }

    public a b() {
        return this.a;
    }

    public String toString() {
        return MoreObjects.toStringHelper((Object)this).add("action", (Object)this.a).add("entries", this.b).toString();
    }

    public class b {
        private final int b;
        private final amq c;
        private final GameProfile d;
        private final hh e;

        public b(GameProfile profileIn, int latencyIn, @Nullable amq gameModeIn, hh displayNameIn) {
            this.d = profileIn;
            this.b = latencyIn;
            this.c = gameModeIn;
            this.e = displayNameIn;
        }

        public GameProfile a() {
            return this.d;
        }

        public int b() {
            return this.b;
        }

        public amq c() {
            return this.c;
        }

        @Nullable
        public hh d() {
            return this.e;
        }

        public String toString() {
            return MoreObjects.toStringHelper((Object)this).add("latency", this.b).add("gameMode", (Object)this.c).add("profile", (Object)this.d).add("displayName", this.e == null ? null : hh.a.a(this.e)).toString();
        }
    }

    public static enum a {
        a,
        b,
        c,
        d,
        e;

    }
}

