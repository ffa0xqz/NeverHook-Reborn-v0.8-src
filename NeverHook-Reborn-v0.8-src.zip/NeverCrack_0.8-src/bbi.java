/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  javax.annotation.Nullable
 */
import com.google.common.collect.Lists;
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;

public class bbi {
    public static void a() {
        bbt.a(a.class, "MSCorridor");
        bbt.a(b.class, "MSCrossing");
        bbt.a(d.class, "MSRoom");
        bbt.a(e.class, "MSStairs");
    }

    private static c a(List<bbv> list2, Random random, int n2, int n3, int n4, @Nullable fa fa2, int n5, bbh.a a2) {
        int n6 = random.nextInt(100);
        if (n6 >= 80) {
            bbe bbe2 = b.a(list2, random, n2, n3, n4, fa2);
            if (bbe2 != null) {
                return new b(n5, random, bbe2, fa2, a2);
            }
        } else if (n6 >= 70) {
            bbe bbe3 = e.a(list2, random, n2, n3, n4, fa2);
            if (bbe3 != null) {
                return new e(n5, random, bbe3, fa2, a2);
            }
        } else {
            List<bbv> list2;
            bbe \u26032 = a.a(list2, random, n2, n3, n4, fa2);
            if (\u26032 != null) {
                return new a(n5, random, \u26032, fa2, a2);
            }
        }
        return null;
    }

    private static c b(bbv bbv2, List<bbv> list, Random random, int n2, int n3, int n4, fa fa2, int n5) {
        if (n5 > 8) {
            return null;
        }
        if (Math.abs(n2 - bbv2.d().a) > 80 || Math.abs(n4 - bbv2.d().c) > 80) {
            return null;
        }
        bbh.a a2 = ((c)bbv2).a;
        c \u26032 = bbi.a(list, random, n2, n3, n4, fa2, n5 + 1, a2);
        if (\u26032 != null) {
            list.add(\u26032);
            \u26032.a(bbv2, list, random);
        }
        return \u26032;
    }

    public static class e
    extends c {
        public e() {
        }

        public e(int n2, Random random, bbe bbe2, fa fa2, bbh.a a2) {
            super(n2, a2);
            this.a(fa2);
            this.l = bbe2;
        }

        public static bbe a(List<bbv> list, Random random, int n2, int n3, int n4, fa fa2) {
            bbe bbe2 = new bbe(n2, n3 - 5, n4, n2, n3 + 2, n4);
            switch (fa2) {
                default: {
                    bbe2.d = n2 + 2;
                    bbe2.c = n4 - 8;
                    break;
                }
                case d: {
                    bbe2.d = n2 + 2;
                    bbe2.f = n4 + 8;
                    break;
                }
                case e: {
                    bbe2.a = n2 - 8;
                    bbe2.f = n4 + 2;
                    break;
                }
                case f: {
                    bbe2.d = n2 + 8;
                    bbe2.f = n4 + 2;
                }
            }
            if (bbv.a(list, bbe2) != null) {
                return null;
            }
            return bbe2;
        }

        @Override
        public void a(bbv bbv2, List<bbv> list, Random random) {
            int n2 = this.e();
            fa \u26032 = this.f();
            if (\u26032 != null) {
                switch (\u26032) {
                    default: {
                        bbi.b(bbv2, list, random, this.l.a, this.l.b, this.l.c - 1, fa.c, n2);
                        break;
                    }
                    case d: {
                        bbi.b(bbv2, list, random, this.l.a, this.l.b, this.l.f + 1, fa.d, n2);
                        break;
                    }
                    case e: {
                        bbi.b(bbv2, list, random, this.l.a - 1, this.l.b, this.l.c, fa.e, n2);
                        break;
                    }
                    case f: {
                        bbi.b(bbv2, list, random, this.l.d + 1, this.l.b, this.l.c, fa.f, n2);
                    }
                }
            }
        }

        @Override
        public boolean a(ams ams2, Random random, bbe bbe2) {
            if (this.a(ams2, bbe2)) {
                return false;
            }
            this.a(ams2, bbe2, 0, 5, 0, 2, 7, 1, aov.a.t(), aov.a.t(), false);
            this.a(ams2, bbe2, 0, 0, 7, 2, 2, 8, aov.a.t(), aov.a.t(), false);
            for (int i2 = 0; i2 < 5; ++i2) {
                this.a(ams2, bbe2, 0, 5 - i2 - (i2 < 4 ? 1 : 0), 2 + i2, 2, 7 - i2, 2 + i2, aov.a.t(), aov.a.t(), false);
            }
            return true;
        }
    }

    public static class b
    extends c {
        private fa b;
        private boolean c;

        public b() {
        }

        @Override
        protected void a(fy fy2) {
            super.a(fy2);
            fy2.a("tf", this.c);
            fy2.a("D", this.b.b());
        }

        @Override
        protected void a(fy fy2, bce bce2) {
            super.a(fy2, bce2);
            this.c = fy2.q("tf");
            this.b = fa.b(fy2.h("D"));
        }

        public b(int n2, Random random, bbe bbe2, @Nullable fa fa2, bbh.a a2) {
            super(n2, a2);
            this.b = fa2;
            this.l = bbe2;
            this.c = bbe2.d() > 3;
        }

        public static bbe a(List<bbv> list, Random random, int n2, int n3, int n4, fa fa2) {
            bbe bbe2 = new bbe(n2, n3, n4, n2, n3 + 2, n4);
            if (random.nextInt(4) == 0) {
                bbe2.e += 4;
            }
            switch (fa2) {
                default: {
                    bbe2.a = n2 - 1;
                    bbe2.d = n2 + 3;
                    bbe2.c = n4 - 4;
                    break;
                }
                case d: {
                    bbe2.a = n2 - 1;
                    bbe2.d = n2 + 3;
                    bbe2.f = n4 + 3 + 1;
                    break;
                }
                case e: {
                    bbe2.a = n2 - 4;
                    bbe2.c = n4 - 1;
                    bbe2.f = n4 + 3;
                    break;
                }
                case f: {
                    bbe2.d = n2 + 3 + 1;
                    bbe2.c = n4 - 1;
                    bbe2.f = n4 + 3;
                }
            }
            if (bbv.a(list, bbe2) != null) {
                return null;
            }
            return bbe2;
        }

        @Override
        public void a(bbv bbv2, List<bbv> list, Random random) {
            int n2 = this.e();
            switch (this.b) {
                default: {
                    bbi.b(bbv2, list, random, this.l.a + 1, this.l.b, this.l.c - 1, fa.c, n2);
                    bbi.b(bbv2, list, random, this.l.a - 1, this.l.b, this.l.c + 1, fa.e, n2);
                    bbi.b(bbv2, list, random, this.l.d + 1, this.l.b, this.l.c + 1, fa.f, n2);
                    break;
                }
                case d: {
                    bbi.b(bbv2, list, random, this.l.a + 1, this.l.b, this.l.f + 1, fa.d, n2);
                    bbi.b(bbv2, list, random, this.l.a - 1, this.l.b, this.l.c + 1, fa.e, n2);
                    bbi.b(bbv2, list, random, this.l.d + 1, this.l.b, this.l.c + 1, fa.f, n2);
                    break;
                }
                case e: {
                    bbi.b(bbv2, list, random, this.l.a + 1, this.l.b, this.l.c - 1, fa.c, n2);
                    bbi.b(bbv2, list, random, this.l.a + 1, this.l.b, this.l.f + 1, fa.d, n2);
                    bbi.b(bbv2, list, random, this.l.a - 1, this.l.b, this.l.c + 1, fa.e, n2);
                    break;
                }
                case f: {
                    bbi.b(bbv2, list, random, this.l.a + 1, this.l.b, this.l.c - 1, fa.c, n2);
                    bbi.b(bbv2, list, random, this.l.a + 1, this.l.b, this.l.f + 1, fa.d, n2);
                    bbi.b(bbv2, list, random, this.l.d + 1, this.l.b, this.l.c + 1, fa.f, n2);
                }
            }
            if (this.c) {
                if (random.nextBoolean()) {
                    bbi.b(bbv2, list, random, this.l.a + 1, this.l.b + 3 + 1, this.l.c - 1, fa.c, n2);
                }
                if (random.nextBoolean()) {
                    bbi.b(bbv2, list, random, this.l.a - 1, this.l.b + 3 + 1, this.l.c + 1, fa.e, n2);
                }
                if (random.nextBoolean()) {
                    bbi.b(bbv2, list, random, this.l.d + 1, this.l.b + 3 + 1, this.l.c + 1, fa.f, n2);
                }
                if (random.nextBoolean()) {
                    bbi.b(bbv2, list, random, this.l.a + 1, this.l.b + 3 + 1, this.l.f + 1, fa.d, n2);
                }
            }
        }

        @Override
        public boolean a(ams ams2, Random random, bbe bbe2) {
            if (this.a(ams2, bbe2)) {
                return false;
            }
            awr awr2 = this.G_();
            if (this.c) {
                this.a(ams2, bbe2, this.l.a + 1, this.l.b, this.l.c, this.l.d - 1, this.l.b + 3 - 1, this.l.f, aov.a.t(), aov.a.t(), false);
                this.a(ams2, bbe2, this.l.a, this.l.b, this.l.c + 1, this.l.d, this.l.b + 3 - 1, this.l.f - 1, aov.a.t(), aov.a.t(), false);
                this.a(ams2, bbe2, this.l.a + 1, this.l.e - 2, this.l.c, this.l.d - 1, this.l.e, this.l.f, aov.a.t(), aov.a.t(), false);
                this.a(ams2, bbe2, this.l.a, this.l.e - 2, this.l.c + 1, this.l.d, this.l.e, this.l.f - 1, aov.a.t(), aov.a.t(), false);
                this.a(ams2, bbe2, this.l.a + 1, this.l.b + 3, this.l.c + 1, this.l.d - 1, this.l.b + 3, this.l.f - 1, aov.a.t(), aov.a.t(), false);
            } else {
                this.a(ams2, bbe2, this.l.a + 1, this.l.b, this.l.c, this.l.d - 1, this.l.e, this.l.f, aov.a.t(), aov.a.t(), false);
                this.a(ams2, bbe2, this.l.a, this.l.b, this.l.c + 1, this.l.d, this.l.e, this.l.f - 1, aov.a.t(), aov.a.t(), false);
            }
            this.b(ams2, bbe2, this.l.a + 1, this.l.b, this.l.c + 1, this.l.e);
            this.b(ams2, bbe2, this.l.a + 1, this.l.b, this.l.f - 1, this.l.e);
            this.b(ams2, bbe2, this.l.d - 1, this.l.b, this.l.c + 1, this.l.e);
            this.b(ams2, bbe2, this.l.d - 1, this.l.b, this.l.f - 1, this.l.e);
            for (int i2 = this.l.a; i2 <= this.l.d; ++i2) {
                for (\u2603 = this.l.c; \u2603 <= this.l.f; ++\u2603) {
                    if (this.a(ams2, i2, this.l.b - 1, \u2603, bbe2).a() != bcx.a || this.b(ams2, i2, this.l.b - 1, \u2603, bbe2) >= 8) continue;
                    this.a(ams2, awr2, i2, this.l.b - 1, \u2603, bbe2);
                }
            }
            return true;
        }

        private void b(ams ams2, bbe bbe2, int n2, int n3, int n4, int n5) {
            if (this.a(ams2, n2, n5 + 1, n4, bbe2).a() != bcx.a) {
                this.a(ams2, bbe2, n2, n3, n4, n2, n5, n4, this.G_(), aov.a.t(), false);
            }
        }
    }

    public static class a
    extends c {
        private boolean b;
        private boolean c;
        private boolean d;
        private int e;

        public a() {
        }

        @Override
        protected void a(fy fy2) {
            super.a(fy2);
            fy2.a("hr", this.b);
            fy2.a("sc", this.c);
            fy2.a("hps", this.d);
            fy2.a("Num", this.e);
        }

        @Override
        protected void a(fy fy2, bce bce2) {
            super.a(fy2, bce2);
            this.b = fy2.q("hr");
            this.c = fy2.q("sc");
            this.d = fy2.q("hps");
            this.e = fy2.h("Num");
        }

        public a(int n2, Random random, bbe bbe2, fa fa2, bbh.a a2) {
            super(n2, a2);
            this.a(fa2);
            this.l = bbe2;
            this.b = random.nextInt(3) == 0;
            this.c = !this.b && random.nextInt(23) == 0;
            this.e = this.f().k() == fa.a.c ? bbe2.e() / 5 : bbe2.c() / 5;
        }

        public static bbe a(List<bbv> list, Random random, int n2, int n3, int n4, fa fa2) {
            int n5;
            bbe bbe2 = new bbe(n2, n3, n4, n2, n3 + 2, n4);
            for (n5 = random.nextInt(3) + 2; n5 > 0; --n5) {
                \u2603 = n5 * 5;
                switch (fa2) {
                    default: {
                        bbe2.d = n2 + 2;
                        bbe2.c = n4 - (\u2603 - 1);
                        break;
                    }
                    case d: {
                        bbe2.d = n2 + 2;
                        bbe2.f = n4 + (\u2603 - 1);
                        break;
                    }
                    case e: {
                        bbe2.a = n2 - (\u2603 - 1);
                        bbe2.f = n4 + 2;
                        break;
                    }
                    case f: {
                        bbe2.d = n2 + (\u2603 - 1);
                        bbe2.f = n4 + 2;
                    }
                }
                if (bbv.a(list, bbe2) == null) break;
            }
            if (n5 > 0) {
                return bbe2;
            }
            return null;
        }

        @Override
        public void a(bbv bbv2, List<bbv> list, Random random) {
            block24: {
                int n2 = this.e();
                \u2603 = random.nextInt(4);
                fa \u26032 = this.f();
                if (\u26032 != null) {
                    switch (\u26032) {
                        default: {
                            if (\u2603 <= 1) {
                                bbi.b(bbv2, list, random, this.l.a, this.l.b - 1 + random.nextInt(3), this.l.c - 1, \u26032, n2);
                                break;
                            }
                            if (\u2603 == 2) {
                                bbi.b(bbv2, list, random, this.l.a - 1, this.l.b - 1 + random.nextInt(3), this.l.c, fa.e, n2);
                                break;
                            }
                            bbi.b(bbv2, list, random, this.l.d + 1, this.l.b - 1 + random.nextInt(3), this.l.c, fa.f, n2);
                            break;
                        }
                        case d: {
                            if (\u2603 <= 1) {
                                bbi.b(bbv2, list, random, this.l.a, this.l.b - 1 + random.nextInt(3), this.l.f + 1, \u26032, n2);
                                break;
                            }
                            if (\u2603 == 2) {
                                bbi.b(bbv2, list, random, this.l.a - 1, this.l.b - 1 + random.nextInt(3), this.l.f - 3, fa.e, n2);
                                break;
                            }
                            bbi.b(bbv2, list, random, this.l.d + 1, this.l.b - 1 + random.nextInt(3), this.l.f - 3, fa.f, n2);
                            break;
                        }
                        case e: {
                            if (\u2603 <= 1) {
                                bbi.b(bbv2, list, random, this.l.a - 1, this.l.b - 1 + random.nextInt(3), this.l.c, \u26032, n2);
                                break;
                            }
                            if (\u2603 == 2) {
                                bbi.b(bbv2, list, random, this.l.a, this.l.b - 1 + random.nextInt(3), this.l.c - 1, fa.c, n2);
                                break;
                            }
                            bbi.b(bbv2, list, random, this.l.a, this.l.b - 1 + random.nextInt(3), this.l.f + 1, fa.d, n2);
                            break;
                        }
                        case f: {
                            if (\u2603 <= 1) {
                                bbi.b(bbv2, list, random, this.l.d + 1, this.l.b - 1 + random.nextInt(3), this.l.c, \u26032, n2);
                                break;
                            }
                            if (\u2603 == 2) {
                                bbi.b(bbv2, list, random, this.l.d - 3, this.l.b - 1 + random.nextInt(3), this.l.c - 1, fa.c, n2);
                                break;
                            }
                            bbi.b(bbv2, list, random, this.l.d - 3, this.l.b - 1 + random.nextInt(3), this.l.f + 1, fa.d, n2);
                        }
                    }
                }
                if (n2 >= 8) break block24;
                if (\u26032 == fa.c || \u26032 == fa.d) {
                    \u2603 = this.l.c + 3;
                    while (\u2603 + 3 <= this.l.f) {
                        \u2603 = random.nextInt(5);
                        if (\u2603 == 0) {
                            bbi.b(bbv2, list, random, this.l.a - 1, this.l.b, \u2603, fa.e, n2 + 1);
                        } else if (\u2603 == 1) {
                            bbi.b(bbv2, list, random, this.l.d + 1, this.l.b, \u2603, fa.f, n2 + 1);
                        }
                        \u2603 += 5;
                    }
                } else {
                    \u2603 = this.l.a + 3;
                    while (\u2603 + 3 <= this.l.d) {
                        \u2603 = random.nextInt(5);
                        if (\u2603 == 0) {
                            bbi.b(bbv2, list, random, \u2603, this.l.b, this.l.c - 1, fa.c, n2 + 1);
                        } else if (\u2603 == 1) {
                            bbi.b(bbv2, list, random, \u2603, this.l.b, this.l.f + 1, fa.d, n2 + 1);
                        }
                        \u2603 += 5;
                    }
                }
            }
        }

        @Override
        protected boolean a(ams ams2, bbe bbe2, Random random, int n2, int n3, int n4, nd nd2) {
            et et2 = new et(this.a(n2, n4), this.d(n3), this.b(n2, n4));
            if (bbe2.b(et2) && ams2.o(et2).a() == bcx.a && ams2.o(et2.b()).a() != bcx.a) {
                awr awr2 = aov.av.t().a(asz.d, random.nextBoolean() ? aoq.b.a : aoq.b.b);
                this.a(ams2, awr2, n2, n3, n4, bbe2);
                afd \u26032 = new afd(ams2, (float)et2.p() + 0.5f, (float)et2.q() + 0.5f, (float)et2.r() + 0.5f);
                \u26032.a(nd2, random.nextLong());
                ams2.a(\u26032);
                return true;
            }
            return false;
        }

        @Override
        public boolean a(ams ams2, Random random, bbe bbe2) {
            int n2;
            if (this.a(ams2, bbe2)) {
                return false;
            }
            boolean bl2 = false;
            int \u26032 = 2;
            \u2603 = false;
            int \u26033 = 2;
            int \u26034 = this.e * 5 - 1;
            awr \u26035 = this.G_();
            this.a(ams2, bbe2, 0, 0, 0, 2, 1, \u26034, aov.a.t(), aov.a.t(), false);
            this.a(ams2, bbe2, random, 0.8f, 0, 2, 0, 2, 2, \u26034, aov.a.t(), aov.a.t(), false, 0);
            if (this.c) {
                this.a(ams2, bbe2, random, 0.6f, 0, 0, 0, 2, 1, \u26034, aov.G.t(), aov.a.t(), false, 8);
            }
            for (n2 = 0; n2 < this.e; ++n2) {
                i2 = 2 + n2 * 5;
                this.a(ams2, bbe2, 0, 0, i2, 2, 2, random);
                this.a(ams2, bbe2, random, 0.1f, 0, 2, i2 - 1);
                this.a(ams2, bbe2, random, 0.1f, 2, 2, i2 - 1);
                this.a(ams2, bbe2, random, 0.1f, 0, 2, i2 + 1);
                this.a(ams2, bbe2, random, 0.1f, 2, 2, i2 + 1);
                this.a(ams2, bbe2, random, 0.05f, 0, 2, i2 - 2);
                this.a(ams2, bbe2, random, 0.05f, 2, 2, i2 - 2);
                this.a(ams2, bbe2, random, 0.05f, 0, 2, i2 + 2);
                this.a(ams2, bbe2, random, 0.05f, 2, 2, i2 + 2);
                if (random.nextInt(100) == 0) {
                    this.a(ams2, bbe2, random, 2, 0, i2 - 1, bfl.f);
                }
                if (random.nextInt(100) == 0) {
                    this.a(ams2, bbe2, random, 0, 0, i2 + 1, bfl.f);
                }
                if (!this.c || this.d) continue;
                \u2603 = this.d(0);
                \u2603 = i2 - 1 + random.nextInt(3);
                \u26037 = this.a(1, \u2603);
                et et2 = new et(\u26037, \u2603, \u2603 = this.b(1, \u2603));
                if (!bbe2.b(et2) || this.b(ams2, 1, 0, \u2603, bbe2) >= 8) continue;
                this.d = true;
                ams2.a(et2, aov.ac.t(), 2);
                avh \u26036 = ams2.r(et2);
                if (!(\u26036 instanceof avw)) continue;
                ((avw)\u26036).a().a(vg.a(acp.class));
            }
            for (n2 = 0; n2 <= 2; ++n2) {
                for (i2 = 0; i2 <= \u26034; ++i2) {
                    \u2603 = -1;
                    awr awr2 = this.a(ams2, n2, -1, i2, bbe2);
                    if (awr2.a() != bcx.a || this.b(ams2, n2, -1, i2, bbe2) >= 8) continue;
                    int \u26037 = -1;
                    this.a(ams2, \u26035, n2, -1, i2, bbe2);
                }
            }
            if (this.b) {
                \u2603 = aov.av.t().a(asz.d, aoq.b.a);
                for (int i2 = 0; i2 <= \u26034; ++i2) {
                    awr awr3 = this.a(ams2, 1, -1, i2, bbe2);
                    if (awr3.a() == bcx.a || !awr3.b()) continue;
                    float \u26038 = this.b(ams2, 1, 0, i2, bbe2) > 8 ? 0.9f : 0.7f;
                    this.a(ams2, bbe2, random, \u26038, 1, 0, i2, \u2603);
                }
            }
            return true;
        }

        private void a(ams ams2, bbe bbe2, int n2, int n3, int n4, int n5, int n6, Random random) {
            if (!this.a(ams2, bbe2, n2, n6, n5, n4)) {
                return;
            }
            awr awr2 = this.G_();
            \u2603 = this.b();
            \u2603 = aov.a.t();
            this.a(ams2, bbe2, n2, n3, n4, n2, n5 - 1, n4, \u2603, \u2603, false);
            this.a(ams2, bbe2, n6, n3, n4, n6, n5 - 1, n4, \u2603, \u2603, false);
            if (random.nextInt(4) == 0) {
                this.a(ams2, bbe2, n2, n5, n4, n2, n5, n4, awr2, \u2603, false);
                this.a(ams2, bbe2, n6, n5, n4, n6, n5, n4, awr2, \u2603, false);
            } else {
                this.a(ams2, bbe2, n2, n5, n4, n6, n5, n4, awr2, \u2603, false);
                this.a(ams2, bbe2, random, 0.05f, n2 + 1, n5, n4 - 1, aov.aa.t().a(auo.a, fa.c));
                this.a(ams2, bbe2, random, 0.05f, n2 + 1, n5, n4 + 1, aov.aa.t().a(auo.a, fa.d));
            }
        }

        private void a(ams ams2, bbe bbe2, Random random, float f2, int n2, int n3, int n4) {
            if (this.b(ams2, n2, n3, n4, bbe2) < 8) {
                this.a(ams2, bbe2, random, f2, n2, n3, n4, aov.G.t());
            }
        }
    }

    public static class d
    extends c {
        private final List<bbe> b = Lists.newLinkedList();

        public d() {
        }

        public d(int n2, Random random, int n3, int n4, bbh.a a2) {
            super(n2, a2);
            this.a = a2;
            this.l = new bbe(n3, 50, n4, n3 + 7 + random.nextInt(6), 54 + random.nextInt(6), n4 + 7 + random.nextInt(6));
        }

        @Override
        public void a(bbv bbv2, List<bbv> list, Random random) {
            int n2;
            bbe \u26032;
            c c2;
            int n3 = this.e();
            \u2603 = this.l.d() - 3 - 1;
            if (\u2603 <= 0) {
                \u2603 = 1;
            }
            for (n2 = 0; n2 < this.l.c() && (n2 += random.nextInt(this.l.c())) + 3 <= this.l.c(); n2 += 4) {
                c2 = bbi.b(bbv2, list, random, this.l.a + n2, this.l.b + random.nextInt(\u2603) + 1, this.l.c - 1, fa.c, n3);
                if (c2 == null) continue;
                \u26032 = c2.d();
                this.b.add(new bbe(\u26032.a, \u26032.b, this.l.c, \u26032.d, \u26032.e, this.l.c + 1));
            }
            for (n2 = 0; n2 < this.l.c() && (n2 += random.nextInt(this.l.c())) + 3 <= this.l.c(); n2 += 4) {
                c2 = bbi.b(bbv2, list, random, this.l.a + n2, this.l.b + random.nextInt(\u2603) + 1, this.l.f + 1, fa.d, n3);
                if (c2 == null) continue;
                \u26032 = c2.d();
                this.b.add(new bbe(\u26032.a, \u26032.b, this.l.f - 1, \u26032.d, \u26032.e, this.l.f));
            }
            for (n2 = 0; n2 < this.l.e() && (n2 += random.nextInt(this.l.e())) + 3 <= this.l.e(); n2 += 4) {
                c2 = bbi.b(bbv2, list, random, this.l.a - 1, this.l.b + random.nextInt(\u2603) + 1, this.l.c + n2, fa.e, n3);
                if (c2 == null) continue;
                \u26032 = c2.d();
                this.b.add(new bbe(this.l.a, \u26032.b, \u26032.c, this.l.a + 1, \u26032.e, \u26032.f));
            }
            for (n2 = 0; n2 < this.l.e() && (n2 += random.nextInt(this.l.e())) + 3 <= this.l.e(); n2 += 4) {
                c2 = bbi.b(bbv2, list, random, this.l.d + 1, this.l.b + random.nextInt(\u2603) + 1, this.l.c + n2, fa.f, n3);
                if (c2 == null) continue;
                \u26032 = c2.d();
                this.b.add(new bbe(this.l.d - 1, \u26032.b, \u26032.c, this.l.d, \u26032.e, \u26032.f));
            }
        }

        @Override
        public boolean a(ams ams2, Random random, bbe bbe2) {
            if (this.a(ams2, bbe2)) {
                return false;
            }
            this.a(ams2, bbe2, this.l.a, this.l.b, this.l.c, this.l.d, this.l.b, this.l.f, aov.d.t(), aov.a.t(), true);
            this.a(ams2, bbe2, this.l.a, this.l.b + 1, this.l.c, this.l.d, Math.min(this.l.b + 3, this.l.e), this.l.f, aov.a.t(), aov.a.t(), false);
            for (bbe bbe3 : this.b) {
                this.a(ams2, bbe2, bbe3.a, bbe3.e - 2, bbe3.c, bbe3.d, bbe3.e, bbe3.f, aov.a.t(), aov.a.t(), false);
            }
            this.a(ams2, bbe2, this.l.a, this.l.b + 4, this.l.c, this.l.d, this.l.e, this.l.f, aov.a.t(), false);
            return true;
        }

        @Override
        public void a(int n2, int n3, int n4) {
            super.a(n2, n3, n4);
            for (bbe bbe2 : this.b) {
                bbe2.a(n2, n3, n4);
            }
        }

        @Override
        protected void a(fy fy22) {
            fy fy22;
            super.a(fy22);
            ge ge2 = new ge();
            for (bbe bbe2 : this.b) {
                ge2.a(bbe2.g());
            }
            fy22.a("Entrances", ge2);
        }

        @Override
        protected void a(fy fy2, bce bce2) {
            super.a(fy2, bce2);
            ge ge2 = fy2.c("Entrances", 11);
            for (int i2 = 0; i2 < ge2.c(); ++i2) {
                this.b.add(new bbe(ge2.d(i2)));
            }
        }
    }

    static abstract class c
    extends bbv {
        protected bbh.a a;

        public c() {
        }

        public c(int n2, bbh.a a2) {
            super(n2);
            this.a = a2;
        }

        @Override
        protected void a(fy fy2) {
            fy2.a("MST", this.a.ordinal());
        }

        @Override
        protected void a(fy fy2, bce bce2) {
            this.a = bbh.a.a(fy2.h("MST"));
        }

        protected awr G_() {
            switch (this.a) {
                default: {
                    return aov.f.t();
                }
                case b: 
            }
            return aov.f.t().a(asp.a, asp.a.f);
        }

        protected awr b() {
            switch (this.a) {
                default: {
                    return aov.aO.t();
                }
                case b: 
            }
            return aov.aS.t();
        }

        protected boolean a(ams ams2, bbe bbe2, int n2, int n3, int n4, int n5) {
            for (\u2603 = n2; \u2603 <= n3; ++\u2603) {
                if (this.a(ams2, \u2603, n4 + 1, n5, bbe2).a() != bcx.a) continue;
                return false;
            }
            return true;
        }
    }
}

