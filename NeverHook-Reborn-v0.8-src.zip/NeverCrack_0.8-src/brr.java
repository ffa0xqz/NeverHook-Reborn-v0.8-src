/*
 * Decompiled with CFR 0.150.
 */
public class brr {
    public final int a;
    public final int b;

    public brr(int n2, int n3) {
        this.a = n2;
        this.b = n3;
    }
}

