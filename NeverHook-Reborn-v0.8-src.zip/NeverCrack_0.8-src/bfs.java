/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonDeserializationContext
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonSerializationContext
 */
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import java.util.Collection;
import java.util.List;
import java.util.Random;

public class bfs
extends bfp {
    protected final nd a;

    public bfs(nd nd2, int n2, int n3, bgj[] arrbgj) {
        super(n2, n3, arrbgj);
        this.a = nd2;
    }

    @Override
    public void a(Collection<ain> collection, Random random, bfr bfr2) {
        bfq bfq2 = bfr2.e().a(this.a);
        List<ain> \u26032 = bfq2.a(random, bfr2);
        collection.addAll(\u26032);
    }

    @Override
    protected void a(JsonObject jsonObject, JsonSerializationContext jsonSerializationContext) {
        jsonObject.addProperty("name", this.a.toString());
    }

    public static bfs a(JsonObject jsonObject, JsonDeserializationContext jsonDeserializationContext, int n2, int n3, bgj[] arrbgj) {
        nd nd2 = new nd(ra.h(jsonObject, "name"));
        return new bfs(nd2, n2, n3, arrbgj);
    }
}

