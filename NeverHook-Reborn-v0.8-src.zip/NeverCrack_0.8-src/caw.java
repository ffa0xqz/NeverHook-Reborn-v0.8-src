/*
 * Decompiled with CFR 0.150.
 */
public class caw
extends caq {
    private static final nd a = new nd("textures/entity/skeleton/stray.png");

    public caw(bzd bzd2) {
        super(bzd2);
        this.a(new ccj(this));
    }

    @Override
    protected nd a(acn acn2) {
        return a;
    }
}

