/*
 * Decompiled with CFR 0.150.
 */
import java.util.Random;

public class apx
extends aoo {
    public static final axe a = apv.H;
    public static final axd b = axd.a("triggered");
    public static final ez<ail, fb> c = new ez(new ex());
    protected Random d = new Random();

    protected apx() {
        super(bcx.e);
        this.w(this.A.b().a(a, fa.c).a(b, false));
        this.a(ahn.d);
    }

    @Override
    public int a(ams ams2) {
        return 4;
    }

    @Override
    public void c(ams ams2, et et2, awr awr2) {
        super.c(ams2, et2, awr2);
        this.e(ams2, et2, awr2);
    }

    private void e(ams ams22, et et2, awr awr2) {
        ams ams22;
        if (ams22.G) {
            return;
        }
        fa fa2 = awr2.c(a);
        boolean \u26032 = ams22.o(et2.c()).b();
        boolean \u26033 = ams22.o(et2.d()).b();
        if (fa2 == fa.c && \u26032 && !\u26033) {
            fa2 = fa.d;
        } else if (fa2 == fa.d && \u26033 && !\u26032) {
            fa2 = fa.c;
        } else {
            boolean bl2 = ams22.o(et2.e()).b();
            \u2603 = ams22.o(et2.f()).b();
            if (fa2 == fa.e && bl2 && !\u2603) {
                fa2 = fa.f;
            } else if (fa2 == fa.f && \u2603 && !bl2) {
                fa2 = fa.e;
            }
        }
        ams22.a(et2, awr2.a(a, fa2).a(b, false), 2);
    }

    @Override
    public boolean a(ams ams2, et et2, awr awr2, aeb aeb2, tz tz2, fa fa2, float f2, float f3, float f4) {
        if (ams2.G) {
            return true;
        }
        avh avh2 = ams2.r(et2);
        if (avh2 instanceof avn) {
            aeb2.a((avn)avh2);
            if (avh2 instanceof avo) {
                aeb2.b(qq.O);
            } else {
                aeb2.b(qq.Q);
            }
        }
        return true;
    }

    protected void c(ams ams2, et et2) {
        ev ev2 = new ev(ams2, et2);
        avn \u26032 = (avn)ev2.g();
        if (\u26032 == null) {
            return;
        }
        int \u26033 = \u26032.o();
        if (\u26033 < 0) {
            ams2.b(1001, et2, 0);
            return;
        }
        ain \u26034 = \u26032.a(\u26033);
        fb \u26035 = this.a(\u26034);
        if (\u26035 != fb.a) {
            \u26032.a(\u26033, \u26035.a(ev2, \u26034));
        }
    }

    protected fb a(ain ain2) {
        return c.c(ain2.c());
    }

    @Override
    public void a(awr awr2, ams ams2, et et2, aou aou2, et et3) {
        boolean bl2 = ams2.y(et2) || ams2.y(et2.a());
        \u2603 = awr2.c(b);
        if (bl2 && !\u2603) {
            ams2.a(et2, (aou)this, this.a(ams2));
            ams2.a(et2, awr2.a(b, true), 4);
        } else if (!bl2 && \u2603) {
            ams2.a(et2, awr2.a(b, false), 4);
        }
    }

    @Override
    public void b(ams ams2, et et2, awr awr2, Random random) {
        if (!ams2.G) {
            this.c(ams2, et2);
        }
    }

    @Override
    public avh a(ams ams2, int n2) {
        return new avn();
    }

    @Override
    public awr a(ams ams2, et et2, fa fa2, float f2, float f3, float f4, int n2, vn vn2) {
        return this.t().a(a, fa.a(et2, vn2)).a(b, false);
    }

    @Override
    public void a(ams ams2, et et2, awr awr2, vn vn2, ain ain2) {
        ams2.a(et2, awr2.a(a, fa.a(et2, vn2)), 2);
        if (ain2.t() && (\u2603 = ams2.r(et2)) instanceof avn) {
            ((avn)\u2603).a(ain2.r());
        }
    }

    @Override
    public void b(ams ams2, et et2, awr awr2) {
        avh avh2 = ams2.r(et2);
        if (avh2 instanceof avn) {
            tw.a(ams2, et2, (tt)((avn)avh2));
            ams2.d(et2, this);
        }
        super.b(ams2, et2, awr2);
    }

    public static fk a(eu eu2) {
        fa fa2 = eu2.e().c(a);
        double \u26032 = eu2.a() + 0.7 * (double)fa2.g();
        double \u26033 = eu2.b() + 0.7 * (double)fa2.h();
        double \u26034 = eu2.c() + 0.7 * (double)fa2.i();
        return new fl(\u26032, \u26033, \u26034);
    }

    @Override
    public boolean v(awr awr2) {
        return true;
    }

    @Override
    public int c(awr awr2, ams ams2, et et2) {
        return afp.a(ams2.r(et2));
    }

    @Override
    public ath a(awr awr2) {
        return ath.d;
    }

    @Override
    public awr a(int n2) {
        return this.t().a(a, fa.a(n2 & 7)).a(b, (n2 & 8) > 0);
    }

    @Override
    public int e(awr awr2) {
        int n2 = 0;
        n2 |= awr2.c(a).a();
        if (awr2.c(b).booleanValue()) {
            n2 |= 8;
        }
        return n2;
    }

    @Override
    public awr a(awr awr2, atk atk2) {
        return awr2.a(a, atk2.a(awr2.c(a)));
    }

    @Override
    public awr a(awr awr2, arw arw2) {
        return awr2.a(arw2.a(awr2.c(a)));
    }

    @Override
    protected aws b() {
        return new aws((aou)this, a, b);
    }
}

