/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufAllocator;
import io.netty.buffer.ByteBufInputStream;
import io.netty.buffer.ByteBufOutputStream;
import io.netty.handler.codec.DecoderException;
import io.netty.handler.codec.EncoderException;
import io.netty.util.ByteProcessor;
import java.io.DataOutput;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;
import java.nio.channels.GatheringByteChannel;
import java.nio.channels.ScatteringByteChannel;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.UUID;
import javax.annotation.Nullable;

public class gy
extends ByteBuf {
    private final ByteBuf a;

    public gy(ByteBuf byteBuf) {
        this.a = byteBuf;
    }

    public static int a(int n2) {
        for (\u2603 = 1; \u2603 < 5; ++\u2603) {
            if ((n2 & -1 << \u2603 * 7) != 0) continue;
            return \u2603;
        }
        return 5;
    }

    public gy a(byte[] arrby) {
        this.d(arrby.length);
        this.writeBytes(arrby);
        return this;
    }

    public byte[] a() {
        return this.b(this.readableBytes());
    }

    public byte[] b(int n2) {
        \u2603 = this.g();
        if (\u2603 > n2) {
            throw new DecoderException("ByteArray with size " + \u2603 + " is bigger than allowed " + n2);
        }
        byte[] arrby = new byte[\u2603];
        this.readBytes(arrby);
        return arrby;
    }

    public gy a(int[] arrn) {
        this.d(arrn.length);
        for (int n2 : arrn) {
            this.d(n2);
        }
        return this;
    }

    public int[] b() {
        return this.c(this.readableBytes());
    }

    public int[] c(int n2) {
        \u2603 = this.g();
        if (\u2603 > n2) {
            throw new DecoderException("VarIntArray with size " + \u2603 + " is bigger than allowed " + n2);
        }
        int[] arrn = new int[\u2603];
        for (int i2 = 0; i2 < arrn.length; ++i2) {
            arrn[i2] = this.g();
        }
        return arrn;
    }

    public gy a(long[] arrl) {
        this.d(arrl.length);
        for (long l2 : arrl) {
            this.writeLong(l2);
        }
        return this;
    }

    public long[] b(@Nullable long[] arrl) {
        return this.a(arrl, this.readableBytes() / 8);
    }

    public long[] a(@Nullable long[] arrl2, int n2) {
        long[] arrl2;
        \u2603 = this.g();
        if (arrl2 == null || arrl2.length != \u2603) {
            if (\u2603 > n2) {
                throw new DecoderException("LongArray with size " + \u2603 + " is bigger than allowed " + n2);
            }
            arrl2 = new long[\u2603];
        }
        for (int i2 = 0; i2 < arrl2.length; ++i2) {
            arrl2[i2] = this.readLong();
        }
        return arrl2;
    }

    public et e() {
        return et.a(this.readLong());
    }

    public gy a(et et2) {
        this.writeLong(et2.g());
        return this;
    }

    public hh f() {
        return hh.a.a(this.e(32767));
    }

    public gy a(hh hh2) {
        return this.a(hh.a.a(hh2));
    }

    public <T extends Enum<T>> T a(Class<T> class_) {
        return (T)((Enum[])class_.getEnumConstants())[this.g()];
    }

    public gy a(Enum<?> enum_) {
        return this.d(enum_.ordinal());
    }

    public int g() {
        int n2 = 0;
        \u2603 = 0;
        do {
            byte by2 = this.readByte();
            n2 |= (by2 & 0x7F) << \u2603++ * 7;
            if (\u2603 <= 5) continue;
            throw new RuntimeException("VarInt too big");
        } while ((by2 & 0x80) == 128);
        return n2;
    }

    public long h() {
        long l2 = 0L;
        int \u26032 = 0;
        do {
            byte by2 = this.readByte();
            l2 |= (long)(by2 & 0x7F) << \u26032++ * 7;
            if (\u26032 <= 10) continue;
            throw new RuntimeException("VarLong too big");
        } while ((by2 & 0x80) == 128);
        return l2;
    }

    public gy a(UUID uUID) {
        this.writeLong(uUID.getMostSignificantBits());
        this.writeLong(uUID.getLeastSignificantBits());
        return this;
    }

    public UUID i() {
        return new UUID(this.readLong(), this.readLong());
    }

    public gy d(int n2) {
        while (true) {
            if ((n2 & 0xFFFFFF80) == 0) {
                this.writeByte(n2);
                return this;
            }
            this.writeByte(n2 & 0x7F | 0x80);
            n2 >>>= 7;
        }
    }

    public gy b(long l2) {
        while (true) {
            if ((l2 & 0xFFFFFFFFFFFFFF80L) == 0L) {
                this.writeByte((int)l2);
                return this;
            }
            this.writeByte((int)(l2 & 0x7FL) | 0x80);
            l2 >>>= 7;
        }
    }

    public gy a(@Nullable fy fy2) {
        if (fy2 == null) {
            this.writeByte(0);
        } else {
            try {
                gi.a(fy2, (DataOutput)new ByteBufOutputStream(this));
            }
            catch (IOException iOException) {
                throw new EncoderException(iOException);
            }
        }
        return this;
    }

    @Nullable
    public fy j() {
        int n2 = this.readerIndex();
        byte \u26032 = this.readByte();
        if (\u26032 == 0) {
            return null;
        }
        this.readerIndex(n2);
        try {
            return gi.a(new ByteBufInputStream(this), new gh(0x200000L));
        }
        catch (IOException \u26033) {
            throw new EncoderException(\u26033);
        }
    }

    public gy a(ain ain2) {
        if (ain2.b()) {
            this.writeShort(-1);
        } else {
            this.writeShort(ail.a(ain2.c()));
            this.writeByte(ain2.E());
            this.writeShort(ain2.j());
            fy fy2 = null;
            if (ain2.c().m() || ain2.c().p()) {
                fy2 = ain2.p();
            }
            this.a(fy2);
        }
        return this;
    }

    public ain k() {
        short s2 = this.readShort();
        if (s2 < 0) {
            return ain.a;
        }
        byte \u26032 = this.readByte();
        \u2603 = this.readShort();
        ain \u26033 = new ain(ail.c(s2), (int)\u26032, (int)\u2603);
        \u26033.b(this.j());
        return \u26033;
    }

    public String e(int n2) {
        \u2603 = this.g();
        if (\u2603 > n2 * 4) {
            throw new DecoderException("The received encoded string buffer length is longer than maximum allowed (" + \u2603 + " > " + n2 * 4 + ")");
        }
        if (\u2603 < 0) {
            throw new DecoderException("The received encoded string buffer length is less than zero! Weird string!");
        }
        String string = this.toString(this.readerIndex(), \u2603, StandardCharsets.UTF_8);
        this.readerIndex(this.readerIndex() + \u2603);
        if (string.length() > n2) {
            throw new DecoderException("The received string length is longer than maximum allowed (" + \u2603 + " > " + n2 + ")");
        }
        return string;
    }

    public gy a(String string) {
        byte[] arrby = string.getBytes(StandardCharsets.UTF_8);
        if (arrby.length > 32767) {
            throw new EncoderException("String too big (was " + arrby.length + " bytes encoded, max " + 32767 + ")");
        }
        this.d(arrby.length);
        this.writeBytes(arrby);
        return this;
    }

    public nd l() {
        return new nd(this.e(32767));
    }

    public gy a(nd nd2) {
        this.a(nd2.toString());
        return this;
    }

    public Date m() {
        return new Date(this.readLong());
    }

    public gy a(Date date) {
        this.writeLong(date.getTime());
        return this;
    }

    @Override
    public int capacity() {
        return this.a.capacity();
    }

    @Override
    public ByteBuf capacity(int n2) {
        return this.a.capacity(n2);
    }

    @Override
    public int maxCapacity() {
        return this.a.maxCapacity();
    }

    @Override
    public ByteBufAllocator alloc() {
        return this.a.alloc();
    }

    @Override
    public ByteOrder order() {
        return this.a.order();
    }

    @Override
    public ByteBuf order(ByteOrder byteOrder) {
        return this.a.order(byteOrder);
    }

    @Override
    public ByteBuf unwrap() {
        return this.a.unwrap();
    }

    @Override
    public boolean isDirect() {
        return this.a.isDirect();
    }

    @Override
    public boolean isReadOnly() {
        return this.a.isReadOnly();
    }

    @Override
    public ByteBuf asReadOnly() {
        return this.a.asReadOnly();
    }

    @Override
    public int readerIndex() {
        return this.a.readerIndex();
    }

    @Override
    public ByteBuf readerIndex(int n2) {
        return this.a.readerIndex(n2);
    }

    @Override
    public int writerIndex() {
        return this.a.writerIndex();
    }

    @Override
    public ByteBuf writerIndex(int n2) {
        return this.a.writerIndex(n2);
    }

    @Override
    public ByteBuf setIndex(int n2, int n3) {
        return this.a.setIndex(n2, n3);
    }

    @Override
    public int readableBytes() {
        return this.a.readableBytes();
    }

    @Override
    public int writableBytes() {
        return this.a.writableBytes();
    }

    @Override
    public int maxWritableBytes() {
        return this.a.maxWritableBytes();
    }

    @Override
    public boolean isReadable() {
        return this.a.isReadable();
    }

    @Override
    public boolean isReadable(int n2) {
        return this.a.isReadable(n2);
    }

    @Override
    public boolean isWritable() {
        return this.a.isWritable();
    }

    @Override
    public boolean isWritable(int n2) {
        return this.a.isWritable(n2);
    }

    @Override
    public ByteBuf clear() {
        return this.a.clear();
    }

    @Override
    public ByteBuf markReaderIndex() {
        return this.a.markReaderIndex();
    }

    @Override
    public ByteBuf resetReaderIndex() {
        return this.a.resetReaderIndex();
    }

    @Override
    public ByteBuf markWriterIndex() {
        return this.a.markWriterIndex();
    }

    @Override
    public ByteBuf resetWriterIndex() {
        return this.a.resetWriterIndex();
    }

    @Override
    public ByteBuf discardReadBytes() {
        return this.a.discardReadBytes();
    }

    @Override
    public ByteBuf discardSomeReadBytes() {
        return this.a.discardSomeReadBytes();
    }

    @Override
    public ByteBuf ensureWritable(int n2) {
        return this.a.ensureWritable(n2);
    }

    @Override
    public int ensureWritable(int n2, boolean bl2) {
        return this.a.ensureWritable(n2, bl2);
    }

    @Override
    public boolean getBoolean(int n2) {
        return this.a.getBoolean(n2);
    }

    @Override
    public byte getByte(int n2) {
        return this.a.getByte(n2);
    }

    @Override
    public short getUnsignedByte(int n2) {
        return this.a.getUnsignedByte(n2);
    }

    @Override
    public short getShort(int n2) {
        return this.a.getShort(n2);
    }

    @Override
    public short getShortLE(int n2) {
        return this.a.getShortLE(n2);
    }

    @Override
    public int getUnsignedShort(int n2) {
        return this.a.getUnsignedShort(n2);
    }

    @Override
    public int getUnsignedShortLE(int n2) {
        return this.a.getUnsignedShortLE(n2);
    }

    @Override
    public int getMedium(int n2) {
        return this.a.getMedium(n2);
    }

    @Override
    public int getMediumLE(int n2) {
        return this.a.getMediumLE(n2);
    }

    @Override
    public int getUnsignedMedium(int n2) {
        return this.a.getUnsignedMedium(n2);
    }

    @Override
    public int getUnsignedMediumLE(int n2) {
        return this.a.getUnsignedMediumLE(n2);
    }

    @Override
    public int getInt(int n2) {
        return this.a.getInt(n2);
    }

    @Override
    public int getIntLE(int n2) {
        return this.a.getIntLE(n2);
    }

    @Override
    public long getUnsignedInt(int n2) {
        return this.a.getUnsignedInt(n2);
    }

    @Override
    public long getUnsignedIntLE(int n2) {
        return this.a.getUnsignedIntLE(n2);
    }

    @Override
    public long getLong(int n2) {
        return this.a.getLong(n2);
    }

    @Override
    public long getLongLE(int n2) {
        return this.a.getLongLE(n2);
    }

    @Override
    public char getChar(int n2) {
        return this.a.getChar(n2);
    }

    @Override
    public float getFloat(int n2) {
        return this.a.getFloat(n2);
    }

    @Override
    public double getDouble(int n2) {
        return this.a.getDouble(n2);
    }

    @Override
    public ByteBuf getBytes(int n2, ByteBuf byteBuf) {
        return this.a.getBytes(n2, byteBuf);
    }

    @Override
    public ByteBuf getBytes(int n2, ByteBuf byteBuf, int n3) {
        return this.a.getBytes(n2, byteBuf, n3);
    }

    @Override
    public ByteBuf getBytes(int n2, ByteBuf byteBuf, int n3, int n4) {
        return this.a.getBytes(n2, byteBuf, n3, n4);
    }

    @Override
    public ByteBuf getBytes(int n2, byte[] arrby) {
        return this.a.getBytes(n2, arrby);
    }

    @Override
    public ByteBuf getBytes(int n2, byte[] arrby, int n3, int n4) {
        return this.a.getBytes(n2, arrby, n3, n4);
    }

    @Override
    public ByteBuf getBytes(int n2, ByteBuffer byteBuffer) {
        return this.a.getBytes(n2, byteBuffer);
    }

    @Override
    public ByteBuf getBytes(int n2, OutputStream outputStream, int n3) throws IOException {
        return this.a.getBytes(n2, outputStream, n3);
    }

    @Override
    public int getBytes(int n2, GatheringByteChannel gatheringByteChannel, int n3) throws IOException {
        return this.a.getBytes(n2, gatheringByteChannel, n3);
    }

    @Override
    public int getBytes(int n2, FileChannel fileChannel, long l2, int n3) throws IOException {
        return this.a.getBytes(n2, fileChannel, l2, n3);
    }

    @Override
    public CharSequence getCharSequence(int n2, int n3, Charset charset) {
        return this.a.getCharSequence(n2, n3, charset);
    }

    @Override
    public ByteBuf setBoolean(int n2, boolean bl2) {
        return this.a.setBoolean(n2, bl2);
    }

    @Override
    public ByteBuf setByte(int n2, int n3) {
        return this.a.setByte(n2, n3);
    }

    @Override
    public ByteBuf setShort(int n2, int n3) {
        return this.a.setShort(n2, n3);
    }

    @Override
    public ByteBuf setShortLE(int n2, int n3) {
        return this.a.setShortLE(n2, n3);
    }

    @Override
    public ByteBuf setMedium(int n2, int n3) {
        return this.a.setMedium(n2, n3);
    }

    @Override
    public ByteBuf setMediumLE(int n2, int n3) {
        return this.a.setMediumLE(n2, n3);
    }

    @Override
    public ByteBuf setInt(int n2, int n3) {
        return this.a.setInt(n2, n3);
    }

    @Override
    public ByteBuf setIntLE(int n2, int n3) {
        return this.a.setIntLE(n2, n3);
    }

    @Override
    public ByteBuf setLong(int n2, long l2) {
        return this.a.setLong(n2, l2);
    }

    @Override
    public ByteBuf setLongLE(int n2, long l2) {
        return this.a.setLongLE(n2, l2);
    }

    @Override
    public ByteBuf setChar(int n2, int n3) {
        return this.a.setChar(n2, n3);
    }

    @Override
    public ByteBuf setFloat(int n2, float f2) {
        return this.a.setFloat(n2, f2);
    }

    @Override
    public ByteBuf setDouble(int n2, double d2) {
        return this.a.setDouble(n2, d2);
    }

    @Override
    public ByteBuf setBytes(int n2, ByteBuf byteBuf) {
        return this.a.setBytes(n2, byteBuf);
    }

    @Override
    public ByteBuf setBytes(int n2, ByteBuf byteBuf, int n3) {
        return this.a.setBytes(n2, byteBuf, n3);
    }

    @Override
    public ByteBuf setBytes(int n2, ByteBuf byteBuf, int n3, int n4) {
        return this.a.setBytes(n2, byteBuf, n3, n4);
    }

    @Override
    public ByteBuf setBytes(int n2, byte[] arrby) {
        return this.a.setBytes(n2, arrby);
    }

    @Override
    public ByteBuf setBytes(int n2, byte[] arrby, int n3, int n4) {
        return this.a.setBytes(n2, arrby, n3, n4);
    }

    @Override
    public ByteBuf setBytes(int n2, ByteBuffer byteBuffer) {
        return this.a.setBytes(n2, byteBuffer);
    }

    @Override
    public int setBytes(int n2, InputStream inputStream, int n3) throws IOException {
        return this.a.setBytes(n2, inputStream, n3);
    }

    @Override
    public int setBytes(int n2, ScatteringByteChannel scatteringByteChannel, int n3) throws IOException {
        return this.a.setBytes(n2, scatteringByteChannel, n3);
    }

    @Override
    public int setBytes(int n2, FileChannel fileChannel, long l2, int n3) throws IOException {
        return this.a.setBytes(n2, fileChannel, l2, n3);
    }

    @Override
    public ByteBuf setZero(int n2, int n3) {
        return this.a.setZero(n2, n3);
    }

    @Override
    public int setCharSequence(int n2, CharSequence charSequence, Charset charset) {
        return this.a.setCharSequence(n2, charSequence, charset);
    }

    @Override
    public boolean readBoolean() {
        return this.a.readBoolean();
    }

    @Override
    public byte readByte() {
        return this.a.readByte();
    }

    @Override
    public short readUnsignedByte() {
        return this.a.readUnsignedByte();
    }

    @Override
    public short readShort() {
        return this.a.readShort();
    }

    @Override
    public short readShortLE() {
        return this.a.readShortLE();
    }

    @Override
    public int readUnsignedShort() {
        return this.a.readUnsignedShort();
    }

    @Override
    public int readUnsignedShortLE() {
        return this.a.readUnsignedShortLE();
    }

    @Override
    public int readMedium() {
        return this.a.readMedium();
    }

    @Override
    public int readMediumLE() {
        return this.a.readMediumLE();
    }

    @Override
    public int readUnsignedMedium() {
        return this.a.readUnsignedMedium();
    }

    @Override
    public int readUnsignedMediumLE() {
        return this.a.readUnsignedMediumLE();
    }

    @Override
    public int readInt() {
        return this.a.readInt();
    }

    @Override
    public int readIntLE() {
        return this.a.readIntLE();
    }

    @Override
    public long readUnsignedInt() {
        return this.a.readUnsignedInt();
    }

    @Override
    public long readUnsignedIntLE() {
        return this.a.readUnsignedIntLE();
    }

    @Override
    public long readLong() {
        return this.a.readLong();
    }

    @Override
    public long readLongLE() {
        return this.a.readLongLE();
    }

    @Override
    public char readChar() {
        return this.a.readChar();
    }

    @Override
    public float readFloat() {
        return this.a.readFloat();
    }

    @Override
    public double readDouble() {
        return this.a.readDouble();
    }

    @Override
    public ByteBuf readBytes(int n2) {
        return this.a.readBytes(n2);
    }

    @Override
    public ByteBuf readSlice(int n2) {
        return this.a.readSlice(n2);
    }

    @Override
    public ByteBuf readRetainedSlice(int n2) {
        return this.a.readRetainedSlice(n2);
    }

    @Override
    public ByteBuf readBytes(ByteBuf byteBuf) {
        return this.a.readBytes(byteBuf);
    }

    @Override
    public ByteBuf readBytes(ByteBuf byteBuf, int n2) {
        return this.a.readBytes(byteBuf, n2);
    }

    @Override
    public ByteBuf readBytes(ByteBuf byteBuf, int n2, int n3) {
        return this.a.readBytes(byteBuf, n2, n3);
    }

    @Override
    public ByteBuf readBytes(byte[] arrby) {
        return this.a.readBytes(arrby);
    }

    @Override
    public ByteBuf readBytes(byte[] arrby, int n2, int n3) {
        return this.a.readBytes(arrby, n2, n3);
    }

    @Override
    public ByteBuf readBytes(ByteBuffer byteBuffer) {
        return this.a.readBytes(byteBuffer);
    }

    @Override
    public ByteBuf readBytes(OutputStream outputStream, int n2) throws IOException {
        return this.a.readBytes(outputStream, n2);
    }

    @Override
    public int readBytes(GatheringByteChannel gatheringByteChannel, int n2) throws IOException {
        return this.a.readBytes(gatheringByteChannel, n2);
    }

    @Override
    public CharSequence readCharSequence(int n2, Charset charset) {
        return this.a.readCharSequence(n2, charset);
    }

    @Override
    public int readBytes(FileChannel fileChannel, long l2, int n2) throws IOException {
        return this.a.readBytes(fileChannel, l2, n2);
    }

    @Override
    public ByteBuf skipBytes(int n2) {
        return this.a.skipBytes(n2);
    }

    @Override
    public ByteBuf writeBoolean(boolean bl2) {
        return this.a.writeBoolean(bl2);
    }

    @Override
    public ByteBuf writeByte(int n2) {
        return this.a.writeByte(n2);
    }

    @Override
    public ByteBuf writeShort(int n2) {
        return this.a.writeShort(n2);
    }

    @Override
    public ByteBuf writeShortLE(int n2) {
        return this.a.writeShortLE(n2);
    }

    @Override
    public ByteBuf writeMedium(int n2) {
        return this.a.writeMedium(n2);
    }

    @Override
    public ByteBuf writeMediumLE(int n2) {
        return this.a.writeMediumLE(n2);
    }

    @Override
    public ByteBuf writeInt(int n2) {
        return this.a.writeInt(n2);
    }

    @Override
    public ByteBuf writeIntLE(int n2) {
        return this.a.writeIntLE(n2);
    }

    @Override
    public ByteBuf writeLong(long l2) {
        return this.a.writeLong(l2);
    }

    @Override
    public ByteBuf writeLongLE(long l2) {
        return this.a.writeLongLE(l2);
    }

    @Override
    public ByteBuf writeChar(int n2) {
        return this.a.writeChar(n2);
    }

    @Override
    public ByteBuf writeFloat(float f2) {
        return this.a.writeFloat(f2);
    }

    @Override
    public ByteBuf writeDouble(double d2) {
        return this.a.writeDouble(d2);
    }

    @Override
    public ByteBuf writeBytes(ByteBuf byteBuf) {
        return this.a.writeBytes(byteBuf);
    }

    @Override
    public ByteBuf writeBytes(ByteBuf byteBuf, int n2) {
        return this.a.writeBytes(byteBuf, n2);
    }

    @Override
    public ByteBuf writeBytes(ByteBuf byteBuf, int n2, int n3) {
        return this.a.writeBytes(byteBuf, n2, n3);
    }

    @Override
    public ByteBuf writeBytes(byte[] arrby) {
        return this.a.writeBytes(arrby);
    }

    @Override
    public ByteBuf writeBytes(byte[] arrby, int n2, int n3) {
        return this.a.writeBytes(arrby, n2, n3);
    }

    @Override
    public ByteBuf writeBytes(ByteBuffer byteBuffer) {
        return this.a.writeBytes(byteBuffer);
    }

    @Override
    public int writeBytes(InputStream inputStream, int n2) throws IOException {
        return this.a.writeBytes(inputStream, n2);
    }

    @Override
    public int writeBytes(ScatteringByteChannel scatteringByteChannel, int n2) throws IOException {
        return this.a.writeBytes(scatteringByteChannel, n2);
    }

    @Override
    public int writeBytes(FileChannel fileChannel, long l2, int n2) throws IOException {
        return this.a.writeBytes(fileChannel, l2, n2);
    }

    @Override
    public ByteBuf writeZero(int n2) {
        return this.a.writeZero(n2);
    }

    @Override
    public int writeCharSequence(CharSequence charSequence, Charset charset) {
        return this.a.writeCharSequence(charSequence, charset);
    }

    @Override
    public int indexOf(int n2, int n3, byte by2) {
        return this.a.indexOf(n2, n3, by2);
    }

    @Override
    public int bytesBefore(byte by2) {
        return this.a.bytesBefore(by2);
    }

    @Override
    public int bytesBefore(int n2, byte by2) {
        return this.a.bytesBefore(n2, by2);
    }

    @Override
    public int bytesBefore(int n2, int n3, byte by2) {
        return this.a.bytesBefore(n2, n3, by2);
    }

    @Override
    public int forEachByte(ByteProcessor byteProcessor) {
        return this.a.forEachByte(byteProcessor);
    }

    @Override
    public int forEachByte(int n2, int n3, ByteProcessor byteProcessor) {
        return this.a.forEachByte(n2, n3, byteProcessor);
    }

    @Override
    public int forEachByteDesc(ByteProcessor byteProcessor) {
        return this.a.forEachByteDesc(byteProcessor);
    }

    @Override
    public int forEachByteDesc(int n2, int n3, ByteProcessor byteProcessor) {
        return this.a.forEachByteDesc(n2, n3, byteProcessor);
    }

    @Override
    public ByteBuf copy() {
        return this.a.copy();
    }

    @Override
    public ByteBuf copy(int n2, int n3) {
        return this.a.copy(n2, n3);
    }

    @Override
    public ByteBuf slice() {
        return this.a.slice();
    }

    @Override
    public ByteBuf retainedSlice() {
        return this.a.retainedSlice();
    }

    @Override
    public ByteBuf slice(int n2, int n3) {
        return this.a.slice(n2, n3);
    }

    @Override
    public ByteBuf retainedSlice(int n2, int n3) {
        return this.a.retainedSlice(n2, n3);
    }

    @Override
    public ByteBuf duplicate() {
        return this.a.duplicate();
    }

    @Override
    public ByteBuf retainedDuplicate() {
        return this.a.retainedDuplicate();
    }

    @Override
    public int nioBufferCount() {
        return this.a.nioBufferCount();
    }

    @Override
    public ByteBuffer nioBuffer() {
        return this.a.nioBuffer();
    }

    @Override
    public ByteBuffer nioBuffer(int n2, int n3) {
        return this.a.nioBuffer(n2, n3);
    }

    @Override
    public ByteBuffer internalNioBuffer(int n2, int n3) {
        return this.a.internalNioBuffer(n2, n3);
    }

    @Override
    public ByteBuffer[] nioBuffers() {
        return this.a.nioBuffers();
    }

    @Override
    public ByteBuffer[] nioBuffers(int n2, int n3) {
        return this.a.nioBuffers(n2, n3);
    }

    @Override
    public boolean hasArray() {
        return this.a.hasArray();
    }

    @Override
    public byte[] array() {
        return this.a.array();
    }

    @Override
    public int arrayOffset() {
        return this.a.arrayOffset();
    }

    @Override
    public boolean hasMemoryAddress() {
        return this.a.hasMemoryAddress();
    }

    @Override
    public long memoryAddress() {
        return this.a.memoryAddress();
    }

    @Override
    public String toString(Charset charset) {
        return this.a.toString(charset);
    }

    @Override
    public String toString(int n2, int n3, Charset charset) {
        return this.a.toString(n2, n3, charset);
    }

    @Override
    public int hashCode() {
        return this.a.hashCode();
    }

    @Override
    public boolean equals(Object object) {
        return this.a.equals(object);
    }

    @Override
    public int compareTo(ByteBuf byteBuf) {
        return this.a.compareTo(byteBuf);
    }

    @Override
    public String toString() {
        return this.a.toString();
    }

    @Override
    public ByteBuf retain(int n2) {
        return this.a.retain(n2);
    }

    @Override
    public ByteBuf retain() {
        return this.a.retain();
    }

    @Override
    public ByteBuf touch() {
        return this.a.touch();
    }

    @Override
    public ByteBuf touch(Object object) {
        return this.a.touch(object);
    }

    @Override
    public int refCnt() {
        return this.a.refCnt();
    }

    @Override
    public boolean release() {
        return this.a.release();
    }

    @Override
    public boolean release(int n2) {
        return this.a.release(n2);
    }
}

