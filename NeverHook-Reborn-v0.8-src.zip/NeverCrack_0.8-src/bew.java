/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import java.io.File;
import javax.annotation.Nullable;

public class bew
extends bez {
    public bew(File file, String string, boolean bl2, rw rw2) {
        super(file, string, bl2, rw2);
    }

    @Override
    public ayd a(ayk ayk2) {
        File file = this.b();
        if (ayk2 instanceof aym) {
            \u2603 = new File(file, "DIM-1");
            \u2603.mkdirs();
            return new ayc(\u2603, this.a);
        }
        if (ayk2 instanceof ayq) {
            \u2603 = new File(file, "DIM1");
            \u2603.mkdirs();
            return new ayc(\u2603, this.a);
        }
        return new ayc(file, this.a);
    }

    @Override
    public void a(bfb bfb2, @Nullable fy fy2) {
        bfb2.e(19133);
        super.a(bfb2, fy2);
    }

    @Override
    public void a() {
        try {
            bgv.a().b();
        }
        catch (InterruptedException interruptedException) {
            interruptedException.printStackTrace();
        }
        ayi.a();
    }
}

