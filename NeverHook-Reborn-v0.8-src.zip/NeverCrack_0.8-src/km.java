/*
 * Decompiled with CFR 0.150.
 */
import java.io.IOException;

public class km
implements ht<hw> {
    private et a;

    public km() {
    }

    public km(et et2) {
        this.a = et2;
    }

    @Override
    public void a(gy gy2) throws IOException {
        this.a = gy2.e();
    }

    @Override
    public void b(gy gy2) throws IOException {
        gy2.a(this.a);
    }

    @Override
    public void a(hw hw2) {
        hw2.a(this);
    }

    public et a() {
        return this.a;
    }
}

