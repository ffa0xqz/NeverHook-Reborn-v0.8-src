/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  javax.annotation.Nullable
 */
import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;

public class bbz {
    public static void a() {
        bbt.a(a.class, "ViBH");
        bbt.a(b.class, "ViDF");
        bbt.a(c.class, "ViF");
        bbt.a(d.class, "ViL");
        bbt.a(f.class, "ViPH");
        bbt.a(g.class, "ViSH");
        bbt.a(h.class, "ViSmH");
        bbt.a(i.class, "ViST");
        bbt.a(j.class, "ViS");
        bbt.a(k.class, "ViStart");
        bbt.a(l.class, "ViSR");
        bbt.a(m.class, "ViTRH");
        bbt.a(p.class, "ViW");
    }

    public static List<e> a(Random random, int n2) {
        ArrayList arrayList = Lists.newArrayList();
        arrayList.add(new e(g.class, 4, ri.a(random, 2 + n2, 4 + n2 * 2)));
        arrayList.add(new e(i.class, 20, ri.a(random, 0 + n2, 1 + n2)));
        arrayList.add(new e(a.class, 20, ri.a(random, 0 + n2, 2 + n2)));
        arrayList.add(new e(h.class, 3, ri.a(random, 2 + n2, 5 + n2 * 3)));
        arrayList.add(new e(f.class, 15, ri.a(random, 0 + n2, 2 + n2)));
        arrayList.add(new e(b.class, 3, ri.a(random, 1 + n2, 4 + n2)));
        arrayList.add(new e(c.class, 3, ri.a(random, 2 + n2, 4 + n2 * 2)));
        arrayList.add(new e(j.class, 15, ri.a(random, 0, 1 + n2)));
        arrayList.add(new e(m.class, 8, ri.a(random, 0 + n2, 3 + n2 * 2)));
        Iterator \u26032 = arrayList.iterator();
        while (\u26032.hasNext()) {
            if (((e)\u26032.next()).d != 0) continue;
            \u26032.remove();
        }
        return arrayList;
    }

    private static int a(List<e> list) {
        boolean bl2 = false;
        int \u26032 = 0;
        for (e e22 : list) {
            e e22;
            if (e22.d > 0 && e22.c < e22.d) {
                bl2 = true;
            }
            \u26032 += e22.b;
        }
        return bl2 ? \u26032 : -1;
    }

    private static n a(k k2, e e2, List<bbv> list, Random random, int n2, int n3, int n4, fa fa2, int n5) {
        Class<? extends n> class_ = e2.a;
        n \u26032 = null;
        if (class_ == g.class) {
            \u26032 = g.a(k2, list, random, n2, n3, n4, fa2, n5);
        } else if (class_ == i.class) {
            \u26032 = i.a(k2, list, random, n2, n3, n4, fa2, n5);
        } else if (class_ == a.class) {
            \u26032 = a.a(k2, list, random, n2, n3, n4, fa2, n5);
        } else if (class_ == h.class) {
            \u26032 = h.a(k2, list, random, n2, n3, n4, fa2, n5);
        } else if (class_ == f.class) {
            \u26032 = f.a(k2, list, random, n2, n3, n4, fa2, n5);
        } else if (class_ == b.class) {
            \u26032 = b.a(k2, list, random, n2, n3, n4, fa2, n5);
        } else if (class_ == c.class) {
            \u26032 = c.a(k2, list, random, n2, n3, n4, fa2, n5);
        } else if (class_ == j.class) {
            \u26032 = j.a(k2, list, random, n2, n3, n4, fa2, n5);
        } else if (class_ == m.class) {
            \u26032 = m.a(k2, list, random, n2, n3, n4, fa2, n5);
        }
        return \u26032;
    }

    private static n c(k k22, List<bbv> list, Random random, int n2, int n3, int n4, fa fa2, int n5) {
        k k22;
        \u2603 = bbz.a(k22.d);
        if (\u2603 <= 0) {
            return null;
        }
        \u2603 = 0;
        block0: while (\u2603 < 5) {
            ++\u2603;
            \u2603 = random.nextInt(\u2603);
            for (e e2 : k22.d) {
                if ((\u2603 -= e2.b) >= 0) continue;
                if (!e2.a(n5) || e2 == k22.c && k22.d.size() > 1) continue block0;
                n n6 = bbz.a(k22, e2, list, random, n2, n3, n4, fa2, n5);
                if (n6 == null) continue;
                ++e2.c;
                k22.c = e2;
                if (!e2.a()) {
                    k22.d.remove(e2);
                }
                return n6;
            }
        }
        bbe \u26032 = d.a(k22, list, random, n2, n3, n4, fa2);
        if (\u26032 != null) {
            return new d(k22, n5, random, \u26032, fa2);
        }
        return null;
    }

    private static bbv d(k k2, List<bbv> list, Random random, int n2, int n3, int n4, fa fa2, int n5) {
        if (n5 > 50) {
            return null;
        }
        if (Math.abs(n2 - k2.d().a) > 112 || Math.abs(n4 - k2.d().c) > 112) {
            return null;
        }
        n n6 = bbz.c(k2, list, random, n2, n3, n4, fa2, n5 + 1);
        if (n6 != null) {
            list.add(n6);
            k2.e.add(n6);
            return n6;
        }
        return null;
    }

    private static bbv e(k k2, List<bbv> list, Random random, int n2, int n3, int n4, fa fa2, int n5) {
        if (n5 > 3 + k2.b) {
            return null;
        }
        if (Math.abs(n2 - k2.d().a) > 112 || Math.abs(n4 - k2.d().c) > 112) {
            return null;
        }
        bbe bbe2 = l.a(k2, list, random, n2, n3, n4, fa2);
        if (bbe2 != null && bbe2.b > 10) {
            l l2 = new l(k2, n5, random, bbe2, fa2);
            list.add(l2);
            k2.f.add(l2);
            return l2;
        }
        return null;
    }

    public static class d
    extends n {
        public d() {
        }

        public d(k k2, int n2, Random random, bbe bbe2, fa fa2) {
            super(k2, n2);
            this.a(fa2);
            this.l = bbe2;
        }

        public static bbe a(k k2, List<bbv> list, Random random, int n2, int n3, int n4, fa fa2) {
            bbe bbe2 = bbe.a(n2, n3, n4, 0, 0, 0, 3, 4, 2, fa2);
            if (bbv.a(list, bbe2) != null) {
                return null;
            }
            return bbe2;
        }

        @Override
        public boolean a(ams ams2, Random random, bbe bbe2) {
            if (this.g < 0) {
                this.g = this.b(ams2, bbe2);
                if (this.g < 0) {
                    return true;
                }
                this.l.a(0, this.g - this.l.e + 4 - 1, 0);
            }
            awr awr2 = this.a(aov.aO.t());
            this.a(ams2, bbe2, 0, 0, 0, 2, 3, 1, aov.a.t(), aov.a.t(), false);
            this.a(ams2, awr2, 1, 0, 0, bbe2);
            this.a(ams2, awr2, 1, 1, 0, bbe2);
            this.a(ams2, awr2, 1, 2, 0, bbe2);
            this.a(ams2, aov.L.a(ahq.a.b()), 1, 3, 0, bbe2);
            this.a(ams2, fa.f, 2, 3, 0, bbe2);
            this.a(ams2, fa.c, 1, 3, 1, bbe2);
            this.a(ams2, fa.e, 0, 3, 0, bbe2);
            this.a(ams2, fa.d, 1, 3, -1, bbe2);
            return true;
        }
    }

    public static class b
    extends n {
        private aou a;
        private aou b;
        private aou c;
        private aou d;

        public b() {
        }

        public b(k k2, int n2, Random random, bbe bbe2, fa fa2) {
            super(k2, n2);
            this.a(fa2);
            this.l = bbe2;
            this.a = this.a(random);
            this.b = this.a(random);
            this.c = this.a(random);
            this.d = this.a(random);
        }

        @Override
        protected void a(fy fy2) {
            super.a(fy2);
            fy2.a("CA", aou.h.a(this.a));
            fy2.a("CB", aou.h.a(this.b));
            fy2.a("CC", aou.h.a(this.c));
            fy2.a("CD", aou.h.a(this.d));
        }

        @Override
        protected void a(fy fy2, bce bce2) {
            super.a(fy2, bce2);
            this.a = aou.c(fy2.h("CA"));
            this.b = aou.c(fy2.h("CB"));
            this.c = aou.c(fy2.h("CC"));
            this.d = aou.c(fy2.h("CD"));
            if (!(this.a instanceof apq)) {
                this.a = aov.aj;
            }
            if (!(this.b instanceof apq)) {
                this.b = aov.cb;
            }
            if (!(this.c instanceof apq)) {
                this.c = aov.cc;
            }
            if (!(this.d instanceof apq)) {
                this.d = aov.cZ;
            }
        }

        private aou a(Random random) {
            switch (random.nextInt(10)) {
                default: {
                    return aov.aj;
                }
                case 0: 
                case 1: {
                    return aov.cb;
                }
                case 2: 
                case 3: {
                    return aov.cc;
                }
                case 4: 
            }
            return aov.cZ;
        }

        public static b a(k k2, List<bbv> list, Random random, int n2, int n3, int n4, fa fa2, int n5) {
            bbe bbe2 = bbe.a(n2, n3, n4, 0, 0, 0, 13, 4, 9, fa2);
            if (!bbz$b.a(bbe2) || bbv.a(list, bbe2) != null) {
                return null;
            }
            return new b(k2, n5, random, bbe2, fa2);
        }

        @Override
        public boolean a(ams ams2, Random random, bbe bbe2) {
            int n2;
            if (this.g < 0) {
                this.g = this.b(ams2, bbe2);
                if (this.g < 0) {
                    return true;
                }
                this.l.a(0, this.g - this.l.e + 4 - 1, 0);
            }
            awr awr2 = this.a(aov.r.t());
            this.a(ams2, bbe2, 0, 1, 0, 12, 4, 8, aov.a.t(), aov.a.t(), false);
            this.a(ams2, bbe2, 1, 0, 1, 2, 0, 7, aov.ak.t(), aov.ak.t(), false);
            this.a(ams2, bbe2, 4, 0, 1, 5, 0, 7, aov.ak.t(), aov.ak.t(), false);
            this.a(ams2, bbe2, 7, 0, 1, 8, 0, 7, aov.ak.t(), aov.ak.t(), false);
            this.a(ams2, bbe2, 10, 0, 1, 11, 0, 7, aov.ak.t(), aov.ak.t(), false);
            this.a(ams2, bbe2, 0, 0, 0, 0, 0, 8, awr2, awr2, false);
            this.a(ams2, bbe2, 6, 0, 0, 6, 0, 8, awr2, awr2, false);
            this.a(ams2, bbe2, 12, 0, 0, 12, 0, 8, awr2, awr2, false);
            this.a(ams2, bbe2, 1, 0, 0, 11, 0, 0, awr2, awr2, false);
            this.a(ams2, bbe2, 1, 0, 8, 11, 0, 8, awr2, awr2, false);
            this.a(ams2, bbe2, 3, 0, 1, 3, 0, 7, aov.j.t(), aov.j.t(), false);
            this.a(ams2, bbe2, 9, 0, 1, 9, 0, 7, aov.j.t(), aov.j.t(), false);
            for (n2 = 1; n2 <= 7; ++n2) {
                \u2603 = ((apq)this.a).g();
                \u2603 = \u2603 / 3;
                this.a(ams2, this.a.a(ri.a(random, \u2603, \u2603)), 1, 1, n2, bbe2);
                this.a(ams2, this.a.a(ri.a(random, \u2603, \u2603)), 2, 1, n2, bbe2);
                \u2603 = ((apq)this.b).g();
                \u2603 = \u2603 / 3;
                this.a(ams2, this.b.a(ri.a(random, \u2603, \u2603)), 4, 1, n2, bbe2);
                this.a(ams2, this.b.a(ri.a(random, \u2603, \u2603)), 5, 1, n2, bbe2);
                \u2603 = ((apq)this.c).g();
                \u2603 = \u2603 / 3;
                this.a(ams2, this.c.a(ri.a(random, \u2603, \u2603)), 7, 1, n2, bbe2);
                this.a(ams2, this.c.a(ri.a(random, \u2603, \u2603)), 8, 1, n2, bbe2);
                \u2603 = ((apq)this.d).g();
                \u2603 = \u2603 / 3;
                this.a(ams2, this.d.a(ri.a(random, \u2603, \u2603)), 10, 1, n2, bbe2);
                this.a(ams2, this.d.a(ri.a(random, \u2603, \u2603)), 11, 1, n2, bbe2);
            }
            for (n2 = 0; n2 < 9; ++n2) {
                for (\u2603 = 0; \u2603 < 13; ++\u2603) {
                    this.c(ams2, \u2603, 4, n2, bbe2);
                    this.b(ams2, aov.d.t(), \u2603, -1, n2, bbe2);
                }
            }
            return true;
        }
    }

    public static class c
    extends n {
        private aou a;
        private aou b;

        public c() {
        }

        public c(k k2, int n2, Random random, bbe bbe2, fa fa2) {
            super(k2, n2);
            this.a(fa2);
            this.l = bbe2;
            this.a = this.a(random);
            this.b = this.a(random);
        }

        @Override
        protected void a(fy fy2) {
            super.a(fy2);
            fy2.a("CA", aou.h.a(this.a));
            fy2.a("CB", aou.h.a(this.b));
        }

        @Override
        protected void a(fy fy2, bce bce2) {
            super.a(fy2, bce2);
            this.a = aou.c(fy2.h("CA"));
            this.b = aou.c(fy2.h("CB"));
        }

        private aou a(Random random) {
            switch (random.nextInt(10)) {
                default: {
                    return aov.aj;
                }
                case 0: 
                case 1: {
                    return aov.cb;
                }
                case 2: 
                case 3: {
                    return aov.cc;
                }
                case 4: 
            }
            return aov.cZ;
        }

        public static c a(k k2, List<bbv> list, Random random, int n2, int n3, int n4, fa fa2, int n5) {
            bbe bbe2 = bbe.a(n2, n3, n4, 0, 0, 0, 7, 4, 9, fa2);
            if (!c.a(bbe2) || bbv.a(list, bbe2) != null) {
                return null;
            }
            return new c(k2, n5, random, bbe2, fa2);
        }

        @Override
        public boolean a(ams ams2, Random random, bbe bbe2) {
            int n2;
            if (this.g < 0) {
                this.g = this.b(ams2, bbe2);
                if (this.g < 0) {
                    return true;
                }
                this.l.a(0, this.g - this.l.e + 4 - 1, 0);
            }
            awr awr2 = this.a(aov.r.t());
            this.a(ams2, bbe2, 0, 1, 0, 6, 4, 8, aov.a.t(), aov.a.t(), false);
            this.a(ams2, bbe2, 1, 0, 1, 2, 0, 7, aov.ak.t(), aov.ak.t(), false);
            this.a(ams2, bbe2, 4, 0, 1, 5, 0, 7, aov.ak.t(), aov.ak.t(), false);
            this.a(ams2, bbe2, 0, 0, 0, 0, 0, 8, awr2, awr2, false);
            this.a(ams2, bbe2, 6, 0, 0, 6, 0, 8, awr2, awr2, false);
            this.a(ams2, bbe2, 1, 0, 0, 5, 0, 0, awr2, awr2, false);
            this.a(ams2, bbe2, 1, 0, 8, 5, 0, 8, awr2, awr2, false);
            this.a(ams2, bbe2, 3, 0, 1, 3, 0, 7, aov.j.t(), aov.j.t(), false);
            for (n2 = 1; n2 <= 7; ++n2) {
                \u2603 = ((apq)this.a).g();
                \u2603 = \u2603 / 3;
                this.a(ams2, this.a.a(ri.a(random, \u2603, \u2603)), 1, 1, n2, bbe2);
                this.a(ams2, this.a.a(ri.a(random, \u2603, \u2603)), 2, 1, n2, bbe2);
                \u2603 = ((apq)this.b).g();
                \u2603 = \u2603 / 3;
                this.a(ams2, this.b.a(ri.a(random, \u2603, \u2603)), 4, 1, n2, bbe2);
                this.a(ams2, this.b.a(ri.a(random, \u2603, \u2603)), 5, 1, n2, bbe2);
            }
            for (n2 = 0; n2 < 9; ++n2) {
                for (\u2603 = 0; \u2603 < 7; ++\u2603) {
                    this.c(ams2, \u2603, 4, n2, bbe2);
                    this.b(ams2, aov.d.t(), \u2603, -1, n2, bbe2);
                }
            }
            return true;
        }
    }

    public static class j
    extends n {
        private boolean a;

        public j() {
        }

        public j(k k2, int n2, Random random, bbe bbe2, fa fa2) {
            super(k2, n2);
            this.a(fa2);
            this.l = bbe2;
        }

        public static j a(k k2, List<bbv> list, Random random, int n2, int n3, int n4, fa fa2, int n5) {
            bbe bbe2 = bbe.a(n2, n3, n4, 0, 0, 0, 10, 6, 7, fa2);
            if (!j.a(bbe2) || bbv.a(list, bbe2) != null) {
                return null;
            }
            return new j(k2, n5, random, bbe2, fa2);
        }

        @Override
        protected void a(fy fy2) {
            super.a(fy2);
            fy2.a("Chest", this.a);
        }

        @Override
        protected void a(fy fy2, bce bce2) {
            super.a(fy2, bce2);
            this.a = fy2.q("Chest");
        }

        @Override
        public boolean a(ams ams22, Random random, bbe bbe2) {
            ams ams22;
            int n2;
            if (this.g < 0) {
                this.g = this.b(ams22, bbe2);
                if (this.g < 0) {
                    return true;
                }
                this.l.a(0, this.g - this.l.e + 6 - 1, 0);
            }
            awr awr2 = aov.e.t();
            \u2603 = this.a(aov.ad.t().a(aub.a, fa.c));
            \u2603 = this.a(aov.ad.t().a(aub.a, fa.e));
            \u2603 = this.a(aov.f.t());
            \u2603 = this.a(aov.aw.t().a(aub.a, fa.c));
            \u2603 = this.a(aov.r.t());
            \u2603 = this.a(aov.aO.t());
            this.a(ams22, bbe2, 0, 1, 0, 9, 4, 6, aov.a.t(), aov.a.t(), false);
            this.a(ams22, bbe2, 0, 0, 0, 9, 0, 6, awr2, awr2, false);
            this.a(ams22, bbe2, 0, 4, 0, 9, 4, 6, awr2, awr2, false);
            this.a(ams22, bbe2, 0, 5, 0, 9, 5, 6, aov.U.t(), aov.U.t(), false);
            this.a(ams22, bbe2, 1, 5, 1, 8, 5, 5, aov.a.t(), aov.a.t(), false);
            this.a(ams22, bbe2, 1, 1, 0, 2, 3, 0, \u2603, \u2603, false);
            this.a(ams22, bbe2, 0, 1, 0, 0, 4, 0, \u2603, \u2603, false);
            this.a(ams22, bbe2, 3, 1, 0, 3, 4, 0, \u2603, \u2603, false);
            this.a(ams22, bbe2, 0, 1, 6, 0, 4, 6, \u2603, \u2603, false);
            this.a(ams22, \u2603, 3, 3, 1, bbe2);
            this.a(ams22, bbe2, 3, 1, 2, 3, 3, 2, \u2603, \u2603, false);
            this.a(ams22, bbe2, 4, 1, 3, 5, 3, 3, \u2603, \u2603, false);
            this.a(ams22, bbe2, 0, 1, 1, 0, 3, 5, \u2603, \u2603, false);
            this.a(ams22, bbe2, 1, 1, 6, 5, 3, 6, \u2603, \u2603, false);
            this.a(ams22, bbe2, 5, 1, 0, 5, 3, 0, \u2603, \u2603, false);
            this.a(ams22, bbe2, 9, 1, 0, 9, 3, 0, \u2603, \u2603, false);
            this.a(ams22, bbe2, 6, 1, 4, 9, 4, 6, awr2, awr2, false);
            this.a(ams22, aov.k.t(), 7, 1, 5, bbe2);
            this.a(ams22, aov.k.t(), 8, 1, 5, bbe2);
            this.a(ams22, aov.bi.t(), 9, 2, 5, bbe2);
            this.a(ams22, aov.bi.t(), 9, 2, 4, bbe2);
            this.a(ams22, bbe2, 7, 2, 4, 8, 2, 5, aov.a.t(), aov.a.t(), false);
            this.a(ams22, awr2, 6, 1, 3, bbe2);
            this.a(ams22, aov.al.t(), 6, 2, 3, bbe2);
            this.a(ams22, aov.al.t(), 6, 3, 3, bbe2);
            this.a(ams22, aov.T.t(), 8, 1, 1, bbe2);
            this.a(ams22, aov.bj.t(), 0, 2, 2, bbe2);
            this.a(ams22, aov.bj.t(), 0, 2, 4, bbe2);
            this.a(ams22, aov.bj.t(), 2, 2, 6, bbe2);
            this.a(ams22, aov.bj.t(), 4, 2, 6, bbe2);
            this.a(ams22, \u2603, 2, 1, 4, bbe2);
            this.a(ams22, aov.aB.t(), 2, 2, 4, bbe2);
            this.a(ams22, \u2603, 1, 1, 5, bbe2);
            this.a(ams22, \u2603, 2, 1, 5, bbe2);
            this.a(ams22, \u2603, 1, 1, 4, bbe2);
            if (!this.a && bbe2.b(new et(this.a(5, 5), this.d(1), this.b(5, 5)))) {
                this.a = true;
                this.a(ams22, bbe2, random, 5, 1, 5, bfl.e);
            }
            for (n2 = 6; n2 <= 8; ++n2) {
                if (this.a(ams22, n2, 0, -1, bbe2).a() != bcx.a || this.a(ams22, n2, -1, -1, bbe2).a() == bcx.a) continue;
                this.a(ams22, \u2603, n2, 0, -1, bbe2);
                if (this.a(ams22, n2, -1, -1, bbe2).u() != aov.da) continue;
                this.a(ams22, aov.c.t(), n2, -1, -1, bbe2);
            }
            for (n2 = 0; n2 < 7; ++n2) {
                for (\u2603 = 0; \u2603 < 10; ++\u2603) {
                    this.c(ams22, \u2603, 6, n2, bbe2);
                    this.b(ams22, awr2, \u2603, -1, n2, bbe2);
                }
            }
            this.a(ams22, bbe2, 7, 1, 1, 1);
            return true;
        }

        @Override
        protected int c(int n2, int n3) {
            return 3;
        }
    }

    public static class m
    extends n {
        public m() {
        }

        public m(k k2, int n2, Random random, bbe bbe2, fa fa2) {
            super(k2, n2);
            this.a(fa2);
            this.l = bbe2;
        }

        public static m a(k k2, List<bbv> list, Random random, int n2, int n3, int n4, fa fa2, int n5) {
            bbe bbe2 = bbe.a(n2, n3, n4, 0, 0, 0, 9, 7, 12, fa2);
            if (!m.a(bbe2) || bbv.a(list, bbe2) != null) {
                return null;
            }
            return new m(k2, n5, random, bbe2, fa2);
        }

        @Override
        public boolean a(ams ams22, Random random, bbe bbe2) {
            ams ams22;
            int n2;
            if (this.g < 0) {
                this.g = this.b(ams22, bbe2);
                if (this.g < 0) {
                    return true;
                }
                this.l.a(0, this.g - this.l.e + 7 - 1, 0);
            }
            awr awr2 = this.a(aov.e.t());
            \u2603 = this.a(aov.ad.t().a(aub.a, fa.c));
            \u2603 = this.a(aov.ad.t().a(aub.a, fa.d));
            \u2603 = this.a(aov.ad.t().a(aub.a, fa.f));
            \u2603 = this.a(aov.ad.t().a(aub.a, fa.e));
            \u2603 = this.a(aov.f.t());
            \u2603 = this.a(aov.r.t());
            this.a(ams22, bbe2, 1, 1, 1, 7, 4, 4, aov.a.t(), aov.a.t(), false);
            this.a(ams22, bbe2, 2, 1, 6, 8, 4, 10, aov.a.t(), aov.a.t(), false);
            this.a(ams22, bbe2, 2, 0, 5, 8, 0, 10, \u2603, \u2603, false);
            this.a(ams22, bbe2, 1, 0, 1, 7, 0, 4, \u2603, \u2603, false);
            this.a(ams22, bbe2, 0, 0, 0, 0, 3, 5, awr2, awr2, false);
            this.a(ams22, bbe2, 8, 0, 0, 8, 3, 10, awr2, awr2, false);
            this.a(ams22, bbe2, 1, 0, 0, 7, 2, 0, awr2, awr2, false);
            this.a(ams22, bbe2, 1, 0, 5, 2, 1, 5, awr2, awr2, false);
            this.a(ams22, bbe2, 2, 0, 6, 2, 3, 10, awr2, awr2, false);
            this.a(ams22, bbe2, 3, 0, 10, 7, 3, 10, awr2, awr2, false);
            this.a(ams22, bbe2, 1, 2, 0, 7, 3, 0, \u2603, \u2603, false);
            this.a(ams22, bbe2, 1, 2, 5, 2, 3, 5, \u2603, \u2603, false);
            this.a(ams22, bbe2, 0, 4, 1, 8, 4, 1, \u2603, \u2603, false);
            this.a(ams22, bbe2, 0, 4, 4, 3, 4, 4, \u2603, \u2603, false);
            this.a(ams22, bbe2, 0, 5, 2, 8, 5, 3, \u2603, \u2603, false);
            this.a(ams22, \u2603, 0, 4, 2, bbe2);
            this.a(ams22, \u2603, 0, 4, 3, bbe2);
            this.a(ams22, \u2603, 8, 4, 2, bbe2);
            this.a(ams22, \u2603, 8, 4, 3, bbe2);
            this.a(ams22, \u2603, 8, 4, 4, bbe2);
            \u2603 = \u2603;
            \u2603 = \u2603;
            \u2603 = \u2603;
            \u2603 = \u2603;
            for (n2 = -1; n2 <= 2; ++n2) {
                for (\u2603 = 0; \u2603 <= 8; ++\u2603) {
                    this.a(ams22, \u2603, \u2603, 4 + n2, n2, bbe2);
                    if (n2 <= -1 && \u2603 > 1 || n2 <= 0 && \u2603 > 3 || n2 <= 1 && \u2603 > 4 && \u2603 < 6) continue;
                    this.a(ams22, \u2603, \u2603, 4 + n2, 5 - n2, bbe2);
                }
            }
            this.a(ams22, bbe2, 3, 4, 5, 3, 4, 10, \u2603, \u2603, false);
            this.a(ams22, bbe2, 7, 4, 2, 7, 4, 10, \u2603, \u2603, false);
            this.a(ams22, bbe2, 4, 5, 4, 4, 5, 10, \u2603, \u2603, false);
            this.a(ams22, bbe2, 6, 5, 4, 6, 5, 10, \u2603, \u2603, false);
            this.a(ams22, bbe2, 5, 6, 3, 5, 6, 10, \u2603, \u2603, false);
            for (n2 = 4; n2 >= 1; --n2) {
                this.a(ams22, \u2603, n2, 2 + n2, 7 - n2, bbe2);
                for (\u2603 = 8 - n2; \u2603 <= 10; ++\u2603) {
                    this.a(ams22, \u2603, n2, 2 + n2, \u2603, bbe2);
                }
            }
            this.a(ams22, \u2603, 6, 6, 3, bbe2);
            this.a(ams22, \u2603, 7, 5, 4, bbe2);
            this.a(ams22, \u2603, 6, 6, 4, bbe2);
            for (n2 = 6; n2 <= 8; ++n2) {
                for (\u2603 = 5; \u2603 <= 10; ++\u2603) {
                    this.a(ams22, \u2603, n2, 12 - n2, \u2603, bbe2);
                }
            }
            this.a(ams22, \u2603, 0, 2, 1, bbe2);
            this.a(ams22, \u2603, 0, 2, 4, bbe2);
            this.a(ams22, aov.bj.t(), 0, 2, 2, bbe2);
            this.a(ams22, aov.bj.t(), 0, 2, 3, bbe2);
            this.a(ams22, \u2603, 4, 2, 0, bbe2);
            this.a(ams22, aov.bj.t(), 5, 2, 0, bbe2);
            this.a(ams22, \u2603, 6, 2, 0, bbe2);
            this.a(ams22, \u2603, 8, 2, 1, bbe2);
            this.a(ams22, aov.bj.t(), 8, 2, 2, bbe2);
            this.a(ams22, aov.bj.t(), 8, 2, 3, bbe2);
            this.a(ams22, \u2603, 8, 2, 4, bbe2);
            this.a(ams22, \u2603, 8, 2, 5, bbe2);
            this.a(ams22, \u2603, 8, 2, 6, bbe2);
            this.a(ams22, aov.bj.t(), 8, 2, 7, bbe2);
            this.a(ams22, aov.bj.t(), 8, 2, 8, bbe2);
            this.a(ams22, \u2603, 8, 2, 9, bbe2);
            this.a(ams22, \u2603, 2, 2, 6, bbe2);
            this.a(ams22, aov.bj.t(), 2, 2, 7, bbe2);
            this.a(ams22, aov.bj.t(), 2, 2, 8, bbe2);
            this.a(ams22, \u2603, 2, 2, 9, bbe2);
            this.a(ams22, \u2603, 4, 4, 10, bbe2);
            this.a(ams22, aov.bj.t(), 5, 4, 10, bbe2);
            this.a(ams22, \u2603, 6, 4, 10, bbe2);
            this.a(ams22, \u2603, 5, 5, 10, bbe2);
            this.a(ams22, aov.a.t(), 2, 1, 0, bbe2);
            this.a(ams22, aov.a.t(), 2, 2, 0, bbe2);
            this.a(ams22, fa.c, 2, 3, 1, bbe2);
            this.a(ams22, bbe2, random, 2, 1, 0, fa.c);
            this.a(ams22, bbe2, 1, 0, -1, 3, 2, -1, aov.a.t(), aov.a.t(), false);
            if (this.a(ams22, 2, 0, -1, bbe2).a() == bcx.a && this.a(ams22, 2, -1, -1, bbe2).a() != bcx.a) {
                this.a(ams22, \u2603, 2, 0, -1, bbe2);
                if (this.a(ams22, 2, -1, -1, bbe2).u() == aov.da) {
                    this.a(ams22, aov.c.t(), 2, -1, -1, bbe2);
                }
            }
            for (n2 = 0; n2 < 5; ++n2) {
                for (\u2603 = 0; \u2603 < 9; ++\u2603) {
                    this.c(ams22, \u2603, 7, n2, bbe2);
                    this.b(ams22, awr2, \u2603, -1, n2, bbe2);
                }
            }
            for (n2 = 5; n2 < 11; ++n2) {
                for (\u2603 = 2; \u2603 < 9; ++\u2603) {
                    this.c(ams22, \u2603, 7, n2, bbe2);
                    this.b(ams22, awr2, \u2603, -1, n2, bbe2);
                }
            }
            this.a(ams22, bbe2, 4, 1, 2, 2);
            return true;
        }
    }

    public static class f
    extends n {
        public f() {
        }

        public f(k k2, int n2, Random random, bbe bbe2, fa fa2) {
            super(k2, n2);
            this.a(fa2);
            this.l = bbe2;
        }

        public static f a(k k2, List<bbv> list, Random random, int n2, int n3, int n4, fa fa2, int n5) {
            bbe bbe2 = bbe.a(n2, n3, n4, 0, 0, 0, 9, 7, 11, fa2);
            if (!f.a(bbe2) || bbv.a(list, bbe2) != null) {
                return null;
            }
            return new f(k2, n5, random, bbe2, fa2);
        }

        @Override
        public boolean a(ams ams22, Random random, bbe bbe2) {
            ams ams22;
            int n2;
            if (this.g < 0) {
                this.g = this.b(ams22, bbe2);
                if (this.g < 0) {
                    return true;
                }
                this.l.a(0, this.g - this.l.e + 7 - 1, 0);
            }
            awr awr2 = this.a(aov.e.t());
            \u2603 = this.a(aov.ad.t().a(aub.a, fa.c));
            \u2603 = this.a(aov.ad.t().a(aub.a, fa.d));
            \u2603 = this.a(aov.ad.t().a(aub.a, fa.e));
            \u2603 = this.a(aov.f.t());
            \u2603 = this.a(aov.r.t());
            \u2603 = this.a(aov.aO.t());
            this.a(ams22, bbe2, 1, 1, 1, 7, 4, 4, aov.a.t(), aov.a.t(), false);
            this.a(ams22, bbe2, 2, 1, 6, 8, 4, 10, aov.a.t(), aov.a.t(), false);
            this.a(ams22, bbe2, 2, 0, 6, 8, 0, 10, aov.d.t(), aov.d.t(), false);
            this.a(ams22, awr2, 6, 0, 6, bbe2);
            this.a(ams22, bbe2, 2, 1, 6, 2, 1, 10, \u2603, \u2603, false);
            this.a(ams22, bbe2, 8, 1, 6, 8, 1, 10, \u2603, \u2603, false);
            this.a(ams22, bbe2, 3, 1, 10, 7, 1, 10, \u2603, \u2603, false);
            this.a(ams22, bbe2, 1, 0, 1, 7, 0, 4, \u2603, \u2603, false);
            this.a(ams22, bbe2, 0, 0, 0, 0, 3, 5, awr2, awr2, false);
            this.a(ams22, bbe2, 8, 0, 0, 8, 3, 5, awr2, awr2, false);
            this.a(ams22, bbe2, 1, 0, 0, 7, 1, 0, awr2, awr2, false);
            this.a(ams22, bbe2, 1, 0, 5, 7, 1, 5, awr2, awr2, false);
            this.a(ams22, bbe2, 1, 2, 0, 7, 3, 0, \u2603, \u2603, false);
            this.a(ams22, bbe2, 1, 2, 5, 7, 3, 5, \u2603, \u2603, false);
            this.a(ams22, bbe2, 0, 4, 1, 8, 4, 1, \u2603, \u2603, false);
            this.a(ams22, bbe2, 0, 4, 4, 8, 4, 4, \u2603, \u2603, false);
            this.a(ams22, bbe2, 0, 5, 2, 8, 5, 3, \u2603, \u2603, false);
            this.a(ams22, \u2603, 0, 4, 2, bbe2);
            this.a(ams22, \u2603, 0, 4, 3, bbe2);
            this.a(ams22, \u2603, 8, 4, 2, bbe2);
            this.a(ams22, \u2603, 8, 4, 3, bbe2);
            \u2603 = \u2603;
            \u2603 = \u2603;
            \u2603 = \u2603;
            for (n2 = -1; n2 <= 2; ++n2) {
                for (\u2603 = 0; \u2603 <= 8; ++\u2603) {
                    this.a(ams22, \u2603, \u2603, 4 + n2, n2, bbe2);
                    this.a(ams22, \u2603, \u2603, 4 + n2, 5 - n2, bbe2);
                }
            }
            this.a(ams22, \u2603, 0, 2, 1, bbe2);
            this.a(ams22, \u2603, 0, 2, 4, bbe2);
            this.a(ams22, \u2603, 8, 2, 1, bbe2);
            this.a(ams22, \u2603, 8, 2, 4, bbe2);
            this.a(ams22, aov.bj.t(), 0, 2, 2, bbe2);
            this.a(ams22, aov.bj.t(), 0, 2, 3, bbe2);
            this.a(ams22, aov.bj.t(), 8, 2, 2, bbe2);
            this.a(ams22, aov.bj.t(), 8, 2, 3, bbe2);
            this.a(ams22, aov.bj.t(), 2, 2, 5, bbe2);
            this.a(ams22, aov.bj.t(), 3, 2, 5, bbe2);
            this.a(ams22, aov.bj.t(), 5, 2, 0, bbe2);
            this.a(ams22, aov.bj.t(), 6, 2, 5, bbe2);
            this.a(ams22, \u2603, 2, 1, 3, bbe2);
            this.a(ams22, aov.aB.t(), 2, 2, 3, bbe2);
            this.a(ams22, \u2603, 1, 1, 4, bbe2);
            this.a(ams22, \u2603, 2, 1, 4, bbe2);
            this.a(ams22, \u2603, 1, 1, 3, bbe2);
            this.a(ams22, bbe2, 5, 0, 1, 7, 0, 3, aov.T.t(), aov.T.t(), false);
            this.a(ams22, aov.T.t(), 6, 1, 1, bbe2);
            this.a(ams22, aov.T.t(), 6, 1, 2, bbe2);
            this.a(ams22, aov.a.t(), 2, 1, 0, bbe2);
            this.a(ams22, aov.a.t(), 2, 2, 0, bbe2);
            this.a(ams22, fa.c, 2, 3, 1, bbe2);
            this.a(ams22, bbe2, random, 2, 1, 0, fa.c);
            if (this.a(ams22, 2, 0, -1, bbe2).a() == bcx.a && this.a(ams22, 2, -1, -1, bbe2).a() != bcx.a) {
                this.a(ams22, \u2603, 2, 0, -1, bbe2);
                if (this.a(ams22, 2, -1, -1, bbe2).u() == aov.da) {
                    this.a(ams22, aov.c.t(), 2, -1, -1, bbe2);
                }
            }
            this.a(ams22, aov.a.t(), 6, 1, 5, bbe2);
            this.a(ams22, aov.a.t(), 6, 2, 5, bbe2);
            this.a(ams22, fa.d, 6, 3, 4, bbe2);
            this.a(ams22, bbe2, random, 6, 1, 5, fa.d);
            for (n2 = 0; n2 < 5; ++n2) {
                for (\u2603 = 0; \u2603 < 9; ++\u2603) {
                    this.c(ams22, \u2603, 7, n2, bbe2);
                    this.b(ams22, awr2, \u2603, -1, n2, bbe2);
                }
            }
            this.a(ams22, bbe2, 4, 1, 2, 2);
            return true;
        }

        @Override
        protected int c(int n2, int n3) {
            if (n2 == 0) {
                return 4;
            }
            return super.c(n2, n3);
        }
    }

    public static class h
    extends n {
        private boolean a;
        private int b;

        public h() {
        }

        public h(k k2, int n2, Random random, bbe bbe2, fa fa2) {
            super(k2, n2);
            this.a(fa2);
            this.l = bbe2;
            this.a = random.nextBoolean();
            this.b = random.nextInt(3);
        }

        @Override
        protected void a(fy fy2) {
            super.a(fy2);
            fy2.a("T", this.b);
            fy2.a("C", this.a);
        }

        @Override
        protected void a(fy fy2, bce bce2) {
            super.a(fy2, bce2);
            this.b = fy2.h("T");
            this.a = fy2.q("C");
        }

        public static h a(k k2, List<bbv> list, Random random, int n2, int n3, int n4, fa fa2, int n5) {
            bbe bbe2 = bbe.a(n2, n3, n4, 0, 0, 0, 4, 6, 5, fa2);
            if (!h.a(bbe2) || bbv.a(list, bbe2) != null) {
                return null;
            }
            return new h(k2, n5, random, bbe2, fa2);
        }

        @Override
        public boolean a(ams ams22, Random random, bbe bbe2) {
            ams ams22;
            if (this.g < 0) {
                this.g = this.b(ams22, bbe2);
                if (this.g < 0) {
                    return true;
                }
                this.l.a(0, this.g - this.l.e + 6 - 1, 0);
            }
            awr awr2 = this.a(aov.e.t());
            \u2603 = this.a(aov.f.t());
            \u2603 = this.a(aov.aw.t().a(aub.a, fa.c));
            \u2603 = this.a(aov.r.t());
            \u2603 = this.a(aov.aO.t());
            this.a(ams22, bbe2, 1, 1, 1, 3, 5, 4, aov.a.t(), aov.a.t(), false);
            this.a(ams22, bbe2, 0, 0, 0, 3, 0, 4, awr2, awr2, false);
            this.a(ams22, bbe2, 1, 0, 1, 2, 0, 3, aov.d.t(), aov.d.t(), false);
            if (this.a) {
                this.a(ams22, bbe2, 1, 4, 1, 2, 4, 3, \u2603, \u2603, false);
            } else {
                this.a(ams22, bbe2, 1, 5, 1, 2, 5, 3, \u2603, \u2603, false);
            }
            this.a(ams22, \u2603, 1, 4, 0, bbe2);
            this.a(ams22, \u2603, 2, 4, 0, bbe2);
            this.a(ams22, \u2603, 1, 4, 4, bbe2);
            this.a(ams22, \u2603, 2, 4, 4, bbe2);
            this.a(ams22, \u2603, 0, 4, 1, bbe2);
            this.a(ams22, \u2603, 0, 4, 2, bbe2);
            this.a(ams22, \u2603, 0, 4, 3, bbe2);
            this.a(ams22, \u2603, 3, 4, 1, bbe2);
            this.a(ams22, \u2603, 3, 4, 2, bbe2);
            this.a(ams22, \u2603, 3, 4, 3, bbe2);
            this.a(ams22, bbe2, 0, 1, 0, 0, 3, 0, \u2603, \u2603, false);
            this.a(ams22, bbe2, 3, 1, 0, 3, 3, 0, \u2603, \u2603, false);
            this.a(ams22, bbe2, 0, 1, 4, 0, 3, 4, \u2603, \u2603, false);
            this.a(ams22, bbe2, 3, 1, 4, 3, 3, 4, \u2603, \u2603, false);
            this.a(ams22, bbe2, 0, 1, 1, 0, 3, 3, \u2603, \u2603, false);
            this.a(ams22, bbe2, 3, 1, 1, 3, 3, 3, \u2603, \u2603, false);
            this.a(ams22, bbe2, 1, 1, 0, 2, 3, 0, \u2603, \u2603, false);
            this.a(ams22, bbe2, 1, 1, 4, 2, 3, 4, \u2603, \u2603, false);
            this.a(ams22, aov.bj.t(), 0, 2, 2, bbe2);
            this.a(ams22, aov.bj.t(), 3, 2, 2, bbe2);
            if (this.b > 0) {
                this.a(ams22, \u2603, this.b, 1, 3, bbe2);
                this.a(ams22, aov.aB.t(), this.b, 2, 3, bbe2);
            }
            this.a(ams22, aov.a.t(), 1, 1, 0, bbe2);
            this.a(ams22, aov.a.t(), 1, 2, 0, bbe2);
            this.a(ams22, bbe2, random, 1, 1, 0, fa.c);
            if (this.a(ams22, 1, 0, -1, bbe2).a() == bcx.a && this.a(ams22, 1, -1, -1, bbe2).a() != bcx.a) {
                this.a(ams22, \u2603, 1, 0, -1, bbe2);
                if (this.a(ams22, 1, -1, -1, bbe2).u() == aov.da) {
                    this.a(ams22, aov.c.t(), 1, -1, -1, bbe2);
                }
            }
            for (int i2 = 0; i2 < 5; ++i2) {
                for (\u2603 = 0; \u2603 < 4; ++\u2603) {
                    this.c(ams22, \u2603, 6, i2, bbe2);
                    this.b(ams22, awr2, \u2603, -1, i2, bbe2);
                }
            }
            this.a(ams22, bbe2, 1, 1, 2, 1);
            return true;
        }
    }

    public static class a
    extends n {
        public a() {
        }

        public a(k k2, int n2, Random random, bbe bbe2, fa fa2) {
            super(k2, n2);
            this.a(fa2);
            this.l = bbe2;
        }

        public static a a(k k2, List<bbv> list, Random random, int n2, int n3, int n4, fa fa2, int n5) {
            bbe bbe2 = bbe.a(n2, n3, n4, 0, 0, 0, 9, 9, 6, fa2);
            if (!a.a(bbe2) || bbv.a(list, bbe2) != null) {
                return null;
            }
            return new a(k2, n5, random, bbe2, fa2);
        }

        @Override
        public boolean a(ams ams22, Random random, bbe bbe2) {
            ams ams22;
            if (this.g < 0) {
                this.g = this.b(ams22, bbe2);
                if (this.g < 0) {
                    return true;
                }
                this.l.a(0, this.g - this.l.e + 9 - 1, 0);
            }
            awr awr2 = this.a(aov.e.t());
            \u2603 = this.a(aov.ad.t().a(aub.a, fa.c));
            \u2603 = this.a(aov.ad.t().a(aub.a, fa.d));
            \u2603 = this.a(aov.ad.t().a(aub.a, fa.f));
            \u2603 = this.a(aov.f.t());
            \u2603 = this.a(aov.aw.t().a(aub.a, fa.c));
            \u2603 = this.a(aov.aO.t());
            this.a(ams22, bbe2, 1, 1, 1, 7, 5, 4, aov.a.t(), aov.a.t(), false);
            this.a(ams22, bbe2, 0, 0, 0, 8, 0, 5, awr2, awr2, false);
            this.a(ams22, bbe2, 0, 5, 0, 8, 5, 5, awr2, awr2, false);
            this.a(ams22, bbe2, 0, 6, 1, 8, 6, 4, awr2, awr2, false);
            this.a(ams22, bbe2, 0, 7, 2, 8, 7, 3, awr2, awr2, false);
            for (int i2 = -1; i2 <= 2; ++i2) {
                for (i3 = 0; i3 <= 8; ++i3) {
                    this.a(ams22, \u2603, i3, 6 + i2, i2, bbe2);
                    this.a(ams22, \u2603, i3, 6 + i2, 5 - i2, bbe2);
                }
            }
            this.a(ams22, bbe2, 0, 1, 0, 0, 1, 5, awr2, awr2, false);
            this.a(ams22, bbe2, 1, 1, 5, 8, 1, 5, awr2, awr2, false);
            this.a(ams22, bbe2, 8, 1, 0, 8, 1, 4, awr2, awr2, false);
            this.a(ams22, bbe2, 2, 1, 0, 7, 1, 0, awr2, awr2, false);
            this.a(ams22, bbe2, 0, 2, 0, 0, 4, 0, awr2, awr2, false);
            this.a(ams22, bbe2, 0, 2, 5, 0, 4, 5, awr2, awr2, false);
            this.a(ams22, bbe2, 8, 2, 5, 8, 4, 5, awr2, awr2, false);
            this.a(ams22, bbe2, 8, 2, 0, 8, 4, 0, awr2, awr2, false);
            this.a(ams22, bbe2, 0, 2, 1, 0, 4, 4, \u2603, \u2603, false);
            this.a(ams22, bbe2, 1, 2, 5, 7, 4, 5, \u2603, \u2603, false);
            this.a(ams22, bbe2, 8, 2, 1, 8, 4, 4, \u2603, \u2603, false);
            this.a(ams22, bbe2, 1, 2, 0, 7, 4, 0, \u2603, \u2603, false);
            this.a(ams22, aov.bj.t(), 4, 2, 0, bbe2);
            this.a(ams22, aov.bj.t(), 5, 2, 0, bbe2);
            this.a(ams22, aov.bj.t(), 6, 2, 0, bbe2);
            this.a(ams22, aov.bj.t(), 4, 3, 0, bbe2);
            this.a(ams22, aov.bj.t(), 5, 3, 0, bbe2);
            this.a(ams22, aov.bj.t(), 6, 3, 0, bbe2);
            this.a(ams22, aov.bj.t(), 0, 2, 2, bbe2);
            this.a(ams22, aov.bj.t(), 0, 2, 3, bbe2);
            this.a(ams22, aov.bj.t(), 0, 3, 2, bbe2);
            this.a(ams22, aov.bj.t(), 0, 3, 3, bbe2);
            this.a(ams22, aov.bj.t(), 8, 2, 2, bbe2);
            this.a(ams22, aov.bj.t(), 8, 2, 3, bbe2);
            this.a(ams22, aov.bj.t(), 8, 3, 2, bbe2);
            this.a(ams22, aov.bj.t(), 8, 3, 3, bbe2);
            this.a(ams22, aov.bj.t(), 2, 2, 5, bbe2);
            this.a(ams22, aov.bj.t(), 3, 2, 5, bbe2);
            this.a(ams22, aov.bj.t(), 5, 2, 5, bbe2);
            this.a(ams22, aov.bj.t(), 6, 2, 5, bbe2);
            this.a(ams22, bbe2, 1, 4, 1, 7, 4, 1, \u2603, \u2603, false);
            this.a(ams22, bbe2, 1, 4, 4, 7, 4, 4, \u2603, \u2603, false);
            this.a(ams22, bbe2, 1, 3, 4, 7, 3, 4, aov.X.t(), aov.X.t(), false);
            this.a(ams22, \u2603, 7, 1, 4, bbe2);
            this.a(ams22, \u2603, 7, 1, 3, bbe2);
            awr \u26032 = \u2603;
            this.a(ams22, \u26032, 6, 1, 4, bbe2);
            this.a(ams22, \u26032, 5, 1, 4, bbe2);
            this.a(ams22, \u26032, 4, 1, 4, bbe2);
            this.a(ams22, \u26032, 3, 1, 4, bbe2);
            this.a(ams22, \u2603, 6, 1, 3, bbe2);
            this.a(ams22, aov.aB.t(), 6, 2, 3, bbe2);
            this.a(ams22, \u2603, 4, 1, 3, bbe2);
            this.a(ams22, aov.aB.t(), 4, 2, 3, bbe2);
            this.a(ams22, aov.ai.t(), 7, 1, 1, bbe2);
            this.a(ams22, aov.a.t(), 1, 1, 0, bbe2);
            this.a(ams22, aov.a.t(), 1, 2, 0, bbe2);
            this.a(ams22, bbe2, random, 1, 1, 0, fa.c);
            if (this.a(ams22, 1, 0, -1, bbe2).a() == bcx.a && this.a(ams22, 1, -1, -1, bbe2).a() != bcx.a) {
                this.a(ams22, \u2603, 1, 0, -1, bbe2);
                if (this.a(ams22, 1, -1, -1, bbe2).u() == aov.da) {
                    this.a(ams22, aov.c.t(), 1, -1, -1, bbe2);
                }
            }
            for (int i3 = 0; i3 < 6; ++i3) {
                for (\u2603 = 0; \u2603 < 9; ++\u2603) {
                    this.c(ams22, \u2603, 9, i3, bbe2);
                    this.b(ams22, awr2, \u2603, -1, i3, bbe2);
                }
            }
            this.a(ams22, bbe2, 2, 1, 2, 1);
            return true;
        }

        @Override
        protected int c(int n2, int n3) {
            return 1;
        }
    }

    public static class i
    extends n {
        public i() {
        }

        public i(k k2, int n2, Random random, bbe bbe2, fa fa2) {
            super(k2, n2);
            this.a(fa2);
            this.l = bbe2;
        }

        public static i a(k k2, List<bbv> list, Random random, int n2, int n3, int n4, fa fa2, int n5) {
            bbe bbe2 = bbe.a(n2, n3, n4, 0, 0, 0, 5, 12, 9, fa2);
            if (!i.a(bbe2) || bbv.a(list, bbe2) != null) {
                return null;
            }
            return new i(k2, n5, random, bbe2, fa2);
        }

        @Override
        public boolean a(ams ams22, Random random, bbe bbe2) {
            ams ams22;
            int n2;
            if (this.g < 0) {
                this.g = this.b(ams22, bbe2);
                if (this.g < 0) {
                    return true;
                }
                this.l.a(0, this.g - this.l.e + 12 - 1, 0);
            }
            awr awr2 = aov.e.t();
            \u2603 = this.a(aov.aw.t().a(aub.a, fa.c));
            \u2603 = this.a(aov.aw.t().a(aub.a, fa.e));
            \u2603 = this.a(aov.aw.t().a(aub.a, fa.f));
            this.a(ams22, bbe2, 1, 1, 1, 3, 3, 7, aov.a.t(), aov.a.t(), false);
            this.a(ams22, bbe2, 1, 5, 1, 3, 9, 3, aov.a.t(), aov.a.t(), false);
            this.a(ams22, bbe2, 1, 0, 0, 3, 0, 8, awr2, awr2, false);
            this.a(ams22, bbe2, 1, 1, 0, 3, 10, 0, awr2, awr2, false);
            this.a(ams22, bbe2, 0, 1, 1, 0, 10, 3, awr2, awr2, false);
            this.a(ams22, bbe2, 4, 1, 1, 4, 10, 3, awr2, awr2, false);
            this.a(ams22, bbe2, 0, 0, 4, 0, 4, 7, awr2, awr2, false);
            this.a(ams22, bbe2, 4, 0, 4, 4, 4, 7, awr2, awr2, false);
            this.a(ams22, bbe2, 1, 1, 8, 3, 4, 8, awr2, awr2, false);
            this.a(ams22, bbe2, 1, 5, 4, 3, 10, 4, awr2, awr2, false);
            this.a(ams22, bbe2, 1, 5, 5, 3, 5, 7, awr2, awr2, false);
            this.a(ams22, bbe2, 0, 9, 0, 4, 9, 4, awr2, awr2, false);
            this.a(ams22, bbe2, 0, 4, 0, 4, 4, 4, awr2, awr2, false);
            this.a(ams22, awr2, 0, 11, 2, bbe2);
            this.a(ams22, awr2, 4, 11, 2, bbe2);
            this.a(ams22, awr2, 2, 11, 0, bbe2);
            this.a(ams22, awr2, 2, 11, 4, bbe2);
            this.a(ams22, awr2, 1, 1, 6, bbe2);
            this.a(ams22, awr2, 1, 1, 7, bbe2);
            this.a(ams22, awr2, 2, 1, 7, bbe2);
            this.a(ams22, awr2, 3, 1, 6, bbe2);
            this.a(ams22, awr2, 3, 1, 7, bbe2);
            this.a(ams22, \u2603, 1, 1, 5, bbe2);
            this.a(ams22, \u2603, 2, 1, 6, bbe2);
            this.a(ams22, \u2603, 3, 1, 5, bbe2);
            this.a(ams22, \u2603, 1, 2, 7, bbe2);
            this.a(ams22, \u2603, 3, 2, 7, bbe2);
            this.a(ams22, aov.bj.t(), 0, 2, 2, bbe2);
            this.a(ams22, aov.bj.t(), 0, 3, 2, bbe2);
            this.a(ams22, aov.bj.t(), 4, 2, 2, bbe2);
            this.a(ams22, aov.bj.t(), 4, 3, 2, bbe2);
            this.a(ams22, aov.bj.t(), 0, 6, 2, bbe2);
            this.a(ams22, aov.bj.t(), 0, 7, 2, bbe2);
            this.a(ams22, aov.bj.t(), 4, 6, 2, bbe2);
            this.a(ams22, aov.bj.t(), 4, 7, 2, bbe2);
            this.a(ams22, aov.bj.t(), 2, 6, 0, bbe2);
            this.a(ams22, aov.bj.t(), 2, 7, 0, bbe2);
            this.a(ams22, aov.bj.t(), 2, 6, 4, bbe2);
            this.a(ams22, aov.bj.t(), 2, 7, 4, bbe2);
            this.a(ams22, aov.bj.t(), 0, 3, 6, bbe2);
            this.a(ams22, aov.bj.t(), 4, 3, 6, bbe2);
            this.a(ams22, aov.bj.t(), 2, 3, 8, bbe2);
            this.a(ams22, fa.d, 2, 4, 7, bbe2);
            this.a(ams22, fa.f, 1, 4, 6, bbe2);
            this.a(ams22, fa.e, 3, 4, 6, bbe2);
            this.a(ams22, fa.c, 2, 4, 5, bbe2);
            \u2603 = aov.au.t().a(aro.a, fa.e);
            for (n2 = 1; n2 <= 9; ++n2) {
                this.a(ams22, \u2603, 3, n2, 3, bbe2);
            }
            this.a(ams22, aov.a.t(), 2, 1, 0, bbe2);
            this.a(ams22, aov.a.t(), 2, 2, 0, bbe2);
            this.a(ams22, bbe2, random, 2, 1, 0, fa.c);
            if (this.a(ams22, 2, 0, -1, bbe2).a() == bcx.a && this.a(ams22, 2, -1, -1, bbe2).a() != bcx.a) {
                this.a(ams22, \u2603, 2, 0, -1, bbe2);
                if (this.a(ams22, 2, -1, -1, bbe2).u() == aov.da) {
                    this.a(ams22, aov.c.t(), 2, -1, -1, bbe2);
                }
            }
            for (n2 = 0; n2 < 9; ++n2) {
                for (\u2603 = 0; \u2603 < 5; ++\u2603) {
                    this.c(ams22, \u2603, 12, n2, bbe2);
                    this.b(ams22, awr2, \u2603, -1, n2, bbe2);
                }
            }
            this.a(ams22, bbe2, 2, 1, 2, 1);
            return true;
        }

        @Override
        protected int c(int n2, int n3) {
            return 2;
        }
    }

    public static class g
    extends n {
        private boolean a;

        public g() {
        }

        public g(k k2, int n2, Random random, bbe bbe2, fa fa2) {
            super(k2, n2);
            this.a(fa2);
            this.l = bbe2;
            this.a = random.nextBoolean();
        }

        @Override
        protected void a(fy fy2) {
            super.a(fy2);
            fy2.a("Terrace", this.a);
        }

        @Override
        protected void a(fy fy2, bce bce2) {
            super.a(fy2, bce2);
            this.a = fy2.q("Terrace");
        }

        public static g a(k k2, List<bbv> list, Random random, int n2, int n3, int n4, fa fa2, int n5) {
            bbe bbe2 = bbe.a(n2, n3, n4, 0, 0, 0, 5, 6, 5, fa2);
            if (bbv.a(list, bbe2) != null) {
                return null;
            }
            return new g(k2, n5, random, bbe2, fa2);
        }

        @Override
        public boolean a(ams ams22, Random random, bbe bbe2) {
            ams ams22;
            if (this.g < 0) {
                this.g = this.b(ams22, bbe2);
                if (this.g < 0) {
                    return true;
                }
                this.l.a(0, this.g - this.l.e + 6 - 1, 0);
            }
            awr awr2 = this.a(aov.e.t());
            \u2603 = this.a(aov.f.t());
            \u2603 = this.a(aov.aw.t().a(aub.a, fa.c));
            \u2603 = this.a(aov.r.t());
            \u2603 = this.a(aov.aO.t());
            this.a(ams22, bbe2, 0, 0, 0, 4, 0, 4, awr2, awr2, false);
            this.a(ams22, bbe2, 0, 4, 0, 4, 4, 4, \u2603, \u2603, false);
            this.a(ams22, bbe2, 1, 4, 1, 3, 4, 3, \u2603, \u2603, false);
            this.a(ams22, awr2, 0, 1, 0, bbe2);
            this.a(ams22, awr2, 0, 2, 0, bbe2);
            this.a(ams22, awr2, 0, 3, 0, bbe2);
            this.a(ams22, awr2, 4, 1, 0, bbe2);
            this.a(ams22, awr2, 4, 2, 0, bbe2);
            this.a(ams22, awr2, 4, 3, 0, bbe2);
            this.a(ams22, awr2, 0, 1, 4, bbe2);
            this.a(ams22, awr2, 0, 2, 4, bbe2);
            this.a(ams22, awr2, 0, 3, 4, bbe2);
            this.a(ams22, awr2, 4, 1, 4, bbe2);
            this.a(ams22, awr2, 4, 2, 4, bbe2);
            this.a(ams22, awr2, 4, 3, 4, bbe2);
            this.a(ams22, bbe2, 0, 1, 1, 0, 3, 3, \u2603, \u2603, false);
            this.a(ams22, bbe2, 4, 1, 1, 4, 3, 3, \u2603, \u2603, false);
            this.a(ams22, bbe2, 1, 1, 4, 3, 3, 4, \u2603, \u2603, false);
            this.a(ams22, aov.bj.t(), 0, 2, 2, bbe2);
            this.a(ams22, aov.bj.t(), 2, 2, 4, bbe2);
            this.a(ams22, aov.bj.t(), 4, 2, 2, bbe2);
            this.a(ams22, \u2603, 1, 1, 0, bbe2);
            this.a(ams22, \u2603, 1, 2, 0, bbe2);
            this.a(ams22, \u2603, 1, 3, 0, bbe2);
            this.a(ams22, \u2603, 2, 3, 0, bbe2);
            this.a(ams22, \u2603, 3, 3, 0, bbe2);
            this.a(ams22, \u2603, 3, 2, 0, bbe2);
            this.a(ams22, \u2603, 3, 1, 0, bbe2);
            if (this.a(ams22, 2, 0, -1, bbe2).a() == bcx.a && this.a(ams22, 2, -1, -1, bbe2).a() != bcx.a) {
                this.a(ams22, \u2603, 2, 0, -1, bbe2);
                if (this.a(ams22, 2, -1, -1, bbe2).u() == aov.da) {
                    this.a(ams22, aov.c.t(), 2, -1, -1, bbe2);
                }
            }
            this.a(ams22, bbe2, 1, 1, 1, 3, 3, 3, aov.a.t(), aov.a.t(), false);
            if (this.a) {
                this.a(ams22, \u2603, 0, 5, 0, bbe2);
                this.a(ams22, \u2603, 1, 5, 0, bbe2);
                this.a(ams22, \u2603, 2, 5, 0, bbe2);
                this.a(ams22, \u2603, 3, 5, 0, bbe2);
                this.a(ams22, \u2603, 4, 5, 0, bbe2);
                this.a(ams22, \u2603, 0, 5, 4, bbe2);
                this.a(ams22, \u2603, 1, 5, 4, bbe2);
                this.a(ams22, \u2603, 2, 5, 4, bbe2);
                this.a(ams22, \u2603, 3, 5, 4, bbe2);
                this.a(ams22, \u2603, 4, 5, 4, bbe2);
                this.a(ams22, \u2603, 4, 5, 1, bbe2);
                this.a(ams22, \u2603, 4, 5, 2, bbe2);
                this.a(ams22, \u2603, 4, 5, 3, bbe2);
                this.a(ams22, \u2603, 0, 5, 1, bbe2);
                this.a(ams22, \u2603, 0, 5, 2, bbe2);
                this.a(ams22, \u2603, 0, 5, 3, bbe2);
            }
            if (this.a) {
                \u2603 = aov.au.t().a(aro.a, fa.d);
                this.a(ams22, \u2603, 3, 1, 3, bbe2);
                this.a(ams22, \u2603, 3, 2, 3, bbe2);
                this.a(ams22, \u2603, 3, 3, 3, bbe2);
                this.a(ams22, \u2603, 3, 4, 3, bbe2);
            }
            this.a(ams22, fa.c, 2, 3, 1, bbe2);
            for (int i2 = 0; i2 < 5; ++i2) {
                for (\u2603 = 0; \u2603 < 5; ++\u2603) {
                    this.c(ams22, \u2603, 6, i2, bbe2);
                    this.b(ams22, awr2, \u2603, -1, i2, bbe2);
                }
            }
            this.a(ams22, bbe2, 1, 1, 2, 1);
            return true;
        }
    }

    public static class l
    extends o {
        private int a;

        public l() {
        }

        public l(k k2, int n2, Random random, bbe bbe2, fa fa2) {
            super(k2, n2);
            this.a(fa2);
            this.l = bbe2;
            this.a = Math.max(bbe2.c(), bbe2.e());
        }

        @Override
        protected void a(fy fy2) {
            super.a(fy2);
            fy2.a("Length", this.a);
        }

        @Override
        protected void a(fy fy2, bce bce2) {
            super.a(fy2, bce2);
            this.a = fy2.h("Length");
        }

        @Override
        public void a(bbv bbv2, List<bbv> list, Random random) {
            Object object;
            int n2;
            boolean \u26032 = false;
            for (n2 = random.nextInt(5); n2 < this.a - 8; n2 += 2 + random.nextInt(5)) {
                object = this.a((k)bbv2, list, random, 0, n2);
                if (object == null) continue;
                n2 += Math.max(((bbv)object).l.c(), ((bbv)object).l.e());
                \u26032 = true;
            }
            for (n2 = random.nextInt(5); n2 < this.a - 8; n2 += 2 + random.nextInt(5)) {
                object = this.b((k)bbv2, list, random, 0, n2);
                if (object == null) continue;
                n2 += Math.max(((bbv)object).l.c(), ((bbv)object).l.e());
                \u26032 = true;
            }
            object = this.f();
            if (\u26032 && random.nextInt(3) > 0 && object != null) {
                switch (1.a[((Enum)object).ordinal()]) {
                    default: {
                        bbz.e((k)bbv2, list, random, this.l.a - 1, this.l.b, this.l.c, fa.e, this.e());
                        break;
                    }
                    case 2: {
                        bbz.e((k)bbv2, list, random, this.l.a - 1, this.l.b, this.l.f - 2, fa.e, this.e());
                        break;
                    }
                    case 4: {
                        bbz.e((k)bbv2, list, random, this.l.d - 2, this.l.b, this.l.c - 1, fa.c, this.e());
                        break;
                    }
                    case 3: {
                        bbz.e((k)bbv2, list, random, this.l.a, this.l.b, this.l.c - 1, fa.c, this.e());
                    }
                }
            }
            if (\u26032 && random.nextInt(3) > 0 && object != null) {
                switch (1.a[((Enum)object).ordinal()]) {
                    default: {
                        bbz.e((k)bbv2, list, random, this.l.d + 1, this.l.b, this.l.c, fa.f, this.e());
                        break;
                    }
                    case 2: {
                        bbz.e((k)bbv2, list, random, this.l.d + 1, this.l.b, this.l.f - 2, fa.f, this.e());
                        break;
                    }
                    case 4: {
                        bbz.e((k)bbv2, list, random, this.l.d - 2, this.l.b, this.l.f + 1, fa.d, this.e());
                        break;
                    }
                    case 3: {
                        bbz.e((k)bbv2, list, random, this.l.a, this.l.b, this.l.f + 1, fa.d, this.e());
                    }
                }
            }
        }

        public static bbe a(k k2, List<bbv> list, Random random, int n2, int n3, int n4, fa fa2) {
            for (int i2 = 7 * ri.a(random, 3, 5); i2 >= 7; i2 -= 7) {
                bbe bbe2 = bbe.a(n2, n3, n4, 0, 0, 0, 3, 3, i2, fa2);
                if (bbv.a(list, bbe2) != null) continue;
                return bbe2;
            }
            return null;
        }

        @Override
        public boolean a(ams ams2, Random random, bbe bbe2) {
            awr awr2 = this.a(aov.da.t());
            \u2603 = this.a(aov.f.t());
            \u2603 = this.a(aov.n.t());
            \u2603 = this.a(aov.e.t());
            for (int i2 = this.l.a; i2 <= this.l.d; ++i2) {
                block1: for (\u2603 = this.l.c; \u2603 <= this.l.f; ++\u2603) {
                    et \u26032 = new et(i2, 64, \u2603);
                    if (!bbe2.b(\u26032)) continue;
                    if ((\u26032 = ams2.q(\u26032).b()).q() < ams2.M()) {
                        \u26032 = new et(\u26032.p(), ams2.M() - 1, \u26032.r());
                    }
                    while (\u26032.q() >= ams2.M() - 1) {
                        awr awr3 = ams2.o(\u26032);
                        if (awr3.u() == aov.c && ams2.d(\u26032.a())) {
                            ams2.a(\u26032, awr2, 2);
                            continue block1;
                        }
                        if (awr3.a().d()) {
                            ams2.a(\u26032, \u2603, 2);
                            continue block1;
                        }
                        if (awr3.u() == aov.m || awr3.u() == aov.A || awr3.u() == aov.cM) {
                            ams2.a(\u26032, \u2603, 2);
                            ams2.a(\u26032.b(), \u2603, 2);
                            continue block1;
                        }
                        \u26032 = \u26032.b();
                    }
                }
            }
            return true;
        }
    }

    public static abstract class o
    extends n {
        public o() {
        }

        protected o(k k2, int n2) {
            super(k2, n2);
        }
    }

    public static class k
    extends p {
        public anj a;
        public int b;
        public e c;
        public List<e> d;
        public List<bbv> e = Lists.newArrayList();
        public List<bbv> f = Lists.newArrayList();

        public k() {
        }

        public k(anj anj2, int n2, Random random, int n3, int n4, List<e> list, int n5) {
            super(null, 0, random, n3, n4);
            this.a = anj2;
            this.d = list;
            this.b = n5;
            anf anf2 = anj2.a(new et(n3, 0, n4), ank.b);
            if (anf2 instanceof anm) {
                this.h = 1;
            } else if (anf2 instanceof aob) {
                this.h = 2;
            } else if (anf2 instanceof aoe) {
                this.h = 3;
            }
            this.a(this.h);
            this.i = random.nextInt(50) == 0;
        }
    }

    public static class p
    extends n {
        public p() {
        }

        public p(k k2, int n2, Random random, int n3, int n4) {
            super(k2, n2);
            this.a(fa.c.a.a(random));
            this.l = this.f().k() == fa.a.c ? new bbe(n3, 64, n4, n3 + 6 - 1, 78, n4 + 6 - 1) : new bbe(n3, 64, n4, n3 + 6 - 1, 78, n4 + 6 - 1);
        }

        @Override
        public void a(bbv bbv2, List<bbv> list, Random random) {
            bbz.e((k)bbv2, list, random, this.l.a - 1, this.l.e - 4, this.l.c + 1, fa.e, this.e());
            bbz.e((k)bbv2, list, random, this.l.d + 1, this.l.e - 4, this.l.c + 1, fa.f, this.e());
            bbz.e((k)bbv2, list, random, this.l.a + 1, this.l.e - 4, this.l.c - 1, fa.c, this.e());
            bbz.e((k)bbv2, list, random, this.l.a + 1, this.l.e - 4, this.l.f + 1, fa.d, this.e());
        }

        @Override
        public boolean a(ams ams2, Random random, bbe bbe2) {
            if (this.g < 0) {
                this.g = this.b(ams2, bbe2);
                if (this.g < 0) {
                    return true;
                }
                this.l.a(0, this.g - this.l.e + 3, 0);
            }
            awr awr2 = this.a(aov.e.t());
            \u2603 = this.a(aov.aO.t());
            this.a(ams2, bbe2, 1, 0, 1, 4, 12, 4, awr2, aov.i.t(), false);
            this.a(ams2, aov.a.t(), 2, 12, 2, bbe2);
            this.a(ams2, aov.a.t(), 3, 12, 2, bbe2);
            this.a(ams2, aov.a.t(), 2, 12, 3, bbe2);
            this.a(ams2, aov.a.t(), 3, 12, 3, bbe2);
            this.a(ams2, \u2603, 1, 13, 1, bbe2);
            this.a(ams2, \u2603, 1, 14, 1, bbe2);
            this.a(ams2, \u2603, 4, 13, 1, bbe2);
            this.a(ams2, \u2603, 4, 14, 1, bbe2);
            this.a(ams2, \u2603, 1, 13, 4, bbe2);
            this.a(ams2, \u2603, 1, 14, 4, bbe2);
            this.a(ams2, \u2603, 4, 13, 4, bbe2);
            this.a(ams2, \u2603, 4, 14, 4, bbe2);
            this.a(ams2, bbe2, 1, 15, 1, 4, 15, 4, awr2, awr2, false);
            for (int i2 = 0; i2 <= 5; ++i2) {
                for (\u2603 = 0; \u2603 <= 5; ++\u2603) {
                    if (\u2603 != 0 && \u2603 != 5 && i2 != 0 && i2 != 5) continue;
                    this.a(ams2, awr2, \u2603, 11, i2, bbe2);
                    this.c(ams2, \u2603, 12, i2, bbe2);
                }
            }
            return true;
        }
    }

    static abstract class n
    extends bbv {
        protected int g = -1;
        private int a;
        protected int h;
        protected boolean i;

        public n() {
        }

        protected n(k k2, int n2) {
            super(n2);
            if (k2 != null) {
                this.h = k2.h;
                this.i = k2.i;
            }
        }

        @Override
        protected void a(fy fy2) {
            fy2.a("HPos", this.g);
            fy2.a("VCount", this.a);
            fy2.a("Type", (byte)this.h);
            fy2.a("Zombie", this.i);
        }

        @Override
        protected void a(fy fy2, bce bce2) {
            this.g = fy2.h("HPos");
            this.a = fy2.h("VCount");
            this.h = fy2.f("Type");
            if (fy2.q("Desert")) {
                this.h = 1;
            }
            this.i = fy2.q("Zombie");
        }

        @Nullable
        protected bbv a(k k2, List<bbv> list, Random random, int n2, int n3) {
            fa fa2 = this.f();
            if (fa2 != null) {
                switch (fa2) {
                    default: {
                        return bbz.d(k2, list, random, this.l.a - 1, this.l.b + n2, this.l.c + n3, fa.e, this.e());
                    }
                    case d: {
                        return bbz.d(k2, list, random, this.l.a - 1, this.l.b + n2, this.l.c + n3, fa.e, this.e());
                    }
                    case e: {
                        return bbz.d(k2, list, random, this.l.a + n3, this.l.b + n2, this.l.c - 1, fa.c, this.e());
                    }
                    case f: 
                }
                return bbz.d(k2, list, random, this.l.a + n3, this.l.b + n2, this.l.c - 1, fa.c, this.e());
            }
            return null;
        }

        @Nullable
        protected bbv b(k k2, List<bbv> list, Random random, int n2, int n3) {
            fa fa2 = this.f();
            if (fa2 != null) {
                switch (fa2) {
                    default: {
                        return bbz.d(k2, list, random, this.l.d + 1, this.l.b + n2, this.l.c + n3, fa.f, this.e());
                    }
                    case d: {
                        return bbz.d(k2, list, random, this.l.d + 1, this.l.b + n2, this.l.c + n3, fa.f, this.e());
                    }
                    case e: {
                        return bbz.d(k2, list, random, this.l.a + n3, this.l.b + n2, this.l.f + 1, fa.d, this.e());
                    }
                    case f: 
                }
                return bbz.d(k2, list, random, this.l.a + n3, this.l.b + n2, this.l.f + 1, fa.d, this.e());
            }
            return null;
        }

        protected int b(ams ams2, bbe bbe2) {
            int n2 = 0;
            \u2603 = 0;
            et.a \u26032 = new et.a();
            for (\u2603 = this.l.c; \u2603 <= this.l.f; ++\u2603) {
                for (\u2603 = this.l.a; \u2603 <= this.l.d; ++\u2603) {
                    \u26032.c(\u2603, 64, \u2603);
                    if (!bbe2.b(\u26032)) continue;
                    n2 += Math.max(ams2.q(\u26032).q(), ams2.s.i() - 1);
                    ++\u2603;
                }
            }
            if (\u2603 == 0) {
                return -1;
            }
            return n2 / \u2603;
        }

        protected static boolean a(bbe bbe2) {
            return bbe2 != null && bbe2.b > 10;
        }

        protected void a(ams ams22, bbe bbe2, int n2, int n3, int n4, int n5) {
            if (this.a >= n5) {
                return;
            }
            for (\u2603 = this.a; \u2603 < n5 && bbe2.b(new et(\u2603 = this.a(n2 + \u2603, n4), \u2603 = this.d(n3), \u2603 = this.b(n2 + \u2603, n4))); ++\u2603) {
                ams ams22;
                vv \u26032;
                ++this.a;
                if (this.i) {
                    \u26032 = new ads(ams22);
                    \u26032.b((double)\u2603 + 0.5, \u2603, (double)\u2603 + 0.5, 0.0f, 0.0f);
                    ((ads)\u26032).a(ams22.D(new et(\u26032)), null);
                    ((ads)\u26032).a(this.c(\u2603, 0));
                    \u26032.cW();
                    ams22.a(\u26032);
                    continue;
                }
                \u26032 = new adw(ams22);
                \u26032.b((double)\u2603 + 0.5, \u2603, (double)\u2603 + 0.5, 0.0f, 0.0f);
                ((adw)\u26032).g(this.c(\u2603, ams22.r.nextInt(6)));
                ((adw)\u26032).a(ams22.D(new et(\u26032)), null, false);
                ams22.a(\u26032);
            }
        }

        protected int c(int n2, int n3) {
            return n3;
        }

        protected awr a(awr awr2) {
            if (this.h == 1) {
                if (awr2.u() == aov.r || awr2.u() == aov.s) {
                    return aov.A.t();
                }
                if (awr2.u() == aov.e) {
                    return aov.A.a(atm.a.a.a());
                }
                if (awr2.u() == aov.f) {
                    return aov.A.a(atm.a.c.a());
                }
                if (awr2.u() == aov.ad) {
                    return aov.bO.t().a(aub.a, awr2.c(aub.a));
                }
                if (awr2.u() == aov.aw) {
                    return aov.bO.t().a(aub.a, awr2.c(aub.a));
                }
                if (awr2.u() == aov.n) {
                    return aov.A.t();
                }
            } else if (this.h == 3) {
                if (awr2.u() == aov.r || awr2.u() == aov.s) {
                    return aov.r.t().a(asm.b, asp.a.b).a(art.a, awr2.c(art.a));
                }
                if (awr2.u() == aov.f) {
                    return aov.f.t().a(asp.a, asp.a.b);
                }
                if (awr2.u() == aov.ad) {
                    return aov.bU.t().a(aub.a, awr2.c(aub.a));
                }
                if (awr2.u() == aov.aO) {
                    return aov.aP.t();
                }
            } else if (this.h == 2) {
                if (awr2.u() == aov.r || awr2.u() == aov.s) {
                    return aov.s.t().a(asf.b, asp.a.e).a(art.a, awr2.c(art.a));
                }
                if (awr2.u() == aov.f) {
                    return aov.f.t().a(asp.a, asp.a.e);
                }
                if (awr2.u() == aov.ad) {
                    return aov.cC.t().a(aub.a, awr2.c(aub.a));
                }
                if (awr2.u() == aov.e) {
                    return aov.s.t().a(asf.b, asp.a.e).a(art.a, art.a.b);
                }
                if (awr2.u() == aov.aO) {
                    return aov.aT.t();
                }
            }
            return awr2;
        }

        protected apy i() {
            switch (this.h) {
                case 2: {
                    return aov.as;
                }
                case 3: {
                    return aov.ap;
                }
            }
            return aov.ao;
        }

        protected void a(ams ams2, bbe bbe2, Random random, int n2, int n3, int n4, fa fa2) {
            if (!this.i) {
                this.a(ams2, bbe2, random, n2, n3, n4, fa.c, this.i());
            }
        }

        protected void a(ams ams2, fa fa2, int n2, int n3, int n4, bbe bbe2) {
            if (!this.i) {
                this.a(ams2, aov.aa.t().a(auo.a, fa2), n2, n3, n4, bbe2);
            }
        }

        @Override
        protected void b(ams ams2, awr awr2, int n2, int n3, int n4, bbe bbe2) {
            awr awr3 = this.a(awr2);
            super.b(ams2, awr3, n2, n3, n4, bbe2);
        }

        protected void a(int n2) {
            this.h = n2;
        }
    }

    public static class e {
        public Class<? extends n> a;
        public final int b;
        public int c;
        public int d;

        public e(Class<? extends n> class_, int n2, int n3) {
            this.a = class_;
            this.b = n2;
            this.d = n3;
        }

        public boolean a(int n2) {
            return this.d == 0 || this.c < this.d;
        }

        public boolean a() {
            return this.d == 0 || this.c < this.d;
        }
    }
}

