/*
 * Decompiled with CFR 0.150.
 */
import net.minecraft.server.MinecraftServer;

public class dd
extends bi {
    @Override
    public String c() {
        return "save-off";
    }

    @Override
    public String b(bn bn2) {
        return "commands.save-off.usage";
    }

    @Override
    public void a(MinecraftServer minecraftServer, bn bn2, String[] arrstring) throws ei {
        boolean \u26032 = false;
        for (int i2 = 0; i2 < minecraftServer.d.length; ++i2) {
            if (minecraftServer.d[i2] == null) continue;
            om om2 = minecraftServer.d[i2];
            if (om2.b) continue;
            om2.b = true;
            \u26032 = true;
        }
        if (!\u26032) {
            throw new ei("commands.save-off.alreadyOff", new Object[0]);
        }
        dd.a(bn2, (bk)this, "commands.save.disabled", new Object[0]);
    }
}

