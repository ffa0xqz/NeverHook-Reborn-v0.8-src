/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Optional
 *  com.google.common.collect.ImmutableSet
 */
import com.google.common.base.Optional;
import com.google.common.collect.ImmutableSet;
import java.util.Collection;

public class axd
extends axc<Boolean> {
    private final ImmutableSet<Boolean> a = ImmutableSet.of((Object)true, (Object)false);

    protected axd(String string) {
        super(string, Boolean.class);
    }

    @Override
    public Collection<Boolean> c() {
        return this.a;
    }

    public static axd a(String string) {
        return new axd(string);
    }

    @Override
    public Optional<Boolean> b(String string) {
        if ("true".equals(string) || "false".equals(string)) {
            return Optional.of((Object)Boolean.valueOf(string));
        }
        return Optional.absent();
    }

    @Override
    public String a(Boolean bl2) {
        return bl2.toString();
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object instanceof axd && super.equals(object)) {
            axd axd2 = (axd)object;
            return this.a.equals(axd2.a);
        }
        return false;
    }

    @Override
    public int hashCode() {
        return 31 * super.hashCode() + this.a.hashCode();
    }
}

