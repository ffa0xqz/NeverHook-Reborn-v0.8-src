/*
 * Decompiled with CFR 0.150.
 */
public class sc
implements rs {
    @Override
    public int a() {
        return 107;
    }

    @Override
    public fy a(fy fy22) {
        fy fy22;
        if (!"MobSpawner".equals(fy22.l("id"))) {
            return fy22;
        }
        if (fy22.b("EntityId", 8)) {
            Object object = fy22.l("EntityId");
            fy \u26032 = fy22.p("SpawnData");
            \u26032.a("id", (String)(((String)object).isEmpty() ? "Pig" : object));
            fy22.a("SpawnData", \u26032);
            fy22.r("EntityId");
        }
        if (fy22.b("SpawnPotentials", 9)) {
            object = fy22.c("SpawnPotentials", 10);
            for (int i2 = 0; i2 < ((ge)object).c(); ++i2) {
                fy fy3 = ((ge)object).b(i2);
                if (!fy3.b("Type", 8)) continue;
                \u2603 = fy3.p("Properties");
                \u2603.a("id", fy3.l("Type"));
                fy3.a("Entity", \u2603);
                fy3.r("Type");
                fy3.r("Properties");
            }
        }
        return fy22;
    }
}

