/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  org.apache.commons.io.IOUtils
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.common.collect.Lists;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Random;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class blr
extends bli {
    private static final Logger a = LogManager.getLogger();
    private static final nd f = new nd("textures/gui/title/minecraft.png");
    private static final nd field_194401_g = new nd("textures/gui/title/edition.png");
    private static final nd g = new nd("textures/misc/vignette.png");
    private final boolean h;
    private final Runnable i;
    private float s;
    private List<String> t;
    private int u;
    private float v = 0.5f;

    public blr(boolean p_i47590_1_, Runnable p_i47590_2_) {
        this.h = p_i47590_1_;
        this.i = p_i47590_2_;
        if (!p_i47590_1_) {
            this.v = 0.75f;
        }
    }

    @Override
    public void e() {
        this.j.s().e();
        this.j.U().e();
        float f2 = (float)(this.u + this.m + this.m + 24) / this.v;
        if (this.s > f2) {
            this.a();
        }
    }

    @Override
    protected void a(char typedChar, int keyCode) throws IOException {
        if (keyCode == 1) {
            this.a();
        }
    }

    private void a() {
        this.i.run();
        this.j.a((bli)null);
    }

    @Override
    public boolean d() {
        return true;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void b() {
        if (this.t == null) {
            this.t = Lists.newArrayList();
            cem iresource = null;
            try {
                String s4;
                String s2 = "" + (Object)((Object)a.p) + (Object)((Object)a.q) + (Object)((Object)a.k) + (Object)((Object)a.l);
                int i2 = 274;
                if (this.h) {
                    String s1;
                    iresource = this.j.O().a(new nd("texts/end.txt"));
                    InputStream inputstream = iresource.b();
                    BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(inputstream, StandardCharsets.UTF_8));
                    Random random = new Random(8124371L);
                    while ((s1 = bufferedreader.readLine()) != null) {
                        s1 = s1.replaceAll("PLAYERNAME", this.j.K().c());
                        while (s1.contains(s2)) {
                            int j2 = s1.indexOf(s2);
                            String s22 = s1.substring(0, j2);
                            String s3 = s1.substring(j2 + s2.length());
                            s1 = s22 + (Object)((Object)a.p) + (Object)((Object)a.q) + "XXXXXXXX".substring(0, random.nextInt(4) + 3) + s3;
                        }
                        this.t.addAll(bhz.k.c(s1, 274));
                        this.t.add("");
                    }
                    inputstream.close();
                    for (int k2 = 0; k2 < 8; ++k2) {
                        this.t.add("");
                    }
                }
                InputStream inputstream1 = this.j.O().a(new nd("texts/credits.txt")).b();
                BufferedReader bufferedreader1 = new BufferedReader(new InputStreamReader(inputstream1, StandardCharsets.UTF_8));
                while ((s4 = bufferedreader1.readLine()) != null) {
                    s4 = s4.replaceAll("PLAYERNAME", this.j.K().c());
                    s4 = s4.replaceAll("\t", "    ");
                    this.t.addAll(bhz.k.c(s4, 274));
                    this.t.add("");
                }
                inputstream1.close();
                this.u = this.t.size() * 12;
                IOUtils.closeQuietly((Closeable)iresource);
            }
            catch (Exception exception) {
                a.error("Couldn't load credits", (Throwable)exception);
            }
            finally {
                IOUtils.closeQuietly(iresource);
            }
        }
    }

    private void b(int p_146575_1_, int p_146575_2_, float p_146575_3_) {
        bvc tessellator = bvc.a();
        bui bufferbuilder = tessellator.c();
        this.j.N().a(bip.b);
        bufferbuilder.a(7, cdw.i);
        int i2 = this.l;
        float f2 = -this.s * 0.5f * this.v;
        float f1 = (float)this.m - this.s * 0.5f * this.v;
        float f22 = 0.015625f;
        float f3 = this.s * 0.02f;
        float f4 = (float)(this.u + this.m + this.m + 24) / this.v;
        float f5 = (f4 - 20.0f - this.s) * 0.005f;
        if (f5 < f3) {
            f3 = f5;
        }
        if (f3 > 1.0f) {
            f3 = 1.0f;
        }
        f3 *= f3;
        f3 = f3 * 96.0f / 255.0f;
        bufferbuilder.b(0.0, (double)this.m, (double)e).a(0.0, f2 * 0.015625f).a(f3, f3, f3, 1.0f).d();
        bufferbuilder.b((double)i2, (double)this.m, (double)e).a((float)i2 * 0.015625f, f2 * 0.015625f).a(f3, f3, f3, 1.0f).d();
        bufferbuilder.b((double)i2, 0.0, (double)e).a((float)i2 * 0.015625f, f1 * 0.015625f).a(f3, f3, f3, 1.0f).d();
        bufferbuilder.b(0.0, 0.0, (double)e).a(0.0, f1 * 0.015625f).a(f3, f3, f3, 1.0f).d();
        tessellator.b();
    }

    @Override
    public void a(int mouseX, int mouseY, float partialTicks) {
        this.b(mouseX, mouseY, partialTicks);
        bvc tessellator = bvc.a();
        bui bufferbuilder = tessellator.c();
        int i2 = 274;
        int j2 = this.l / 2 - 137;
        int k2 = this.m + 50;
        this.s += partialTicks;
        float f2 = -this.s * this.v;
        buq.G();
        buq.c(0.0f, f2, 0.0f);
        this.j.N().a(f);
        buq.c(1.0f, 1.0f, 1.0f, 1.0f);
        buq.e();
        this.b(j2, k2, 0, 0, 155, 44);
        this.b(j2 + 155, k2, 0, 45, 155, 44);
        this.j.N().a(field_194401_g);
        blr.drawModalRectWithCustomSizedTexture(j2 + 88, k2 + 37, 0.0f, 0.0f, 98.0, 14.0, 128.0, 16.0);
        buq.d();
        int l2 = k2 + 100;
        for (int i1 = 0; i1 < this.t.size(); ++i1) {
            float f1;
            if (i1 == this.t.size() - 1 && (f1 = (float)l2 + f2 - (float)(this.m / 2 - 6)) < 0.0f) {
                buq.c(0.0f, -f1, 0.0f);
            }
            if ((float)l2 + f2 + 12.0f + 8.0f > 0.0f && (float)l2 + f2 < (float)this.m) {
                String s2 = this.t.get(i1);
                if (s2.startsWith("[C]")) {
                    this.q.a(s2.substring(3), j2 + (274 - this.q.a(s2.substring(3))) / 2, l2, 0xFFFFFF);
                } else {
                    this.q.b.setSeed((long)((float)((long)i1 * 4238972211L) + this.s / 4.0f));
                    this.q.a(s2, j2, l2, 0xFFFFFF);
                }
            }
            l2 += 12;
        }
        buq.H();
        this.j.N().a(g);
        buq.m();
        buq.a(buq.r.o, buq.l.k);
        int j1 = this.l;
        int k1 = this.m;
        bufferbuilder.a(7, cdw.i);
        bufferbuilder.b(0.0, (double)k1, (double)e).a(0.0, 1.0).a(1.0f, 1.0f, 1.0f, 1.0f).d();
        bufferbuilder.b((double)j1, (double)k1, (double)e).a(1.0, 1.0).a(1.0f, 1.0f, 1.0f, 1.0f).d();
        bufferbuilder.b((double)j1, 0.0, (double)e).a(1.0, 0.0).a(1.0f, 1.0f, 1.0f, 1.0f).d();
        bufferbuilder.b(0.0, 0.0, (double)e).a(0.0, 0.0).a(1.0f, 1.0f, 1.0f, 1.0f).d();
        tessellator.b();
        buq.l();
        super.a(mouseX, mouseY, partialTicks);
    }
}

