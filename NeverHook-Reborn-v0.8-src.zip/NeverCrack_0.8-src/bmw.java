/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import io.netty.buffer.Unpooled;
import java.io.IOException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class bmw
extends bme {
    private static final Logger v = LogManager.getLogger();
    private static final nd w = new nd("textures/gui/container/villager.png");
    private final amd x;
    private a y;
    private a z;
    private int A;
    private final hh B;

    public bmw(aea p_i45500_1_, amd p_i45500_2_, ams worldIn) {
        super(new agi(p_i45500_1_, p_i45500_2_, worldIn));
        this.x = p_i45500_2_;
        this.B = p_i45500_2_.i_();
    }

    @Override
    public void b() {
        super.b();
        int i2 = (this.l - this.f) / 2;
        int j2 = (this.m - this.g) / 2;
        this.y = this.b(new a(1, i2 + 120 + 27, j2 + 24 - 1, true));
        this.z = this.b(new a(2, i2 + 36 - 19, j2 + 24 - 1, false));
        this.y.l = false;
        this.z.l = false;
    }

    @Override
    protected void c(int mouseX, int mouseY) {
        String s2 = this.B.c();
        this.q.drawString(s2, this.f / 2 - this.q.a(s2) / 2, 6.0f, 0x404040);
        this.q.drawString(cew.a("container.inventory", new Object[0]), 8.0f, this.g - 96 + 2, 0x404040);
    }

    @Override
    public void e() {
        super.e();
        amf merchantrecipelist = this.x.b_(this.j.h);
        if (merchantrecipelist != null) {
            this.y.l = this.A < merchantrecipelist.size() - 1;
            this.z.l = this.A > 0;
        }
    }

    @Override
    protected void a(biy button) throws IOException {
        boolean flag = false;
        if (button == this.y) {
            ++this.A;
            amf merchantrecipelist = this.x.b_(this.j.h);
            if (merchantrecipelist != null && this.A >= merchantrecipelist.size()) {
                this.A = merchantrecipelist.size() - 1;
            }
            flag = true;
        } else if (button == this.z) {
            --this.A;
            if (this.A < 0) {
                this.A = 0;
            }
            flag = true;
        }
        if (flag) {
            ((agi)this.h).d(this.A);
            gy packetbuffer = new gy(Unpooled.buffer());
            packetbuffer.writeInt(this.A);
            this.j.v().a(new lh("MC|TrSel", packetbuffer));
        }
    }

    @Override
    protected void a(float partialTicks, int mouseX, int mouseY) {
        buq.c(1.0f, 1.0f, 1.0f, 1.0f);
        this.j.N().a(w);
        int i2 = (this.l - this.f) / 2;
        int j2 = (this.m - this.g) / 2;
        this.b(i2, j2, 0, 0, this.f, this.g);
        amf merchantrecipelist = this.x.b_(this.j.h);
        if (merchantrecipelist != null && !merchantrecipelist.isEmpty()) {
            int k2 = this.A;
            if (k2 < 0 || k2 >= merchantrecipelist.size()) {
                return;
            }
            ame merchantrecipe = (ame)merchantrecipelist.get(k2);
            if (merchantrecipe.h()) {
                this.j.N().a(w);
                buq.c(1.0f, 1.0f, 1.0f, 1.0f);
                buq.g();
                this.b(this.i + 83, this.s + 21, 212, 0, 28, 21);
                this.b(this.i + 83, this.s + 51, 212, 0, 28, 21);
            }
        }
    }

    @Override
    public void a(int mouseX, int mouseY, float partialTicks) {
        this.c();
        super.a(mouseX, mouseY, partialTicks);
        amf merchantrecipelist = this.x.b_(this.j.h);
        if (merchantrecipelist != null && !merchantrecipelist.isEmpty()) {
            int i2 = (this.l - this.f) / 2;
            int j2 = (this.m - this.g) / 2;
            int k2 = this.A;
            ame merchantrecipe = (ame)merchantrecipelist.get(k2);
            ain itemstack = merchantrecipe.a();
            ain itemstack1 = merchantrecipe.b();
            ain itemstack2 = merchantrecipe.d();
            buq.G();
            bhx.c();
            buq.g();
            buq.D();
            buq.h();
            buq.f();
            this.k.a = 100.0f;
            this.k.b(itemstack, i2 + 36, j2 + 24);
            this.k.a(this.q, itemstack, i2 + 36, j2 + 24);
            if (!itemstack1.b()) {
                this.k.b(itemstack1, i2 + 62, j2 + 24);
                this.k.a(this.q, itemstack1, i2 + 62, j2 + 24);
            }
            this.k.b(itemstack2, i2 + 120, j2 + 24);
            this.k.a(this.q, itemstack2, i2 + 120, j2 + 24);
            this.k.a = 0.0f;
            buq.g();
            if (this.c(36, 24, 16, 16, mouseX, mouseY) && !itemstack.b()) {
                this.a(itemstack, mouseX, mouseY);
            } else if (!itemstack1.b() && this.c(62, 24, 16, 16, mouseX, mouseY) && !itemstack1.b()) {
                this.a(itemstack1, mouseX, mouseY);
            } else if (!itemstack2.b() && this.c(120, 24, 16, 16, mouseX, mouseY) && !itemstack2.b()) {
                this.a(itemstack2, mouseX, mouseY);
            } else if (merchantrecipe.h() && (this.c(83, 21, 28, 21, mouseX, mouseY) || this.c(83, 51, 28, 21, mouseX, mouseY))) {
                this.a(cew.a("merchant.deprecated", new Object[0]), mouseX, mouseY);
            }
            buq.H();
            buq.f();
            buq.k();
            bhx.b();
        }
        this.b(mouseX, mouseY);
    }

    public amd a() {
        return this.x;
    }

    static class a
    extends biy {
        private final boolean o;

        public a(int buttonID, int x2, int y2, boolean p_i1095_4_) {
            super(buttonID, x2, y2, 12, 19, "");
            this.o = p_i1095_4_;
        }

        public void a(bhz p_191745_1_, int p_191745_2_, int p_191745_3_, float p_191745_4_) {
            if (this.m) {
                p_191745_1_.N().a(w);
                buq.c(1.0f, 1.0f, 1.0f, 1.0f);
                boolean flag = p_191745_2_ >= this.h && p_191745_3_ >= this.i && p_191745_2_ < this.h + this.f && p_191745_3_ < this.i + this.g;
                int i2 = 0;
                int j2 = 176;
                if (!this.l) {
                    j2 += this.f * 2;
                } else if (flag) {
                    j2 += this.f;
                }
                if (!this.o) {
                    i2 += this.g;
                }
                this.b(this.h, this.i, j2, i2, this.f, this.g);
            }
        }
    }
}

