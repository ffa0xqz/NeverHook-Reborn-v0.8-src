/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import java.util.UUID;
import javax.annotation.Nullable;

public class ads
extends adr {
    private static final mx<Boolean> b = na.a(ads.class, mz.h);
    private static final mx<Integer> c = na.a(ads.class, mz.b);
    private int bx;
    private UUID by;

    public ads(ams ams2) {
        super(ams2);
    }

    @Override
    protected void i() {
        super.i();
        this.Y.a(b, false);
        this.Y.a(c, 0);
    }

    public void a(int n2) {
        this.Y.b(c, n2);
    }

    public int dp() {
        return Math.max(this.Y.a(c) % 6, 0);
    }

    public static void a(rw rw2) {
        vo.a(rw2, ads.class);
    }

    @Override
    public void b(fy fy2) {
        super.b(fy2);
        fy2.a("Profession", this.dp());
        fy2.a("ConversionTime", this.ds() ? this.bx : -1);
        if (this.by != null) {
            fy2.a("ConversionPlayer", this.by);
        }
    }

    @Override
    public void a(fy fy2) {
        super.a(fy2);
        this.a(fy2.h("Profession"));
        if (fy2.b("ConversionTime", 99) && fy2.h("ConversionTime") > -1) {
            this.a(fy2.b("ConversionPlayer") ? fy2.a("ConversionPlayer") : null, fy2.h("ConversionTime"));
        }
    }

    @Override
    @Nullable
    public vq a(ty ty2, @Nullable vq vq2) {
        this.a(this.l.r.nextInt(6));
        return super.a(ty2, vq2);
    }

    @Override
    public void B_() {
        if (!this.l.G && this.ds()) {
            int n2 = this.du();
            this.bx -= n2;
            if (this.bx <= 0) {
                this.dt();
            }
        }
        super.B_();
    }

    @Override
    public boolean a(aeb aeb2, tz tz2) {
        ain ain2 = aeb2.b(tz2);
        if (ain2.c() == aip.ar && ain2.j() == 0 && this.a(uz.r)) {
            if (!aeb2.bO.d) {
                ain2.g(1);
            }
            if (!this.l.G) {
                this.a(aeb2.bm(), this.S.nextInt(2401) + 3600);
            }
            return true;
        }
        return false;
    }

    @Override
    protected boolean K() {
        return !this.ds();
    }

    public boolean ds() {
        return this.V().a(b);
    }

    protected void a(@Nullable UUID uUID, int n2) {
        this.by = uUID;
        this.bx = n2;
        this.V().b(b, true);
        this.d(uz.r);
        this.c(new uy(uz.e, n2, Math.min(this.l.ag().a() - 1, 0)));
        this.l.a((ve)this, (byte)16);
    }

    @Override
    public void a(byte by2) {
        if (by2 == 16) {
            if (!this.ai()) {
                this.l.a(this.p + 0.5, this.q + 0.5, this.r + 0.5, qd.jz, this.bK(), 1.0f + this.S.nextFloat(), this.S.nextFloat() * 0.7f + 0.3f, false);
            }
        } else {
            super.a(by2);
        }
    }

    protected void dt() {
        adw adw2 = new adw(this.l);
        adw2.u(this);
        adw2.g(this.dp());
        adw2.a(this.l.D(new et(adw2)), null, false);
        adw2.dp();
        if (this.l_()) {
            adw2.c(-24000);
        }
        this.l.e(this);
        adw2.n(this.dc());
        if (this.n_()) {
            adw2.c(this.bq());
            adw2.j(this.br());
        }
        this.l.a(adw2);
        if (this.by != null && (\u2603 = this.l.b(this.by)) instanceof oo) {
            m.q.a((oo)\u2603, this, adw2);
        }
        adw2.c(new uy(uz.i, 200, 0));
        this.l.a(null, 1027, new et((int)this.p, (int)this.q, (int)this.r), 0);
    }

    protected int du() {
        int n2 = 1;
        if (this.S.nextFloat() < 0.01f) {
            \u2603 = 0;
            et.a a2 = new et.a();
            for (int i2 = (int)this.p - 4; i2 < (int)this.p + 4 && \u2603 < 14; ++i2) {
                for (\u2603 = (int)this.q - 4; \u2603 < (int)this.q + 4 && \u2603 < 14; ++\u2603) {
                    for (\u2603 = (int)this.r - 4; \u2603 < (int)this.r + 4 && \u2603 < 14; ++\u2603) {
                        aou aou2 = this.l.o(a2.c(i2, \u2603, \u2603)).u();
                        if (aou2 != aov.bi && aou2 != aov.C) continue;
                        if (this.S.nextFloat() < 0.3f) {
                            ++n2;
                        }
                        ++\u2603;
                    }
                }
            }
        }
        return n2;
    }

    @Override
    protected float cr() {
        if (this.l_()) {
            return (this.S.nextFloat() - this.S.nextFloat()) * 0.2f + 2.0f;
        }
        return (this.S.nextFloat() - this.S.nextFloat()) * 0.2f + 1.0f;
    }

    @Override
    public qc F() {
        return qd.jx;
    }

    @Override
    public qc d(up up2) {
        return qd.jB;
    }

    @Override
    public qc cf() {
        return qd.jA;
    }

    @Override
    public qc dm() {
        return qd.jC;
    }

    @Override
    @Nullable
    protected nd J() {
        return bfl.as;
    }

    @Override
    protected ain dn() {
        return ain.a;
    }
}

