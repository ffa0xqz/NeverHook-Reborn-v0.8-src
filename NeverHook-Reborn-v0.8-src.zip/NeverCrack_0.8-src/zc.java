/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import javax.annotation.Nullable;

public abstract class zc {
    protected vo a;
    protected ams b;
    @Nullable
    protected bej c;
    protected double d;
    private final wb i;
    protected int e;
    private int j;
    private bhc k = bhc.a;
    private bhc l = bhc.a;
    private long m;
    private long n;
    private double o;
    protected float f = 0.5f;
    protected boolean g;
    private long p;
    protected bei h;
    private et q;
    private final bek r;

    public zc(vo vo2, ams ams2) {
        this.a = vo2;
        this.b = ams2;
        this.i = vo2.a(adf.b);
        this.r = this.a();
    }

    protected abstract bek a();

    public void a(double d2) {
        this.d = d2;
    }

    public float i() {
        return (float)this.i.e();
    }

    public boolean j() {
        return this.g;
    }

    public void k() {
        if (this.b.R() - this.p > 20L) {
            if (this.q != null) {
                this.c = null;
                this.c = this.b(this.q);
                this.p = this.b.R();
                this.g = false;
            }
        } else {
            this.g = true;
        }
    }

    @Nullable
    public final bej a(double d2, double d3, double d4) {
        return this.b(new et(d2, d3, d4));
    }

    @Nullable
    public bej b(et et2) {
        if (!this.b()) {
            return null;
        }
        if (this.c != null && !this.c.b() && et2.equals(this.q)) {
            return this.c;
        }
        this.q = et2;
        float f2 = this.i();
        this.b.E.a("pathfind");
        et \u26032 = new et(this.a);
        int \u26033 = (int)(f2 + 8.0f);
        anb \u26034 = new anb(this.b, \u26032.a(-\u26033, -\u26033, -\u26033), \u26032.a(\u26033, \u26033, \u26033), 0);
        bej \u26035 = this.r.a((amw)\u26034, this.a, this.q, f2);
        this.b.E.b();
        return \u26035;
    }

    @Nullable
    public bej a(ve ve2) {
        if (!this.b()) {
            return null;
        }
        et et2 = new et(ve2);
        if (this.c != null && !this.c.b() && et2.equals(this.q)) {
            return this.c;
        }
        this.q = et2;
        float \u26032 = this.i();
        this.b.E.a("pathfind");
        \u2603 = new et(this.a).a();
        int \u26033 = (int)(\u26032 + 16.0f);
        anb \u26034 = new anb(this.b, \u2603.a(-\u26033, -\u26033, -\u26033), \u2603.a(\u26033, \u26033, \u26033), 0);
        bej \u26035 = this.r.a((amw)\u26034, this.a, ve2, \u26032);
        this.b.E.b();
        return \u26035;
    }

    public boolean a(double d2, double d3, double d4, double d5) {
        return this.a(this.a(d2, d3, d4), d5);
    }

    public boolean a(ve ve2, double d2) {
        bej bej2 = this.a(ve2);
        return bej2 != null && this.a(bej2, d2);
    }

    public boolean a(@Nullable bej bej2, double d2) {
        if (bej2 == null) {
            this.c = null;
            return false;
        }
        if (!bej2.a(this.c)) {
            this.c = bej2;
        }
        this.q_();
        if (this.c.d() <= 0) {
            return false;
        }
        this.d = d2;
        bhc bhc2 = this.c();
        this.j = this.e;
        this.k = bhc2;
        return true;
    }

    @Nullable
    public bej l() {
        return this.c;
    }

    public void d() {
        Object \u26032;
        bhc \u26033;
        ++this.e;
        if (this.g) {
            this.k();
        }
        if (this.o()) {
            return;
        }
        if (this.b()) {
            this.n();
        } else if (this.c != null && this.c.e() < this.c.d()) {
            \u26033 = this.c();
            \u26032 = this.c.a(this.a, this.c.e());
            if (\u26033.c > ((bhc)\u26032).c && !this.a.z && ri.c(\u26033.b) == ri.c(((bhc)\u26032).b) && ri.c(\u26033.d) == ri.c(((bhc)\u26032).d)) {
                this.c.c(this.c.e() + 1);
            }
        }
        this.m();
        if (this.o()) {
            return;
        }
        \u26033 = this.c.a(this.a);
        \u26032 = new et(\u26033).b();
        bgz bgz2 = this.b.o((et)\u26032).e(this.b, (et)\u26032);
        \u26033 = \u26033.a(0.0, 1.0 - bgz2.e, 0.0);
        this.a.u().a(\u26033.b, \u26033.c, \u26033.d, this.d);
    }

    protected void m() {
    }

    protected void n() {
        bhc bhc2 = this.c();
        int \u26032 = this.c.d();
        for (int i2 = this.c.e(); i2 < this.c.d(); ++i2) {
            if ((double)this.c.a((int)i2).b == Math.floor(bhc2.c)) continue;
            \u26032 = i2;
            break;
        }
        this.f = this.a.G > 0.75f ? this.a.G / 2.0f : 0.75f - this.a.G / 2.0f;
        bhc bhc3 = this.c.f();
        if (ri.e((float)(this.a.p - (bhc3.b + 0.5))) < this.f && ri.e((float)(this.a.r - (bhc3.d + 0.5))) < this.f && Math.abs(this.a.q - bhc3.c) < 1.0) {
            this.c.c(this.c.e() + 1);
        }
        int \u26033 = ri.f(this.a.G);
        int \u26034 = ri.f(this.a.H);
        int \u26035 = \u26033;
        for (int i3 = \u26032 - 1; i3 >= this.c.e(); --i3) {
            if (!this.a(bhc2, this.c.a(this.a, i3), \u26033, \u26034, \u26035)) continue;
            this.c.c(i3);
            break;
        }
        this.a(bhc2);
    }

    protected void a(bhc bhc2) {
        if (this.e - this.j > 100) {
            if (bhc2.g(this.k) < 2.25) {
                this.p();
            }
            this.j = this.e;
            this.k = bhc2;
        }
        if (this.c != null && !this.c.b()) {
            \u2603 = this.c.f();
            if (\u2603.equals(this.l)) {
                this.m += System.currentTimeMillis() - this.n;
            } else {
                this.l = \u2603;
                double d2 = bhc2.f(this.l);
                double d3 = this.o = this.a.cy() > 0.0f ? d2 / (double)this.a.cy() * 1000.0 : 0.0;
            }
            if (this.o > 0.0 && (double)this.m > this.o * 3.0) {
                this.l = bhc.a;
                this.m = 0L;
                this.o = 0.0;
                this.p();
            }
            this.n = System.currentTimeMillis();
        }
    }

    public boolean o() {
        return this.c == null || this.c.b();
    }

    public void p() {
        this.c = null;
    }

    protected abstract bhc c();

    protected abstract boolean b();

    protected boolean q() {
        return this.a.ao() || this.a.au();
    }

    protected void q_() {
        if (this.c == null) {
            return;
        }
        for (int i2 = 0; i2 < this.c.d(); ++i2) {
            beh beh2 = this.c.a(i2);
            \u2603 = i2 + 1 < this.c.d() ? this.c.a(i2 + 1) : null;
            awr \u26032 = this.b.o(new et(beh2.a, beh2.b, beh2.c));
            aou \u26033 = \u26032.u();
            if (\u26033 != aov.bE) continue;
            this.c.a(i2, beh2.a(beh2.a, beh2.b + 1, beh2.c));
            if (\u2603 == null || beh2.b < \u2603.b) continue;
            this.c.a(i2 + 1, \u2603.a(\u2603.a, beh2.b + 1, \u2603.c));
        }
    }

    protected abstract boolean a(bhc var1, bhc var2, int var3, int var4, int var5);

    public boolean a(et et2) {
        return this.b.o(et2.b()).b();
    }

    public bei r() {
        return this.h;
    }
}

