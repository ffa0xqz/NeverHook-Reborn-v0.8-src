/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Sets
 */
import com.google.common.collect.Sets;
import java.util.Set;

public class cht
implements chy {
    private static final Set<aou> a = Sets.newHashSet((Object[])new aou[]{aov.r, aov.s, aov.t, aov.u});
    private static final hh b = new hp("tutorial.find_tree.title", new Object[0]);
    private static final hh c = new hp("tutorial.find_tree.description", new Object[0]);
    private final chx d;
    private bkb e;
    private int f;

    public cht(chx chx2) {
        this.d = chx2;
    }

    @Override
    public void a() {
        bub bub2;
        ++this.f;
        if (this.d.f() != amq.b) {
            this.d.a(chz.f);
            return;
        }
        if (this.f == 1 && (bub2 = this.d.e().h) != null) {
            for (aou aou2 : a) {
                if (!bub2.bv.h(new ain(aou2))) continue;
                this.d.a(chz.e);
                return;
            }
            if (cht.a(bub2)) {
                this.d.a(chz.e);
                return;
            }
        }
        if (this.f >= 6000 && this.e == null) {
            this.e = new bkb(bkb.a.c, b, c, false);
            this.d.e().ao().a(this.e);
        }
    }

    @Override
    public void b() {
        if (this.e != null) {
            this.e.a();
            this.e = null;
        }
    }

    @Override
    public void a(brz brz2, bha bha2) {
        if (bha2.a == bha.a.b && bha2.a() != null && a.contains((\u2603 = brz2.o(bha2.a())).u())) {
            this.d.a(chz.c);
        }
    }

    @Override
    public void a(ain ain2) {
        for (aou aou2 : a) {
            if (ain2.c() != ail.a(aou2)) continue;
            this.d.a(chz.e);
            return;
        }
    }

    public static boolean a(bub bub2) {
        for (aou aou2 : a) {
            qm qm2 = qq.a(aou2);
            if (qm2 == null || bub2.D().a(qm2) <= 0) continue;
            return true;
        }
        return false;
    }
}

