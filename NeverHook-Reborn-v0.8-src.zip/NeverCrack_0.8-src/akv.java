/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParseException
 */
import com.google.common.collect.Lists;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.util.ArrayList;

public class akv
implements akr {
    private final ain a;
    private final fi<ako> b;
    private final String c;

    public akv(String string, ain ain2, fi<ako> fi2) {
        this.c = string;
        this.a = ain2;
        this.b = fi2;
    }

    @Override
    public String e() {
        return this.c;
    }

    @Override
    public ain b() {
        return this.a;
    }

    @Override
    public fi<ako> d() {
        return this.b;
    }

    @Override
    public fi<ain> b(afw afw2) {
        fi<ain> fi2 = fi.a(afw2.w_(), ain.a);
        for (int i2 = 0; i2 < fi2.size(); ++i2) {
            ain ain2 = afw2.a(i2);
            if (!ain2.c().r()) continue;
            fi2.set(i2, new ain(ain2.c().q()));
        }
        return fi2;
    }

    @Override
    public boolean a(afw afw2, ams ams2) {
        ArrayList arrayList = Lists.newArrayList(this.b);
        for (int i2 = 0; i2 < afw2.i(); ++i2) {
            for (\u2603 = 0; \u2603 < afw2.j(); ++\u2603) {
                ain ain2 = afw2.c(\u2603, i2);
                if (ain2.b()) continue;
                boolean \u26032 = false;
                for (ako ako2 : arrayList) {
                    if (!ako2.a(ain2)) continue;
                    \u26032 = true;
                    arrayList.remove(ako2);
                    break;
                }
                if (\u26032) continue;
                return false;
            }
        }
        return arrayList.isEmpty();
    }

    @Override
    public ain a(afw afw2) {
        return this.a.l();
    }

    public static akv a(JsonObject jsonObject) {
        String string = ra.a(jsonObject, "group", "");
        fi<ako> \u26032 = akv.a(ra.u(jsonObject, "ingredients"));
        if (\u26032.isEmpty()) {
            throw new JsonParseException("No ingredients for shapeless recipe");
        }
        if (\u26032.size() > 9) {
            throw new JsonParseException("Too many ingredients for shapeless recipe");
        }
        ain \u26033 = aku.a(ra.t(jsonObject, "result"), true);
        return new akv(string, \u26033, \u26032);
    }

    private static fi<ako> a(JsonArray jsonArray) {
        fi<ako> fi2 = fi.a();
        for (int i2 = 0; i2 < jsonArray.size(); ++i2) {
            ako ako2 = aku.a(jsonArray.get(i2));
            if (ako2 == ako.a) continue;
            fi2.add(ako2);
        }
        return fi2;
    }

    @Override
    public boolean a(int n2, int n3) {
        return n2 * n3 >= this.b.size();
    }
}

