/*
 * Decompiled with CFR 0.150.
 */
public class ahk
extends ail {
    public ahk() {
        this.a(true);
        this.e(0);
        this.b(ahn.l);
    }

    @Override
    public String a(ain ain2) {
        if (ain2.j() == 1) {
            return "item.charcoal";
        }
        return "item.coal";
    }

    @Override
    public void a(ahn ahn2, fi<ain> fi2) {
        if (this.a(ahn2)) {
            fi2.add(new ain(this, 1, 0));
            fi2.add(new ain(this, 1, 1));
        }
    }
}

