/*
 * Decompiled with CFR 0.150.
 */
public class asv
extends aou {
    public static final axf<a> a = axf.a("variant", a.class);
    public static final int b = asv$a.a.a();
    public static final int c = asv$a.b.a();
    public static final int d = asv$a.c.a();

    public asv() {
        super(bcx.e);
        this.w(this.A.b().a(a, asv$a.a));
        this.a(ahn.b);
    }

    @Override
    public String c() {
        return ft.a(this.a() + "." + asv$a.a.c() + ".name");
    }

    @Override
    public bcy c(awr awr2, amw amw2, et et2) {
        if (awr2.c(a) == asv$a.a) {
            return bcy.z;
        }
        return bcy.H;
    }

    @Override
    public int d(awr awr2) {
        return awr2.c(a).a();
    }

    @Override
    public int e(awr awr2) {
        return awr2.c(a).a();
    }

    @Override
    protected aws b() {
        return new aws((aou)this, a);
    }

    @Override
    public awr a(int n2) {
        return this.t().a(a, asv$a.a(n2));
    }

    @Override
    public void a(ahn ahn2, fi<ain> fi2) {
        fi2.add(new ain(this, 1, b));
        fi2.add(new ain(this, 1, c));
        fi2.add(new ain(this, 1, d));
    }

    public static enum a implements rm
    {
        a(0, "prismarine", "rough"),
        b(1, "prismarine_bricks", "bricks"),
        c(2, "dark_prismarine", "dark");

        private static final a[] d;
        private final int e;
        private final String f;
        private final String g;

        private a(int n3, String string2, String string3) {
            this.e = n3;
            this.f = string2;
            this.g = string3;
        }

        public int a() {
            return this.e;
        }

        public String toString() {
            return this.f;
        }

        public static a a(int n2) {
            if (n2 < 0 || n2 >= d.length) {
                n2 = 0;
            }
            return d[n2];
        }

        @Override
        public String m() {
            return this.f;
        }

        public String c() {
            return this.g;
        }

        static {
            d = new a[asv$a.values().length];
            a[] arra = asv$a.values();
            int n2 = arra.length;
            for (int i2 = 0; i2 < n2; ++i2) {
                a a2;
                asv$a.d[a2.a()] = a2 = arra[i2];
            }
        }
    }
}

