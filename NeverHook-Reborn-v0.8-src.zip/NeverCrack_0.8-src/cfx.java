/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 */
import com.google.common.collect.Maps;
import java.util.Map;
import java.util.Optional;
import javax.vecmath.Matrix4f;
import net.minecraftforge.common.model.IModelPart;
import net.minecraftforge.common.model.IModelState;
import net.minecraftforge.common.model.ITransformation;
import net.minecraftforge.common.model.TRSRTransformation;
import optifine.Reflector;
import org.lwjgl.util.vector.Vector3f;

public enum cfx implements IModelState,
ITransformation
{
    a(0, 0),
    b(0, 90),
    c(0, 180),
    d(0, 270),
    e(90, 0),
    f(90, 90),
    g(90, 180),
    h(90, 270),
    i(180, 0),
    j(180, 90),
    k(180, 180),
    l(180, 270),
    m(270, 0),
    n(270, 90),
    o(270, 180),
    p(270, 270);

    private static final Map<Integer, cfx> q;
    private final int r;
    private final org.lwjgl.util.vector.Matrix4f s;
    private final int t;
    private final int u;

    private static int b(int p_177521_0_, int p_177521_1_) {
        return p_177521_0_ * 360 + p_177521_1_;
    }

    private cfx(int x2, int y2) {
        this.r = cfx.b(x2, y2);
        this.s = new org.lwjgl.util.vector.Matrix4f();
        org.lwjgl.util.vector.Matrix4f matrix4f = new org.lwjgl.util.vector.Matrix4f();
        matrix4f.setIdentity();
        org.lwjgl.util.vector.Matrix4f.rotate((float)(-x2) * ((float)Math.PI / 180), new Vector3f(1.0f, 0.0f, 0.0f), matrix4f, matrix4f);
        this.t = ri.a(x2 / 90);
        org.lwjgl.util.vector.Matrix4f matrix4f1 = new org.lwjgl.util.vector.Matrix4f();
        matrix4f1.setIdentity();
        org.lwjgl.util.vector.Matrix4f.rotate((float)(-y2) * ((float)Math.PI / 180), new Vector3f(0.0f, 1.0f, 0.0f), matrix4f1, matrix4f1);
        this.u = ri.a(y2 / 90);
        org.lwjgl.util.vector.Matrix4f.mul(matrix4f1, matrix4f, this.s);
    }

    public org.lwjgl.util.vector.Matrix4f a() {
        return this.s;
    }

    public fa a(fa facing) {
        fa enumfacing = facing;
        for (int i2 = 0; i2 < this.t; ++i2) {
            enumfacing = enumfacing.a(fa.a.a);
        }
        if (enumfacing.k() != fa.a.b) {
            for (int j2 = 0; j2 < this.u; ++j2) {
                enumfacing = enumfacing.a(fa.a.b);
            }
        }
        return enumfacing;
    }

    public int a(fa facing, int vertexIndex) {
        int i2 = vertexIndex;
        if (facing.k() == fa.a.a) {
            i2 = (vertexIndex + this.t) % 4;
        }
        fa enumfacing = facing;
        for (int j2 = 0; j2 < this.t; ++j2) {
            enumfacing = enumfacing.a(fa.a.a);
        }
        if (enumfacing.k() == fa.a.b) {
            i2 = (i2 + this.u) % 4;
        }
        return i2;
    }

    public static cfx a(int x2, int y2) {
        return q.get(cfx.b(ri.b(x2, 360), ri.b(y2, 360)));
    }

    @Override
    public Optional<TRSRTransformation> apply(Optional<? extends IModelPart> p_apply_1_) {
        return (Optional)Reflector.call(Reflector.ForgeHooksClient_applyTransform, this.getMatrix(), p_apply_1_);
    }

    @Override
    public Matrix4f getMatrix() {
        return Reflector.ForgeHooksClient_getMatrix.exists() ? (Matrix4f)Reflector.call(Reflector.ForgeHooksClient_getMatrix, this) : new Matrix4f();
    }

    @Override
    public fa rotate(fa p_rotate_1_) {
        return this.a(p_rotate_1_);
    }

    @Override
    public int rotate(fa p_rotate_1_, int p_rotate_2_) {
        return this.a(p_rotate_1_, p_rotate_2_);
    }

    static {
        q = Maps.newHashMap();
        for (cfx modelrotation : cfx.values()) {
            q.put(modelrotation.r, modelrotation);
        }
    }
}

