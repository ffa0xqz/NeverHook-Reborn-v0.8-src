/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 */
import com.google.common.collect.Maps;
import java.io.IOException;
import java.util.Map;

public class ie
implements ht<hw> {
    private Map<qm, Integer> a;

    public ie() {
    }

    public ie(Map<qm, Integer> map) {
        this.a = map;
    }

    @Override
    public void a(hw hw2) {
        hw2.a(this);
    }

    @Override
    public void a(gy gy2) throws IOException {
        int n2 = gy2.g();
        this.a = Maps.newHashMap();
        for (\u2603 = 0; \u2603 < n2; ++\u2603) {
            qm qm2 = qq.a(gy2.e(32767));
            int \u26032 = gy2.g();
            if (qm2 == null) continue;
            this.a.put(qm2, \u26032);
        }
    }

    @Override
    public void b(gy gy2) throws IOException {
        gy2.d(this.a.size());
        for (Map.Entry<qm, Integer> entry : this.a.entrySet()) {
            gy2.a(entry.getKey().a);
            gy2.d(entry.getValue());
        }
    }

    public Map<qm, Integer> a() {
        return this.a;
    }
}

