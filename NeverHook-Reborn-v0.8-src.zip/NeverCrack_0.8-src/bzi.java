/*
 * Decompiled with CFR 0.150.
 */
public class bzi
extends bze<aci> {
    public bzi(bzd bzd2) {
        super(bzd2);
        this.c = 0.5f;
    }

    @Override
    public void a(aci aci2, double d2, double d3, double d4, float f2, float f3) {
        if (aci2.l() == null) {
            return;
        }
        awr awr2 = aci2.l();
        if (awr2.i() != ath.d) {
            return;
        }
        ams \u26032 = aci2.k();
        if (awr2 == \u26032.o(new et(aci2)) || awr2.i() == ath.a) {
            return;
        }
        this.a(cdn.g);
        buq.G();
        buq.g();
        bvc \u26033 = bvc.a();
        bui \u26034 = \u26033.c();
        if (this.e) {
            buq.h();
            buq.e(this.c(aci2));
        }
        \u26034.a(7, cdw.a);
        et \u26035 = new et(aci2.p, aci2.bw().e, aci2.r);
        buq.c((float)(d2 - (double)\u26035.p() - 0.5), (float)(d3 - (double)\u26035.q()), (float)(d4 - (double)\u26035.r() - 0.5));
        bvk \u26036 = bhz.z().ab();
        \u26036.b().a(\u26032, \u26036.a(awr2), awr2, \u26035, \u26034, false, ri.a(aci2.j()));
        \u26033.b();
        if (this.e) {
            buq.n();
            buq.i();
        }
        buq.f();
        buq.H();
        super.a(aci2, d2, d3, d4, f2, f3);
    }

    @Override
    protected nd a(aci aci2) {
        return cdn.g;
    }
}

