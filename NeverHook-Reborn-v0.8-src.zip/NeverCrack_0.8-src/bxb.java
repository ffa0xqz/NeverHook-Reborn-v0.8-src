/*
 * Decompiled with CFR 0.150.
 */
public class bxb
extends bww<awk> {
    private final bvk a = bhz.z().ab();

    @Override
    public void a(awk awk2, double d2, double d3, double d4, float f2, int n2, float f3) {
        et et2 = awk2.w();
        awr \u26032 = awk2.a();
        aou \u26033 = \u26032.u();
        if (\u26032.a() == bcx.a || awk2.a(f2) >= 1.0f) {
            return;
        }
        bvc \u26034 = bvc.a();
        bui \u26035 = \u26034.c();
        this.a(cdn.g);
        bhx.a();
        buq.a(buq.r.l, buq.l.j);
        buq.m();
        buq.r();
        if (bhz.y()) {
            buq.j(7425);
        } else {
            buq.j(7424);
        }
        \u26035.a(7, cdw.a);
        \u26035.c(d2 - (double)et2.p() + (double)awk2.b(f2), d3 - (double)et2.q() + (double)awk2.c(f2), d4 - (double)et2.r() + (double)awk2.d(f2));
        ams \u26036 = this.a();
        if (\u26033 == aov.K && awk2.a(f2) <= 0.25f) {
            \u26032 = \u26032.a(awi.b, true);
            this.a(et2, \u26032, \u26035, \u26036, true);
        } else if (awk2.i() && !awk2.f()) {
            awi.a a2 = \u26033 == aov.F ? awi.a.b : awi.a.a;
            awr \u26037 = aov.K.t().a(awi.a, a2).a(awi.H, \u26032.c(awh.H));
            \u26037 = \u26037.a(awi.b, awk2.a(f2) >= 0.5f);
            this.a(et2, \u26037, \u26035, \u26036, true);
            \u26035.c(d2 - (double)et2.p(), d3 - (double)et2.q(), d4 - (double)et2.r());
            \u26032 = \u26032.a(awh.a, true);
            this.a(et2, \u26032, \u26035, \u26036, true);
        } else {
            this.a(et2, \u26032, \u26035, \u26036, false);
        }
        \u26035.c(0.0, 0.0, 0.0);
        \u26034.b();
        bhx.b();
    }

    private boolean a(et et2, awr awr2, bui bui2, ams ams2, boolean bl2) {
        return this.a.b().a(ams2, this.a.a(awr2), awr2, et2, bui2, bl2);
    }
}

