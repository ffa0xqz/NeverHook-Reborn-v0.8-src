/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import java.util.Random;
import javax.annotation.Nullable;

public class aus
extends aou {
    public static final axd a = axd.a("up");
    public static final axd b = axd.a("north");
    public static final axd c = axd.a("east");
    public static final axd d = axd.a("south");
    public static final axd e = axd.a("west");
    public static final axd[] f = new axd[]{a, b, d, e, c};
    protected static final bgz g = new bgz(0.0, 0.9375, 0.0, 1.0, 1.0, 1.0);
    protected static final bgz B = new bgz(0.0, 0.0, 0.0, 0.0625, 1.0, 1.0);
    protected static final bgz C = new bgz(0.9375, 0.0, 0.0, 1.0, 1.0, 1.0);
    protected static final bgz D = new bgz(0.0, 0.0, 0.0, 1.0, 1.0, 0.0625);
    protected static final bgz E = new bgz(0.0, 0.0, 0.9375, 1.0, 1.0, 1.0);

    public aus() {
        super(bcx.l);
        this.w(this.A.b().a(a, false).a(b, false).a(c, false).a(d, false).a(e, false));
        this.a(true);
        this.a(ahn.c);
    }

    @Override
    @Nullable
    public bgz a(awr awr2, amw amw2, et et2) {
        return k;
    }

    @Override
    public bgz b(awr awr22, amw amw2, et et2) {
        awr awr22 = awr22.c(amw2, et2);
        int \u26032 = 0;
        bgz \u26033 = j;
        if (awr22.c(a).booleanValue()) {
            \u26033 = g;
            ++\u26032;
        }
        if (awr22.c(b).booleanValue()) {
            \u26033 = D;
            ++\u26032;
        }
        if (awr22.c(c).booleanValue()) {
            \u26033 = C;
            ++\u26032;
        }
        if (awr22.c(d).booleanValue()) {
            \u26033 = E;
            ++\u26032;
        }
        if (awr22.c(e).booleanValue()) {
            \u26033 = B;
            ++\u26032;
        }
        return \u26032 == 1 ? \u26033 : j;
    }

    @Override
    public awr d(awr awr2, amw amw2, et et2) {
        \u2603 = et2.a();
        return awr2.a(a, amw2.o(\u2603).d(amw2, \u2603, fa.a) == awp.a);
    }

    @Override
    public boolean b(awr awr2) {
        return false;
    }

    @Override
    public boolean c(awr awr2) {
        return false;
    }

    @Override
    public boolean a(amw amw2, et et2) {
        return true;
    }

    @Override
    public boolean b(ams ams2, et et2, fa fa2) {
        return fa2 != fa.a && fa2 != fa.b && this.a(ams2, et2, fa2);
    }

    public boolean a(ams ams2, et et2, fa fa2) {
        aou aou2 = ams2.o(et2.a()).u();
        return this.c(ams2, et2.a(fa2.d()), fa2) && (aou2 == aov.a || aou2 == aov.bn || this.c(ams2, et2.a(), fa.b));
    }

    private boolean c(ams ams2, et et2, fa fa2) {
        awr awr2 = ams2.o(et2);
        return awr2.d(ams2, et2, fa2) == awp.a && !aus.e(awr2.u());
    }

    protected static boolean e(aou aou2) {
        return aou2 instanceof atp || aou2 == aov.bY || aou2 == aov.bE || aou2 == aov.w || aou2 == aov.cG || aou2 == aov.J || aou2 == aov.F || aou2 == aov.K || aou2 == aov.bd;
    }

    private boolean e(ams ams2, et et2, awr \u260322) {
        awr \u260322;
        \u2603 = \u260322;
        for (fa fa2 : fa.c.a) {
            axd axd2 = aus.a(fa2);
            if (!\u260322.c(axd2).booleanValue() || this.a(ams2, et2, fa2.d()) || (\u2603 = ams2.o(et2.a())).u() == this && \u2603.c(axd2).booleanValue()) continue;
            \u260322 = \u260322.a(axd2, false);
        }
        if (aus.x(\u260322) == 0) {
            return false;
        }
        if (\u2603 != \u260322) {
            ams2.a(et2, \u260322, 2);
        }
        return true;
    }

    @Override
    public void a(awr awr2, ams ams2, et et2, aou aou2, et et3) {
        if (!ams2.G && !this.e(ams2, et2, awr2)) {
            this.b(ams2, et2, awr2, 0);
            ams2.g(et2);
        }
    }

    @Override
    public void b(ams ams22, et et2, awr awr22, Random random) {
        awr awr22;
        if (ams22.G) {
            return;
        }
        if (ams22.r.nextInt(4) != 0) {
            return;
        }
        int n2 = 4;
        \u2603 = 5;
        boolean \u26032 = false;
        block0: for (\u2603 = -4; \u2603 <= 4; ++\u2603) {
            for (\u2603 = -4; \u2603 <= 4; ++\u2603) {
                for (\u2603 = -1; \u2603 <= 1; ++\u2603) {
                    if (ams22.o(et2.a(\u2603, \u2603, \u2603)).u() != this || --\u2603 > 0) continue;
                    \u26032 = true;
                    break block0;
                }
            }
        }
        fa \u26033 = fa.a(random);
        et \u26034 = et2.a();
        if (\u26033 == fa.b && et2.q() < 255 && ams22.d(\u26034)) {
            awr awr3 = awr22;
            for (fa fa2 : fa.c.a) {
                if (random.nextBoolean() && this.a(ams22, \u26034, fa2.d())) {
                    awr3 = awr3.a(aus.a(fa2), true);
                    continue;
                }
                awr3 = awr3.a(aus.a(fa2), false);
            }
            if (awr3.c(b).booleanValue() || awr3.c(c).booleanValue() || awr3.c(d).booleanValue() || awr3.c(e).booleanValue()) {
                ams22.a(\u26034, awr3, 2);
            }
            return;
        }
        if (\u26033.k().c() && !awr22.c(aus.a(\u26033)).booleanValue()) {
            if (\u26032) {
                return;
            }
            et et3 = et2.a(\u26033);
            awr \u26035 = ams22.o(et3);
            aou \u26036 = \u26035.u();
            if (\u26036.x == bcx.a) {
                fa fa3 = \u26033.e();
                \u2603 = \u26033.f();
                boolean \u26037 = awr22.c(aus.a(fa3));
                boolean \u26038 = awr22.c(aus.a(\u2603));
                et \u26039 = et3.a(fa3);
                et \u260310 = et3.a(\u2603);
                if (\u26037 && this.a(ams22, \u26039.a(fa3), fa3)) {
                    ams22.a(et3, this.t().a(aus.a(fa3), true), 2);
                } else if (\u26038 && this.a(ams22, \u260310.a(\u2603), \u2603)) {
                    ams22.a(et3, this.t().a(aus.a(\u2603), true), 2);
                } else if (\u26037 && ams22.d(\u26039) && this.a(ams22, \u26039, \u26033)) {
                    ams22.a(\u26039, this.t().a(aus.a(\u26033.d()), true), 2);
                } else if (\u26038 && ams22.d(\u260310) && this.a(ams22, \u260310, \u26033)) {
                    ams22.a(\u260310, this.t().a(aus.a(\u26033.d()), true), 2);
                }
            } else if (\u26035.d(ams22, et3, \u26033) == awp.a) {
                ams22.a(et2, awr22.a(aus.a(\u26033), true), 2);
            }
            return;
        }
        if (et2.q() > 1) {
            et et4 = et2.b();
            awr \u260311 = ams22.o(et4);
            aou \u260312 = \u260311.u();
            if (\u260312.x == bcx.a) {
                awr awr4 = awr22;
                for (fa fa4 : fa.c.a) {
                    if (!random.nextBoolean()) continue;
                    awr4 = awr4.a(aus.a(fa4), false);
                }
                if (awr4.c(b).booleanValue() || awr4.c(c).booleanValue() || awr4.c(d).booleanValue() || awr4.c(e).booleanValue()) {
                    ams22.a(et4, awr4, 2);
                }
            } else if (\u260312 == this) {
                awr \u260313 = \u260311;
                for (fa fa5 : fa.c.a) {
                    axd axd2 = aus.a(fa5);
                    if (!random.nextBoolean() || !awr22.c(axd2).booleanValue()) continue;
                    \u260313 = \u260313.a(axd2, true);
                }
                if (\u260313.c(b).booleanValue() || \u260313.c(c).booleanValue() || \u260313.c(d).booleanValue() || \u260313.c(e).booleanValue()) {
                    ams ams22;
                    ams22.a(et4, \u260313, 2);
                }
            }
        }
    }

    @Override
    public awr a(ams ams2, et et2, fa fa2, float f2, float f3, float f4, int n2, vn vn2) {
        awr awr2 = this.t().a(a, false).a(b, false).a(c, false).a(d, false).a(e, false);
        if (fa2.k().c()) {
            return awr2.a(aus.a(fa2.d()), true);
        }
        return awr2;
    }

    @Override
    public ail a(awr awr2, Random random, int n2) {
        return aip.a;
    }

    @Override
    public int a(Random random) {
        return 0;
    }

    @Override
    public void a(ams ams2, aeb aeb2, et et2, awr awr2, @Nullable avh avh2, ain ain2) {
        if (!ams2.G && ain2.c() == aip.bm) {
            aeb2.b(qq.a(this));
            aus.a(ams2, et2, new ain(aov.bn, 1, 0));
        } else {
            super.a(ams2, aeb2, et2, awr2, avh2, ain2);
        }
    }

    @Override
    public amk f() {
        return amk.c;
    }

    @Override
    public awr a(int n2) {
        return this.t().a(d, (n2 & 1) > 0).a(e, (n2 & 2) > 0).a(b, (n2 & 4) > 0).a(c, (n2 & 8) > 0);
    }

    @Override
    public int e(awr awr2) {
        int n2 = 0;
        if (awr2.c(d).booleanValue()) {
            n2 |= 1;
        }
        if (awr2.c(e).booleanValue()) {
            n2 |= 2;
        }
        if (awr2.c(b).booleanValue()) {
            n2 |= 4;
        }
        if (awr2.c(c).booleanValue()) {
            n2 |= 8;
        }
        return n2;
    }

    @Override
    protected aws b() {
        return new aws((aou)this, a, b, c, d, e);
    }

    @Override
    public awr a(awr awr2, atk atk2) {
        switch (atk2) {
            case c: {
                return awr2.a(b, awr2.c(d)).a(c, awr2.c(e)).a(d, awr2.c(b)).a(e, awr2.c(c));
            }
            case d: {
                return awr2.a(b, awr2.c(c)).a(c, awr2.c(d)).a(d, awr2.c(e)).a(e, awr2.c(b));
            }
            case b: {
                return awr2.a(b, awr2.c(e)).a(c, awr2.c(b)).a(d, awr2.c(c)).a(e, awr2.c(d));
            }
        }
        return awr2;
    }

    @Override
    public awr a(awr awr2, arw arw2) {
        switch (arw2) {
            case b: {
                return awr2.a(b, awr2.c(d)).a(d, awr2.c(b));
            }
            case c: {
                return awr2.a(c, awr2.c(e)).a(e, awr2.c(c));
            }
        }
        return super.a(awr2, arw2);
    }

    public static axd a(fa fa2) {
        switch (fa2) {
            case b: {
                return a;
            }
            case c: {
                return b;
            }
            case d: {
                return d;
            }
            case e: {
                return e;
            }
            case f: {
                return c;
            }
        }
        throw new IllegalArgumentException(fa2 + " is an invalid choice");
    }

    public static int x(awr awr2) {
        int n2 = 0;
        for (axd axd2 : f) {
            if (!awr2.c(axd2).booleanValue()) continue;
            ++n2;
        }
        return n2;
    }

    @Override
    public awp a(amw amw2, awr awr2, et et2, fa fa2) {
        return awp.i;
    }
}

