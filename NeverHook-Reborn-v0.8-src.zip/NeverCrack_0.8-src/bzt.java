/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import javax.annotation.Nullable;
import optifine.Config;
import optifine.Reflector;
import optifine.ReflectorForge;

public class bzt
extends bze<abz> {
    private static final nd a = new nd("textures/map/map_background.png");
    private final bhz f = bhz.z();
    private final cgb g = new cgb("item_frame", "normal");
    private final cgb h = new cgb("item_frame", "map");
    private final bzu i;

    public bzt(bzd renderManagerIn, bzu itemRendererIn) {
        super(renderManagerIn);
        this.i = itemRendererIn;
    }

    @Override
    public void a(abz entity, double x2, double y2, double z2, float entityYaw, float partialTicks) {
        buq.G();
        et blockpos = entity.q();
        double d0 = (double)blockpos.p() - entity.p + x2;
        double d1 = (double)blockpos.q() - entity.q + y2;
        double d2 = (double)blockpos.r() - entity.r + z2;
        buq.b(d0 + 0.5, d1 + 0.5, d2 + 0.5);
        buq.b(180.0f - entity.v, 0.0f, 1.0f, 0.0f);
        this.b.a.a(cdn.g);
        bvk blockrendererdispatcher = this.f.ab();
        cga modelmanager = blockrendererdispatcher.a().b();
        cfw ibakedmodel = entity.r().c() instanceof aiu ? modelmanager.a(this.h) : modelmanager.a(this.g);
        buq.G();
        buq.c(-0.5f, -0.5f, -0.5f);
        if (this.e) {
            buq.h();
            buq.e(this.c(entity));
        }
        blockrendererdispatcher.b().a(ibakedmodel, 1.0f, 1.0f, 1.0f, 1.0f);
        if (this.e) {
            buq.n();
            buq.i();
        }
        buq.H();
        buq.c(0.0f, 0.0f, 0.4375f);
        this.b(entity);
        buq.H();
        this.a(entity, x2 + (double)((float)entity.b.g() * 0.3f), y2 - 0.25, z2 + (double)((float)entity.b.i() * 0.3f));
    }

    @Override
    @Nullable
    protected nd a(abz entity) {
        return null;
    }

    private void b(abz itemFrame) {
        ain itemstack = itemFrame.r();
        if (!itemstack.b()) {
            if (!Config.zoomMode) {
                bub entity = this.f.h;
                double d0 = itemFrame.d(entity.p, entity.q, entity.r);
                if (d0 > 4096.0) {
                    return;
                }
            }
            buq.G();
            buq.g();
            boolean flag = itemstack.c() instanceof aiu;
            int i2 = flag ? itemFrame.s() % 4 * 2 : itemFrame.s();
            buq.b((float)i2 * 360.0f / 8.0f, 0.0f, 0.0f, 1.0f);
            if (!Reflector.postForgeBusEvent(Reflector.RenderItemInFrameEvent_Constructor, itemFrame, this)) {
                if (flag) {
                    this.b.a.a(a);
                    buq.b(180.0f, 0.0f, 0.0f, 1.0f);
                    float f2 = 0.0078125f;
                    buq.b(0.0078125f, 0.0078125f, 0.0078125f);
                    buq.c(-64.0f, -64.0f, 0.0f);
                    bet mapdata = ReflectorForge.getMapData(aip.bl, itemstack, itemFrame.l);
                    buq.c(0.0f, 0.0f, -1.0f);
                    if (mapdata != null) {
                        this.f.o.l().a(mapdata, true);
                    }
                } else {
                    buq.b(0.5f, 0.5f, 0.5f);
                    buq.a();
                    bhx.b();
                    this.i.a(itemstack, bwa.b.i);
                    bhx.a();
                    buq.c();
                }
            }
            buq.f();
            buq.H();
        }
    }

    @Override
    protected void a(abz entity, double x2, double y2, double z2) {
        if (bhz.w() && !entity.r().b() && entity.r().t() && this.b.d == entity) {
            float f2;
            double d0 = entity.h(this.b.c);
            float f3 = f2 = entity.aU() ? 32.0f : 64.0f;
            if (d0 < (double)(f2 * f2)) {
                String s2 = entity.r().r();
                this.a(entity, s2, x2, y2, z2, 64);
            }
        }
    }
}

