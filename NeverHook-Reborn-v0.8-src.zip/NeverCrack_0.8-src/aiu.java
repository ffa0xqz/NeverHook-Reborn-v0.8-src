/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.HashMultiset
 *  com.google.common.collect.Iterables
 *  com.google.common.collect.Multiset
 *  com.google.common.collect.Multisets
 *  javax.annotation.Nullable
 */
import com.google.common.collect.HashMultiset;
import com.google.common.collect.Iterables;
import com.google.common.collect.Multiset;
import com.google.common.collect.Multisets;
import java.util.List;
import javax.annotation.Nullable;

public class aiu
extends ahm {
    protected aiu() {
        this.a(true);
    }

    public static ain a(ams ams2, double d2, double d3, byte by2, boolean bl2, boolean bl3) {
        ain ain2 = new ain(aip.bl, 1, ams2.b("map"));
        String \u26032 = "map_" + ain2.j();
        bet \u26033 = new bet(\u26032);
        ams2.a(\u26032, \u26033);
        \u26033.g = by2;
        \u26033.a(d2, d3, \u26033.g);
        \u26033.d = (byte)ams2.s.q().a();
        \u26033.e = bl2;
        \u26033.f = bl3;
        \u26033.c();
        return ain2;
    }

    @Nullable
    public static bet a(int n2, ams ams2) {
        String string = "map_" + n2;
        return (bet)ams2.a(bet.class, string);
    }

    @Nullable
    public bet a(ain ain2, ams ams2) {
        String string = "map_" + ain2.j();
        bet \u26032 = (bet)ams2.a(bet.class, string);
        if (\u26032 == null && !ams2.G) {
            ain2.b(ams2.b("map"));
            string = "map_" + ain2.j();
            \u26032 = new bet(string);
            \u26032.g = (byte)3;
            \u26032.a(ams2.V().b(), ams2.V().d(), \u26032.g);
            \u26032.d = (byte)ams2.s.q().a();
            \u26032.c();
            ams2.a(string, \u26032);
        }
        return \u26032;
    }

    public void a(ams ams2, ve ve2, bet bet2) {
        if (ams2.s.q().a() != bet2.d || !(ve2 instanceof aeb)) {
            return;
        }
        int n2 = 1 << bet2.g;
        \u2603 = bet2.b;
        \u2603 = bet2.c;
        \u2603 = ri.c(ve2.p - (double)\u2603) / n2 + 64;
        \u2603 = ri.c(ve2.r - (double)\u2603) / n2 + 64;
        \u2603 = 128 / n2;
        if (ams2.s.n()) {
            \u2603 /= 2;
        }
        bet.a \u26032 = bet2.a((aeb)ve2);
        ++\u26032.b;
        boolean \u26033 = false;
        for (\u2603 = \u2603 - \u2603 + 1; \u2603 < \u2603 + \u2603; ++\u2603) {
            if ((\u2603 & 0xF) != (\u26032.b & 0xF) && !\u26033) continue;
            \u26033 = false;
            double \u260313 = 0.0;
            for (int i2 = \u2603 - \u2603 - 1; i2 < \u2603 + \u2603; ++i2) {
                if (\u2603 < 0 || i2 < -1 || \u2603 >= 128 || i2 >= 128) continue;
                \u2603 = \u2603 - \u2603;
                \u2603 = i2 - \u2603;
                boolean bl2 = \u2603 * \u2603 + \u2603 * \u2603 > (\u2603 - 2) * (\u2603 - 2);
                int \u26034 = (\u2603 / n2 + \u2603 - 64) * n2;
                int \u26035 = (\u2603 / n2 + i2 - 64) * n2;
                HashMultiset \u26036 = HashMultiset.create();
                axu \u26037 = ams2.f(new et(\u26034, 0, \u26035));
                if (\u26037.f()) continue;
                int \u26038 = \u26034 & 0xF;
                int \u26039 = \u26035 & 0xF;
                int \u260310 = 0;
                double \u260311 = 0.0;
                if (ams2.s.n()) {
                    int n3 = \u26034 + \u26035 * 231871;
                    if (((n3 = n3 * n3 * 31287121 + n3 * 11) >> 20 & 1) == 0) {
                        \u26036.add((Object)aov.d.t().a(apw.a, apw.a.a).a((amw)ams2, et.a), 10);
                    } else {
                        \u26036.add((Object)aov.b.t().a(auf.a, auf.a.a).a((amw)ams2, et.a), 100);
                    }
                    \u260311 = 100.0;
                } else {
                    et.a a2 = new et.a();
                    for (int i3 = 0; i3 < n2; ++i3) {
                        for (\u2603 = 0; \u2603 < n2; ++\u2603) {
                            int n4;
                            n4 = \u26037.b(i3 + \u26038, \u2603 + \u26039) + 1;
                            awr awr2 = aov.a.t();
                            if (n4 > 1) {
                                do {
                                    awr2 = \u26037.a(i3 + \u26038, --n4, \u2603 + \u26039);
                                    a2.c((\u26037.b << 4) + i3 + \u26038, n4, (\u26037.c << 4) + \u2603 + \u26039);
                                } while (awr2.a((amw)ams2, (et)a2) == bcy.c && n4 > 0);
                                if (n4 > 0 && awr2.a().d()) {
                                    int n5 = n4 - 1;
                                    do {
                                        awr awr3 = \u26037.a(i3 + \u26038, n5--, \u2603 + \u26039);
                                        ++\u260310;
                                    } while (n5 > 0 && awr3.a().d());
                                }
                            } else {
                                awr2 = aov.h.t();
                            }
                            \u260311 += (double)n4 / (double)(n2 * n2);
                            \u26036.add((Object)awr2.a((amw)ams2, (et)a2));
                        }
                    }
                }
                \u260310 /= n2 * n2;
                double \u260312 = (\u260311 - \u260313) * 4.0 / (double)(n2 + 4) + ((double)(\u2603 + i2 & 1) - 0.5) * 0.4;
                \u2603 = 1;
                if (\u260312 > 0.6) {
                    \u2603 = 2;
                }
                if (\u260312 < -0.6) {
                    \u2603 = 0;
                }
                if ((\u2603 = (bcy)Iterables.getFirst((Iterable)Multisets.copyHighestCountFirst((Multiset)\u26036), (Object)bcy.c)) == bcy.o) {
                    \u260312 = (double)\u260310 * 0.1 + (double)(\u2603 + i2 & 1) * 0.2;
                    \u2603 = 1;
                    if (\u260312 < 0.5) {
                        \u2603 = 2;
                    }
                    if (\u260312 > 0.9) {
                        \u2603 = 0;
                    }
                }
                \u260313 = \u260311;
                if (i2 < 0 || \u2603 * \u2603 + \u2603 * \u2603 >= \u2603 * \u2603 || bl2 && (\u2603 + i2 & 1) == 0 || (\u2603 = bet2.h[\u2603 + i2 * 128]) == (n5 = (int)((byte)(\u2603.ad * 4 + \u2603)))) continue;
                bet2.h[\u2603 + i2 * 128] = n5;
                bet2.a(\u2603, i2);
                \u26033 = true;
            }
        }
    }

    public static void a(ams ams2, ain ain2) {
        if (ain2.c() != aip.bl) {
            return;
        }
        bet bet2 = aip.bl.a(ain2, ams2);
        if (bet2 == null) {
            return;
        }
        if (ams2.s.q().a() != bet2.d) {
            return;
        }
        int \u26032 = 1 << bet2.g;
        int \u26033 = bet2.b;
        int \u26034 = bet2.c;
        anf[] \u26035 = ams2.C().a(null, (\u26033 / \u26032 - 64) * \u26032, (\u26034 / \u26032 - 64) * \u26032, 128 * \u26032, 128 * \u26032, false);
        for (int i2 = 0; i2 < 128; ++i2) {
            for (\u2603 = 0; \u2603 < 128; ++\u2603) {
                \u2603 = i2 * \u26032;
                \u2603 = \u2603 * \u26032;
                anf anf2 = \u26035[\u2603 + \u2603 * 128 * \u26032];
                bcy \u26036 = bcy.c;
                int \u26037 = 3;
                int \u26038 = 8;
                if (i2 > 0 && \u2603 > 0 && i2 < 127 && \u2603 < 127) {
                    if (\u26035[(i2 - 1) * \u26032 + (\u2603 - 1) * \u26032 * 128 * \u26032].j() >= 0.0f) {
                        --\u26038;
                    }
                    if (\u26035[(i2 - 1) * \u26032 + (\u2603 + 1) * \u26032 * 128 * \u26032].j() >= 0.0f) {
                        --\u26038;
                    }
                    if (\u26035[(i2 - 1) * \u26032 + \u2603 * \u26032 * 128 * \u26032].j() >= 0.0f) {
                        --\u26038;
                    }
                    if (\u26035[(i2 + 1) * \u26032 + (\u2603 - 1) * \u26032 * 128 * \u26032].j() >= 0.0f) {
                        --\u26038;
                    }
                    if (\u26035[(i2 + 1) * \u26032 + (\u2603 + 1) * \u26032 * 128 * \u26032].j() >= 0.0f) {
                        --\u26038;
                    }
                    if (\u26035[(i2 + 1) * \u26032 + \u2603 * \u26032 * 128 * \u26032].j() >= 0.0f) {
                        --\u26038;
                    }
                    if (\u26035[i2 * \u26032 + (\u2603 - 1) * \u26032 * 128 * \u26032].j() >= 0.0f) {
                        --\u26038;
                    }
                    if (\u26035[i2 * \u26032 + (\u2603 + 1) * \u26032 * 128 * \u26032].j() >= 0.0f) {
                        --\u26038;
                    }
                    if (anf2.j() < 0.0f) {
                        \u26036 = bcy.r;
                        if (\u26038 > 7 && \u2603 % 2 == 0) {
                            \u26037 = (i2 + (int)(ri.a((float)\u2603 + 0.0f) * 7.0f)) / 8 % 5;
                            if (\u26037 == 3) {
                                \u26037 = 1;
                            } else if (\u26037 == 4) {
                                \u26037 = 0;
                            }
                        } else if (\u26038 > 7) {
                            \u26036 = bcy.c;
                        } else if (\u26038 > 5) {
                            \u26037 = 1;
                        } else if (\u26038 > 3) {
                            \u26037 = 0;
                        } else if (\u26038 > 1) {
                            \u26037 = 0;
                        }
                    } else if (\u26038 > 0) {
                        \u26036 = bcy.C;
                        \u26037 = \u26038 > 3 ? 1 : 3;
                    }
                }
                if (\u26036 == bcy.c) continue;
                bet2.h[i2 + \u2603 * 128] = (byte)(\u26036.ad * 4 + \u26037);
                bet2.a(i2, \u2603);
            }
        }
    }

    @Override
    public void a(ain ain2, ams ams2, ve ve2, int n2, boolean bl22) {
        boolean bl22;
        if (ams2.G) {
            return;
        }
        bet bet2 = this.a(ain2, ams2);
        if (ve2 instanceof aeb) {
            aeb aeb2 = (aeb)ve2;
            bet2.a(aeb2, ain2);
        }
        if (bl22 || ve2 instanceof aeb && ((aeb)ve2).cp() == ain2) {
            this.a(ams2, ve2, bet2);
        }
    }

    @Override
    @Nullable
    public ht<?> a(ain ain2, ams ams2, aeb aeb2) {
        return this.a(ain2, ams2).a(ain2, ams2, aeb2);
    }

    @Override
    public void b(ain ain2, ams ams2, aeb aeb2) {
        fy fy2 = ain2.p();
        if (fy2 != null) {
            if (fy2.b("map_scale_direction", 99)) {
                aiu.a(ain2, ams2, fy2.h("map_scale_direction"));
                fy2.r("map_scale_direction");
            } else if (fy2.q("map_tracking_position")) {
                aiu.b(ain2, ams2);
                fy2.r("map_tracking_position");
            }
        }
    }

    protected static void a(ain ain2, ams ams2, int n2) {
        bet bet2 = aip.bl.a(ain2, ams2);
        ain2.b(ams2.b("map"));
        \u2603 = new bet("map_" + ain2.j());
        if (bet2 != null) {
            \u2603.g = (byte)ri.a(bet2.g + n2, 0, 4);
            \u2603.e = bet2.e;
            \u2603.a(bet2.b, bet2.c, \u2603.g);
            \u2603.d = bet2.d;
            \u2603.c();
            ams2.a("map_" + ain2.j(), \u2603);
        }
    }

    protected static void b(ain ain2, ams ams2) {
        bet bet2 = aip.bl.a(ain2, ams2);
        ain2.b(ams2.b("map"));
        \u2603 = new bet("map_" + ain2.j());
        \u2603.e = true;
        if (bet2 != null) {
            \u2603.b = bet2.b;
            \u2603.c = bet2.c;
            \u2603.g = bet2.g;
            \u2603.d = bet2.d;
            \u2603.c();
            ams2.a("map_" + ain2.j(), \u2603);
        }
    }

    @Override
    public void a(ain ain2, @Nullable ams ams2, List<String> list, ajz ajz2) {
        if (ajz2.a()) {
            bet bet2 = \u2603 = ams2 == null ? null : this.a(ain2, ams2);
            if (\u2603 != null) {
                list.add(ft.a("filled_map.scale", 1 << \u2603.g));
                list.add(ft.a("filled_map.level", \u2603.g, 4));
            } else {
                list.add(ft.a("filled_map.unknown"));
            }
        }
    }

    public static int h(ain ain2) {
        fy fy2 = ain2.d("display");
        if (fy2 != null && fy2.b("MapColor", 99)) {
            int n2 = fy2.h("MapColor");
            return 0xFF000000 | n2 & 0xFFFFFF;
        }
        return -12173266;
    }
}

