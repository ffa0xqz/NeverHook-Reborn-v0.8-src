/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 *  com.google.common.collect.Sets
 *  org.lwjgl.input.Keyboard
 */
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import java.util.Map;
import java.util.Set;
import java.util.function.Supplier;
import org.lwjgl.input.Keyboard;

public class bhw
implements Comparable<bhw> {
    private static final Map<String, bhw> a = Maps.newHashMap();
    private static final re<bhw> b = new re();
    private static final Set<String> c = Sets.newHashSet();
    private static final Map<String, Integer> d = Maps.newHashMap();
    private final String e;
    private final int f;
    private final String g;
    private int h;
    public boolean i;
    private int j;

    public static void a(int keyCode) {
        bhw keybinding;
        if (keyCode != 0 && (keybinding = b.a(keyCode)) != null) {
            ++keybinding.j;
        }
    }

    public static void a(int keyCode, boolean pressed) {
        bhw keybinding;
        if (keyCode != 0 && (keybinding = b.a(keyCode)) != null) {
            keybinding.i = pressed;
        }
    }

    public void setPressed(boolean bl2) {
        this.i = bl2;
    }

    public static void a() {
        for (bhw keybinding : a.values()) {
            try {
                bhw.a(keybinding.h, keybinding.h < 256 && Keyboard.isKeyDown((int)keybinding.h));
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {}
        }
    }

    public static void b() {
        for (bhw keybinding : a.values()) {
            keybinding.k();
        }
    }

    public static void c() {
        b.c();
        for (bhw keybinding : a.values()) {
            b.a(keybinding.h, keybinding);
        }
    }

    public static Set<String> d() {
        return c;
    }

    public bhw(String description, int keyCode, String category) {
        this.e = description;
        this.h = keyCode;
        this.f = keyCode;
        this.g = category;
        a.put(description, this);
        b.a(keyCode, this);
        c.add(category);
    }

    public boolean e() {
        return this.i;
    }

    public String f() {
        return this.g;
    }

    public boolean g() {
        if (this.j == 0) {
            return false;
        }
        --this.j;
        return true;
    }

    private void k() {
        this.j = 0;
        this.i = false;
    }

    public String h() {
        return this.e;
    }

    public int i() {
        return this.f;
    }

    public int j() {
        return this.h;
    }

    public void b(int keyCode) {
        this.h = keyCode;
    }

    public int a(bhw p_compareTo_1_) {
        return this.g.equals(p_compareTo_1_.g) ? cew.a(this.e, new Object[0]).compareTo(cew.a(p_compareTo_1_.e, new Object[0])) : d.get(this.g).compareTo(d.get(p_compareTo_1_.g));
    }

    public static Supplier<String> b(String p_193626_0_) {
        bhw keybinding = a.get(p_193626_0_);
        return keybinding == null ? () -> p_193626_0_ : () -> bib.a(keybinding.j());
    }

    static {
        d.put("key.categories.movement", 1);
        d.put("key.categories.gameplay", 2);
        d.put("key.categories.inventory", 3);
        d.put("key.categories.creative", 4);
        d.put("key.categories.multiplayer", 5);
        d.put("key.categories.ui", 6);
        d.put("key.categories.misc", 7);
    }
}

