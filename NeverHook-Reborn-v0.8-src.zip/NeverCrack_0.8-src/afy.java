/*
 * Decompiled with CFR 0.150.
 */
public class afy
extends afp {
    private final tt a;

    public afy(tt tt2, tt tt3) {
        int n2;
        this.a = tt3;
        for (n2 = 0; n2 < 3; ++n2) {
            for (\u2603 = 0; \u2603 < 3; ++\u2603) {
                this.a(new agp(tt3, \u2603 + n2 * 3, 62 + \u2603 * 18, 17 + n2 * 18));
            }
        }
        for (n2 = 0; n2 < 3; ++n2) {
            for (\u2603 = 0; \u2603 < 9; ++\u2603) {
                this.a(new agp(tt2, \u2603 + n2 * 9 + 9, 8 + \u2603 * 18, 84 + n2 * 18));
            }
        }
        for (n2 = 0; n2 < 9; ++n2) {
            this.a(new agp(tt2, n2, 8 + n2 * 18, 142));
        }
    }

    @Override
    public boolean a(aeb aeb2) {
        return this.a.a(aeb2);
    }

    @Override
    public ain b(aeb aeb2, int n2) {
        ain ain2 = ain.a;
        agp \u26032 = (agp)this.c.get(n2);
        if (\u26032 != null && \u26032.e()) {
            \u2603 = \u26032.d();
            ain2 = \u2603.l();
            if (n2 < 9 ? !this.a(\u2603, 9, 45, true) : !this.a(\u2603, 0, 9, false)) {
                return ain.a;
            }
            if (\u2603.b()) {
                \u26032.d(ain.a);
            } else {
                \u26032.f();
            }
            if (\u2603.E() == ain2.E()) {
                return ain.a;
            }
            \u26032.a(aeb2, \u2603);
        }
        return ain2;
    }
}

