/*
 * Decompiled with CFR 0.150.
 */
public interface fe
extends ff {
}

