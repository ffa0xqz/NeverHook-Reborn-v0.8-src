/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.GsonBuilder
 *  javax.annotation.Nullable
 *  org.apache.commons.io.IOUtils
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.Closeable;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class chm
implements ceo,
nv {
    public static final cgo a = new cgo("meta:missing_sound", 1.0f, 1.0f, 1, cgo.a.a, false);
    private static final Logger b = LogManager.getLogger();
    private static final Gson c = new GsonBuilder().registerTypeHierarchyAdapter(hh.class, (Object)new hh.a()).registerTypeAdapter(cgp.class, (Object)new cgq()).create();
    private static final ParameterizedType d = new ParameterizedType(){

        @Override
        public Type[] getActualTypeArguments() {
            return new Type[]{String.class, cgp.class};
        }

        @Override
        public Type getRawType() {
            return Map.class;
        }

        @Override
        public Type getOwnerType() {
            return null;
        }
    };
    private final chn e = new chn();
    private final chk f;
    private final cen g;

    public chm(cen cen2, bib bib2) {
        this.g = cen2;
        this.f = new chk(this, bib2);
    }

    @Override
    public void a(cen cen2) {
        this.e.a();
        for (String string : cen2.a()) {
            try {
                List<cem> iOException = cen2.b(new nd(string, "sounds.json"));
                for (cem cem2 : iOException) {
                    try {
                        Map<String, cgp> map = this.a(cem2.b());
                        for (Map.Entry<String, cgp> entry : map.entrySet()) {
                            this.a(new nd(string, entry.getKey()), entry.getValue());
                        }
                    }
                    catch (RuntimeException runtimeException) {
                        b.warn("Invalid sounds.json", (Throwable)runtimeException);
                    }
                }
            }
            catch (IOException iOException) {
            }
        }
        for (nd nd2 : this.e.c()) {
            cho cho2 = (cho)this.e.c(nd2);
            if (!(cho2.c() instanceof hp) || cew.a(\u2603 = ((hp)cho2.c()).i())) continue;
            b.debug("Missing subtitle {} for event: {}", (Object)\u2603, (Object)nd2);
        }
        for (nd nd3 : this.e.c()) {
            if (qc.a.c(nd3) != null) continue;
            b.debug("Not having sound event for: {}", (Object)nd3);
        }
        this.f.a();
    }

    @Nullable
    protected Map<String, cgp> a(InputStream inputStream) {
        try {
            Map map = (Map)ra.a(c, (Reader)new InputStreamReader(inputStream, StandardCharsets.UTF_8), (Type)d);
            return map;
        }
        finally {
            IOUtils.closeQuietly((InputStream)inputStream);
        }
    }

    private void a(nd nd2, cgp cgp2) {
        cho cho2 = (cho)this.e.c(nd2);
        boolean bl2 = \u2603 = cho2 == null;
        if (\u2603 || cgp2.b()) {
            if (!\u2603) {
                b.debug("Replaced sound event location {}", (Object)nd2);
            }
            cho2 = new cho(nd2, cgp2.c());
            this.e.a(cho2);
        }
        block4: for (final cgo cgo2 : cgp2.a()) {
            chp<cgo> \u26032;
            final nd nd3 = cgo2.a();
            switch (cgo2.g()) {
                case a: {
                    if (!this.a(cgo2, nd2)) continue block4;
                    \u26032 = cgo2;
                    break;
                }
                case b: {
                    \u26032 = new chp<cgo>(){

                        @Override
                        public int e() {
                            cho cho2 = (cho)chm.this.e.c(nd3);
                            return cho2 == null ? 0 : cho2.e();
                        }

                        public cgo a() {
                            cho cho2 = (cho)chm.this.e.c(nd3);
                            if (cho2 == null) {
                                return a;
                            }
                            cgo \u26032 = cho2.a();
                            return new cgo(\u26032.a().toString(), \u26032.c() * cgo2.c(), \u26032.d() * cgo2.d(), cgo2.e(), cgo.a.a, \u26032.h() || cgo2.h());
                        }

                        @Override
                        public /* synthetic */ Object i() {
                            return this.a();
                        }
                    };
                    break;
                }
                default: {
                    throw new IllegalStateException("Unknown SoundEventRegistration type: " + (Object)((Object)cgo2.g()));
                }
            }
            cho2.a(\u26032);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private boolean a(cgo cgo2, nd nd2) {
        nd nd3 = cgo2.b();
        cem cem2 = null;
        try {
            cem2 = this.g.a(nd3);
            cem2.b();
        }
        catch (FileNotFoundException \u26032) {
            b.warn("File {} does not exist, cannot add it to event {}", (Object)nd3, (Object)nd2);
            boolean bl2 = false;
            {
                catch (Throwable throwable) {
                    IOUtils.closeQuietly(cem2);
                    throw throwable;
                }
            }
            IOUtils.closeQuietly((Closeable)cem2);
            return bl2;
            catch (IOException \u26033) {
                b.warn("Could not load sound file {}, cannot add it to event {}", (Object)nd3, (Object)nd2, (Object)\u26033);
                boolean bl3 = false;
                IOUtils.closeQuietly((Closeable)cem2);
                return bl3;
            }
        }
        IOUtils.closeQuietly((Closeable)cem2);
        return true;
    }

    @Nullable
    public cho a(nd nd2) {
        return (cho)this.e.c(nd2);
    }

    public void a(cgr cgr2) {
        this.f.c(cgr2);
    }

    public void a(cgr cgr2, int n2) {
        this.f.a(cgr2, n2);
    }

    public void a(aeb aeb2, float f2) {
        this.f.a(aeb2, f2);
    }

    public void a() {
        this.f.e();
    }

    public void b() {
        this.f.c();
    }

    public void c() {
        this.f.b();
    }

    @Override
    public void e() {
        this.f.d();
    }

    public void d() {
        this.f.f();
    }

    public void a(qe qe2, float f2) {
        if (qe2 == qe.a && f2 <= 0.0f) {
            this.b();
        }
        this.f.a(qe2, f2);
    }

    public void b(cgr cgr2) {
        this.f.b(cgr2);
    }

    public boolean c(cgr cgr2) {
        return this.f.a(cgr2);
    }

    public void a(chl chl2) {
        this.f.a(chl2);
    }

    public void b(chl chl2) {
        this.f.b(chl2);
    }

    public void a(String string, qe qe2) {
        this.f.a(string, qe2);
    }
}

