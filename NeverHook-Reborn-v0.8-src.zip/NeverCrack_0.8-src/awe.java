/*
 * Decompiled with CFR 0.150.
 */
public class awe
extends avh {
    public boolean a(fa fa2) {
        return fa2 == fa.b;
    }
}

