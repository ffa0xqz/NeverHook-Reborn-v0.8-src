/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Optional
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Maps
 *  com.google.common.collect.Sets
 *  com.google.gson.JsonDeserializationContext
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonSyntaxException
 *  javax.annotation.Nullable
 */
import com.google.common.base.Optional;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nullable;

public class ah
implements p<b> {
    private static final nd a = new nd("enter_block");
    private final Map<nn, a> b = Maps.newHashMap();

    @Override
    public nd a() {
        return a;
    }

    @Override
    public void a(nn nn2, p.a<b> a2) {
        a a3 = this.b.get(nn2);
        if (a3 == null) {
            a3 = new a(nn2);
            this.b.put(nn2, a3);
        }
        a3.a(a2);
    }

    @Override
    public void b(nn nn2, p.a<b> a2) {
        a a3 = this.b.get(nn2);
        if (a3 != null) {
            a3.b(a2);
            if (a3.a()) {
                this.b.remove(nn2);
            }
        }
    }

    @Override
    public void a(nn nn2) {
        this.b.remove(nn2);
    }

    public b b(JsonObject jsonObject, JsonDeserializationContext jsonDeserializationContext) {
        Object object;
        aou aou2 = null;
        if (jsonObject.has("block")) {
            object = new nd(ra.h(jsonObject, "block"));
            if (aou.h.d((nd)object)) {
                aou2 = aou.h.c((nd)object);
            } else {
                throw new JsonSyntaxException("Unknown block type '" + object + "'");
            }
        }
        object = null;
        if (jsonObject.has("state")) {
            if (aou2 == null) {
                throw new JsonSyntaxException("Can't define block state without a specific block type");
            }
            aws aws2 = aou2.s();
            for (Map.Entry entry2 : ra.t(jsonObject, "state").entrySet()) {
                Map.Entry entry2;
                axh<?> axh2 = aws2.a((String)entry2.getKey());
                if (axh2 == null) {
                    throw new JsonSyntaxException("Unknown block state property '" + (String)entry2.getKey() + "' for block '" + aou.h.b(aou2) + "'");
                }
                String \u26032 = ra.a((JsonElement)entry2.getValue(), (String)entry2.getKey());
                Optional<?> \u26033 = axh2.b(\u26032);
                if (\u26033.isPresent()) {
                    if (object == null) {
                        object = Maps.newHashMap();
                    }
                    object.put(axh2, \u26033.get());
                    continue;
                }
                throw new JsonSyntaxException("Invalid block state value '" + \u26032 + "' for property '" + (String)entry2.getKey() + "' on block '" + aou.h.b(aou2) + "'");
            }
        }
        return new b(aou2, (Map<axh<?>, Object>)object);
    }

    public void a(oo oo2, awr awr2) {
        a a2 = this.b.get(oo2.P());
        if (a2 != null) {
            a2.a(awr2);
        }
    }

    @Override
    public /* synthetic */ q a(JsonObject jsonObject, JsonDeserializationContext jsonDeserializationContext) {
        return this.b(jsonObject, jsonDeserializationContext);
    }

    static class a {
        private final nn a;
        private final Set<p.a<b>> b = Sets.newHashSet();

        public a(nn nn2) {
            this.a = nn2;
        }

        public boolean a() {
            return this.b.isEmpty();
        }

        public void a(p.a<b> a2) {
            this.b.add(a2);
        }

        public void b(p.a<b> a2) {
            this.b.remove(a2);
        }

        public void a(awr awr2) {
            List list = null;
            for (p.a<b> a2 : this.b) {
                if (!a2.a().a(awr2)) continue;
                if (list == null) {
                    list = Lists.newArrayList();
                }
                list.add(a2);
            }
            if (list != null) {
                for (p.a<b> a2 : list) {
                    a2.a(this.a);
                }
            }
        }
    }

    public static class b
    extends u {
        private final aou a;
        private final Map<axh<?>, Object> b;

        public b(@Nullable aou aou2, @Nullable Map<axh<?>, Object> map) {
            super(a);
            this.a = aou2;
            this.b = map;
        }

        public boolean a(awr awr2) {
            if (this.a != null && awr2.u() != this.a) {
                return false;
            }
            if (this.b != null) {
                for (Map.Entry<axh<?>, Object> entry : this.b.entrySet()) {
                    if (awr2.c(entry.getKey()) == entry.getValue()) continue;
                    return false;
                }
            }
            return true;
        }
    }
}

