/*
 * Decompiled with CFR 0.150.
 */
import top.nhprem.Main;
import top.nhprem.client.features.impl.visuals.GAppleTimer;

public class aii
extends aih {
    public aii(int amount, float saturation, boolean isWolfFood) {
        super(amount, saturation, isWolfFood);
        this.a(true);
    }

    @Override
    public boolean f_(ain stack) {
        return super.f_(stack) || stack.j() > 0;
    }

    @Override
    public ajc g(ain stack) {
        return stack.j() == 0 ? ajc.c : ajc.d;
    }

    @Override
    protected void a(ain stack, ams worldIn, aeb player) {
        if (Main.instance.featureDirector.getFeatureByClass(GAppleTimer.class).isToggled()) {
            bhz.z().h.dt().a(aip.ar, (int)(20.0f * GAppleTimer.Timer.getNumberValue()));
        }
        if (!worldIn.G) {
            if (stack.j() > 0) {
                player.c(new uy(uz.j, 400, 1));
                player.c(new uy(uz.k, 6000, 0));
                player.c(new uy(uz.l, 6000, 0));
                player.c(new uy(uz.v, 2400, 3));
            } else {
                player.c(new uy(uz.j, 100, 1));
                player.c(new uy(uz.v, 2400, 0));
            }
        }
    }

    @Override
    public void a(ahn itemIn, fi<ain> tab) {
        if (this.a(itemIn)) {
            tab.add(new ain(this));
            tab.add(new ain(this, 1, 1));
        }
    }
}

