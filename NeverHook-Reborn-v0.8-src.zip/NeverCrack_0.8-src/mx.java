/*
 * Decompiled with CFR 0.150.
 */
public class mx<T> {
    private final int a;
    private final my<T> b;

    public mx(int n2, my<T> my2) {
        this.a = n2;
        this.b = my2;
    }

    public int a() {
        return this.a;
    }

    public my<T> b() {
        return this.b;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null || this.getClass() != object.getClass()) {
            return false;
        }
        mx mx2 = (mx)object;
        return this.a == mx2.a;
    }

    public int hashCode() {
        return this.a;
    }
}

