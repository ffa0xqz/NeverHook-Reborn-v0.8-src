/*
 * Decompiled with CFR 0.150.
 */
public class aky
implements akr {
    @Override
    public boolean a(afw afw2, ams ams2) {
        if (afw2.j() != 3 || afw2.i() != 3) {
            return false;
        }
        for (int i2 = 0; i2 < afw2.j(); ++i2) {
            for (\u2603 = 0; \u2603 < afw2.i(); ++\u2603) {
                ain ain2 = afw2.c(i2, \u2603);
                if (ain2.b()) {
                    return false;
                }
                ail \u26032 = ain2.c();
                if (!(i2 == 1 && \u2603 == 1 ? \u26032 != aip.bJ : \u26032 != aip.h)) continue;
                return false;
            }
        }
        return true;
    }

    @Override
    public ain a(afw afw2) {
        ain ain2 = afw2.c(1, 1);
        if (ain2.c() != aip.bJ) {
            return ain.a;
        }
        \u2603 = new ain(aip.j, 8);
        akg.a(\u2603, akg.d(ain2));
        akg.a(\u2603, akg.b(ain2));
        return \u2603;
    }

    @Override
    public ain b() {
        return ain.a;
    }

    @Override
    public fi<ain> b(afw afw2) {
        return fi.a(afw2.w_(), ain.a);
    }

    @Override
    public boolean c() {
        return true;
    }

    @Override
    public boolean a(int n2, int n3) {
        return n2 >= 2 && n3 >= 2;
    }
}

