/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  javax.annotation.Nullable
 */
import com.google.common.collect.Lists;
import java.util.List;
import javax.annotation.Nullable;

public class uo {
    private final List<um> a = Lists.newArrayList();
    private final vn b;
    private int c;
    private int d;
    private int e;
    private boolean f;
    private boolean g;
    private String h;

    public uo(vn vn2) {
        this.b = vn2;
    }

    public void a() {
        this.k();
        if (this.b.m_()) {
            aou aou2 = this.b.l.o(new et(this.b.p, this.b.bw().b, this.b.r)).u();
            if (aou2 == aov.au) {
                this.h = "ladder";
            } else if (aou2 == aov.bn) {
                this.h = "vines";
            }
        } else if (this.b.ao()) {
            this.h = "water";
        }
    }

    public void a(up up2, float f2, float f3) {
        this.g();
        this.a();
        um um2 = new um(up2, this.b.T, f2, f3, this.h, this.b.L);
        this.a.add(um2);
        this.c = this.b.T;
        this.g = true;
        if (um2.f() && !this.f && this.b.aC()) {
            this.f = true;
            this.e = this.d = this.b.T;
            this.b.j();
        }
    }

    public hh b() {
        hh \u26034;
        if (this.a.isEmpty()) {
            return new hp("death.attack.generic", this.b.i_());
        }
        um um2 = this.j();
        \u2603 = this.a.get(this.a.size() - 1);
        hh \u26032 = \u2603.h();
        ve \u26033 = \u2603.a().j();
        if (um2 != null && \u2603.a() == up.k) {
            hh hh2 = um2.h();
            if (um2.a() == up.k || um2.a() == up.m) {
                \u26034 = new hp("death.fell.accident." + this.a(um2), this.b.i_());
            } else if (!(hh2 == null || \u26032 != null && hh2.equals(\u26032))) {
                ve ve2 = um2.a().j();
                ain ain2 = \u2603 = ve2 instanceof vn ? ((vn)ve2).co() : ain.a;
                \u26034 = !\u2603.b() && \u2603.t() ? new hp("death.fell.assist.item", this.b.i_(), hh2, \u2603.C()) : new hp("death.fell.assist", this.b.i_(), hh2);
            } else if (\u26032 != null) {
                ain ain3 = \u2603 = \u26033 instanceof vn ? ((vn)\u26033).co() : ain.a;
                \u26034 = !\u2603.b() && \u2603.t() ? new hp("death.fell.finish.item", this.b.i_(), \u26032, \u2603.C()) : new hp("death.fell.finish", this.b.i_(), \u26032);
            } else {
                \u26034 = new hp("death.fell.killer", this.b.i_());
            }
        } else {
            \u26034 = \u2603.a().c(this.b);
        }
        return \u26034;
    }

    @Nullable
    public vn c() {
        vn vn2 = null;
        aeb \u26032 = null;
        float \u26033 = 0.0f;
        float \u26034 = 0.0f;
        for (um um2 : this.a) {
            if (um2.a().j() instanceof aeb && (\u26032 == null || um2.c() > \u26034)) {
                \u26034 = um2.c();
                \u26032 = (aeb)um2.a().j();
            }
            if (!(um2.a().j() instanceof vn) || vn2 != null && !(um2.c() > \u26033)) continue;
            \u26033 = um2.c();
            vn2 = (vn)um2.a().j();
        }
        if (\u26032 != null && \u26034 >= \u26033 / 3.0f) {
            return \u26032;
        }
        return vn2;
    }

    @Nullable
    private um j() {
        um um2 = null;
        \u2603 = null;
        float \u26032 = 0.0f;
        float \u26033 = 0.0f;
        for (int i2 = 0; i2 < this.a.size(); ++i2) {
            um um3 = this.a.get(i2);
            um um4 = \u2603 = i2 > 0 ? this.a.get(i2 - 1) : null;
            if ((um3.a() == up.k || um3.a() == up.m) && um3.j() > 0.0f && (um2 == null || um3.j() > \u26033)) {
                um2 = i2 > 0 ? \u2603 : um3;
                \u26033 = um3.j();
            }
            if (um3.g() == null || \u2603 != null && !(um3.c() > \u26032)) continue;
            \u2603 = um3;
            \u26032 = um3.c();
        }
        if (\u26033 > 5.0f && um2 != null) {
            return um2;
        }
        if (\u26032 > 5.0f && \u2603 != null) {
            return \u2603;
        }
        return null;
    }

    private String a(um um2) {
        return um2.g() == null ? "generic" : um2.g();
    }

    public int f() {
        if (this.f) {
            return this.b.T - this.d;
        }
        return this.e - this.d;
    }

    private void k() {
        this.h = null;
    }

    public void g() {
        int n2;
        int n3 = n2 = this.f ? 300 : 100;
        if (this.g && (!this.b.aC() || this.b.T - this.c > n2)) {
            boolean bl2 = this.f;
            this.g = false;
            this.f = false;
            this.e = this.b.T;
            if (bl2) {
                this.b.k();
            }
            this.a.clear();
        }
    }

    public vn h() {
        return this.b;
    }
}

