/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 *  javax.annotation.Nullable
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.common.base.Predicate;
import java.util.List;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class aex
extends aet {
    private static final mx<ain> e = na.a(aex.class, mz.f);
    private static final Logger f = LogManager.getLogger();
    public static final Predicate<vn> d = new Predicate<vn>(){

        public boolean a(@Nullable vn vn2) {
            return aex.c(vn2);
        }

        public /* synthetic */ boolean apply(@Nullable Object object) {
            return this.a((vn)object);
        }
    };

    public aex(ams ams2) {
        super(ams2);
    }

    public aex(ams ams2, vn vn2, ain ain2) {
        super(ams2, vn2);
        this.a(ain2);
    }

    public aex(ams ams2, double d2, double d3, double d4, ain ain2) {
        super(ams2, d2, d3, d4);
        if (!ain2.b()) {
            this.a(ain2);
        }
    }

    @Override
    protected void i() {
        this.V().a(e, ain.a);
    }

    public ain l() {
        ain ain2 = this.V().a(e);
        if (ain2.c() != aip.bI && ain2.c() != aip.bJ) {
            if (this.l != null) {
                f.error("ThrownPotion entity {} has no item?!", (Object)this.S());
            }
            return new ain(aip.bI);
        }
        return ain2;
    }

    public void a(ain ain2) {
        this.V().b(e, ain2);
        this.V().b(e);
    }

    @Override
    protected float j() {
        return 0.05f;
    }

    @Override
    protected void a(bha bha2) {
        boolean bl2;
        if (this.l.G) {
            return;
        }
        ain ain2 = this.l();
        ake \u26032 = akg.d(ain2);
        List<uy> \u26033 = akg.a(ain2);
        boolean bl3 = bl2 = \u26032 == akh.b && \u26033.isEmpty();
        if (bha2.a == bha.a.b && bl2) {
            et et2 = bha2.a().a(bha2.b);
            this.a(et2, bha2.b);
            for (fa fa2 : fa.c.a) {
                this.a(et2.a(fa2), fa2);
            }
        }
        if (bl2) {
            this.n();
        } else if (!\u26033.isEmpty()) {
            if (this.p()) {
                this.a(ain2, \u26032);
            } else {
                this.a(bha2, \u26033);
            }
        }
        int \u26034 = \u26032.c() ? 2007 : 2002;
        this.l.b(\u26034, new et(this), akg.c(ain2));
        this.X();
    }

    private void n() {
        bgz bgz2 = this.bw().c(4.0, 2.0, 4.0);
        Predicate<vn> \u26032 = this.l.a(vn.class, bgz2, d);
        if (!\u26032.isEmpty()) {
            for (vn vn2 : \u26032) {
                double d2 = this.h(vn2);
                if (!(d2 < 16.0) || !aex.c(vn2)) continue;
                vn2.a(up.h, 1.0f);
            }
        }
    }

    private void a(bha bha2, List<uy> list) {
        bgz bgz2 = this.bw().c(4.0, 2.0, 4.0);
        List<vn> \u26032 = this.l.a(vn.class, bgz2);
        if (!\u26032.isEmpty()) {
            for (vn vn2 : \u26032) {
                if (!vn2.cR() || !((\u2603 = this.h(vn2)) < 16.0)) continue;
                double d2 = 1.0 - Math.sqrt(\u2603) / 4.0;
                if (vn2 == bha2.d) {
                    d2 = 1.0;
                }
                for (uy uy2 : list) {
                    ux ux2 = uy2.a();
                    if (ux2.b()) {
                        ux2.a(this, this.k(), vn2, uy2.c(), d2);
                        continue;
                    }
                    int \u26033 = (int)(d2 * (double)uy2.b() + 0.5);
                    if (\u26033 <= 20) continue;
                    vn2.c(new uy(ux2, \u26033, uy2.c(), uy2.d(), uy2.e()));
                }
            }
        }
    }

    private void a(ain ain22, ake ake2) {
        ain ain22;
        vc vc2 = new vc(this.l, this.p, this.q, this.r);
        vc2.a(this.k());
        vc2.a(3.0f);
        vc2.b(-0.5f);
        vc2.g(10);
        vc2.c(-vc2.j() / (float)vc2.r());
        vc2.a(ake2);
        for (uy uy2 : akg.b(ain22)) {
            vc2.a(new uy(uy2));
        }
        fy \u26032 = ain22.p();
        if (\u26032 != null && \u26032.b("CustomPotionColor", 99)) {
            vc2.a(\u26032.h("CustomPotionColor"));
        }
        this.l.a(vc2);
    }

    private boolean p() {
        return this.l().c() == aip.bJ;
    }

    private void a(et et2, fa fa2) {
        if (this.l.o(et2).u() == aov.ab) {
            this.l.a(null, et2.a(fa2), fa2.d());
        }
    }

    public static void a(rw rw2) {
        aet.a(rw2, "ThrownPotion");
        rw2.a(ru.e, (ry)new ti(aex.class, "Potion"));
    }

    @Override
    public void a(fy fy2) {
        super.a(fy2);
        ain ain2 = new ain(fy2.p("Potion"));
        if (ain2.b()) {
            this.X();
        } else {
            this.a(ain2);
        }
    }

    @Override
    public void b(fy fy2) {
        super.b(fy2);
        ain ain2 = this.l();
        if (!ain2.b()) {
            fy2.a("Potion", ain2.a(new fy()));
        }
    }

    private static boolean c(vn vn2) {
        return vn2 instanceof acs || vn2 instanceof aco;
    }
}

