/*
 * Decompiled with CFR 0.150.
 */
public interface buu {
    public cgb a(ain var1);
}

