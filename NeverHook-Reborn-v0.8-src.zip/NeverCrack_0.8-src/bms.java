/*
 * Decompiled with CFR 0.150.
 */
public class bms
extends bme {
    private static final nd v = new nd("textures/gui/container/furnace.png");
    private final aea w;
    private final tt x;

    public bms(aea playerInv, tt furnaceInv) {
        super(new agb(playerInv, furnaceInv));
        this.w = playerInv;
        this.x = furnaceInv;
    }

    @Override
    public void a(int mouseX, int mouseY, float partialTicks) {
        this.c();
        super.a(mouseX, mouseY, partialTicks);
        this.b(mouseX, mouseY);
    }

    @Override
    protected void c(int mouseX, int mouseY) {
        String s2 = this.x.i_().c();
        this.q.drawString(s2, this.f / 2 - this.q.a(s2) / 2, 6.0f, 0x404040);
        this.q.drawString(this.w.i_().c(), 8.0f, this.g - 96 + 2, 0x404040);
    }

    @Override
    protected void a(float partialTicks, int mouseX, int mouseY) {
        buq.c(1.0f, 1.0f, 1.0f, 1.0f);
        this.j.N().a(v);
        int i2 = (this.l - this.f) / 2;
        int j2 = (this.m - this.g) / 2;
        this.b(i2, j2, 0, 0, this.f, this.g);
        if (avs.a(this.x)) {
            int k2 = this.i(13);
            this.b(i2 + 56, j2 + 36 + 12 - k2, 176, 12 - k2, 14, k2 + 1);
        }
        int l2 = this.h(24);
        this.b(i2 + 79, j2 + 34, 176, 14, l2 + 1, 16);
    }

    private int h(int pixels) {
        int i2 = this.x.c(2);
        int j2 = this.x.c(3);
        return j2 != 0 && i2 != 0 ? i2 * pixels / j2 : 0;
    }

    private int i(int pixels) {
        int i2 = this.x.c(1);
        if (i2 == 0) {
            i2 = 200;
        }
        return this.x.c(0) * pixels / i2;
    }
}

