/*
 * Decompiled with CFR 0.150.
 */
public class afx
extends afp {
    public afw a = new afw(this, 3, 3);
    public agl f = new agl();
    private final ams g;
    private final et h;
    private final aeb i;

    public afx(aea aea2, ams ams2, et et2) {
        int n2;
        this.g = ams2;
        this.h = et2;
        this.i = aea2.e;
        this.a(new agm(aea2.e, this.a, this.f, 0, 124, 35));
        for (n2 = 0; n2 < 3; ++n2) {
            for (\u2603 = 0; \u2603 < 3; ++\u2603) {
                this.a(new agp(this.a, \u2603 + n2 * 3, 30 + \u2603 * 18, 17 + n2 * 18));
            }
        }
        for (n2 = 0; n2 < 3; ++n2) {
            for (\u2603 = 0; \u2603 < 9; ++\u2603) {
                this.a(new agp(aea2, \u2603 + n2 * 9 + 9, 8 + \u2603 * 18, 84 + n2 * 18));
            }
        }
        for (n2 = 0; n2 < 9; ++n2) {
            this.a(new agp(aea2, n2, 8 + n2 * 18, 142));
        }
    }

    @Override
    public void a(tt tt2) {
        this.a(this.g, this.i, this.a, this.f);
    }

    @Override
    public void b(aeb aeb2) {
        super.b(aeb2);
        if (this.g.G) {
            return;
        }
        this.a(aeb2, this.g, this.a);
    }

    @Override
    public boolean a(aeb aeb2) {
        if (this.g.o(this.h).u() != aov.ai) {
            return false;
        }
        return aeb2.d((double)this.h.p() + 0.5, (double)this.h.q() + 0.5, (double)this.h.r() + 0.5) <= 64.0;
    }

    @Override
    public ain b(aeb aeb2, int n2) {
        ain ain2 = ain.a;
        agp \u26032 = (agp)this.c.get(n2);
        if (\u26032 != null && \u26032.e()) {
            \u2603 = \u26032.d();
            ain2 = \u2603.l();
            if (n2 == 0) {
                \u2603.c().b(\u2603, this.g, aeb2);
                if (!this.a(\u2603, 10, 46, true)) {
                    return ain.a;
                }
                \u26032.a(\u2603, ain2);
            } else if (n2 >= 10 && n2 < 37 ? !this.a(\u2603, 37, 46, false) : (n2 >= 37 && n2 < 46 ? !this.a(\u2603, 10, 37, false) : !this.a(\u2603, 10, 46, false))) {
                return ain.a;
            }
            if (\u2603.b()) {
                \u26032.d(ain.a);
            } else {
                \u26032.f();
            }
            if (\u2603.E() == ain2.E()) {
                return ain.a;
            }
            \u2603 = \u26032.a(aeb2, \u2603);
            if (n2 == 0) {
                aeb2.a(\u2603, false);
            }
        }
        return ain2;
    }

    @Override
    public boolean a(ain ain2, agp agp2) {
        return agp2.d != this.f && super.a(ain2, agp2);
    }
}

