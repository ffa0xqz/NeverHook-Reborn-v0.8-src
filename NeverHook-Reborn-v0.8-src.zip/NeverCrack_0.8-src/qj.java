/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import java.util.BitSet;
import javax.annotation.Nullable;

public class qj {
    protected final BitSet a = new BitSet();
    protected final BitSet b = new BitSet();
    protected boolean c;
    protected boolean d;

    public void a(qj p_193824_1_) {
        this.a.clear();
        this.b.clear();
        this.a.or(p_193824_1_.a);
        this.b.or(p_193824_1_.b);
    }

    public void a(akr p_194073_1_) {
        if (!p_194073_1_.c()) {
            this.a.set(qj.d(p_194073_1_));
        }
    }

    public boolean b(@Nullable akr p_193830_1_) {
        return this.a.get(qj.d(p_193830_1_));
    }

    public void c(akr p_193831_1_) {
        int i2 = qj.d(p_193831_1_);
        this.a.clear(i2);
        this.b.clear(i2);
    }

    protected static int d(@Nullable akr p_194075_0_) {
        return aks.a.a(p_194075_0_);
    }

    public boolean e(akr p_194076_1_) {
        return this.b.get(qj.d(p_194076_1_));
    }

    public void f(akr p_194074_1_) {
        this.b.clear(qj.d(p_194074_1_));
    }

    public void g(akr p_193825_1_) {
        this.b.set(qj.d(p_193825_1_));
    }

    public boolean a() {
        return this.c;
    }

    public void a(boolean p_192813_1_) {
        this.c = p_192813_1_;
    }

    public boolean b() {
        return this.d;
    }

    public void b(boolean p_192810_1_) {
        this.d = p_192810_1_;
    }
}

