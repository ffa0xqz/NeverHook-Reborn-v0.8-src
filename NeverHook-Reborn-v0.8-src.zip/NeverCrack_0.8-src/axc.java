/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.base.MoreObjects
 */
import com.google.common.base.MoreObjects;

public abstract class axc<T extends Comparable<T>>
implements axh<T> {
    private final Class<T> a;
    private final String b;

    protected axc(String string, Class<T> class_) {
        this.a = class_;
        this.b = string;
    }

    @Override
    public String a() {
        return this.b;
    }

    @Override
    public Class<T> b() {
        return this.a;
    }

    public String toString() {
        return MoreObjects.toStringHelper((Object)this).add("name", (Object)this.b).add("clazz", this.a).add("values", this.c()).toString();
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object instanceof axc) {
            axc axc2 = (axc)object;
            return this.a.equals(axc2.a) && this.b.equals(axc2.b);
        }
        return false;
    }

    public int hashCode() {
        return 31 * this.a.hashCode() + this.b.hashCode();
    }
}

