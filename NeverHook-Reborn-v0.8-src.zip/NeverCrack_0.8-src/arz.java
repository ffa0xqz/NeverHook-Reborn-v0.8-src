/*
 * Decompiled with CFR 0.150.
 */
import java.util.Random;

public class arz
extends apa
implements aox {
    protected static final bgz a = new bgz(0.3f, 0.0, 0.3f, 0.7f, 0.4f, 0.7f);

    protected arz() {
        this.a(true);
    }

    @Override
    public bgz b(awr awr2, amw amw2, et et2) {
        return a;
    }

    /*
     * WARNING - void declaration
     */
    @Override
    public void b(ams ams22, et et22, awr awr2, Random random) {
        if (random.nextInt(25) == 0) {
            void var8_10;
            int n2 = 5;
            int n3 = 4;
            for (et et2 : et.b(et22.a(-4, -1, -4), et22.a(4, 1, 4))) {
                if (ams22.o(et2).u() != this || --n2 > 0) continue;
                return;
            }
            et \u26032 = et22.a(random.nextInt(3) - 1, random.nextInt(2) - random.nextInt(2), random.nextInt(3) - 1);
            boolean bl2 = false;
            while (++var8_10 < 4) {
                if (ams22.d(\u26032) && this.f(ams22, \u26032, this.t())) {
                    et22 = \u26032;
                }
                \u26032 = et22.a(random.nextInt(3) - 1, random.nextInt(2) - random.nextInt(2), random.nextInt(3) - 1);
            }
            if (ams22.d(\u26032) && this.f(ams22, \u26032, this.t())) {
                ams22.a(\u26032, this.t(), 2);
            }
        }
    }

    @Override
    public boolean a(ams ams2, et et2) {
        return super.a(ams2, et2) && this.f(ams2, et2, this.t());
    }

    @Override
    protected boolean x(awr awr2) {
        return awr2.b();
    }

    @Override
    public boolean f(ams ams2, et et2, awr awr2) {
        if (et2.q() < 0 || et2.q() >= 256) {
            return false;
        }
        \u2603 = ams2.o(et2.b());
        if (\u2603.u() == aov.bw) {
            return true;
        }
        if (\u2603.u() == aov.d && \u2603.c(apw.a) == apw.a.c) {
            return true;
        }
        return ams2.j(et2) < 13 && this.x(\u2603);
    }

    public boolean c(ams ams2, et et2, awr awr2, Random random) {
        ams2.g(et2);
        azz azz2 = null;
        if (this == aov.P) {
            azz2 = new azz(aov.bg);
        } else if (this == aov.Q) {
            azz2 = new azz(aov.bh);
        }
        if (azz2 != null && ((azs)azz2).b(ams2, random, et2)) {
            return true;
        }
        ams2.a(et2, awr2, 3);
        return false;
    }

    @Override
    public boolean a(ams ams2, et et2, awr awr2, boolean bl2) {
        return true;
    }

    @Override
    public boolean a(ams ams2, Random random, et et2, awr awr2) {
        return (double)random.nextFloat() < 0.4;
    }

    @Override
    public void b(ams ams2, Random random, et et2, awr awr2) {
        this.c(ams2, et2, awr2, random);
    }
}

