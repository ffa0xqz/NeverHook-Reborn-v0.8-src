/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import io.netty.buffer.Unpooled;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class bmg
extends bme {
    private static final Logger v = LogManager.getLogger();
    private static final nd w = new nd("textures/gui/container/beacon.png");
    private final tt x;
    private b y;
    private boolean z;

    public bmg(aea aea2, tt tt2) {
        super(new afr(aea2, tt2));
        this.x = tt2;
        this.f = 230;
        this.g = 219;
    }

    @Override
    public void b() {
        super.b();
        this.y = new b(-1, this.i + 164, this.s + 107);
        this.n.add(this.y);
        this.n.add(new a(-2, this.i + 190, this.s + 107));
        this.z = true;
        this.y.l = false;
    }

    @Override
    public void e() {
        super.e();
        int n2 = this.x.c(0);
        ux \u26032 = ux.a(this.x.c(1));
        ux \u26033 = ux.a(this.x.c(2));
        if (this.z && n2 >= 0) {
            c \u26034;
            ux ux2;
            this.z = false;
            n4 = 100;
            for (n3 = 0; n3 <= 2; ++n3) {
                \u2603 = avf.a[n3].length;
                \u2603 = \u2603 * 22 + (\u2603 - 1) * 2;
                for (\u2603 = 0; \u2603 < \u2603; ++\u2603) {
                    ux2 = avf.a[n3][\u2603];
                    \u26034 = new c(n4++, this.i + 76 + \u2603 * 24 - \u2603 / 2, this.s + 22 + n3 * 25, ux2, n3);
                    this.n.add(\u26034);
                    if (n3 >= n2) {
                        \u26034.l = false;
                        continue;
                    }
                    if (ux2 != \u26032) continue;
                    \u26034.b(true);
                }
            }
            int n3 = 3;
            \u2603 = avf.a[3].length + 1;
            \u2603 = \u2603 * 22 + (\u2603 - 1) * 2;
            for (\u2603 = 0; \u2603 < \u2603 - 1; ++\u2603) {
                ux2 = avf.a[3][\u2603];
                \u26034 = new c(n4++, this.i + 167 + \u2603 * 24 - \u2603 / 2, this.s + 47, ux2, 3);
                this.n.add(\u26034);
                if (3 >= n2) {
                    \u26034.l = false;
                    continue;
                }
                if (ux2 != \u26033) continue;
                \u26034.b(true);
            }
            if (\u26032 != null) {
                int n4;
                c \u26035 = new c(n4++, this.i + 167 + (\u2603 - 1) * 24 - \u2603 / 2, this.s + 47, \u26032, 3);
                this.n.add(\u26035);
                if (3 >= n2) {
                    \u26035.l = false;
                } else if (\u26032 == \u26033) {
                    \u26035.b(true);
                }
            }
        }
        this.y.l = !this.x.a(0).b() && \u26032 != null;
    }

    @Override
    protected void a(biy biy2) {
        if (biy2.k == -2) {
            this.j.h.d.a(new lg(this.j.h.by.d));
            this.j.a((bli)null);
        } else if (biy2.k == -1) {
            String string = "MC|Beacon";
            gy \u26032 = new gy(Unpooled.buffer());
            \u26032.writeInt(this.x.c(1));
            \u26032.writeInt(this.x.c(2));
            this.j.v().a(new lh("MC|Beacon", \u26032));
            this.j.h.d.a(new lg(this.j.h.by.d));
            this.j.a((bli)null);
        } else if (biy2 instanceof c) {
            c \u26033 = (c)biy2;
            if (\u26033.c()) {
                return;
            }
            int \u26034 = ux.a(\u26033.p);
            if (\u26033.q < 3) {
                this.x.b(1, \u26034);
            } else {
                this.x.b(2, \u26034);
            }
            this.n.clear();
            this.b();
            this.e();
        }
    }

    @Override
    public void a(int n2, int n3, float f2) {
        this.c();
        super.a(n2, n3, f2);
        this.b(n2, n3);
    }

    @Override
    protected void c(int n2, int n3) {
        bhx.a();
        this.a(this.q, cew.a("tile.beacon.primary", new Object[0]), 62, 10, 0xE0E0E0);
        this.a(this.q, cew.a("tile.beacon.secondary", new Object[0]), 169, 10, 0xE0E0E0);
        for (biy biy2 : this.n) {
            if (!biy2.a()) continue;
            biy2.b(n2 - this.i, n3 - this.s);
            break;
        }
        bhx.c();
    }

    @Override
    protected void a(float f2, int n2, int n3) {
        buq.c(1.0f, 1.0f, 1.0f, 1.0f);
        this.j.N().a(w);
        \u2603 = (this.l - this.f) / 2;
        \u2603 = (this.m - this.g) / 2;
        this.b(\u2603, \u2603, 0, 0, this.f, this.g);
        this.k.a = 100.0f;
        this.k.b(new ain(aip.bZ), \u2603 + 42, \u2603 + 109);
        this.k.b(new ain(aip.l), \u2603 + 42 + 22, \u2603 + 109);
        this.k.b(new ain(aip.n), \u2603 + 42 + 44, \u2603 + 109);
        this.k.b(new ain(aip.m), \u2603 + 42 + 66, \u2603 + 109);
        this.k.a = 0.0f;
    }

    class a
    extends d {
        public a(int n2, int n3, int n4) {
            super(n2, n3, n4, w, 112, 220);
        }

        @Override
        public void b(int n2, int n3) {
            bmg.this.a(cew.a("gui.cancel", new Object[0]), n2, n3);
        }
    }

    class b
    extends d {
        public b(int n2, int n3, int n4) {
            super(n2, n3, n4, w, 90, 220);
        }

        @Override
        public void b(int n2, int n3) {
            bmg.this.a(cew.a("gui.done", new Object[0]), n2, n3);
        }
    }

    class c
    extends d {
        private final ux p;
        private final int q;

        public c(int n2, int n3, int n4, ux ux2, int n5) {
            super(n2, n3, n4, bme.a, ux2.d() % 8 * 18, 198 + ux2.d() / 8 * 18);
            this.p = ux2;
            this.q = n5;
        }

        @Override
        public void b(int n2, int n3) {
            String string = cew.a(this.p.a(), new Object[0]);
            if (this.q >= 3 && this.p != uz.j) {
                string = string + " II";
            }
            bmg.this.a(string, n2, n3);
        }
    }

    static class d
    extends biy {
        private final nd o;
        private final int p;
        private final int q;
        private boolean r;

        protected d(int n2, int n3, int n4, nd nd2, int n5, int n6) {
            super(n2, n3, n4, 22, 22, "");
            this.o = nd2;
            this.p = n5;
            this.q = n6;
        }

        public void a(bhz bhz2, int n2, int n3, float f2) {
            if (!this.m) {
                return;
            }
            bhz2.N().a(w);
            buq.c(1.0f, 1.0f, 1.0f, 1.0f);
            this.n = n2 >= this.h && n3 >= this.i && n2 < this.h + this.f && n3 < this.i + this.g;
            int n4 = 219;
            \u2603 = 0;
            if (!this.l) {
                \u2603 += this.f * 2;
            } else if (this.r) {
                \u2603 += this.f * 1;
            } else if (this.n) {
                \u2603 += this.f * 3;
            }
            this.b(this.h, this.i, \u2603, 219, this.f, this.g);
            if (!w.equals(this.o)) {
                bhz2.N().a(this.o);
            }
            this.b(this.h + 2, this.i + 2, this.p, this.q, 18, 18);
        }

        public boolean c() {
            return this.r;
        }

        public void b(boolean bl2) {
            this.r = bl2;
        }
    }
}

