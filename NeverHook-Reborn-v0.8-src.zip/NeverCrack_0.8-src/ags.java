/*
 * Decompiled with CFR 0.150.
 */
public class ags
extends aix {
    public ags(aou aou2) {
        super(aou2, aou2, new String[]{"intact", "slightlyDamaged", "veryDamaged"});
    }

    @Override
    public int a(int n2) {
        return n2 << 2;
    }
}

