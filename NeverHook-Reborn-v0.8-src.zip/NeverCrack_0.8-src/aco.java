/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import javax.annotation.Nullable;

public class aco
extends adc {
    private float a = 0.5f;
    private int b;
    private static final mx<Byte> c = na.a(aco.class, mz.a);

    public aco(ams ams2) {
        super(ams2);
        this.a(bef.g, -1.0f);
        this.a(bef.f, 8.0f);
        this.a(bef.i, 0.0f);
        this.a(bef.j, 0.0f);
        this.X = true;
        this.b_ = 10;
    }

    public static void a(rw rw2) {
        vo.a(rw2, aco.class);
    }

    @Override
    protected void r() {
        this.br.a(4, new a(this));
        this.br.a(5, new xq(this, 1.0));
        this.br.a(7, new yn((vv)this, 1.0, 0.0f));
        this.br.a(8, new xj(this, aeb.class, 8.0f));
        this.br.a(8, new xz(this));
        this.bs.a(1, new yr((vv)this, true, new Class[0]));
        this.bs.a(2, new yu<aeb>((vv)this, aeb.class, true));
    }

    @Override
    protected void bM() {
        super.bM();
        this.a(adf.f).a(6.0);
        this.a(adf.d).a(0.23f);
        this.a(adf.b).a(48.0);
    }

    @Override
    protected void i() {
        super.i();
        this.Y.a(c, (byte)0);
    }

    @Override
    protected qc F() {
        return qd.C;
    }

    @Override
    protected qc d(up up2) {
        return qd.F;
    }

    @Override
    protected qc cf() {
        return qd.E;
    }

    @Override
    public int av() {
        return 0xF000F0;
    }

    @Override
    public float aw() {
        return 1.0f;
    }

    @Override
    public void n() {
        if (!this.z && this.t < 0.0) {
            this.t *= 0.6;
        }
        if (this.l.G) {
            if (this.S.nextInt(24) == 0 && !this.ai()) {
                this.l.a(this.p + 0.5, this.q + 0.5, this.r + 0.5, qd.D, this.bK(), 1.0f + this.S.nextFloat(), this.S.nextFloat() * 0.7f + 0.3f, false);
            }
            for (int i2 = 0; i2 < 2; ++i2) {
                this.l.a(fj.m, this.p + (this.S.nextDouble() - 0.5) * (double)this.G, this.q + this.S.nextDouble() * (double)this.H, this.r + (this.S.nextDouble() - 0.5) * (double)this.G, 0.0, 0.0, 0.0, new int[0]);
            }
        }
        super.n();
    }

    @Override
    protected void M() {
        vn vn2;
        if (this.an()) {
            this.a(up.h, 1.0f);
        }
        --this.b;
        if (this.b <= 0) {
            this.b = 100;
            this.a = 0.5f + (float)this.S.nextGaussian() * 3.0f;
        }
        if ((vn2 = this.z()) != null && vn2.q + (double)vn2.by() > this.q + (double)this.by() + (double)this.a) {
            this.t += ((double)0.3f - this.t) * (double)0.3f;
            this.ai = true;
        }
        super.M();
    }

    @Override
    public void e(float f2, float f3) {
    }

    @Override
    public boolean aR() {
        return this.p();
    }

    @Override
    @Nullable
    protected nd J() {
        return bfl.q;
    }

    public boolean p() {
        return (this.Y.a(c) & 1) != 0;
    }

    public void a(boolean bl2) {
        byte by2 = this.Y.a(c);
        by2 = bl2 ? (byte)(by2 | 1) : (byte)(by2 & 0xFFFFFFFE);
        this.Y.b(c, by2);
    }

    @Override
    protected boolean s_() {
        return true;
    }

    static class a
    extends xc {
        private final aco a;
        private int b;
        private int c;

        public a(aco aco2) {
            this.a = aco2;
            this.a(3);
        }

        @Override
        public boolean a() {
            vn vn2 = this.a.z();
            return vn2 != null && vn2.aC();
        }

        @Override
        public void c() {
            this.b = 0;
        }

        @Override
        public void d() {
            this.a.a(false);
        }

        @Override
        public void e() {
            --this.c;
            vn vn2 = this.a.z();
            double \u26032 = this.a.h(vn2);
            if (\u26032 < 4.0) {
                if (this.c <= 0) {
                    this.c = 20;
                    this.a.B(vn2);
                }
                this.a.u().a(vn2.p, vn2.q, vn2.r, 1.0);
            } else if (\u26032 < this.f() * this.f()) {
                double d2 = vn2.p - this.a.p;
                \u2603 = vn2.bw().b + (double)(vn2.H / 2.0f) - (this.a.q + (double)(this.a.H / 2.0f));
                \u2603 = vn2.r - this.a.r;
                if (this.c <= 0) {
                    ++this.b;
                    if (this.b == 1) {
                        this.c = 60;
                        this.a.a(true);
                    } else if (this.b <= 4) {
                        this.c = 6;
                    } else {
                        this.c = 100;
                        this.b = 0;
                        this.a.a(false);
                    }
                    if (this.b > 1) {
                        float f2 = ri.c(ri.a(\u26032)) * 0.5f;
                        this.a.l.a(null, 1018, new et((int)this.a.p, (int)this.a.q, (int)this.a.r), 0);
                        for (int i2 = 0; i2 < 1; ++i2) {
                            aeq aeq2 = new aeq(this.a.l, this.a, d2 + this.a.bR().nextGaussian() * (double)f2, \u2603, \u2603 + this.a.bR().nextGaussian() * (double)f2);
                            aeq2.q = this.a.q + (double)(this.a.H / 2.0f) + 0.5;
                            this.a.l.a(aeq2);
                        }
                    }
                }
                this.a.t().a(vn2, 10.0f, 10.0f);
            } else {
                this.a.x().p();
                this.a.u().a(vn2.p, vn2.q, vn2.r, 1.0);
            }
            super.e();
        }

        private double f() {
            wb wb2 = this.a.a(adf.b);
            return wb2 == null ? 16.0 : wb2.e();
        }
    }
}

