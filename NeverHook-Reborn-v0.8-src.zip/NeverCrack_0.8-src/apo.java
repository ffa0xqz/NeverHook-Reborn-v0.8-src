/*
 * Decompiled with CFR 0.150.
 */
public class apo
extends aqk {
    public static final axf<ahq> a = axf.a("color", ahq.class);

    public apo() {
        super(bcx.p);
        this.w(this.A.b().a(a, ahq.a));
        this.a(ahn.b);
    }

    @Override
    public void a(ams ams2, et et2, awr awr2, awr awr3) {
        if (awr3.a().d()) {
            ams2.a(et2, aov.dR.t().a(apl.a, awr2.c(a)), 3);
        }
    }

    protected boolean e(ams ams2, et et2, awr awr2) {
        boolean bl2 = false;
        for (fa fa2 : fa.values()) {
            if (fa2 == fa.a || ams2.o(\u2603 = et2.a(fa2)).a() != bcx.h) continue;
            bl2 = true;
            break;
        }
        if (bl2) {
            ams2.a(et2, aov.dR.t().a(apl.a, awr2.c(a)), 3);
        }
        return bl2;
    }

    @Override
    public void a(awr awr2, ams ams2, et et2, aou aou2, et et3) {
        if (!this.e(ams2, et2, awr2)) {
            super.a(awr2, ams2, et2, aou2, et3);
        }
    }

    @Override
    public void c(ams ams2, et et2, awr awr2) {
        if (!this.e(ams2, et2, awr2)) {
            super.c(ams2, et2, awr2);
        }
    }

    @Override
    public int d(awr awr2) {
        return awr2.c(a).a();
    }

    @Override
    public void a(ahn ahn2, fi<ain> fi2) {
        for (ahq ahq2 : ahq.values()) {
            fi2.add(new ain(this, 1, ahq2.a()));
        }
    }

    @Override
    public bcy c(awr awr2, amw amw2, et et2) {
        return bcy.a(awr2.c(a));
    }

    @Override
    public awr a(int n2) {
        return this.t().a(a, ahq.b(n2));
    }

    @Override
    public int e(awr awr2) {
        return awr2.c(a).a();
    }

    @Override
    protected aws b() {
        return new aws((aou)this, a);
    }
}

