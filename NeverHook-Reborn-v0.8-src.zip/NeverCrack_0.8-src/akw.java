/*
 * Decompiled with CFR 0.150.
 */
public class akw {

    public static class a
    implements akr {
        @Override
        public boolean a(afw afw2, ams ams2) {
            ain ain2 = ain.a;
            \u2603 = ain.a;
            for (int i2 = 0; i2 < afw2.w_(); ++i2) {
                ain ain3 = afw2.a(i2);
                if (ain3.b()) continue;
                if (ain3.c() == aip.cP) {
                    if (!\u2603.b()) {
                        return false;
                    }
                    \u2603 = ain3;
                    continue;
                }
                if (ain3.c() == aip.cR) {
                    if (!ain2.b()) {
                        return false;
                    }
                    if (ain3.d("BlockEntityTag") != null) {
                        return false;
                    }
                    ain2 = ain3;
                    continue;
                }
                return false;
            }
            return !ain2.b() && !\u2603.b();
        }

        @Override
        public ain a(afw afw2) {
            ain \u26032;
            Object \u26033;
            ain ain2 = ain.a;
            \u26032 = ain.a;
            for (int i2 = 0; i2 < afw2.w_(); ++i2) {
                \u26033 = afw2.a(i2);
                if (((ain)\u26033).b()) continue;
                if (((ain)\u26033).c() == aip.cP) {
                    ain2 = \u26033;
                    continue;
                }
                if (((ain)\u26033).c() != aip.cR) continue;
                \u26032 = ((ain)\u26033).l();
            }
            if (\u26032.b()) {
                return \u26032;
            }
            fy fy2 = ain2.d("BlockEntityTag");
            \u26033 = fy2 == null ? new fy() : fy2.g();
            ((fy)\u26033).a("Base", ain2.j() & 0xF);
            \u26032.a("BlockEntityTag", (gn)\u26033);
            return \u26032;
        }

        @Override
        public ain b() {
            return ain.a;
        }

        @Override
        public fi<ain> b(afw afw2) {
            fi<ain> fi2 = fi.a(afw2.w_(), ain.a);
            for (int i2 = 0; i2 < fi2.size(); ++i2) {
                ain ain2 = afw2.a(i2);
                if (!ain2.c().r()) continue;
                fi2.set(i2, new ain(ain2.c().q()));
            }
            return fi2;
        }

        @Override
        public boolean c() {
            return true;
        }

        @Override
        public boolean a(int n2, int n3) {
            return n2 * n3 >= 2;
        }
    }
}

