/*
 * Decompiled with CFR 0.150.
 */
import java.nio.FloatBuffer;
import java.util.Random;
import optifine.Config;
import shadersmod.client.ShadersRender;

public class bxh
extends bww<awe> {
    private static final nd a = new nd("textures/environment/end_sky.png");
    private static final nd d = new nd("textures/entity/end_portal.png");
    private static final Random e = new Random(31100L);
    private static final FloatBuffer f = bhy.h(16);
    private static final FloatBuffer g = bhy.h(16);
    private final FloatBuffer h = bhy.h(16);

    @Override
    public void a(awe p_192841_1_, double p_192841_2_, double p_192841_4_, double p_192841_6_, float p_192841_8_, int p_192841_9_, float p_192841_10_) {
        if (!Config.isShaders() || !ShadersRender.renderEndPortal(p_192841_1_, p_192841_2_, p_192841_4_, p_192841_6_, p_192841_8_, p_192841_9_, this.c())) {
            buq.g();
            e.setSeed(31100L);
            buq.c(2982, f);
            buq.c(2983, g);
            double d0 = p_192841_2_ * p_192841_2_ + p_192841_4_ * p_192841_4_ + p_192841_6_ * p_192841_6_;
            int i2 = this.a(d0);
            float f2 = this.c();
            boolean flag = false;
            for (int j2 = 0; j2 < i2; ++j2) {
                buq.G();
                float f1 = 2.0f / (float)(18 - j2);
                if (j2 == 0) {
                    this.a(a);
                    f1 = 0.15f;
                    buq.m();
                    buq.a(buq.r.l, buq.l.j);
                }
                if (j2 >= 1) {
                    this.a(d);
                    flag = true;
                    bhz.z().o.d(true);
                }
                if (j2 == 1) {
                    buq.m();
                    buq.a(buq.r.e, buq.l.e);
                }
                buq.a(buq.u.a, 9216);
                buq.a(buq.u.b, 9216);
                buq.a(buq.u.c, 9216);
                buq.a(buq.u.a, 9474, this.a(1.0f, 0.0f, 0.0f, 0.0f));
                buq.a(buq.u.b, 9474, this.a(0.0f, 1.0f, 0.0f, 0.0f));
                buq.a(buq.u.c, 9474, this.a(0.0f, 0.0f, 1.0f, 0.0f));
                buq.a(buq.u.a);
                buq.a(buq.u.b);
                buq.a(buq.u.c);
                buq.H();
                buq.n(5890);
                buq.G();
                buq.F();
                buq.c(0.5f, 0.5f, 0.0f);
                buq.b(0.5f, 0.5f, 1.0f);
                float f22 = j2 + 1;
                buq.c(17.0f / f22, (2.0f + f22 / 1.5f) * ((float)bhz.I() % 800000.0f / 800000.0f), 0.0f);
                buq.b((f22 * f22 * 4321.0f + f22 * 9.0f) * 2.0f, 0.0f, 0.0f, 1.0f);
                buq.b(4.5f - f22 / 4.0f, 4.5f - f22 / 4.0f, 1.0f);
                buq.a(g);
                buq.a(f);
                bvc tessellator = bvc.a();
                bui bufferbuilder = tessellator.c();
                bufferbuilder.a(7, cdw.f);
                float f3 = (e.nextFloat() * 0.5f + 0.1f) * f1;
                float f4 = (e.nextFloat() * 0.5f + 0.4f) * f1;
                float f5 = (e.nextFloat() * 0.5f + 0.5f) * f1;
                if (p_192841_1_.a(fa.d)) {
                    bufferbuilder.b(p_192841_2_, p_192841_4_, p_192841_6_ + 1.0).a(f3, f4, f5, 1.0f).d();
                    bufferbuilder.b(p_192841_2_ + 1.0, p_192841_4_, p_192841_6_ + 1.0).a(f3, f4, f5, 1.0f).d();
                    bufferbuilder.b(p_192841_2_ + 1.0, p_192841_4_ + 1.0, p_192841_6_ + 1.0).a(f3, f4, f5, 1.0f).d();
                    bufferbuilder.b(p_192841_2_, p_192841_4_ + 1.0, p_192841_6_ + 1.0).a(f3, f4, f5, 1.0f).d();
                }
                if (p_192841_1_.a(fa.c)) {
                    bufferbuilder.b(p_192841_2_, p_192841_4_ + 1.0, p_192841_6_).a(f3, f4, f5, 1.0f).d();
                    bufferbuilder.b(p_192841_2_ + 1.0, p_192841_4_ + 1.0, p_192841_6_).a(f3, f4, f5, 1.0f).d();
                    bufferbuilder.b(p_192841_2_ + 1.0, p_192841_4_, p_192841_6_).a(f3, f4, f5, 1.0f).d();
                    bufferbuilder.b(p_192841_2_, p_192841_4_, p_192841_6_).a(f3, f4, f5, 1.0f).d();
                }
                if (p_192841_1_.a(fa.f)) {
                    bufferbuilder.b(p_192841_2_ + 1.0, p_192841_4_ + 1.0, p_192841_6_).a(f3, f4, f5, 1.0f).d();
                    bufferbuilder.b(p_192841_2_ + 1.0, p_192841_4_ + 1.0, p_192841_6_ + 1.0).a(f3, f4, f5, 1.0f).d();
                    bufferbuilder.b(p_192841_2_ + 1.0, p_192841_4_, p_192841_6_ + 1.0).a(f3, f4, f5, 1.0f).d();
                    bufferbuilder.b(p_192841_2_ + 1.0, p_192841_4_, p_192841_6_).a(f3, f4, f5, 1.0f).d();
                }
                if (p_192841_1_.a(fa.e)) {
                    bufferbuilder.b(p_192841_2_, p_192841_4_, p_192841_6_).a(f3, f4, f5, 1.0f).d();
                    bufferbuilder.b(p_192841_2_, p_192841_4_, p_192841_6_ + 1.0).a(f3, f4, f5, 1.0f).d();
                    bufferbuilder.b(p_192841_2_, p_192841_4_ + 1.0, p_192841_6_ + 1.0).a(f3, f4, f5, 1.0f).d();
                    bufferbuilder.b(p_192841_2_, p_192841_4_ + 1.0, p_192841_6_).a(f3, f4, f5, 1.0f).d();
                }
                if (p_192841_1_.a(fa.a)) {
                    bufferbuilder.b(p_192841_2_, p_192841_4_, p_192841_6_).a(f3, f4, f5, 1.0f).d();
                    bufferbuilder.b(p_192841_2_ + 1.0, p_192841_4_, p_192841_6_).a(f3, f4, f5, 1.0f).d();
                    bufferbuilder.b(p_192841_2_ + 1.0, p_192841_4_, p_192841_6_ + 1.0).a(f3, f4, f5, 1.0f).d();
                    bufferbuilder.b(p_192841_2_, p_192841_4_, p_192841_6_ + 1.0).a(f3, f4, f5, 1.0f).d();
                }
                if (p_192841_1_.a(fa.b)) {
                    bufferbuilder.b(p_192841_2_, p_192841_4_ + (double)f2, p_192841_6_ + 1.0).a(f3, f4, f5, 1.0f).d();
                    bufferbuilder.b(p_192841_2_ + 1.0, p_192841_4_ + (double)f2, p_192841_6_ + 1.0).a(f3, f4, f5, 1.0f).d();
                    bufferbuilder.b(p_192841_2_ + 1.0, p_192841_4_ + (double)f2, p_192841_6_).a(f3, f4, f5, 1.0f).d();
                    bufferbuilder.b(p_192841_2_, p_192841_4_ + (double)f2, p_192841_6_).a(f3, f4, f5, 1.0f).d();
                }
                tessellator.b();
                buq.H();
                buq.n(5888);
                this.a(a);
            }
            buq.l();
            buq.b(buq.u.a);
            buq.b(buq.u.b);
            buq.b(buq.u.c);
            buq.f();
            if (flag) {
                bhz.z().o.d(false);
            }
        }
    }

    protected int a(double p_191286_1_) {
        int i2 = p_191286_1_ > 36864.0 ? 1 : (p_191286_1_ > 25600.0 ? 3 : (p_191286_1_ > 16384.0 ? 5 : (p_191286_1_ > 9216.0 ? 7 : (p_191286_1_ > 4096.0 ? 9 : (p_191286_1_ > 1024.0 ? 11 : (p_191286_1_ > 576.0 ? 13 : (p_191286_1_ > 256.0 ? 14 : 15)))))));
        return i2;
    }

    protected float c() {
        return 0.75f;
    }

    private FloatBuffer a(float p_147525_1_, float p_147525_2_, float p_147525_3_, float p_147525_4_) {
        this.h.clear();
        this.h.put(p_147525_1_).put(p_147525_2_).put(p_147525_3_).put(p_147525_4_);
        this.h.flip();
        return this.h;
    }
}

