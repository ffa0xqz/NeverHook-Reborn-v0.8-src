/*
 * Decompiled with CFR 0.150.
 */
import java.util.List;

public class hi {
    public static hh a(bn bn2, hh hh22, ve ve22) throws ei {
        Object object;
        he \u26033;
        if (hh22 instanceof hl) {
            hl \u26035 = (hl)hh22;
            String \u26032 = \u26035.g();
            if (bq.b(\u26032)) {
                List<ve> list = bq.b(bn2, \u26032, ve.class);
                if (list.size() != 1) {
                    throw new ej("commands.generic.selector.notFound", \u26032);
                }
                ve ve3 = list.get(0);
                \u26032 = ve3 instanceof aeb ? ve3.h_() : ve3.bn();
            }
            String string = ve22 != null && \u26032.equals("*") ? ve22.h_() : \u26032;
            \u26033 = new hl(string, \u26035.h());
            ((hl)\u26033).b(\u26035.e());
            ((hl)\u26033).a(bn2);
        } else if (hh22 instanceof hm) {
            object = ((hm)hh22).g();
            hh \u26034 = bq.c(bn2, (String)object);
            if (\u26034 == null) {
                \u26034 = new ho("");
            }
        } else if (hh22 instanceof ho) {
            \u26033 = new ho(((ho)hh22).g());
        } else if (hh22 instanceof hk) {
            \u26033 = new hk(((hk)hh22).h());
        } else if (hh22 instanceof hp) {
            object = ((hp)hh22).j();
            for (int i2 = 0; i2 < ((Object[])object).length; ++i2) {
                Object object2 = object[i2];
                if (!(object2 instanceof hh)) continue;
                object[i2] = hi.a(bn2, (hh)object2, ve22);
            }
            \u26033 = new hp(((hp)hh22).i(), (Object[])object);
        } else {
            return hh22;
        }
        object = hh22.b();
        if (object != null) {
            \u26033.a(((hn)object).m());
        }
        for (hh hh2 : hh22.a()) {
            \u26033.a(hi.a(bn2, hh2, ve22));
        }
        return \u26033;
    }
}

