/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import javax.annotation.Nullable;

public class wh
extends wd {
    private final double a;
    private final double b;
    private String c;

    public wh(@Nullable wa wa2, String string, double d2, double d3, double d4) {
        super(wa2, string, d2);
        this.a = d3;
        this.b = d4;
        if (d3 > d4) {
            throw new IllegalArgumentException("Minimum value cannot be bigger than maximum value!");
        }
        if (d2 < d3) {
            throw new IllegalArgumentException("Default value cannot be lower than minimum value!");
        }
        if (d2 > d4) {
            throw new IllegalArgumentException("Default value cannot be bigger than maximum value!");
        }
    }

    public wh a(String string) {
        this.c = string;
        return this;
    }

    public String g() {
        return this.c;
    }

    @Override
    public double a(double d2) {
        d2 = ri.a(d2, this.a, this.b);
        return d2;
    }
}

