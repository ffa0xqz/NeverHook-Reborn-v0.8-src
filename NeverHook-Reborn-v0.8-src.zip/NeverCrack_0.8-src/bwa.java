/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonDeserializationContext
 *  com.google.gson.JsonDeserializer
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParseException
 */
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.lang.reflect.Type;
import org.lwjgl.util.vector.Quaternion;

public class bwa {
    public static final bwa a = new bwa();
    public static float b;
    public static float c;
    public static float d;
    public static float e;
    public static float f;
    public static float g;
    public static float h;
    public static float i;
    public static float j;
    public final bvz k;
    public final bvz l;
    public final bvz m;
    public final bvz n;
    public final bvz o;
    public final bvz p;
    public final bvz q;
    public final bvz r;

    private bwa() {
        this(bvz.a, bvz.a, bvz.a, bvz.a, bvz.a, bvz.a, bvz.a, bvz.a);
    }

    public bwa(bwa bwa2) {
        this.k = bwa2.k;
        this.l = bwa2.l;
        this.m = bwa2.m;
        this.n = bwa2.n;
        this.o = bwa2.o;
        this.p = bwa2.p;
        this.q = bwa2.q;
        this.r = bwa2.r;
    }

    public bwa(bvz bvz2, bvz bvz3, bvz bvz4, bvz bvz5, bvz bvz6, bvz bvz7, bvz bvz8, bvz bvz9) {
        this.k = bvz2;
        this.l = bvz3;
        this.m = bvz4;
        this.n = bvz5;
        this.o = bvz6;
        this.p = bvz7;
        this.q = bvz8;
        this.r = bvz9;
    }

    public void a(b b2) {
        bwa.a(this.b(b2), false);
    }

    public static void a(bvz bvz2, boolean bl2) {
        if (bvz2 == bvz.a) {
            return;
        }
        int n2 = bl2 ? -1 : 1;
        buq.c((float)n2 * (b + bvz2.c.x), c + bvz2.c.y, d + bvz2.c.z);
        float \u26032 = e + bvz2.b.x;
        float \u26033 = f + bvz2.b.y;
        float \u26034 = g + bvz2.b.z;
        if (bl2) {
            \u26033 = -\u26033;
            \u26034 = -\u26034;
        }
        buq.a(bwa.a(\u26032, \u26033, \u26034));
        buq.b(h + bvz2.d.x, i + bvz2.d.y, j + bvz2.d.z);
    }

    private static Quaternion a(float f2, float f3, float f4) {
        \u2603 = f2 * ((float)Math.PI / 180);
        \u2603 = f3 * ((float)Math.PI / 180);
        \u2603 = f4 * ((float)Math.PI / 180);
        \u2603 = ri.a(0.5f * \u2603);
        \u2603 = ri.b(0.5f * \u2603);
        \u2603 = ri.a(0.5f * \u2603);
        \u2603 = ri.b(0.5f * \u2603);
        \u2603 = ri.a(0.5f * \u2603);
        \u2603 = ri.b(0.5f * \u2603);
        return new Quaternion(\u2603 * \u2603 * \u2603 + \u2603 * \u2603 * \u2603, \u2603 * \u2603 * \u2603 - \u2603 * \u2603 * \u2603, \u2603 * \u2603 * \u2603 + \u2603 * \u2603 * \u2603, \u2603 * \u2603 * \u2603 - \u2603 * \u2603 * \u2603);
    }

    public bvz b(b b2) {
        switch (b2) {
            case b: {
                return this.k;
            }
            case c: {
                return this.l;
            }
            case d: {
                return this.m;
            }
            case e: {
                return this.n;
            }
            case f: {
                return this.o;
            }
            case g: {
                return this.p;
            }
            case h: {
                return this.q;
            }
            case i: {
                return this.r;
            }
        }
        return bvz.a;
    }

    public boolean c(b b2) {
        return this.b(b2) != bvz.a;
    }

    static class a
    implements JsonDeserializer<bwa> {
        a() {
        }

        public bwa a(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            JsonObject jsonObject = jsonElement.getAsJsonObject();
            bvz \u26032 = this.a(jsonDeserializationContext, jsonObject, "thirdperson_righthand");
            bvz \u26033 = this.a(jsonDeserializationContext, jsonObject, "thirdperson_lefthand");
            if (\u26033 == bvz.a) {
                \u26033 = \u26032;
            }
            bvz \u26034 = this.a(jsonDeserializationContext, jsonObject, "firstperson_righthand");
            bvz \u26035 = this.a(jsonDeserializationContext, jsonObject, "firstperson_lefthand");
            if (\u26035 == bvz.a) {
                \u26035 = \u26034;
            }
            bvz \u26036 = this.a(jsonDeserializationContext, jsonObject, "head");
            bvz \u26037 = this.a(jsonDeserializationContext, jsonObject, "gui");
            bvz \u26038 = this.a(jsonDeserializationContext, jsonObject, "ground");
            bvz \u26039 = this.a(jsonDeserializationContext, jsonObject, "fixed");
            return new bwa(\u26033, \u26032, \u26035, \u26034, \u26036, \u26037, \u26038, \u26039);
        }

        private bvz a(JsonDeserializationContext jsonDeserializationContext, JsonObject jsonObject, String string) {
            if (jsonObject.has(string)) {
                return (bvz)jsonDeserializationContext.deserialize(jsonObject.get(string), bvz.class);
            }
            return bvz.a;
        }

        public /* synthetic */ Object deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            return this.a(jsonElement, type, jsonDeserializationContext);
        }
    }

    public static enum b {
        a,
        b,
        c,
        d,
        e,
        f,
        g,
        h,
        i;

    }
}

