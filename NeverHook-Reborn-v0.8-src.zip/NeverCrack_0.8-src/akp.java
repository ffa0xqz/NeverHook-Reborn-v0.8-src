/*
 * Decompiled with CFR 0.150.
 */
public class akp
implements akr {
    @Override
    public boolean a(afw afw2, ams ams2) {
        int n2 = 0;
        ain \u26032 = ain.a;
        for (\u2603 = 0; \u2603 < afw2.w_(); ++\u2603) {
            ain ain2 = afw2.a(\u2603);
            if (ain2.b()) continue;
            if (ain2.c() == aip.bl) {
                if (!\u26032.b()) {
                    return false;
                }
                \u26032 = ain2;
                continue;
            }
            if (ain2.c() == aip.cg) {
                ++n2;
                continue;
            }
            return false;
        }
        return !\u26032.b() && n2 > 0;
    }

    @Override
    public ain a(afw afw2) {
        int n2 = 0;
        ain \u26032 = ain.a;
        for (\u2603 = 0; \u2603 < afw2.w_(); ++\u2603) {
            ain ain2 = afw2.a(\u2603);
            if (ain2.b()) continue;
            if (ain2.c() == aip.bl) {
                if (!\u26032.b()) {
                    return ain.a;
                }
                \u26032 = ain2;
                continue;
            }
            if (ain2.c() == aip.cg) {
                ++n2;
                continue;
            }
            return ain.a;
        }
        if (\u26032.b() || n2 < 1) {
            return ain.a;
        }
        ain \u26033 = new ain(aip.bl, n2 + 1, \u26032.j());
        if (\u26032.t()) {
            \u26033.g(\u26032.r());
        }
        if (\u26032.o()) {
            \u26033.b(\u26032.p());
        }
        return \u26033;
    }

    @Override
    public ain b() {
        return ain.a;
    }

    @Override
    public fi<ain> b(afw afw2) {
        fi<ain> fi2 = fi.a(afw2.w_(), ain.a);
        for (int i2 = 0; i2 < fi2.size(); ++i2) {
            ain ain2 = afw2.a(i2);
            if (!ain2.c().r()) continue;
            fi2.set(i2, new ain(ain2.c().q()));
        }
        return fi2;
    }

    @Override
    public boolean c() {
        return true;
    }

    @Override
    public boolean a(int n2, int n3) {
        return n2 >= 3 && n3 >= 3;
    }
}

