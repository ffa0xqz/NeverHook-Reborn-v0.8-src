/*
 * Decompiled with CFR 0.150.
 */
public class brg
extends bre {
    public boolean g;
    private final brq h = new brq(this).b(64, 128);
    private final brq i;

    public brg(float f2) {
        super(f2, 0.0f, 64, 128);
        this.h.a(0.0f, -2.0f, 0.0f);
        this.h.a(0, 0).a(0.0f, 3.0f, -6.75f, 1, 1, 1, -0.25f);
        this.f.a(this.h);
        this.i = new brq(this).b(64, 128);
        this.i.a(-5.0f, -10.03125f, -5.0f);
        this.i.a(0, 64).a(0.0f, 0.0f, 0.0f, 10, 2, 10);
        this.a.a(this.i);
        brq brq2 = new brq(this).b(64, 128);
        brq2.a(1.75f, -4.0f, 2.0f);
        brq2.a(0, 76).a(0.0f, 0.0f, 0.0f, 7, 4, 7);
        brq2.f = -0.05235988f;
        brq2.h = 0.02617994f;
        this.i.a(brq2);
        \u2603 = new brq(this).b(64, 128);
        \u2603.a(1.75f, -4.0f, 2.0f);
        \u2603.a(0, 87).a(0.0f, 0.0f, 0.0f, 4, 4, 4);
        \u2603.f = -0.10471976f;
        \u2603.h = 0.05235988f;
        brq2.a(\u2603);
        \u2603 = new brq(this).b(64, 128);
        \u2603.a(1.75f, -2.0f, 2.0f);
        \u2603.a(0, 95).a(0.0f, 0.0f, 0.0f, 1, 2, 1, 0.25f);
        \u2603.f = -0.20943952f;
        \u2603.h = 0.10471976f;
        \u2603.a(\u2603);
    }

    @Override
    public void a(float f2, float f3, float f4, float f5, float f6, float f7, ve ve2) {
        super.a(f2, f3, f4, f5, f6, f7, ve2);
        this.f.o = 0.0f;
        this.f.p = 0.0f;
        this.f.q = 0.0f;
        float f8 = 0.01f * (float)(ve2.S() % 10);
        this.f.f = ri.a((float)ve2.T * f8) * 4.5f * ((float)Math.PI / 180);
        this.f.g = 0.0f;
        this.f.h = ri.b((float)ve2.T * f8) * 2.5f * ((float)Math.PI / 180);
        if (this.g) {
            this.f.f = -0.9f;
            this.f.q = -0.09375f;
            this.f.p = 0.1875f;
        }
    }
}

