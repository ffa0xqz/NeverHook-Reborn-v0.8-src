/*
 * Decompiled with CFR 0.150.
 */
import java.io.IOException;

public class lm
implements ht<kw> {
    private boolean a;
    private boolean b;

    public lm() {
    }

    public lm(boolean bl2, boolean bl3) {
        this.a = bl2;
        this.b = bl3;
    }

    @Override
    public void a(gy gy2) throws IOException {
        this.a = gy2.readBoolean();
        this.b = gy2.readBoolean();
    }

    @Override
    public void b(gy gy2) throws IOException {
        gy2.writeBoolean(this.a);
        gy2.writeBoolean(this.b);
    }

    @Override
    public void a(kw kw2) {
        kw2.a(this);
    }

    public boolean a() {
        return this.a;
    }

    public boolean b() {
        return this.b;
    }
}

