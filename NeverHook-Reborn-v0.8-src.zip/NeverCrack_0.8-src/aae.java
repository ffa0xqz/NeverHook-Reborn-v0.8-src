/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 *  javax.annotation.Nullable
 */
import com.google.common.collect.Maps;
import java.util.Map;
import java.util.Random;
import javax.annotation.Nullable;

public class aae
extends zt {
    private static final mx<Byte> bx = na.a(aae.class, mz.a);
    private final afw by = new afw(new afp(){

        @Override
        public boolean a(aeb aeb2) {
            return false;
        }
    }, 2, 1);
    private static final Map<ahq, float[]> bz = Maps.newEnumMap(ahq.class);
    private int bB;
    private wv bC;

    private static float[] c(ahq ahq2) {
        float[] arrf = ahq2.f();
        float \u26032 = 0.75f;
        return new float[]{arrf[0] * 0.75f, arrf[1] * 0.75f, arrf[2] * 0.75f};
    }

    public static float[] a(ahq ahq2) {
        return bz.get(ahq2);
    }

    public aae(ams ams2) {
        super(ams2);
        this.a(0.9f, 1.3f);
        this.by.a(0, new ain(aip.be));
        this.by.a(1, new ain(aip.be));
    }

    @Override
    protected void r() {
        this.bC = new wv(this);
        this.br.a(0, new wx(this));
        this.br.a(1, new xw(this, 1.25));
        this.br.a(2, new wt(this, 1.0));
        this.br.a(3, new yj((vv)this, 1.1, aip.R, false));
        this.br.a(4, new xb(this, 1.1));
        this.br.a(5, this.bC);
        this.br.a(6, new yn(this, 1.0));
        this.br.a(7, new xj(this, aeb.class, 6.0f));
        this.br.a(8, new xz(this));
    }

    @Override
    protected void M() {
        this.bB = this.bC.f();
        super.M();
    }

    @Override
    public void n() {
        if (this.l.G) {
            this.bB = Math.max(0, this.bB - 1);
        }
        super.n();
    }

    @Override
    protected void bM() {
        super.bM();
        this.a(adf.a).a(8.0);
        this.a(adf.d).a(0.23f);
    }

    @Override
    protected void i() {
        super.i();
        this.Y.a(bx, (byte)0);
    }

    @Override
    @Nullable
    protected nd J() {
        if (this.dm()) {
            return bfl.P;
        }
        switch (this.dl()) {
            default: {
                return bfl.Q;
            }
            case b: {
                return bfl.R;
            }
            case c: {
                return bfl.S;
            }
            case d: {
                return bfl.T;
            }
            case e: {
                return bfl.U;
            }
            case f: {
                return bfl.V;
            }
            case g: {
                return bfl.W;
            }
            case h: {
                return bfl.X;
            }
            case i: {
                return bfl.Y;
            }
            case j: {
                return bfl.Z;
            }
            case k: {
                return bfl.aa;
            }
            case l: {
                return bfl.ab;
            }
            case m: {
                return bfl.ac;
            }
            case n: {
                return bfl.ad;
            }
            case o: {
                return bfl.ae;
            }
            case p: 
        }
        return bfl.af;
    }

    @Override
    public void a(byte by2) {
        if (by2 == 10) {
            this.bB = 40;
        } else {
            super.a(by2);
        }
    }

    public float r(float f2) {
        if (this.bB <= 0) {
            return 0.0f;
        }
        if (this.bB >= 4 && this.bB <= 36) {
            return 1.0f;
        }
        if (this.bB < 4) {
            return ((float)this.bB - f2) / 4.0f;
        }
        return -((float)(this.bB - 40) - f2) / 4.0f;
    }

    public float s(float f2) {
        if (this.bB > 4 && this.bB <= 36) {
            \u2603 = ((float)(this.bB - 4) - f2) / 32.0f;
            return 0.62831855f + 0.21991149f * ri.a(\u2603 * 28.7f);
        }
        if (this.bB > 0) {
            return 0.62831855f;
        }
        return this.w * ((float)Math.PI / 180);
    }

    @Override
    public boolean a(aeb aeb22, tz tz2) {
        aeb aeb22;
        ain ain2 = aeb22.b(tz2);
        if (ain2.c() == aip.bm && !this.dm() && !this.l_()) {
            if (!this.l.G) {
                this.p(true);
                int n2 = 1 + this.S.nextInt(3);
                for (\u2603 = 0; \u2603 < n2; ++\u2603) {
                    acj acj2 = this.a(new ain(ail.a(aov.L), 1, this.dl().a()), 1.0f);
                    acj2.t += (double)(this.S.nextFloat() * 0.05f);
                    acj2.s += (double)((this.S.nextFloat() - this.S.nextFloat()) * 0.1f);
                    acj2.u += (double)((this.S.nextFloat() - this.S.nextFloat()) * 0.1f);
                }
            }
            ain2.a(1, (vn)aeb22);
            this.a(qd.gv, 1.0f, 1.0f);
        }
        return super.a(aeb22, tz2);
    }

    public static void a(rw rw2) {
        vo.a(rw2, aae.class);
    }

    @Override
    public void b(fy fy2) {
        super.b(fy2);
        fy2.a("Sheared", this.dm());
        fy2.a("Color", (byte)this.dl().a());
    }

    @Override
    public void a(fy fy2) {
        super.a(fy2);
        this.p(fy2.q("Sheared"));
        this.b(ahq.b(fy2.f("Color")));
    }

    @Override
    protected qc F() {
        return qd.gs;
    }

    @Override
    protected qc d(up up2) {
        return qd.gu;
    }

    @Override
    protected qc cf() {
        return qd.gt;
    }

    @Override
    protected void a(et et2, aou aou2) {
        this.a(qd.gw, 0.15f, 1.0f);
    }

    public ahq dl() {
        return ahq.b(this.Y.a(bx) & 0xF);
    }

    public void b(ahq ahq2) {
        byte by2 = this.Y.a(bx);
        this.Y.b(bx, (byte)(by2 & 0xF0 | ahq2.a() & 0xF));
    }

    public boolean dm() {
        return (this.Y.a(bx) & 0x10) != 0;
    }

    public void p(boolean bl2) {
        byte by2 = this.Y.a(bx);
        if (bl2) {
            this.Y.b(bx, (byte)(by2 | 0x10));
        } else {
            this.Y.b(bx, (byte)(by2 & 0xFFFFFFEF));
        }
    }

    public static ahq a(Random random) {
        int n2 = random.nextInt(100);
        if (n2 < 5) {
            return ahq.p;
        }
        if (n2 < 10) {
            return ahq.h;
        }
        if (n2 < 15) {
            return ahq.i;
        }
        if (n2 < 18) {
            return ahq.m;
        }
        if (random.nextInt(500) == 0) {
            return ahq.g;
        }
        return ahq.a;
    }

    public aae b(vb vb2) {
        aae aae2 = (aae)vb2;
        \u2603 = new aae(this.l);
        \u2603.b(this.a(this, aae2));
        return \u2603;
    }

    @Override
    public void A() {
        this.p(false);
        if (this.l_()) {
            this.a(60);
        }
    }

    @Override
    @Nullable
    public vq a(ty ty2, @Nullable vq vq2) {
        vq2 = super.a(ty2, vq2);
        this.b(aae.a(this.l.r));
        return vq2;
    }

    private ahq a(zt zt2, zt zt3) {
        int n2 = ((aae)zt2).dl().b();
        \u2603 = ((aae)zt3).dl().b();
        this.by.a(0).b(n2);
        this.by.a(1).b(\u2603);
        ain \u26032 = aks.a(this.by, ((aae)zt2).l);
        \u2603 = \u26032.c() == aip.be ? \u26032.j() : (this.l.r.nextBoolean() ? n2 : \u2603);
        return ahq.a(\u2603);
    }

    @Override
    public float by() {
        return 0.95f * this.H;
    }

    @Override
    public /* synthetic */ vb a(vb vb2) {
        return this.b(vb2);
    }

    static {
        for (ahq ahq2 : ahq.values()) {
            bz.put(ahq2, aae.c(ahq2));
        }
        bz.put(ahq.a, new float[]{0.9019608f, 0.9019608f, 0.9019608f});
    }
}

