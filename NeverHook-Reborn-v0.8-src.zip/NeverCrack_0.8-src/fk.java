/*
 * Decompiled with CFR 0.150.
 */
public interface fk {
    public double a();

    public double b();

    public double c();
}

