/*
 * Decompiled with CFR 0.150.
 */
import java.util.List;

public class yr
extends yy {
    private final boolean a;
    private int b;
    private final Class<?>[] c;

    public yr(vv vv2, boolean bl2, Class<?> ... arrclass) {
        super(vv2, true);
        this.a = bl2;
        this.c = arrclass;
        this.a(1);
    }

    @Override
    public boolean a() {
        int n2 = this.e.bT();
        vn \u26032 = this.e.bS();
        return n2 != this.b && \u26032 != null && this.a(\u26032, false);
    }

    @Override
    public void c() {
        this.e.d(this.e.bS());
        this.g = this.e.z();
        this.b = this.e.bT();
        this.h = 300;
        if (this.a) {
            this.f();
        }
        super.c();
    }

    protected void f() {
        double d2 = this.i();
        List<?> \u26032 = this.e.l.a(this.e.getClass(), new bgz(this.e.p, this.e.q, this.e.r, this.e.p + 1.0, this.e.q + 1.0, this.e.r + 1.0).c(d2, 10.0, d2));
        for (vv vv2 : \u26032) {
            if (this.e == vv2 || vv2.z() != null || this.e instanceof vz && ((vz)this.e).do() != ((vz)vv2).do() || vv2.r(this.e.bS())) continue;
            boolean bl2 = false;
            for (Class<?> class_ : this.c) {
                if (vv2.getClass() != class_) continue;
                bl2 = true;
                break;
            }
            if (bl2) continue;
            this.a(vv2, this.e.bS());
        }
    }

    protected void a(vv vv2, vn vn2) {
        vv2.d(vn2);
    }
}

