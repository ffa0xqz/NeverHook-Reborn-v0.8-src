/*
 * Decompiled with CFR 0.150.
 */
public class ass
extends aou {
    public ass(bcx bcx2, bcy bcy2) {
        super(bcx2, bcy2);
    }

    @Override
    public boolean g(awr awr2) {
        return true;
    }

    @Override
    public int b(awr awr2, amw amw2, et et2, fa fa2) {
        return 15;
    }
}

