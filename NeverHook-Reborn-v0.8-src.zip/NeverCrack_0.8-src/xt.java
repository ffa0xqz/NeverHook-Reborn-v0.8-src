/*
 * Decompiled with CFR 0.150.
 */
public class xt
extends xp {
    private final zz c;

    public xt(zz zz2, double d2) {
        super(zz2, d2, 8);
        this.c = zz2;
    }

    @Override
    public boolean a() {
        return this.c.dl() && !this.c.dn() && super.a();
    }

    @Override
    public void c() {
        super.c();
        this.c.dp().a(false);
    }

    @Override
    public void d() {
        super.d();
        this.c.r(false);
    }

    @Override
    public void e() {
        super.e();
        this.c.dp().a(false);
        if (!this.f()) {
            this.c.r(false);
        } else if (!this.c.dn()) {
            this.c.r(true);
        }
    }

    @Override
    protected boolean a(ams ams2, et et2) {
        if (!ams2.d(et2.a())) {
            return false;
        }
        awr awr2 = ams2.o(et2);
        aou \u26032 = awr2.u();
        if (\u26032 == aov.ae) {
            avh avh2 = ams2.r(et2);
            if (avh2 instanceof avj && ((avj)avh2).l < 1) {
                return true;
            }
        } else {
            if (\u26032 == aov.am) {
                return true;
            }
            if (\u26032 == aov.C && awr2.c(aos.a) != aos.a.a) {
                return true;
            }
        }
        return false;
    }
}

