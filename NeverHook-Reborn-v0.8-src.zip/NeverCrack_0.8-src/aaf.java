/*
 * Decompiled with CFR 0.150.
 */
public abstract class aaf
extends vz {
    private int bB;

    public aaf(ams ams2) {
        super(ams2);
    }

    public boolean g(aeb aeb2) {
        fy fy2 = new fy();
        fy2.a("id", this.aB());
        this.e(fy2);
        if (aeb2.g(fy2)) {
            this.l.e(this);
            return true;
        }
        return false;
    }

    @Override
    public void B_() {
        ++this.bB;
        super.B_();
    }

    public boolean dw() {
        return this.bB > 100;
    }
}

