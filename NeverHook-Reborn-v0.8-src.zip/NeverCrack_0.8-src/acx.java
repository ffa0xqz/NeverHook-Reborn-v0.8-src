/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import javax.annotation.Nullable;

public class acx
extends adc {
    public acx(ams ams2) {
        super(ams2);
        this.a(this.G * 6.0f, this.H * 6.0f);
    }

    public static void a(rw rw2) {
        vo.a(rw2, acx.class);
    }

    @Override
    public float by() {
        return 10.440001f;
    }

    @Override
    protected void bM() {
        super.bM();
        this.a(adf.a).a(100.0);
        this.a(adf.d).a(0.5);
        this.a(adf.f).a(50.0);
    }

    @Override
    public float a(et et2) {
        return this.l.n(et2) - 0.5f;
    }

    @Override
    @Nullable
    protected nd J() {
        return bfl.u;
    }
}

