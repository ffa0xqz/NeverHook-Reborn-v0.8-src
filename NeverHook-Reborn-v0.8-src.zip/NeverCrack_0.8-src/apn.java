/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 *  javax.annotation.Nullable
 */
import com.google.common.base.Predicate;
import java.util.Random;
import javax.annotation.Nullable;

public class apn
extends apu
implements aqj {
    public static final axd a = axd.a("powered");
    public static final axf<a> b = axf.a("mode", a.class);

    public apn(boolean bl2) {
        super(bl2);
        this.w(this.A.b().a(D, fa.c).a(a, false).a(b, apn$a.a));
        this.u = true;
    }

    @Override
    public String c() {
        return ft.a("item.comparator.name");
    }

    @Override
    public ail a(awr awr2, Random random, int n2) {
        return aip.cp;
    }

    @Override
    public ain a(ams ams2, et et2, awr awr2) {
        return new ain(aip.cp);
    }

    @Override
    protected int x(awr awr2) {
        return 2;
    }

    @Override
    protected awr y(awr awr2) {
        Boolean bl2 = awr2.c(a);
        a \u26032 = awr2.c(b);
        fa \u26033 = awr2.c(D);
        return aov.ck.t().a(D, \u26033).a(a, bl2).a(b, \u26032);
    }

    @Override
    protected awr z(awr awr2) {
        Boolean bl2 = awr2.c(a);
        a \u26032 = awr2.c(b);
        fa \u26033 = awr2.c(D);
        return aov.cj.t().a(D, \u26033).a(a, bl2).a(b, \u26032);
    }

    @Override
    protected boolean A(awr awr2) {
        return this.d || awr2.c(a) != false;
    }

    @Override
    protected int a(amw amw2, et et2, awr awr2) {
        avh avh2 = amw2.r(et2);
        if (avh2 instanceof avl) {
            return ((avl)avh2).a();
        }
        return 0;
    }

    private int j(ams ams2, et et2, awr awr2) {
        if (awr2.c(b) == apn$a.b) {
            return Math.max(this.f(ams2, et2, awr2) - this.c((amw)ams2, et2, awr2), 0);
        }
        return this.f(ams2, et2, awr2);
    }

    @Override
    protected boolean e(ams ams2, et et2, awr awr2) {
        int n2 = this.f(ams2, et2, awr2);
        if (n2 >= 15) {
            return true;
        }
        if (n2 == 0) {
            return false;
        }
        \u2603 = this.c((amw)ams2, et2, awr2);
        if (\u2603 == 0) {
            return true;
        }
        return n2 >= \u2603;
    }

    @Override
    protected int f(ams ams2, et et2, awr awr2) {
        int n2 = super.f(ams2, et2, awr2);
        fa \u26032 = awr2.c(D);
        et \u26033 = et2.a(\u26032);
        awr \u26034 = ams2.o(\u26033);
        if (\u26034.n()) {
            n2 = \u26034.a(ams2, \u26033);
        } else if (n2 < 15 && \u26034.l()) {
            \u26034 = ams2.o(\u26033 = \u26033.a(\u26032));
            if (\u26034.n()) {
                n2 = \u26034.a(ams2, \u26033);
            } else if (\u26034.a() == bcx.a && (\u2603 = this.a(ams2, \u26032, \u26033)) != null) {
                n2 = \u2603.t();
            }
        }
        return n2;
    }

    @Nullable
    private abz a(ams ams2, final fa fa2, et et2) {
        1 \u2603 = ams2.a(abz.class, new bgz(et2.p(), et2.q(), et2.r(), et2.p() + 1, et2.q() + 1, et2.r() + 1), new Predicate<ve>(){

            public boolean a(@Nullable ve ve2) {
                return ve2 != null && ve2.bt() == fa2;
            }

            public /* synthetic */ boolean apply(@Nullable Object object) {
                return this.a((ve)object);
            }
        });
        if (\u2603.size() == 1) {
            return (abz)\u2603.get(0);
        }
        return null;
    }

    @Override
    public boolean a(ams ams2, et et2, awr awr2, aeb aeb2, tz tz2, fa fa2, float f2, float f3, float f4) {
        if (!aeb2.bO.e) {
            return false;
        }
        \u2603 = (awr2 = awr2.a(b)).c(b) == apn$a.b ? 0.55f : 0.5f;
        ams2.a(aeb2, et2, qd.aq, qe.e, 0.3f, \u2603);
        ams2.a(et2, awr2, 2);
        this.k(ams2, et2, awr2);
        return true;
    }

    @Override
    protected void g(ams ams2, et et2, awr awr2) {
        if (ams2.a(et2, this)) {
            return;
        }
        int n2 = this.j(ams2, et2, awr2);
        avh \u26032 = ams2.r(et2);
        int n3 = \u2603 = \u26032 instanceof avl ? ((avl)\u26032).a() : 0;
        if (n2 != \u2603 || this.A(awr2) != this.e(ams2, et2, awr2)) {
            if (this.i(ams2, et2, awr2)) {
                ams2.a(et2, this, 2, -1);
            } else {
                ams2.a(et2, this, 2, 0);
            }
        }
    }

    private void k(ams ams2, et et2, awr awr2) {
        int \u26033;
        int n2 = this.j(ams2, et2, awr2);
        avh \u26032 = ams2.r(et2);
        \u26033 = 0;
        if (\u26032 instanceof avl) {
            avl avl2 = (avl)\u26032;
            \u26033 = avl2.a();
            avl2.a(n2);
        }
        if (\u26033 != n2 || awr2.c(b) == apn$a.a) {
            boolean \u26034 = this.e(ams2, et2, awr2);
            boolean \u26035 = this.A(awr2);
            if (\u26035 && !\u26034) {
                ams2.a(et2, awr2.a(a, false), 2);
            } else if (!\u26035 && \u26034) {
                ams2.a(et2, awr2.a(a, true), 2);
            }
            this.h(ams2, et2, awr2);
        }
    }

    @Override
    public void b(ams ams2, et et2, awr awr2, Random random) {
        if (this.d) {
            ams2.a(et2, this.z(awr2).a(a, true), 4);
        }
        this.k(ams2, et2, awr2);
    }

    @Override
    public void c(ams ams2, et et2, awr awr2) {
        super.c(ams2, et2, awr2);
        ams2.a(et2, this.a(ams2, 0));
    }

    @Override
    public void b(ams ams2, et et2, awr awr2) {
        super.b(ams2, et2, awr2);
        ams2.s(et2);
        this.h(ams2, et2, awr2);
    }

    @Override
    public boolean a(awr awr2, ams ams2, et et2, int n2, int n3) {
        super.a(awr2, ams2, et2, n2, n3);
        avh avh2 = ams2.r(et2);
        if (avh2 == null) {
            return false;
        }
        return avh2.c(n2, n3);
    }

    @Override
    public avh a(ams ams2, int n2) {
        return new avl();
    }

    @Override
    public awr a(int n2) {
        return this.t().a(D, fa.b(n2)).a(a, (n2 & 8) > 0).a(b, (n2 & 4) > 0 ? apn$a.b : apn$a.a);
    }

    @Override
    public int e(awr awr2) {
        int n2 = 0;
        n2 |= awr2.c(D).b();
        if (awr2.c(a).booleanValue()) {
            n2 |= 8;
        }
        if (awr2.c(b) == apn$a.b) {
            n2 |= 4;
        }
        return n2;
    }

    @Override
    public awr a(awr awr2, atk atk2) {
        return awr2.a(D, atk2.a(awr2.c(D)));
    }

    @Override
    public awr a(awr awr2, arw arw2) {
        return awr2.a(arw2.a(awr2.c(D)));
    }

    @Override
    protected aws b() {
        return new aws((aou)this, D, b, a);
    }

    @Override
    public awr a(ams ams2, et et2, fa fa2, float f2, float f3, float f4, int n2, vn vn2) {
        return this.t().a(D, vn2.bt().d()).a(a, false).a(b, apn$a.a);
    }

    public static enum a implements rm
    {
        a("compare"),
        b("subtract");

        private final String c;

        private a(String string2) {
            this.c = string2;
        }

        public String toString() {
            return this.c;
        }

        @Override
        public String m() {
            return this.c;
        }
    }
}

