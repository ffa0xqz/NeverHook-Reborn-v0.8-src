/*
 * Decompiled with CFR 0.150.
 */
import java.io.IOException;

public class jw
implements ht<hw> {
    private int a;
    private byte b;

    public jw() {
    }

    public jw(ve ve2, byte by2) {
        this.a = ve2.S();
        this.b = by2;
    }

    @Override
    public void a(gy gy2) throws IOException {
        this.a = gy2.g();
        this.b = gy2.readByte();
    }

    @Override
    public void b(gy gy2) throws IOException {
        gy2.d(this.a);
        gy2.writeByte(this.b);
    }

    @Override
    public void a(hw hw2) {
        hw2.a(this);
    }

    public ve a(ams ams2) {
        return ams2.a(this.a);
    }

    public byte a() {
        return this.b;
    }
}

