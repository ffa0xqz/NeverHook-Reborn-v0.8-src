/*
 * Decompiled with CFR 0.150.
 */
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class ga
extends gn {
    ga() {
    }

    @Override
    void a(DataInput dataInput, int n2, gh gh2) throws IOException {
        gh2.a(64L);
    }

    @Override
    void a(DataOutput dataOutput) throws IOException {
    }

    @Override
    public byte a() {
        return 0;
    }

    @Override
    public String toString() {
        return "END";
    }

    public ga c() {
        return new ga();
    }

    @Override
    public /* synthetic */ gn b() {
        return this.c();
    }
}

