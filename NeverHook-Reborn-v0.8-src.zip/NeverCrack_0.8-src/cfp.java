/*
 * Decompiled with CFR 0.150.
 */
public class cfp
implements cfc {
    private final hh a;
    private final int b;

    public cfp(hh hh2, int n2) {
        this.a = hh2;
        this.b = n2;
    }

    public hh a() {
        return this.a;
    }

    public int b() {
        return this.b;
    }
}

