/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import javax.annotation.Nullable;

public class abi
extends abd {
    private bhc b;

    public abi(abb abb2) {
        super(abb2);
    }

    @Override
    public void c() {
        if (this.b == null) {
            this.b = new bhc(this.a.p, this.a.q, this.a.r);
        }
    }

    @Override
    public boolean a() {
        return true;
    }

    @Override
    public void d() {
        this.b = null;
    }

    @Override
    public float f() {
        return 1.0f;
    }

    @Override
    @Nullable
    public bhc g() {
        return this.b;
    }

    public abr<abi> i() {
        return abr.k;
    }
}

