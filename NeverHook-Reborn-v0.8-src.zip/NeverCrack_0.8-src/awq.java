/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import java.util.List;
import javax.annotation.Nullable;

public interface awq {
    public bcx a();

    public boolean b();

    public boolean a(ve var1);

    public int c();

    public int d();

    public boolean e();

    public boolean f();

    public bcy a(amw var1, et var2);

    public awr a(atk var1);

    public awr a(arw var1);

    public boolean g();

    public boolean h();

    public ath i();

    public int b(amw var1, et var2);

    public float j();

    public boolean k();

    public boolean l();

    public boolean m();

    public int a(amw var1, et var2, fa var3);

    public boolean n();

    public int a(ams var1, et var2);

    public float b(ams var1, et var2);

    public float a(aeb var1, ams var2, et var3);

    public int b(amw var1, et var2, fa var3);

    public bda o();

    public awr c(amw var1, et var2);

    public bgz c(ams var1, et var2);

    public boolean c(amw var1, et var2, fa var3);

    public boolean p();

    @Nullable
    public bgz d(amw var1, et var2);

    public void a(ams var1, et var2, bgz var3, List<bgz> var4, @Nullable ve var5, boolean var6);

    public bgz e(amw var1, et var2);

    public bha a(ams var1, et var2, bhc var3, bhc var4);

    public boolean q();

    public bhc f(amw var1, et var2);

    public boolean r();

    public awp d(amw var1, et var2, fa var3);
}

