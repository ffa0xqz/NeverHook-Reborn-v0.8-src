/*
 * Decompiled with CFR 0.150.
 */
import java.util.List;

public class acd
extends ve {
    private static final mx<Integer> b = na.a(acd.class, mz.b);
    private boolean c;
    private int d;
    private aeb e;
    private int f;
    private int g;
    private int h;
    private int at;
    private float au;
    public ve a;
    private a av = acd$a.a;
    private int aw;
    private int ax;

    public acd(ams ams2, aeb aeb2, double d2, double d3, double d4) {
        super(ams2);
        this.a(aeb2);
        this.b(d2, d3, d4);
        this.m = this.p;
        this.n = this.q;
        this.o = this.r;
    }

    public acd(ams ams2, aeb aeb2) {
        super(ams2);
        this.a(aeb2);
        this.n();
    }

    private void a(aeb aeb2) {
        this.a(0.25f, 0.25f);
        this.ah = true;
        this.e = aeb2;
        this.e.bU = this;
    }

    public void a(int n2) {
        this.ax = n2;
    }

    public void c(int n2) {
        this.aw = n2;
    }

    private void n() {
        float f2 = this.e.y + (this.e.w - this.e.y);
        \u2603 = this.e.x + (this.e.v - this.e.x);
        \u2603 = ri.b(-\u2603 * ((float)Math.PI / 180) - (float)Math.PI);
        \u2603 = ri.a(-\u2603 * ((float)Math.PI / 180) - (float)Math.PI);
        \u2603 = -ri.b(-f2 * ((float)Math.PI / 180));
        \u2603 = ri.a(-f2 * ((float)Math.PI / 180));
        double \u26032 = this.e.m + (this.e.p - this.e.m) - (double)\u2603 * 0.3;
        double \u26033 = this.e.n + (this.e.q - this.e.n) + (double)this.e.by();
        double \u26034 = this.e.o + (this.e.r - this.e.o) - (double)\u2603 * 0.3;
        this.b(\u26032, \u26033, \u26034, \u2603, f2);
        this.s = -\u2603;
        this.t = ri.a(-(\u2603 / \u2603), -5.0f, 5.0f);
        this.u = -\u2603;
        \u2603 = ri.a(this.s * this.s + this.t * this.t + this.u * this.u);
        this.s *= 0.6 / (double)\u2603 + 0.5 + this.S.nextGaussian() * 0.0045;
        this.t *= 0.6 / (double)\u2603 + 0.5 + this.S.nextGaussian() * 0.0045;
        this.u *= 0.6 / (double)\u2603 + 0.5 + this.S.nextGaussian() * 0.0045;
        \u2603 = ri.a(this.s * this.s + this.u * this.u);
        this.v = (float)(ri.c(this.s, this.u) * 57.2957763671875);
        this.w = (float)(ri.c(this.t, \u2603) * 57.2957763671875);
        this.x = this.v;
        this.y = this.w;
    }

    @Override
    protected void i() {
        this.V().a(b, 0);
    }

    @Override
    public void a(mx<?> mx22) {
        mx<?> mx22;
        if (b.equals(mx22)) {
            int n2 = this.V().a(b);
            this.a = n2 > 0 ? this.l.a(n2 - 1) : null;
        }
        super.a(mx22);
    }

    @Override
    public boolean a(double d2) {
        \u2603 = 64.0;
        return d2 < 4096.0;
    }

    @Override
    public void a(double d2, double d3, double d4, float f2, float f3, int n2, boolean bl2) {
    }

    @Override
    public void B_() {
        double d2;
        super.B_();
        if (this.e == null) {
            this.X();
            return;
        }
        if (!this.l.G && this.p()) {
            return;
        }
        if (this.c) {
            ++this.d;
            if (this.d >= 1200) {
                this.X();
                return;
            }
        }
        float f2 = 0.0f;
        et \u26032 = new et(this);
        awr \u26033 = this.l.o(\u26032);
        if (\u26033.a() == bcx.h) {
            f2 = ars.g(\u26033, this.l, \u26032);
        }
        if (this.av == acd$a.a) {
            if (this.a != null) {
                this.s = 0.0;
                this.t = 0.0;
                this.u = 0.0;
                this.av = acd$a.b;
                return;
            }
            if (f2 > 0.0f) {
                this.s *= 0.3;
                this.t *= 0.2;
                this.u *= 0.3;
                this.av = acd$a.c;
                return;
            }
            if (!this.l.G) {
                this.r();
            }
            if (this.c || this.z || this.A) {
                this.f = 0;
                this.s = 0.0;
                this.t = 0.0;
                this.u = 0.0;
            } else {
                ++this.f;
            }
        } else {
            if (this.av == acd$a.b) {
                if (this.a != null) {
                    if (this.a.F) {
                        this.a = null;
                        this.av = acd$a.a;
                    } else {
                        this.p = this.a.p;
                        this.q = this.a.bw().b + (double)this.a.H * 0.8;
                        this.r = this.a.r;
                        this.b(this.p, this.q, this.r);
                    }
                }
                return;
            }
            if (this.av == acd$a.c) {
                this.s *= 0.9;
                this.u *= 0.9;
                d2 = this.q + this.t - (double)\u26032.q() - (double)f2;
                if (Math.abs(d2) < 0.01) {
                    d2 += Math.signum(d2) * 0.1;
                }
                this.t -= d2 * (double)this.S.nextFloat() * 0.2;
                if (!this.l.G && f2 > 0.0f) {
                    this.a(\u26032);
                }
            }
        }
        if (\u26033.a() != bcx.h) {
            this.t -= 0.03;
        }
        this.a(vt.a, this.s, this.t, this.u);
        this.q();
        d2 = 0.92;
        this.s *= 0.92;
        this.t *= 0.92;
        this.u *= 0.92;
        this.b(this.p, this.q, this.r);
    }

    private boolean p() {
        ain ain2 = this.e.co();
        \u2603 = this.e.cp();
        boolean \u26032 = ain2.c() == aip.aZ;
        boolean bl2 = \u2603 = \u2603.c() == aip.aZ;
        if (this.e.F || !this.e.aC() || !\u26032 && !\u2603 || this.h(this.e) > 1024.0) {
            this.X();
            return true;
        }
        return false;
    }

    private void q() {
        float f2 = ri.a(this.s * this.s + this.u * this.u);
        this.v = (float)(ri.c(this.s, this.u) * 57.2957763671875);
        this.w = (float)(ri.c(this.t, f2) * 57.2957763671875);
        while (this.w - this.y < -180.0f) {
            this.y -= 360.0f;
        }
        while (this.w - this.y >= 180.0f) {
            this.y += 360.0f;
        }
        while (this.v - this.x < -180.0f) {
            this.x -= 360.0f;
        }
        while (this.v - this.x >= 180.0f) {
            this.x += 360.0f;
        }
        this.w = this.y + (this.w - this.y) * 0.2f;
        this.v = this.x + (this.v - this.x) * 0.2f;
    }

    private void r() {
        bhc bhc2 = new bhc(this.p, this.q, this.r);
        \u2603 = new bhc(this.p + this.s, this.q + this.t, this.r + this.u);
        bha \u26032 = this.l.a(bhc2, \u2603, false, true, false);
        bhc2 = new bhc(this.p, this.q, this.r);
        \u2603 = new bhc(this.p + this.s, this.q + this.t, this.r + this.u);
        if (\u26032 != null) {
            \u2603 = new bhc(\u26032.c.b, \u26032.c.c, \u26032.c.d);
        }
        ve \u26033 = null;
        List<ve> \u26034 = this.l.b((ve)this, this.bw().b(this.s, this.t, this.u).g(1.0));
        double \u26035 = 0.0;
        for (ve ve2 : \u26034) {
            if (!this.a(ve2) || ve2 == this.e && this.f < 5 || (\u2603 = (\u2603 = ve2.bw().g(0.3f)).b(bhc2, \u2603)) == null || !((\u2603 = bhc2.g(\u2603.c)) < \u26035) && \u26035 != 0.0) continue;
            \u26033 = ve2;
            \u26035 = \u2603;
        }
        if (\u26033 != null) {
            \u26032 = new bha(\u26033);
        }
        if (\u26032 != null && \u26032.a != bha.a.a) {
            if (\u26032.a == bha.a.c) {
                this.a = \u26032.d;
                this.s();
            } else {
                this.c = true;
            }
        }
    }

    private void s() {
        this.V().b(b, this.a.S() + 1);
    }

    private void a(et et2) {
        om om2 = (om)this.l;
        int \u26032 = 1;
        et \u26033 = et2.a();
        if (this.S.nextFloat() < 0.25f && this.l.B(\u26033)) {
            ++\u26032;
        }
        if (this.S.nextFloat() < 0.5f && !this.l.h(\u26033)) {
            --\u26032;
        }
        if (this.g > 0) {
            --this.g;
            if (this.g <= 0) {
                this.h = 0;
                this.at = 0;
            } else {
                this.t -= 0.2 * (double)this.S.nextFloat() * (double)this.S.nextFloat();
            }
        } else if (this.at > 0) {
            this.at -= \u26032;
            if (this.at > 0) {
                this.au = (float)((double)this.au + this.S.nextGaussian() * 4.0);
                float f2 = this.au * ((float)Math.PI / 180);
                \u2603 = ri.a(f2);
                \u2603 = ri.b(f2);
                double \u26034 = this.p + (double)(\u2603 * (float)this.at * 0.1f);
                double \u26035 = (float)ri.c(this.bw().b) + 1.0f;
                aou \u26036 = om2.o(new et(\u26034, \u26035 - 1.0, \u2603 = this.r + (double)(\u2603 * (float)this.at * 0.1f))).u();
                if (\u26036 == aov.j || \u26036 == aov.i) {
                    if (this.S.nextFloat() < 0.15f) {
                        om2.a(fj.e, \u26034, \u26035 - (double)0.1f, \u2603, 1, (double)\u2603, 0.1, (double)\u2603, 0.0, new int[0]);
                    }
                    \u2603 = \u2603 * 0.04f;
                    \u2603 = \u2603 * 0.04f;
                    om2.a(fj.g, \u26034, \u26035, \u2603, 0, (double)\u2603, 0.01, (double)(-\u2603), 1.0, new int[0]);
                    om2.a(fj.g, \u26034, \u26035, \u2603, 0, (double)(-\u2603), 0.01, (double)\u2603, 1.0, new int[0]);
                }
            } else {
                this.t = -0.4f * ri.a(this.S, 0.6f, 1.0f);
                this.a(qd.K, 0.25f, 1.0f + (this.S.nextFloat() - this.S.nextFloat()) * 0.4f);
                double \u26037 = this.bw().b + 0.5;
                om2.a(fj.e, this.p, \u26037, this.r, (int)(1.0f + this.G * 20.0f), (double)this.G, 0.0, (double)this.G, (double)0.2f, new int[0]);
                om2.a(fj.g, this.p, \u26037, this.r, (int)(1.0f + this.G * 20.0f), (double)this.G, 0.0, (double)this.G, (double)0.2f, new int[0]);
                this.g = ri.a(this.S, 20, 40);
            }
        } else if (this.h > 0) {
            this.h -= \u26032;
            \u2603 = 0.15f;
            if (this.h < 20) {
                \u2603 = (float)((double)\u2603 + (double)(20 - this.h) * 0.05);
            } else if (this.h < 40) {
                \u2603 = (float)((double)\u2603 + (double)(40 - this.h) * 0.02);
            } else if (this.h < 60) {
                \u2603 = (float)((double)\u2603 + (double)(60 - this.h) * 0.01);
            }
            if (this.S.nextFloat() < \u2603) {
                \u2603 = ri.a(this.S, 0.0f, 360.0f) * ((float)Math.PI / 180);
                \u2603 = ri.a(this.S, 25.0f, 60.0f);
                double \u26038 = this.p + (double)(ri.a(\u2603) * \u2603 * 0.1f);
                aou \u26039 = om2.o(new et((int)\u26038, (int)(\u2603 = (double)((float)ri.c(this.bw().b) + 1.0f)) - 1, (int)(\u2603 = this.r + (double)(ri.b(\u2603) * \u2603 * 0.1f)))).u();
                if (\u26039 == aov.j || \u26039 == aov.i) {
                    om2.a(fj.f, \u26038, \u2603, \u2603, 2 + this.S.nextInt(2), (double)0.1f, 0.0, (double)0.1f, 0.0, new int[0]);
                }
            }
            if (this.h <= 0) {
                this.au = ri.a(this.S, 0.0f, 360.0f);
                this.at = ri.a(this.S, 20, 80);
            }
        } else {
            this.h = ri.a(this.S, 100, 600);
            this.h -= this.ax * 20 * 5;
        }
    }

    protected boolean a(ve ve2) {
        return ve2.ay() || ve2 instanceof acj;
    }

    @Override
    public void b(fy fy2) {
    }

    @Override
    public void a(fy fy2) {
    }

    public int j() {
        if (this.l.G || this.e == null) {
            return 0;
        }
        int n2 = 0;
        if (this.a != null) {
            this.k();
            this.l.a((ve)this, (byte)31);
            n2 = this.a instanceof acj ? 3 : 5;
        } else if (this.g > 0) {
            bfr.a a2 = new bfr.a((om)this.l);
            a2.a((float)this.aw + this.e.du());
            for (ain ain2 : this.l.am().a(bfl.aA).a(this.S, a2.a())) {
                acj acj2 = new acj(this.l, this.p, this.q, this.r, ain2);
                double \u26032 = this.e.p - this.p;
                double \u26033 = this.e.q - this.q;
                double \u26034 = this.e.r - this.r;
                double \u26035 = ri.a(\u26032 * \u26032 + \u26033 * \u26033 + \u26034 * \u26034);
                double \u26036 = 0.1;
                acj2.s = \u26032 * 0.1;
                acj2.t = \u26033 * 0.1 + (double)ri.a(\u26035) * 0.08;
                acj2.u = \u26034 * 0.1;
                this.l.a(acj2);
                this.e.l.a(new vk(this.e.l, this.e.p, this.e.q + 0.5, this.e.r + 0.5, this.S.nextInt(6) + 1));
                ail \u26037 = ain2.c();
                if (\u26037 != aip.bc && \u26037 != aip.bd) continue;
                this.e.a(qq.E, 1);
            }
            n2 = 1;
        }
        if (this.c) {
            n2 = 2;
        }
        this.X();
        return n2;
    }

    @Override
    public void a(byte by2) {
        if (by2 == 31 && this.l.G && this.a instanceof aeb && ((aeb)this.a).cZ()) {
            this.k();
        }
        super.a(by2);
    }

    protected void k() {
        if (this.e == null) {
            return;
        }
        double d2 = this.e.p - this.p;
        \u2603 = this.e.q - this.q;
        \u2603 = this.e.r - this.r;
        \u2603 = 0.1;
        this.a.s += d2 * 0.1;
        this.a.t += \u2603 * 0.1;
        this.a.u += \u2603 * 0.1;
    }

    @Override
    protected boolean ak() {
        return false;
    }

    @Override
    public void X() {
        super.X();
        if (this.e != null) {
            this.e.bU = null;
        }
    }

    public aeb l() {
        return this.e;
    }

    static enum a {
        a,
        b,
        c;

    }
}

