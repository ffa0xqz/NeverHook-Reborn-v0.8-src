/*
 * Decompiled with CFR 0.150.
 */
import net.minecraft.server.MinecraftServer;

public class cq
extends bi {
    @Override
    public String c() {
        return "list";
    }

    @Override
    public int a() {
        return 0;
    }

    @Override
    public String b(bn bn2) {
        return "commands.players.usage";
    }

    @Override
    public void a(MinecraftServer minecraftServer, bn bn2, String[] arrstring) throws ei {
        int n2 = minecraftServer.H();
        bn2.a(new hp("commands.players.list", n2, minecraftServer.I()));
        bn2.a(new ho(minecraftServer.am().b(arrstring.length > 0 && "uuids".equalsIgnoreCase(arrstring[0]))));
        bn2.a(bp.a.e, n2);
    }
}

