/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 */
import com.google.common.collect.Lists;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class bbq
extends bbs {
    private final List<anf> a;
    private boolean b;
    private aml[] d = new aml[128];
    private double h = 32.0;
    private int i = 3;

    public bbq() {
        this.a = Lists.newArrayList();
        for (anf anf2 : anf.p) {
            if (anf2 == null || !(anf2.j() > 0.0f)) continue;
            this.a.add(anf2);
        }
    }

    public bbq(Map<String, String> map) {
        this();
        for (Map.Entry<String, String> entry : map.entrySet()) {
            if (entry.getKey().equals("distance")) {
                this.h = ri.a(entry.getValue(), this.h, 1.0);
                continue;
            }
            if (entry.getKey().equals("count")) {
                this.d = new aml[ri.a(entry.getValue(), this.d.length, 1)];
                continue;
            }
            if (!entry.getKey().equals("spread")) continue;
            this.i = ri.a(entry.getValue(), this.i, 1);
        }
    }

    @Override
    public String a() {
        return "Stronghold";
    }

    @Override
    public et a(ams ams2, et et2, boolean bl2) {
        if (!this.b) {
            this.c();
            this.b = true;
        }
        et \u26034 = null;
        et.a \u26032 = new et.a(0, 0, 0);
        double \u26033 = Double.MAX_VALUE;
        for (aml aml2 : this.d) {
            \u26032.c((aml2.a << 4) + 8, 32, (aml2.b << 4) + 8);
            double d2 = \u26032.n(et2);
            if (\u26034 == null) {
                \u26034 = new et(\u26032);
                \u26033 = d2;
                continue;
            }
            if (!(d2 < \u26033)) continue;
            \u26034 = new et(\u26032);
            \u26033 = d2;
        }
        return \u26034;
    }

    @Override
    protected boolean a(int n2, int n3) {
        if (!this.b) {
            this.c();
            this.b = true;
        }
        for (aml aml2 : this.d) {
            if (n2 != aml2.a || n3 != aml2.b) continue;
            return true;
        }
        return false;
    }

    private void c() {
        this.a(this.g);
        int n2 = 0;
        for (bbw bbw2 : this.c.values()) {
            if (n2 >= this.d.length) continue;
            this.d[n2++] = new aml(bbw2.e(), bbw2.f());
        }
        Random random = new Random();
        random.setSeed(this.g.Q());
        double \u26032 = random.nextDouble() * Math.PI * 2.0;
        int \u26033 = 0;
        int \u26034 = 0;
        int \u26035 = this.c.size();
        if (\u26035 < this.d.length) {
            for (int i2 = 0; i2 < this.d.length; ++i2) {
                double d2 = 4.0 * this.h + this.h * (double)\u26033 * 6.0 + (random.nextDouble() - 0.5) * (this.h * 2.5);
                int \u26036 = (int)Math.round(Math.cos(\u26032) * d2);
                int \u26037 = (int)Math.round(Math.sin(\u26032) * d2);
                et \u26038 = this.g.C().a((\u26036 << 4) + 8, (\u26037 << 4) + 8, 112, this.a, random);
                if (\u26038 != null) {
                    \u26036 = \u26038.p() >> 4;
                    \u26037 = \u26038.r() >> 4;
                }
                if (i2 >= \u26035) {
                    this.d[i2] = new aml(\u26036, \u26037);
                }
                \u26032 += Math.PI * 2 / (double)this.i;
                if (++\u26034 != this.i) continue;
                \u26034 = 0;
                this.i += 2 * this.i / (++\u26033 + 1);
                this.i = Math.min(this.i, this.d.length - i2);
                \u26032 += random.nextDouble() * Math.PI * 2.0;
            }
        }
    }

    @Override
    protected bbw b(int n2, int n3) {
        a a2 = new a(this.g, this.f, n2, n3);
        while (a2.c().isEmpty() || ((bbr.m)a2.c().get((int)0)).b == null) {
            a2 = new a(this.g, this.f, n2, n3);
        }
        return a2;
    }

    public static class a
    extends bbw {
        public a() {
        }

        public a(ams ams2, Random random, int n2, int n3) {
            super(n2, n3);
            bbr.b();
            bbr.m m2 = new bbr.m(0, random, (n2 << 4) + 2, (n3 << 4) + 2);
            this.a.add(m2);
            m2.a(m2, this.a, random);
            List<bbv> \u26032 = m2.c;
            while (!\u26032.isEmpty()) {
                int n4 = random.nextInt(\u26032.size());
                bbv \u26033 = \u26032.remove(n4);
                \u26033.a(m2, this.a, random);
            }
            this.d();
            this.a(ams2, random, 10);
        }
    }
}

