/*
 * Decompiled with CFR 0.150.
 */
import java.awt.Color;
import top.nhprem.api.utils.render.DrawHelper;

public class biy
extends bip {
    protected static final nd a = new nd("textures/gui/widgets.png");
    protected int f = 200;
    protected int g = 20;
    public int h;
    public int i;
    public String j;
    public int k;
    public boolean l = true;
    public boolean m = true;
    protected boolean n;
    private int fade = 20;
    private int fadeOutline = 20;
    public static bir sr = new bir(bhz.z());

    public biy(int buttonId, int x2, int y2, String buttonText) {
        this(buttonId, x2, y2, 200, 20, buttonText);
    }

    public biy(int buttonId, int x2, int y2, int widthIn, int heightIn, String buttonText) {
        this.k = buttonId;
        this.h = x2;
        this.i = y2;
        this.f = widthIn;
        this.g = heightIn;
        this.j = buttonText;
    }

    protected int a(boolean mouseOver) {
        int i2 = 1;
        if (!this.l) {
            i2 = 0;
        } else if (mouseOver) {
            i2 = 2;
        }
        return i2;
    }

    public void drawButton(bhz mc2, int mouseX, int mouseY, float mouseButton) {
        if (this.m) {
            this.n = mouseX >= this.h && mouseY >= this.i && mouseX < this.h + this.f && mouseY < this.i + this.g;
            Color text = new Color(215, 215, 215, 255);
            Color color = new Color(0, 0, 0, 73);
            if (this.n) {
                if (this.fade < 100) {
                    this.fade += 7;
                }
                text = Color.white;
            } else if (this.fade > 20) {
                this.fade -= 7;
            }
            Color colorOutline = new Color(this.fade + 60, this.fade, this.fade);
            if (this.n) {
                if (this.fadeOutline < 100) {
                    this.fadeOutline += 7;
                }
            } else if (this.fadeOutline > 20) {
                this.fadeOutline -= 7;
            }
            DrawHelper.drawOutlineRect(this.h, this.i, this.f, this.g, color, new Color(255, 255, 255, 10));
            mc2.neverlose500_18.drawCenteredString(this.j, (float)this.h + (float)this.f / 2.0f, (float)this.i + ((float)this.g - 7.5f) / 2.0f, text.getRGB());
        }
    }

    protected void a(bhz mc2, int mouseX, int mouseY) {
    }

    public void a(int mouseX, int mouseY) {
    }

    public boolean b(bhz mc2, int mouseX, int mouseY) {
        return this.l && this.m && mouseX >= this.h && mouseY >= this.i && mouseX < this.h + this.f && mouseY < this.i + this.g;
    }

    public boolean a() {
        return this.n;
    }

    public void b(int mouseX, int mouseY) {
    }

    public void a(chm soundHandlerIn) {
        soundHandlerIn.a(cgn.a(qd.ic, 1.0f));
    }

    public int b() {
        return this.f;
    }

    public void a(int width) {
        this.f = width;
    }
}

