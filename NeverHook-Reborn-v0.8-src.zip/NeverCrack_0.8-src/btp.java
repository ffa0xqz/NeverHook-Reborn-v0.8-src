/*
 * Decompiled with CFR 0.150.
 */
public class btp
extends btd {
    protected btp(ams ams2, double d2, double d3, double d4, double d5, double d6, double d7) {
        super(ams2, d2, d3 - 0.125, d4, d5, d6, d7);
        this.A = 0.4f;
        this.B = 0.4f;
        this.C = 0.7f;
        this.b(0);
        this.a(0.01f, 0.01f);
        this.y *= this.r.nextFloat() * 0.6f + 0.2f;
        this.j = d5 * 0.0;
        this.k = d6 * 0.0;
        this.l = d7 * 0.0;
        this.x = (int)(16.0 / (Math.random() * 0.8 + 0.2));
    }

    @Override
    public void a() {
        this.d = this.g;
        this.e = this.h;
        this.f = this.i;
        this.a(this.j, this.k, this.l);
        if (this.c.o(new et(this.g, this.h, this.i)).a() != bcx.h) {
            this.i();
        }
        if (this.x-- <= 0) {
            this.i();
        }
    }

    public static class a
    implements btf {
        @Override
        public btd a(int n2, ams ams2, double d2, double d3, double d4, double d5, double d6, double d7, int ... arrn) {
            return new btp(ams2, d2, d3, d4, d5, d6, d7);
        }
    }
}

