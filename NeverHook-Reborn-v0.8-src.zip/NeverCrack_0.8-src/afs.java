/*
 * Decompiled with CFR 0.150.
 */
public class afs
extends afp {
    private final tt a;
    private final agp f;
    private int g;
    private int h;

    public afs(aea aea2, tt tt2) {
        int n2;
        this.a = tt2;
        this.a(new c(tt2, 0, 56, 51));
        this.a(new c(tt2, 1, 79, 58));
        this.a(new c(tt2, 2, 102, 51));
        this.f = this.a(new b(tt2, 3, 79, 17));
        this.a(new a(tt2, 4, 17, 17));
        for (n2 = 0; n2 < 3; ++n2) {
            for (\u2603 = 0; \u2603 < 9; ++\u2603) {
                this.a(new agp(aea2, \u2603 + n2 * 9 + 9, 8 + \u2603 * 18, 84 + n2 * 18));
            }
        }
        for (n2 = 0; n2 < 9; ++n2) {
            this.a(new agp(aea2, n2, 8 + n2 * 18, 142));
        }
    }

    @Override
    public void a(afv afv2) {
        super.a(afv2);
        afv2.a((afp)this, this.a);
    }

    @Override
    public void b() {
        super.b();
        for (int i2 = 0; i2 < this.e.size(); ++i2) {
            afv afv2 = (afv)this.e.get(i2);
            if (this.g != this.a.c(0)) {
                afv2.a((afp)this, 0, this.a.c(0));
            }
            if (this.h == this.a.c(1)) continue;
            afv2.a((afp)this, 1, this.a.c(1));
        }
        this.g = this.a.c(0);
        this.h = this.a.c(1);
    }

    @Override
    public void b(int n2, int n3) {
        this.a.b(n2, n3);
    }

    @Override
    public boolean a(aeb aeb2) {
        return this.a.a(aeb2);
    }

    @Override
    public ain b(aeb aeb2, int n2) {
        ain ain2 = ain.a;
        agp \u26032 = (agp)this.c.get(n2);
        if (\u26032 != null && \u26032.e()) {
            \u2603 = \u26032.d();
            ain2 = \u2603.l();
            if (n2 >= 0 && n2 <= 2 || n2 == 3 || n2 == 4) {
                if (!this.a(\u2603, 5, 41, true)) {
                    return ain.a;
                }
                \u26032.a(\u2603, ain2);
            } else if (this.f.a(\u2603) ? !this.a(\u2603, 3, 4, false) : (afs$c.c_(ain2) && ain2.E() == 1 ? !this.a(\u2603, 0, 3, false) : (afs$a.b_(ain2) ? !this.a(\u2603, 4, 5, false) : (n2 >= 5 && n2 < 32 ? !this.a(\u2603, 32, 41, false) : (n2 >= 32 && n2 < 41 ? !this.a(\u2603, 5, 32, false) : !this.a(\u2603, 5, 41, false)))))) {
                return ain.a;
            }
            if (\u2603.b()) {
                \u26032.d(ain.a);
            } else {
                \u26032.f();
            }
            if (\u2603.E() == ain2.E()) {
                return ain.a;
            }
            \u26032.a(aeb2, \u2603);
        }
        return ain2;
    }

    static class a
    extends agp {
        public a(tt tt2, int n2, int n3, int n4) {
            super(tt2, n2, n3, n4);
        }

        @Override
        public boolean a(ain ain2) {
            return afs$a.b_(ain2);
        }

        public static boolean b_(ain ain2) {
            return ain2.c() == aip.bO;
        }

        @Override
        public int a() {
            return 64;
        }
    }

    static class b
    extends agp {
        public b(tt tt2, int n2, int n3, int n4) {
            super(tt2, n2, n3, n4);
        }

        @Override
        public boolean a(ain ain2) {
            return akf.a(ain2);
        }

        @Override
        public int a() {
            return 64;
        }
    }

    static class c
    extends agp {
        public c(tt tt2, int n2, int n3, int n4) {
            super(tt2, n2, n3, n4);
        }

        @Override
        public boolean a(ain ain2) {
            return afs$c.c_(ain2);
        }

        @Override
        public int a() {
            return 1;
        }

        @Override
        public ain a(aeb aeb2, ain ain2) {
            ake ake2 = akg.d(ain2);
            if (aeb2 instanceof oo) {
                m.j.a((oo)aeb2, ake2);
            }
            super.a(aeb2, ain2);
            return ain2;
        }

        public static boolean c_(ain ain2) {
            ail ail2 = ain2.c();
            return ail2 == aip.bH || ail2 == aip.bI || ail2 == aip.bJ || ail2 == aip.bK;
        }
    }
}

