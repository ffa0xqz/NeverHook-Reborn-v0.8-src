/*
 * Decompiled with CFR 0.150.
 */
public class cck
extends cbz {
    public cck(bzy<?> bzy2) {
        super(bzy2);
    }

    @Override
    protected void M_() {
        this.c = new brf(0.5f, 0.0f, true);
        this.d = new brf(1.0f, 0.0f, true);
    }
}

