/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonDeserializationContext
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonPrimitive
 *  com.google.gson.JsonSerializationContext
 */
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import java.util.Random;

public class bgs
implements bgr {
    private final boolean a;

    public bgs(boolean bl2) {
        this.a = bl2;
    }

    @Override
    public boolean a(Random random, ve ve2) {
        return ve2.aR() == this.a;
    }

    public static class a
    extends bgr.a<bgs> {
        protected a() {
            super(new nd("on_fire"), bgs.class);
        }

        @Override
        public JsonElement a(bgs bgs2, JsonSerializationContext jsonSerializationContext) {
            return new JsonPrimitive(Boolean.valueOf(bgs2.a));
        }

        public bgs b(JsonElement jsonElement, JsonDeserializationContext jsonDeserializationContext) {
            return new bgs(ra.c(jsonElement, "on_fire"));
        }

        @Override
        public /* synthetic */ bgr a(JsonElement jsonElement, JsonDeserializationContext jsonDeserializationContext) {
            return this.b(jsonElement, jsonDeserializationContext);
        }
    }
}

