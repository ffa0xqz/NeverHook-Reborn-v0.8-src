/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Optional
 *  com.google.common.collect.ImmutableSet
 *  com.google.common.collect.Sets
 */
import com.google.common.base.Optional;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Sets;
import java.util.Collection;
import java.util.HashSet;

public class axg
extends axc<Integer> {
    private final ImmutableSet<Integer> a;

    protected axg(String string, int n2, int n3) {
        super(string, Integer.class);
        if (n2 < 0) {
            throw new IllegalArgumentException("Min value of " + string + " must be 0 or greater");
        }
        if (n3 <= n2) {
            throw new IllegalArgumentException("Max value of " + string + " must be greater than min (" + n2 + ")");
        }
        HashSet hashSet = Sets.newHashSet();
        for (int i2 = n2; i2 <= n3; ++i2) {
            hashSet.add(i2);
        }
        this.a = ImmutableSet.copyOf((Collection)hashSet);
    }

    @Override
    public Collection<Integer> c() {
        return this.a;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object instanceof axg && super.equals(object)) {
            axg axg2 = (axg)object;
            return this.a.equals(axg2.a);
        }
        return false;
    }

    @Override
    public int hashCode() {
        return 31 * super.hashCode() + this.a.hashCode();
    }

    public static axg a(String string, int n2, int n3) {
        return new axg(string, n2, n3);
    }

    @Override
    public Optional<Integer> b(String string) {
        try {
            Integer n2 = Integer.valueOf(string);
            return this.a.contains((Object)n2) ? Optional.of((Object)n2) : Optional.absent();
        }
        catch (NumberFormatException numberFormatException) {
            return Optional.absent();
        }
    }

    @Override
    public String a(Integer n2) {
        return n2.toString();
    }
}

