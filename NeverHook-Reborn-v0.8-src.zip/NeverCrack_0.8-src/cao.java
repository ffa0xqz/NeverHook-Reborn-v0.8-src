/*
 * Decompiled with CFR 0.150.
 */
public class cao
extends cad<adg> {
    public static final nd[] a = new nd[]{new nd("textures/entity/shulker/shulker_white.png"), new nd("textures/entity/shulker/shulker_orange.png"), new nd("textures/entity/shulker/shulker_magenta.png"), new nd("textures/entity/shulker/shulker_light_blue.png"), new nd("textures/entity/shulker/shulker_yellow.png"), new nd("textures/entity/shulker/shulker_lime.png"), new nd("textures/entity/shulker/shulker_pink.png"), new nd("textures/entity/shulker/shulker_gray.png"), new nd("textures/entity/shulker/shulker_silver.png"), new nd("textures/entity/shulker/shulker_cyan.png"), new nd("textures/entity/shulker/shulker_purple.png"), new nd("textures/entity/shulker/shulker_blue.png"), new nd("textures/entity/shulker/shulker_brown.png"), new nd("textures/entity/shulker/shulker_green.png"), new nd("textures/entity/shulker/shulker_red.png"), new nd("textures/entity/shulker/shulker_black.png")};

    public cao(bzd bzd2) {
        super(bzd2, new bqq(), 0.0f);
        this.a(new a());
    }

    public bqq h() {
        return (bqq)super.b();
    }

    @Override
    public void a(adg adg2, double d2, double d3, double d4, float f2, float f3) {
        int n2 = adg2.do();
        if (n2 > 0 && adg2.dq()) {
            et et2 = adg2.dm();
            \u2603 = adg2.dp();
            double \u26032 = (double)((float)n2 - f3) / 6.0;
            \u26032 *= \u26032;
            double \u26033 = (double)(et2.p() - \u2603.p()) * \u26032;
            double \u26034 = (double)(et2.q() - \u2603.q()) * \u26032;
            double \u26035 = (double)(et2.r() - \u2603.r()) * \u26032;
            super.a(adg2, d2 - \u26033, d3 - \u26034, d4 - \u26035, f2, f3);
        } else {
            super.a(adg2, d2, d3, d4, f2, f3);
        }
    }

    @Override
    public boolean a(adg adg2, bxw bxw2, double d2, double d3, double d4) {
        if (super.a(adg2, bxw2, d2, d3, d4)) {
            return true;
        }
        if (adg2.do() > 0 && adg2.dq()) {
            et et2 = adg2.dp();
            \u2603 = adg2.dm();
            bhc \u26032 = new bhc(\u2603.p(), \u2603.q(), \u2603.r());
            bhc \u26033 = new bhc(et2.p(), et2.q(), et2.r());
            if (bxw2.a(new bgz(\u26033.b, \u26033.c, \u26033.d, \u26032.b, \u26032.c, \u26032.d))) {
                return true;
            }
        }
        return false;
    }

    @Override
    protected nd a(adg adg2) {
        return a[adg2.dr().a()];
    }

    @Override
    protected void a(adg adg2, float f2, float f3, float f4) {
        super.a(adg2, f2, f3, f4);
        switch (adg2.dl()) {
            case a: {
                break;
            }
            case f: {
                buq.c(0.5f, 0.5f, 0.0f);
                buq.b(90.0f, 1.0f, 0.0f, 0.0f);
                buq.b(90.0f, 0.0f, 0.0f, 1.0f);
                break;
            }
            case e: {
                buq.c(-0.5f, 0.5f, 0.0f);
                buq.b(90.0f, 1.0f, 0.0f, 0.0f);
                buq.b(-90.0f, 0.0f, 0.0f, 1.0f);
                break;
            }
            case c: {
                buq.c(0.0f, 0.5f, -0.5f);
                buq.b(90.0f, 1.0f, 0.0f, 0.0f);
                break;
            }
            case d: {
                buq.c(0.0f, 0.5f, 0.5f);
                buq.b(90.0f, 1.0f, 0.0f, 0.0f);
                buq.b(180.0f, 0.0f, 0.0f, 1.0f);
                break;
            }
            case b: {
                buq.c(0.0f, 1.0f, 0.0f);
                buq.b(180.0f, 1.0f, 0.0f, 0.0f);
            }
        }
    }

    @Override
    protected void a(adg adg2, float f2) {
        \u2603 = 0.999f;
        buq.b(0.999f, 0.999f, 0.999f);
    }

    @Override
    public /* synthetic */ bqd b() {
        return this.h();
    }

    class a
    implements cce<adg> {
        private a() {
        }

        @Override
        public void a(adg adg2, float f2, float f3, float f4, float f5, float f6, float f7, float f8) {
            buq.G();
            switch (adg2.dl()) {
                case a: {
                    break;
                }
                case f: {
                    buq.b(90.0f, 0.0f, 0.0f, 1.0f);
                    buq.b(90.0f, 1.0f, 0.0f, 0.0f);
                    buq.c(1.0f, -1.0f, 0.0f);
                    buq.b(180.0f, 0.0f, 1.0f, 0.0f);
                    break;
                }
                case e: {
                    buq.b(-90.0f, 0.0f, 0.0f, 1.0f);
                    buq.b(90.0f, 1.0f, 0.0f, 0.0f);
                    buq.c(-1.0f, -1.0f, 0.0f);
                    buq.b(180.0f, 0.0f, 1.0f, 0.0f);
                    break;
                }
                case c: {
                    buq.b(90.0f, 1.0f, 0.0f, 0.0f);
                    buq.c(0.0f, -1.0f, -1.0f);
                    break;
                }
                case d: {
                    buq.b(180.0f, 0.0f, 0.0f, 1.0f);
                    buq.b(90.0f, 1.0f, 0.0f, 0.0f);
                    buq.c(0.0f, -1.0f, 1.0f);
                    break;
                }
                case b: {
                    buq.b(180.0f, 1.0f, 0.0f, 0.0f);
                    buq.c(0.0f, -2.0f, 0.0f);
                }
            }
            brq brq2 = cao.this.h().c;
            brq2.g = f6 * ((float)Math.PI / 180);
            brq2.f = f7 * ((float)Math.PI / 180);
            cao.this.a(a[adg2.dr().a()]);
            brq2.a(f8);
            buq.H();
        }

        @Override
        public boolean a() {
            return false;
        }
    }
}

