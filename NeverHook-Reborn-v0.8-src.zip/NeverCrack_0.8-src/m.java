/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 *  javax.annotation.Nullable
 */
import com.google.common.collect.Maps;
import java.util.Map;
import javax.annotation.Nullable;

public class m {
    private static final Map<nd, p<?>> C = Maps.newHashMap();
    public static final ak a = m.a(new ak());
    public static final ao b = m.a(new ao(new nd("player_killed_entity")));
    public static final ao c = m.a(new ao(new nd("entity_killed_player")));
    public static final ah d = m.a(new ah());
    public static final al e = m.a(new al());
    public static final ay f = m.a(new ay());
    public static final ax g = m.a(new ax());
    public static final ai h = m.a(new ai());
    public static final af i = m.a(new af());
    public static final w j = m.a(new w());
    public static final y k = m.a(new y());
    public static final bd l = m.a(new bd());
    public static final az m = m.a(new az());
    public static final v n = m.a(new v());
    public static final ar o = m.a(new ar(new nd("location")));
    public static final ar p = m.a(new ar(new nd("slept_in_bed")));
    public static final aa q = m.a(new aa());
    public static final bc r = m.a(new bc());
    public static final am s = m.a(new am());
    public static final ap t = m.a(new ap());
    public static final x u = m.a(new x());
    public static final bb v = m.a(new bb());
    public static final ba w = m.a(new ba());
    public static final aw x = m.a(new aw());
    public static final z y = m.a(new z());
    public static final ae z = m.a(new ae());
    public static final be A = m.a(new be());
    public static final av B = m.a(new av());

    private static <T extends p> T a(T t2) {
        if (C.containsKey(t2.a())) {
            throw new IllegalArgumentException("Duplicate criterion id " + t2.a());
        }
        C.put(t2.a(), t2);
        return t2;
    }

    @Nullable
    public static <T extends q> p<T> a(nd nd2) {
        return C.get(nd2);
    }

    public static Iterable<? extends p<?>> a() {
        return C.values();
    }
}

