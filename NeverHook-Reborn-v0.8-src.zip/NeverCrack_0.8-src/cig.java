/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 *  org.lwjgl.Sys
 *  org.lwjgl.opengl.ARBFramebufferObject
 *  org.lwjgl.opengl.ARBMultitexture
 *  org.lwjgl.opengl.ARBShaderObjects
 *  org.lwjgl.opengl.ARBVertexBufferObject
 *  org.lwjgl.opengl.ARBVertexShader
 *  org.lwjgl.opengl.ContextCapabilities
 *  org.lwjgl.opengl.EXTBlendFuncSeparate
 *  org.lwjgl.opengl.EXTFramebufferObject
 *  org.lwjgl.opengl.GL11
 *  org.lwjgl.opengl.GL13
 *  org.lwjgl.opengl.GL14
 *  org.lwjgl.opengl.GL15
 *  org.lwjgl.opengl.GL20
 *  org.lwjgl.opengl.GL30
 *  org.lwjgl.opengl.GLContext
 *  oshi.SystemInfo
 *  oshi.hardware.Processor
 */
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.Locale;
import optifine.Config;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.Sys;
import org.lwjgl.opengl.ARBFramebufferObject;
import org.lwjgl.opengl.ARBMultitexture;
import org.lwjgl.opengl.ARBShaderObjects;
import org.lwjgl.opengl.ARBVertexBufferObject;
import org.lwjgl.opengl.ARBVertexShader;
import org.lwjgl.opengl.ContextCapabilities;
import org.lwjgl.opengl.EXTBlendFuncSeparate;
import org.lwjgl.opengl.EXTFramebufferObject;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GLContext;
import oshi.SystemInfo;
import oshi.hardware.Processor;

public class cig {
    private static final Logger T = LogManager.getLogger();
    public static boolean a;
    public static boolean b;
    public static int c;
    public static int d;
    public static int e;
    public static int f;
    public static int g;
    public static int h;
    public static int i;
    public static int j;
    public static int k;
    private static a U;
    public static boolean l;
    private static boolean V;
    private static boolean W;
    public static int m;
    public static int n;
    public static int o;
    public static int p;
    private static boolean X;
    public static int q;
    public static int r;
    public static int s;
    private static boolean Y;
    public static int t;
    public static int u;
    public static int v;
    public static int w;
    public static int x;
    public static int y;
    public static int z;
    public static int A;
    public static int B;
    public static int C;
    public static int D;
    public static int E;
    public static int F;
    public static int G;
    public static int H;
    public static int I;
    public static int J;
    public static int K;
    public static int L;
    private static boolean Z;
    public static boolean M;
    public static boolean N;
    public static boolean O;
    private static String aa;
    private static String ab;
    public static boolean P;
    public static boolean Q;
    private static boolean ac;
    public static int R;
    public static int S;
    public static float lastBrightnessX;
    public static float lastBrightnessY;

    public static void a() {
        Config.initDisplay();
        ContextCapabilities contextcapabilities = GLContext.getCapabilities();
        X = contextcapabilities.GL_ARB_multitexture && !contextcapabilities.OpenGL13;
        boolean bl2 = Y = contextcapabilities.GL_ARB_texture_env_combine && !contextcapabilities.OpenGL13;
        if (X) {
            aa = aa + "Using ARB_multitexture.\n";
            q = 33984;
            r = 33985;
            s = 33986;
        } else {
            aa = aa + "Using GL 1.3 multitexturing.\n";
            q = 33984;
            r = 33985;
            s = 33986;
        }
        if (Y) {
            aa = aa + "Using ARB_texture_env_combine.\n";
            t = 34160;
            u = 34165;
            v = 34167;
            w = 34166;
            x = 34168;
            y = 34161;
            z = 34176;
            A = 34177;
            B = 34178;
            C = 34192;
            D = 34193;
            E = 34194;
            F = 34162;
            G = 34184;
            H = 34185;
            I = 34186;
            J = 34200;
            K = 34201;
            L = 34202;
        } else {
            aa = aa + "Using GL 1.3 texture combiners.\n";
            t = 34160;
            u = 34165;
            v = 34167;
            w = 34166;
            x = 34168;
            y = 34161;
            z = 34176;
            A = 34177;
            B = 34178;
            C = 34192;
            D = 34193;
            E = 34194;
            F = 34162;
            G = 34184;
            H = 34185;
            I = 34186;
            J = 34200;
            K = 34201;
            L = 34202;
        }
        M = contextcapabilities.GL_EXT_blend_func_separate && !contextcapabilities.OpenGL14;
        Z = contextcapabilities.OpenGL14 || contextcapabilities.GL_EXT_blend_func_separate;
        boolean bl3 = l = Z && (contextcapabilities.GL_ARB_framebuffer_object || contextcapabilities.GL_EXT_framebuffer_object || contextcapabilities.OpenGL30);
        if (l) {
            aa = aa + "Using framebuffer objects because ";
            if (contextcapabilities.OpenGL30) {
                aa = aa + "OpenGL 3.0 is supported and separate blending is supported.\n";
                U = cig$a.a;
                c = 36160;
                d = 36161;
                e = 36064;
                f = 36096;
                g = 36053;
                h = 36054;
                i = 36055;
                j = 36059;
                k = 36060;
            } else if (contextcapabilities.GL_ARB_framebuffer_object) {
                aa = aa + "ARB_framebuffer_object is supported and separate blending is supported.\n";
                U = cig$a.b;
                c = 36160;
                d = 36161;
                e = 36064;
                f = 36096;
                g = 36053;
                i = 36055;
                h = 36054;
                j = 36059;
                k = 36060;
            } else if (contextcapabilities.GL_EXT_framebuffer_object) {
                aa = aa + "EXT_framebuffer_object is supported.\n";
                U = cig$a.c;
                c = 36160;
                d = 36161;
                e = 36064;
                f = 36096;
                g = 36053;
                i = 36055;
                h = 36054;
                j = 36059;
                k = 36060;
            }
        } else {
            aa = aa + "Not using framebuffer objects because ";
            aa = aa + "OpenGL 1.4 is " + (contextcapabilities.OpenGL14 ? "" : "not ") + "supported, ";
            aa = aa + "EXT_blend_func_separate is " + (contextcapabilities.GL_EXT_blend_func_separate ? "" : "not ") + "supported, ";
            aa = aa + "OpenGL 3.0 is " + (contextcapabilities.OpenGL30 ? "" : "not ") + "supported, ";
            aa = aa + "ARB_framebuffer_object is " + (contextcapabilities.GL_ARB_framebuffer_object ? "" : "not ") + "supported, and ";
            aa = aa + "EXT_framebuffer_object is " + (contextcapabilities.GL_EXT_framebuffer_object ? "" : "not ") + "supported.\n";
        }
        N = contextcapabilities.OpenGL21;
        V = N || contextcapabilities.GL_ARB_vertex_shader && contextcapabilities.GL_ARB_fragment_shader && contextcapabilities.GL_ARB_shader_objects;
        aa = aa + "Shaders are " + (V ? "" : "not ") + "available because ";
        if (V) {
            if (contextcapabilities.OpenGL21) {
                aa = aa + "OpenGL 2.1 is supported.\n";
                W = false;
                m = 35714;
                n = 35713;
                o = 35633;
                p = 35632;
            } else {
                aa = aa + "ARB_shader_objects, ARB_vertex_shader, and ARB_fragment_shader are supported.\n";
                W = true;
                m = 35714;
                n = 35713;
                o = 35633;
                p = 35632;
            }
        } else {
            aa = aa + "OpenGL 2.1 is " + (contextcapabilities.OpenGL21 ? "" : "not ") + "supported, ";
            aa = aa + "ARB_shader_objects is " + (contextcapabilities.GL_ARB_shader_objects ? "" : "not ") + "supported, ";
            aa = aa + "ARB_vertex_shader is " + (contextcapabilities.GL_ARB_vertex_shader ? "" : "not ") + "supported, and ";
            aa = aa + "ARB_fragment_shader is " + (contextcapabilities.GL_ARB_fragment_shader ? "" : "not ") + "supported.\n";
        }
        O = l && V;
        String s2 = GL11.glGetString((int)7936).toLowerCase(Locale.ROOT);
        a = s2.contains("nvidia");
        ac = !contextcapabilities.OpenGL15 && contextcapabilities.GL_ARB_vertex_buffer_object;
        P = contextcapabilities.OpenGL15 || ac;
        aa = aa + "VBOs are " + (P ? "" : "not ") + "available because ";
        if (P) {
            if (ac) {
                aa = aa + "ARB_vertex_buffer_object is supported.\n";
                S = 35044;
                R = 34962;
            } else {
                aa = aa + "OpenGL 1.5 is supported.\n";
                S = 35044;
                R = 34962;
            }
        }
        if (b = s2.contains("ati")) {
            if (P) {
                Q = true;
            } else {
                bib.a.f.a(16.0f);
            }
        }
        try {
            Processor[] aprocessor = new SystemInfo().getHardware().getProcessors();
            ab = String.format("%dx %s", new Object[]{aprocessor.length, aprocessor[0]}).replaceAll("\\s+", " ");
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    public static boolean b() {
        return O;
    }

    public static String c() {
        return aa;
    }

    public static int a(int program, int pname) {
        return W ? ARBShaderObjects.glGetObjectParameteriARB((int)program, (int)pname) : GL20.glGetProgrami((int)program, (int)pname);
    }

    public static void b(int program, int shaderIn) {
        if (W) {
            ARBShaderObjects.glAttachObjectARB((int)program, (int)shaderIn);
        } else {
            GL20.glAttachShader((int)program, (int)shaderIn);
        }
    }

    public static void a(int shaderIn) {
        if (W) {
            ARBShaderObjects.glDeleteObjectARB((int)shaderIn);
        } else {
            GL20.glDeleteShader((int)shaderIn);
        }
    }

    public static int b(int type) {
        return W ? ARBShaderObjects.glCreateShaderObjectARB((int)type) : GL20.glCreateShader((int)type);
    }

    public static void a(int shaderIn, ByteBuffer string) {
        if (W) {
            ARBShaderObjects.glShaderSourceARB((int)shaderIn, (ByteBuffer)string);
        } else {
            GL20.glShaderSource((int)shaderIn, (ByteBuffer)string);
        }
    }

    public static void c(int shaderIn) {
        if (W) {
            ARBShaderObjects.glCompileShaderARB((int)shaderIn);
        } else {
            GL20.glCompileShader((int)shaderIn);
        }
    }

    public static int c(int shaderIn, int pname) {
        return W ? ARBShaderObjects.glGetObjectParameteriARB((int)shaderIn, (int)pname) : GL20.glGetShaderi((int)shaderIn, (int)pname);
    }

    public static String d(int shaderIn, int maxLength) {
        return W ? ARBShaderObjects.glGetInfoLogARB((int)shaderIn, (int)maxLength) : GL20.glGetShaderInfoLog((int)shaderIn, (int)maxLength);
    }

    public static String e(int program, int maxLength) {
        return W ? ARBShaderObjects.glGetInfoLogARB((int)program, (int)maxLength) : GL20.glGetProgramInfoLog((int)program, (int)maxLength);
    }

    public static void d(int program) {
        if (W) {
            ARBShaderObjects.glUseProgramObjectARB((int)program);
        } else {
            GL20.glUseProgram((int)program);
        }
    }

    public static int d() {
        return W ? ARBShaderObjects.glCreateProgramObjectARB() : GL20.glCreateProgram();
    }

    public static void e(int program) {
        if (W) {
            ARBShaderObjects.glDeleteObjectARB((int)program);
        } else {
            GL20.glDeleteProgram((int)program);
        }
    }

    public static void f(int program) {
        if (W) {
            ARBShaderObjects.glLinkProgramARB((int)program);
        } else {
            GL20.glLinkProgram((int)program);
        }
    }

    public static int a(int programObj, CharSequence name) {
        return W ? ARBShaderObjects.glGetUniformLocationARB((int)programObj, (CharSequence)name) : GL20.glGetUniformLocation((int)programObj, (CharSequence)name);
    }

    public static void a(int location, IntBuffer values) {
        if (W) {
            ARBShaderObjects.glUniform1ARB((int)location, (IntBuffer)values);
        } else {
            GL20.glUniform1((int)location, (IntBuffer)values);
        }
    }

    public static void f(int location, int v0) {
        if (W) {
            ARBShaderObjects.glUniform1iARB((int)location, (int)v0);
        } else {
            GL20.glUniform1i((int)location, (int)v0);
        }
    }

    public static void a(int location, FloatBuffer values) {
        if (W) {
            ARBShaderObjects.glUniform1ARB((int)location, (FloatBuffer)values);
        } else {
            GL20.glUniform1((int)location, (FloatBuffer)values);
        }
    }

    public static void b(int location, IntBuffer values) {
        if (W) {
            ARBShaderObjects.glUniform2ARB((int)location, (IntBuffer)values);
        } else {
            GL20.glUniform2((int)location, (IntBuffer)values);
        }
    }

    public static void b(int location, FloatBuffer values) {
        if (W) {
            ARBShaderObjects.glUniform2ARB((int)location, (FloatBuffer)values);
        } else {
            GL20.glUniform2((int)location, (FloatBuffer)values);
        }
    }

    public static void c(int location, IntBuffer values) {
        if (W) {
            ARBShaderObjects.glUniform3ARB((int)location, (IntBuffer)values);
        } else {
            GL20.glUniform3((int)location, (IntBuffer)values);
        }
    }

    public static void c(int location, FloatBuffer values) {
        if (W) {
            ARBShaderObjects.glUniform3ARB((int)location, (FloatBuffer)values);
        } else {
            GL20.glUniform3((int)location, (FloatBuffer)values);
        }
    }

    public static void d(int location, IntBuffer values) {
        if (W) {
            ARBShaderObjects.glUniform4ARB((int)location, (IntBuffer)values);
        } else {
            GL20.glUniform4((int)location, (IntBuffer)values);
        }
    }

    public static void d(int location, FloatBuffer values) {
        if (W) {
            ARBShaderObjects.glUniform4ARB((int)location, (FloatBuffer)values);
        } else {
            GL20.glUniform4((int)location, (FloatBuffer)values);
        }
    }

    public static void a(int location, boolean transpose, FloatBuffer matrices) {
        if (W) {
            ARBShaderObjects.glUniformMatrix2ARB((int)location, (boolean)transpose, (FloatBuffer)matrices);
        } else {
            GL20.glUniformMatrix2((int)location, (boolean)transpose, (FloatBuffer)matrices);
        }
    }

    public static void b(int location, boolean transpose, FloatBuffer matrices) {
        if (W) {
            ARBShaderObjects.glUniformMatrix3ARB((int)location, (boolean)transpose, (FloatBuffer)matrices);
        } else {
            GL20.glUniformMatrix3((int)location, (boolean)transpose, (FloatBuffer)matrices);
        }
    }

    public static void c(int location, boolean transpose, FloatBuffer matrices) {
        if (W) {
            ARBShaderObjects.glUniformMatrix4ARB((int)location, (boolean)transpose, (FloatBuffer)matrices);
        } else {
            GL20.glUniformMatrix4((int)location, (boolean)transpose, (FloatBuffer)matrices);
        }
    }

    public static int b(int program, CharSequence name) {
        return W ? ARBVertexShader.glGetAttribLocationARB((int)program, (CharSequence)name) : GL20.glGetAttribLocation((int)program, (CharSequence)name);
    }

    public static int e() {
        return ac ? ARBVertexBufferObject.glGenBuffersARB() : GL15.glGenBuffers();
    }

    public static void g(int target, int buffer) {
        if (ac) {
            ARBVertexBufferObject.glBindBufferARB((int)target, (int)buffer);
        } else {
            GL15.glBindBuffer((int)target, (int)buffer);
        }
    }

    public static void a(int target, ByteBuffer data, int usage) {
        if (ac) {
            ARBVertexBufferObject.glBufferDataARB((int)target, (ByteBuffer)data, (int)usage);
        } else {
            GL15.glBufferData((int)target, (ByteBuffer)data, (int)usage);
        }
    }

    public static void g(int buffer) {
        if (ac) {
            ARBVertexBufferObject.glDeleteBuffersARB((int)buffer);
        } else {
            GL15.glDeleteBuffers((int)buffer);
        }
    }

    public static boolean f() {
        if (Config.isMultiTexture()) {
            return false;
        }
        return P && bhz.z().t.w;
    }

    public static void h(int target, int framebufferIn) {
        if (l) {
            switch (U) {
                case a: {
                    GL30.glBindFramebuffer((int)target, (int)framebufferIn);
                    break;
                }
                case b: {
                    ARBFramebufferObject.glBindFramebuffer((int)target, (int)framebufferIn);
                    break;
                }
                case c: {
                    EXTFramebufferObject.glBindFramebufferEXT((int)target, (int)framebufferIn);
                }
            }
        }
    }

    public static void i(int target, int renderbuffer) {
        if (l) {
            switch (U) {
                case a: {
                    GL30.glBindRenderbuffer((int)target, (int)renderbuffer);
                    break;
                }
                case b: {
                    ARBFramebufferObject.glBindRenderbuffer((int)target, (int)renderbuffer);
                    break;
                }
                case c: {
                    EXTFramebufferObject.glBindRenderbufferEXT((int)target, (int)renderbuffer);
                }
            }
        }
    }

    public static void h(int renderbuffer) {
        if (l) {
            switch (U) {
                case a: {
                    GL30.glDeleteRenderbuffers((int)renderbuffer);
                    break;
                }
                case b: {
                    ARBFramebufferObject.glDeleteRenderbuffers((int)renderbuffer);
                    break;
                }
                case c: {
                    EXTFramebufferObject.glDeleteRenderbuffersEXT((int)renderbuffer);
                }
            }
        }
    }

    public static void i(int framebufferIn) {
        if (l) {
            switch (U) {
                case a: {
                    GL30.glDeleteFramebuffers((int)framebufferIn);
                    break;
                }
                case b: {
                    ARBFramebufferObject.glDeleteFramebuffers((int)framebufferIn);
                    break;
                }
                case c: {
                    EXTFramebufferObject.glDeleteFramebuffersEXT((int)framebufferIn);
                }
            }
        }
    }

    public static int g() {
        if (!l) {
            return -1;
        }
        switch (U) {
            case a: {
                return GL30.glGenFramebuffers();
            }
            case b: {
                return ARBFramebufferObject.glGenFramebuffers();
            }
            case c: {
                return EXTFramebufferObject.glGenFramebuffersEXT();
            }
        }
        return -1;
    }

    public static int h() {
        if (!l) {
            return -1;
        }
        switch (U) {
            case a: {
                return GL30.glGenRenderbuffers();
            }
            case b: {
                return ARBFramebufferObject.glGenRenderbuffers();
            }
            case c: {
                return EXTFramebufferObject.glGenRenderbuffersEXT();
            }
        }
        return -1;
    }

    public static void a(int target, int internalFormat, int width, int height) {
        if (l) {
            switch (U) {
                case a: {
                    GL30.glRenderbufferStorage((int)target, (int)internalFormat, (int)width, (int)height);
                    break;
                }
                case b: {
                    ARBFramebufferObject.glRenderbufferStorage((int)target, (int)internalFormat, (int)width, (int)height);
                    break;
                }
                case c: {
                    EXTFramebufferObject.glRenderbufferStorageEXT((int)target, (int)internalFormat, (int)width, (int)height);
                }
            }
        }
    }

    public static void b(int target, int attachment, int renderBufferTarget, int renderBuffer) {
        if (l) {
            switch (U) {
                case a: {
                    GL30.glFramebufferRenderbuffer((int)target, (int)attachment, (int)renderBufferTarget, (int)renderBuffer);
                    break;
                }
                case b: {
                    ARBFramebufferObject.glFramebufferRenderbuffer((int)target, (int)attachment, (int)renderBufferTarget, (int)renderBuffer);
                    break;
                }
                case c: {
                    EXTFramebufferObject.glFramebufferRenderbufferEXT((int)target, (int)attachment, (int)renderBufferTarget, (int)renderBuffer);
                }
            }
        }
    }

    public static int j(int target) {
        if (!l) {
            return -1;
        }
        switch (U) {
            case a: {
                return GL30.glCheckFramebufferStatus((int)target);
            }
            case b: {
                return ARBFramebufferObject.glCheckFramebufferStatus((int)target);
            }
            case c: {
                return EXTFramebufferObject.glCheckFramebufferStatusEXT((int)target);
            }
        }
        return -1;
    }

    public static void a(int target, int attachment, int textarget, int texture, int level) {
        if (l) {
            switch (U) {
                case a: {
                    GL30.glFramebufferTexture2D((int)target, (int)attachment, (int)textarget, (int)texture, (int)level);
                    break;
                }
                case b: {
                    ARBFramebufferObject.glFramebufferTexture2D((int)target, (int)attachment, (int)textarget, (int)texture, (int)level);
                    break;
                }
                case c: {
                    EXTFramebufferObject.glFramebufferTexture2DEXT((int)target, (int)attachment, (int)textarget, (int)texture, (int)level);
                }
            }
        }
    }

    public static void k(int texture) {
        if (X) {
            ARBMultitexture.glActiveTextureARB((int)texture);
        } else {
            GL13.glActiveTexture((int)texture);
        }
    }

    public static void l(int texture) {
        if (X) {
            ARBMultitexture.glClientActiveTextureARB((int)texture);
        } else {
            GL13.glClientActiveTexture((int)texture);
        }
    }

    public static void a(int target, float p_77475_1_, float t2) {
        if (X) {
            ARBMultitexture.glMultiTexCoord2fARB((int)target, (float)p_77475_1_, (float)t2);
        } else {
            GL13.glMultiTexCoord2f((int)target, (float)p_77475_1_, (float)t2);
        }
        if (target == r) {
            lastBrightnessX = p_77475_1_;
            lastBrightnessY = t2;
        }
    }

    public static void c(int sFactorRGB, int dFactorRGB, int sfactorAlpha, int dfactorAlpha) {
        if (Z) {
            if (M) {
                EXTBlendFuncSeparate.glBlendFuncSeparateEXT((int)sFactorRGB, (int)dFactorRGB, (int)sfactorAlpha, (int)dfactorAlpha);
            } else {
                GL14.glBlendFuncSeparate((int)sFactorRGB, (int)dFactorRGB, (int)sfactorAlpha, (int)dfactorAlpha);
            }
        } else {
            GL11.glBlendFunc((int)sFactorRGB, (int)dFactorRGB);
        }
    }

    public static boolean j() {
        if (Config.isFastRender()) {
            return false;
        }
        if (Config.isAntialiasing()) {
            return false;
        }
        return l && bhz.z().t.h;
    }

    public static String k() {
        return ab == null ? "<unknown>" : ab;
    }

    public static void m(int p_188785_0_) {
        buq.z();
        buq.a(false);
        bvc tessellator = bvc.a();
        bui bufferbuilder = tessellator.c();
        GL11.glLineWidth((float)4.0f);
        bufferbuilder.a(1, cdw.f);
        bufferbuilder.b(0.0, 0.0, 0.0).b(0, 0, 0, 255).d();
        bufferbuilder.b((double)p_188785_0_, 0.0, 0.0).b(0, 0, 0, 255).d();
        bufferbuilder.b(0.0, 0.0, 0.0).b(0, 0, 0, 255).d();
        bufferbuilder.b(0.0, (double)p_188785_0_, 0.0).b(0, 0, 0, 255).d();
        bufferbuilder.b(0.0, 0.0, 0.0).b(0, 0, 0, 255).d();
        bufferbuilder.b(0.0, 0.0, (double)p_188785_0_).b(0, 0, 0, 255).d();
        tessellator.b();
        GL11.glLineWidth((float)2.0f);
        bufferbuilder.a(1, cdw.f);
        bufferbuilder.b(0.0, 0.0, 0.0).b(255, 0, 0, 255).d();
        bufferbuilder.b((double)p_188785_0_, 0.0, 0.0).b(255, 0, 0, 255).d();
        bufferbuilder.b(0.0, 0.0, 0.0).b(0, 255, 0, 255).d();
        bufferbuilder.b(0.0, (double)p_188785_0_, 0.0).b(0, 255, 0, 255).d();
        bufferbuilder.b(0.0, 0.0, 0.0).b(127, 127, 255, 255).d();
        bufferbuilder.b(0.0, 0.0, (double)p_188785_0_).b(127, 127, 255, 255).d();
        tessellator.b();
        GL11.glLineWidth((float)1.0f);
        buq.a(true);
        buq.y();
    }

    public static void a(File fileIn) {
        String s2 = fileIn.getAbsolutePath();
        if (h.a() == h.a.d) {
            try {
                T.info(s2);
                Runtime.getRuntime().exec(new String[]{"/usr/bin/open", s2});
                return;
            }
            catch (IOException ioexception1) {
                T.error("Couldn't open file", (Throwable)ioexception1);
            }
        } else if (h.a() == h.a.c) {
            String s1 = String.format("cmd.exe /C start \"Open file\" \"%s\"", s2);
            try {
                Runtime.getRuntime().exec(s1);
                return;
            }
            catch (IOException ioexception) {
                T.error("Couldn't open file", (Throwable)ioexception);
            }
        }
        boolean flag = false;
        try {
            Class<?> oclass = Class.forName("java.awt.Desktop");
            Object object = oclass.getMethod("getDesktop", new Class[0]).invoke(null, new Object[0]);
            oclass.getMethod("browse", URI.class).invoke(object, fileIn.toURI());
        }
        catch (Throwable throwable1) {
            T.error("Couldn't open link", throwable1);
            flag = true;
        }
        if (flag) {
            T.info("Opening via system class!");
            Sys.openURL((String)("file://" + s2));
        }
    }

    static {
        aa = "";
        lastBrightnessX = 0.0f;
        lastBrightnessY = 0.0f;
    }

    static enum a {
        a,
        b,
        c;

    }
}

