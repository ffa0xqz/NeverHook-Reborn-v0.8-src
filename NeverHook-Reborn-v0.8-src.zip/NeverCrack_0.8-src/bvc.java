/*
 * Decompiled with CFR 0.150.
 */
public class bvc {
    private final bui a;
    private final buj b = new buj();
    private static final bvc c = new bvc(0x200000);

    public static bvc a() {
        return c;
    }

    public bvc(int n2) {
        this.a = new bui(n2);
    }

    public void b() {
        this.a.e();
        this.b.a(this.a);
    }

    public bui c() {
        return this.a;
    }
}

