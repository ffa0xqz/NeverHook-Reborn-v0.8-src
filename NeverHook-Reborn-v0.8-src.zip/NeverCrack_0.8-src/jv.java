/*
 * Decompiled with CFR 0.150.
 */
import java.io.IOException;

public class jv
implements ht<hw> {
    private int a;
    private tx b;
    private amq c;
    private amx d;

    public jv() {
    }

    public jv(int n2, tx tx2, amx amx2, amq amq2) {
        this.a = n2;
        this.b = tx2;
        this.c = amq2;
        this.d = amx2;
    }

    @Override
    public void a(hw hw2) {
        hw2.a(this);
    }

    @Override
    public void a(gy gy2) throws IOException {
        this.a = gy2.readInt();
        this.b = tx.a(gy2.readUnsignedByte());
        this.c = amq.a(gy2.readUnsignedByte());
        this.d = amx.a(gy2.e(16));
        if (this.d == null) {
            this.d = amx.b;
        }
    }

    @Override
    public void b(gy gy2) throws IOException {
        gy2.writeInt(this.a);
        gy2.writeByte(this.b.a());
        gy2.writeByte(this.c.a());
        gy2.a(this.d.a());
    }

    public int a() {
        return this.a;
    }

    public tx b() {
        return this.b;
    }

    public amq c() {
        return this.c;
    }

    public amx d() {
        return this.d;
    }
}

