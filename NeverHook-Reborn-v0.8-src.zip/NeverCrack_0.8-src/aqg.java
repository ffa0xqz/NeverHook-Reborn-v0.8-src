/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicates
 *  javax.annotation.Nullable
 */
import com.google.common.base.Predicates;
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;

public class aqg
extends aou {
    public static final axe a = ark.D;
    public static final axd b = axd.a("eye");
    protected static final bgz c = new bgz(0.0, 0.0, 0.0, 1.0, 0.8125, 1.0);
    protected static final bgz d = new bgz(0.3125, 0.8125, 0.3125, 0.6875, 1.0, 0.6875);
    private static awv e;

    public aqg() {
        super(bcx.e, bcy.D);
        this.w(this.A.b().a(a, fa.c).a(b, false));
    }

    @Override
    public boolean b(awr awr2) {
        return false;
    }

    @Override
    public bgz b(awr awr2, amw amw2, et et2) {
        return c;
    }

    @Override
    public void a(awr awr2, ams ams2, et et2, bgz bgz2, List<bgz> list, @Nullable ve ve2, boolean bl2) {
        aqg.a(et2, bgz2, list, c);
        if (ams2.o(et2).c(b).booleanValue()) {
            aqg.a(et2, bgz2, list, d);
        }
    }

    @Override
    public ail a(awr awr2, Random random, int n2) {
        return aip.a;
    }

    @Override
    public awr a(ams ams2, et et2, fa fa2, float f2, float f3, float f4, int n2, vn vn2) {
        return this.t().a(a, vn2.bt().d()).a(b, false);
    }

    @Override
    public boolean v(awr awr2) {
        return true;
    }

    @Override
    public int c(awr awr2, ams ams2, et et2) {
        if (awr2.c(b).booleanValue()) {
            return 15;
        }
        return 0;
    }

    @Override
    public awr a(int n2) {
        return this.t().a(b, (n2 & 4) != 0).a(a, fa.b(n2 & 3));
    }

    @Override
    public int e(awr awr2) {
        int n2 = 0;
        n2 |= awr2.c(a).b();
        if (awr2.c(b).booleanValue()) {
            n2 |= 4;
        }
        return n2;
    }

    @Override
    public awr a(awr awr2, atk atk2) {
        return awr2.a(a, atk2.a(awr2.c(a)));
    }

    @Override
    public awr a(awr awr2, arw arw2) {
        return awr2.a(arw2.a(awr2.c(a)));
    }

    @Override
    protected aws b() {
        return new aws((aou)this, a, b);
    }

    @Override
    public boolean c(awr awr2) {
        return false;
    }

    public static awv e() {
        if (e == null) {
            e = aww.a().a("?vvv?", ">???<", ">???<", ">???<", "?^^^?").a('?', awu.a(axa.a)).a('^', awu.a(axa.a(aov.bG).a(b, Predicates.equalTo((Object)true)).a(a, Predicates.equalTo((Object)fa.d)))).a('>', awu.a(axa.a(aov.bG).a(b, Predicates.equalTo((Object)true)).a(a, Predicates.equalTo((Object)fa.e)))).a('v', awu.a(axa.a(aov.bG).a(b, Predicates.equalTo((Object)true)).a(a, Predicates.equalTo((Object)fa.c)))).a('<', awu.a(axa.a(aov.bG).a(b, Predicates.equalTo((Object)true)).a(a, Predicates.equalTo((Object)fa.f)))).b();
        }
        return e;
    }

    @Override
    public awp a(amw amw2, awr awr2, et et2, fa fa2) {
        if (fa2 == fa.a) {
            return awp.a;
        }
        return awp.i;
    }
}

