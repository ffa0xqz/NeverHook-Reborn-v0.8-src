/*
 * Decompiled with CFR 0.150.
 */
import java.util.Random;

public abstract class ard
extends aou {
    public static final axf<a> a = axf.a("half", a.class);
    protected static final bgz b = new bgz(0.0, 0.0, 0.0, 1.0, 0.5, 1.0);
    protected static final bgz c = new bgz(0.0, 0.5, 0.0, 1.0, 1.0, 1.0);

    public ard(bcx bcx2) {
        this(bcx2, bcx2.r());
    }

    public ard(bcx bcx2, bcy bcy2) {
        super(bcx2, bcy2);
        this.l = this.e();
        this.e(255);
    }

    @Override
    protected boolean n() {
        return false;
    }

    @Override
    public bgz b(awr awr2, amw amw2, et et2) {
        if (this.e()) {
            return j;
        }
        return awr2.c(a) == ard$a.a ? c : b;
    }

    @Override
    public boolean k(awr awr2) {
        return ((ard)awr2.u()).e() || awr2.c(a) == ard$a.a;
    }

    @Override
    public awp a(amw amw2, awr awr2, et et2, fa fa2) {
        if (((ard)awr2.u()).e()) {
            return awp.a;
        }
        if (fa2 == fa.b && awr2.c(a) == ard$a.a) {
            return awp.a;
        }
        if (fa2 == fa.a && awr2.c(a) == ard$a.b) {
            return awp.a;
        }
        return awp.i;
    }

    @Override
    public boolean b(awr awr2) {
        return this.e();
    }

    @Override
    public awr a(ams ams2, et et2, fa fa2, float f2, float f3, float f4, int n2, vn vn2) {
        awr awr2 = super.a(ams2, et2, fa2, f2, f3, f4, n2, vn2).a(a, ard$a.b);
        if (this.e()) {
            return awr2;
        }
        if (fa2 == fa.a || fa2 != fa.b && (double)f3 > 0.5) {
            return awr2.a(a, ard$a.a);
        }
        return awr2;
    }

    @Override
    public int a(Random random) {
        if (this.e()) {
            return 2;
        }
        return 1;
    }

    @Override
    public boolean c(awr awr2) {
        return this.e();
    }

    @Override
    public boolean a(awr awr2, amw amw2, et et2, fa fa2) {
        if (this.e()) {
            return super.a(awr2, amw2, et2, fa2);
        }
        if (fa2 != fa.b && fa2 != fa.a && !super.a(awr2, amw2, et2, fa2)) {
            return false;
        }
        awr awr3 = amw2.o(et2.a(fa2));
        boolean \u26032 = ard.x(awr3) && awr3.c(a) == ard$a.a;
        boolean bl2 = \u2603 = ard.x(awr2) && awr2.c(a) == ard$a.a;
        if (\u2603) {
            if (fa2 == fa.a) {
                return true;
            }
            if (fa2 == fa.b && super.a(awr2, amw2, et2, fa2)) {
                return true;
            }
            return !ard.x(awr3) || !\u26032;
        }
        if (fa2 == fa.b) {
            return true;
        }
        if (fa2 == fa.a && super.a(awr2, amw2, et2, fa2)) {
            return true;
        }
        return !ard.x(awr3) || \u26032;
    }

    protected static boolean x(awr awr2) {
        aou aou2 = awr2.u();
        return aou2 == aov.U || aou2 == aov.bM || aou2 == aov.cP || aou2 == aov.cX;
    }

    public abstract String b(int var1);

    public abstract boolean e();

    public abstract axh<?> g();

    public abstract Comparable<?> a(ain var1);

    public static enum a implements rm
    {
        a("top"),
        b("bottom");

        private final String c;

        private a(String string2) {
            this.c = string2;
        }

        public String toString() {
            return this.c;
        }

        @Override
        public String m() {
            return this.c;
        }
    }
}

