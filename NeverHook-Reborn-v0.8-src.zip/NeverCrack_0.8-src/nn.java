/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Maps
 *  com.google.common.collect.Sets
 *  com.google.common.io.Files
 *  com.google.gson.Gson
 *  com.google.gson.GsonBuilder
 *  com.google.gson.JsonParseException
 *  com.google.gson.reflect.TypeToken
 *  javax.annotation.Nullable
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.common.io.Files;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import com.google.gson.reflect.TypeToken;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class nn {
    private static final Logger a = LogManager.getLogger();
    private static final Gson b = new GsonBuilder().registerTypeAdapter(k.class, (Object)new k.a()).registerTypeAdapter(nd.class, (Object)new nd.a()).setPrettyPrinting().create();
    private static final TypeToken<Map<nd, k>> c = new TypeToken<Map<nd, k>>(){};
    private final MinecraftServer d;
    private final File e;
    private final Map<i, k> f = Maps.newLinkedHashMap();
    private final Set<i> g = Sets.newLinkedHashSet();
    private final Set<i> h = Sets.newLinkedHashSet();
    private final Set<i> i = Sets.newLinkedHashSet();
    private oo j;
    @Nullable
    private i k;
    private boolean l = true;

    public nn(MinecraftServer minecraftServer, File file, oo oo2) {
        this.d = minecraftServer;
        this.e = file;
        this.j = oo2;
        this.g();
    }

    public void a(oo oo2) {
        this.j = oo2;
    }

    public void a() {
        for (p<?> p2 : m.a()) {
            p2.a(this);
        }
    }

    public void b() {
        this.a();
        this.f.clear();
        this.g.clear();
        this.h.clear();
        this.i.clear();
        this.l = true;
        this.k = null;
        this.g();
    }

    private void d() {
        for (i i2 : this.d.aK().c()) {
            this.c(i2);
        }
    }

    private void e() {
        ArrayList arrayList = Lists.newArrayList();
        for (Map.Entry<i, k> \u26032 : this.f.entrySet()) {
            if (!\u26032.getValue().a()) continue;
            arrayList.add(\u26032.getKey());
            this.i.add((i)\u26032.getKey());
        }
        for (Map.Entry<i, k> \u26032 : arrayList) {
            this.e((i)((Object)\u26032));
        }
    }

    private void f() {
        for (i i2 : this.d.aK().c()) {
            if (!i2.f().isEmpty()) continue;
            this.a(i2, "");
            i2.d().a(this.j);
        }
    }

    private void g() {
        if (this.e.isFile()) {
            try {
                String string = Files.toString((File)this.e, (Charset)StandardCharsets.UTF_8);
                Map \u26032 = (Map)ra.a(b, string, c.getType());
                if (\u26032 == null) {
                    throw new JsonParseException("Found null for advancements");
                }
                Stream<Map.Entry> \u26033 = \u26032.entrySet().stream().sorted(Comparator.comparing(Map.Entry::getValue));
                for (Map.Entry entry : \u26033.collect(Collectors.toList())) {
                    i i2 = this.d.aK().a((nd)entry.getKey());
                    if (i2 == null) {
                        a.warn("Ignored advancement '" + entry.getKey() + "' in progress file " + this.e + " - it doesn't exist anymore?");
                        continue;
                    }
                    this.a(i2, (k)entry.getValue());
                }
            }
            catch (JsonParseException jsonParseException) {
                a.error("Couldn't parse player advancements in " + this.e, (Throwable)jsonParseException);
            }
            catch (IOException iOException) {
                a.error("Couldn't access player advancements in " + this.e, (Throwable)iOException);
            }
        }
        this.f();
        this.e();
        this.d();
    }

    public void c() {
        HashMap hashMap = Maps.newHashMap();
        for (Map.Entry<i, k> entry : this.f.entrySet()) {
            k k2 = entry.getValue();
            if (!k2.b()) continue;
            hashMap.put(entry.getKey().h(), k2);
        }
        if (this.e.getParentFile() != null) {
            this.e.getParentFile().mkdirs();
        }
        try {
            Files.write((CharSequence)b.toJson((Object)hashMap), (File)this.e, (Charset)StandardCharsets.UTF_8);
        }
        catch (IOException iOException) {
            a.error("Couldn't save player advancements to " + this.e, (Throwable)iOException);
        }
    }

    public boolean a(i i2, String string) {
        boolean bl2 = false;
        k \u26032 = this.b(i2);
        \u2603 = \u26032.a();
        if (\u26032.a(string)) {
            this.d(i2);
            this.i.add(i2);
            bl2 = true;
            if (!\u2603 && \u26032.a()) {
                i2.d().a(this.j);
                if (i2.c() != null && i2.c().i() && this.j.l.W().b("announceAdvancements")) {
                    this.d.am().a(new hp("chat.type.advancement." + i2.c().e().a(), this.j.i_(), i2.j()));
                }
            }
        }
        if (\u26032.a()) {
            this.e(i2);
        }
        return bl2;
    }

    public boolean b(i i2, String string) {
        boolean bl2 = false;
        k \u26032 = this.b(i2);
        if (\u26032.b(string)) {
            this.c(i2);
            this.i.add(i2);
            bl2 = true;
        }
        if (!\u26032.b()) {
            this.e(i2);
        }
        return bl2;
    }

    private void c(i i2) {
        k k2 = this.b(i2);
        if (k2.a()) {
            return;
        }
        for (Map.Entry<String, n> entry : i2.f().entrySet()) {
            o o2 = k2.c(entry.getKey());
            if (o2 == null || o2.a() || (\u2603 = entry.getValue().a()) == null || (\u2603 = m.a(\u2603.a())) == null) continue;
            \u2603.a(this, new p.a<q>(\u2603, i2, entry.getKey()));
        }
    }

    private void d(i i2) {
        k k2 = this.b(i2);
        for (Map.Entry<String, n> entry : i2.f().entrySet()) {
            o o2 = k2.c(entry.getKey());
            if (o2 == null || !o2.a() && !k2.a() || (\u2603 = entry.getValue().a()) == null || (\u2603 = m.a(\u2603.a())) == null) continue;
            \u2603.b(this, new p.a<q>(\u2603, i2, entry.getKey()));
        }
    }

    public void b(oo oo2) {
        if (!this.h.isEmpty() || !this.i.isEmpty()) {
            HashMap hashMap = Maps.newHashMap();
            LinkedHashSet \u26032 = Sets.newLinkedHashSet();
            LinkedHashSet \u26033 = Sets.newLinkedHashSet();
            for (i i2 : this.i) {
                if (!this.g.contains(i2)) continue;
                hashMap.put(i2.h(), this.f.get(i2));
            }
            for (i i2 : this.h) {
                if (this.g.contains(i2)) {
                    \u26032.add(i2);
                    continue;
                }
                \u26033.add(i2.h());
            }
            if (!(hashMap.isEmpty() && \u26032.isEmpty() && \u26033.isEmpty())) {
                oo2.a.a(new kt(this.l, \u26032, \u26033, hashMap));
                this.h.clear();
                this.i.clear();
            }
        }
        this.l = false;
    }

    public void a(@Nullable i i2) {
        \u2603 = this.k;
        this.k = i2 != null && i2.b() == null && i2.c() != null ? i2 : null;
        if (\u2603 != this.k) {
            this.j.a.a(new jx(this.k == null ? null : this.k.h()));
        }
    }

    public k b(i i2) {
        k k2 = this.f.get(i2);
        if (k2 == null) {
            k2 = new k();
            this.a(i2, k2);
        }
        return k2;
    }

    private void a(i i2, k k2) {
        k2.a(i2.f(), i2.i());
        this.f.put(i2, k2);
    }

    private void e(i i2) {
        boolean bl2 = this.f(i2);
        \u2603 = this.g.contains(i2);
        if (bl2 && !\u2603) {
            this.g.add(i2);
            this.h.add(i2);
            if (this.f.containsKey(i2)) {
                this.i.add(i2);
            }
        } else if (!bl2 && \u2603) {
            this.g.remove(i2);
            this.h.add(i2);
        }
        if (bl2 != \u2603 && i2.b() != null) {
            this.e(i2.b());
        }
        for (i i3 : i2.e()) {
            this.e(i3);
        }
    }

    private boolean f(i i2) {
        for (int n2 = 0; i2 != null && n2 <= 2; i2 = i2.b(), ++n2) {
            if (n2 == 0 && this.g(i2)) {
                return true;
            }
            if (i2.c() == null) {
                return false;
            }
            k k2 = this.b(i2);
            if (k2.a()) {
                return true;
            }
            if (!i2.c().j()) continue;
            return false;
        }
        return false;
    }

    private boolean g(i i2) {
        k k2 = this.b(i2);
        if (k2.a()) {
            return true;
        }
        for (i i3 : i2.e()) {
            if (!this.g(i3)) continue;
            return true;
        }
        return false;
    }
}

