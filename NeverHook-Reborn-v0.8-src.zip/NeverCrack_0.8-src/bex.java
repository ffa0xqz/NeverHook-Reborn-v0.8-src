/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  org.apache.commons.lang3.StringUtils
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.common.collect.Lists;
import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class bex
extends bfa {
    private static final Logger c = LogManager.getLogger();

    public bex(File file, rw rw2) {
        super(file, rw2);
    }

    @Override
    public String a() {
        return "Anvil";
    }

    @Override
    public List<bff> b() throws bfd {
        if (this.a == null || !this.a.exists() || !this.a.isDirectory()) {
            throw new bfd(ft.a("selectWorld.load_folder_access"));
        }
        ArrayList arrayList = Lists.newArrayList();
        for (File file : \u2603 = this.a.listFiles()) {
            if (!file.isDirectory() || (\u2603 = this.c(\u2603 = file.getName())) == null || \u2603.k() != 19132 && \u2603.k() != 19133) continue;
            boolean bl2 = \u2603.k() != this.c();
            String \u26032 = \u2603.j();
            if (StringUtils.isEmpty((CharSequence)\u26032)) {
                \u26032 = \u2603;
            }
            long \u26033 = 0L;
            arrayList.add(new bff(\u2603, \u2603, \u26032, 0L, bl2));
        }
        return arrayList;
    }

    protected int c() {
        return 19133;
    }

    @Override
    public void d() {
        ayi.a();
    }

    @Override
    public bfc a(String string, boolean bl2) {
        return new bew(this.a, string, bl2, this.b);
    }

    @Override
    public boolean a(String string) {
        bfb bfb2 = this.c(string);
        return bfb2 != null && bfb2.k() == 19132;
    }

    @Override
    public boolean b(String string) {
        bfb bfb2 = this.c(string);
        return bfb2 != null && bfb2.k() != this.c();
    }

    @Override
    public boolean a(String string, rk rk2) {
        rk2.a(0);
        ArrayList arrayList = Lists.newArrayList();
        \u2603 = Lists.newArrayList();
        \u2603 = Lists.newArrayList();
        File \u26032 = new File(this.a, string);
        File \u26033 = new File(\u26032, "DIM-1");
        File \u26034 = new File(\u26032, "DIM1");
        c.info("Scanning folders...");
        this.a(\u26032, arrayList);
        if (\u26033.exists()) {
            this.a(\u26033, \u2603);
        }
        if (\u26034.exists()) {
            this.a(\u26034, \u2603);
        }
        int \u26035 = arrayList.size() + \u2603.size() + \u2603.size();
        c.info("Total conversion count is {}", (Object)\u26035);
        bfb \u26036 = this.c(string);
        anj \u26037 = \u26036 != null && \u26036.t() == amx.c ? new ano(ank.c) : new anj(\u26036);
        this.a(new File(\u26032, "region"), arrayList, \u26037, 0, \u26035, rk2);
        this.a(new File(\u26033, "region"), \u2603, (anj)new ano(ank.j), arrayList.size(), \u26035, rk2);
        this.a(new File(\u26034, "region"), \u2603, (anj)new ano(ank.k), arrayList.size() + \u2603.size(), \u26035, rk2);
        \u26036.e(19133);
        if (\u26036.t() == amx.h) {
            \u26036.a(amx.b);
        }
        this.g(string);
        bfc \u26038 = this.a(string, false);
        \u26038.a(\u26036);
        return true;
    }

    private void g(String string) {
        File file = new File(this.a, string);
        if (!file.exists()) {
            c.warn("Unable to create level.dat_mcr backup");
            return;
        }
        \u2603 = new File(file, "level.dat");
        if (!\u2603.exists()) {
            c.warn("Unable to create level.dat_mcr backup");
            return;
        }
        \u2603 = new File(file, "level.dat_mcr");
        if (!\u2603.renameTo(\u2603)) {
            c.warn("Unable to create level.dat_mcr backup");
        }
    }

    private void a(File file, Iterable<File> iterable, anj anj2, int n2, int n3, rk rk2) {
        for (File file2 : iterable) {
            this.a(file, file2, anj2, n2, n3, rk2);
            int n4 = (int)Math.round(100.0 * (double)(++n2) / (double)n3);
            rk2.a(n4);
        }
    }

    private void a(File file, File file2, anj anj2, int n2, int n3, rk rk2) {
        try {
            String string = file2.getName();
            ayh \u26032 = new ayh(file2);
            ayh \u26033 = new ayh(new File(file, string.substring(0, string.length() - ".mcr".length()) + ".mca"));
            for (int i2 = 0; i2 < 32; ++i2) {
                for (n4 = 0; n4 < 32; ++n4) {
                    if (!\u26032.c(i2, n4) || \u26033.c(i2, n4)) continue;
                    DataInputStream dataInputStream = \u26032.a(i2, n4);
                    if (dataInputStream == null) {
                        c.warn("Failed to fetch input stream");
                        continue;
                    }
                    fy \u26034 = gi.a(dataInputStream);
                    dataInputStream.close();
                    fy \u26035 = \u26034.p("Level");
                    ayg.a \u26036 = ayg.a(\u26035);
                    fy \u26037 = new fy();
                    fy \u26038 = new fy();
                    \u26037.a("Level", \u26038);
                    ayg.a(\u26036, \u26038, anj2);
                    DataOutputStream \u26039 = \u26033.b(i2, n4);
                    gi.a(\u26037, (DataOutput)\u26039);
                    \u26039.close();
                }
                int n4 = (int)Math.round(100.0 * (double)(n2 * 1024) / (double)(n3 * 1024));
                \u2603 = (int)Math.round(100.0 * (double)((i2 + 1) * 32 + n2 * 1024) / (double)(n3 * 1024));
                if (\u2603 <= n4) continue;
                rk2.a(\u2603);
            }
            \u26032.c();
            \u26033.c();
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
    }

    private void a(File file, Collection<File> collection) {
        File file2 = new File(file, "region");
        File[] \u26032 = file2.listFiles(new FilenameFilter(){

            @Override
            public boolean accept(File file, String string) {
                return string.endsWith(".mcr");
            }
        });
        if (\u26032 != null) {
            Collections.addAll(collection, \u26032);
        }
    }
}

