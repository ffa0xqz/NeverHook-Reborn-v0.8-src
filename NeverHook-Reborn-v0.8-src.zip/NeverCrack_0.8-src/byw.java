/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import javax.annotation.Nullable;

public class byw
extends bze<ve> {
    public byw(bzd bzd2) {
        super(bzd2);
    }

    @Override
    public void a(ve ve2, double d2, double d3, double d4, float f2, float f3) {
        buq.G();
        byw.a(ve2.bw(), d2 - ve2.M, d3 - ve2.N, d4 - ve2.O);
        buq.H();
        super.a(ve2, d2, d3, d4, f2, f3);
    }

    @Override
    @Nullable
    protected nd a(ve ve2) {
        return null;
    }
}

