/*
 * Decompiled with CFR 0.150.
 */
public class cgj
extends cgi {
    private final bub m;
    private int n;

    public cgj(bub bub2) {
        super(qd.aQ, qe.h);
        this.m = bub2;
        this.i = true;
        this.j = 0;
        this.d = 0.1f;
    }

    @Override
    public void e() {
        ++this.n;
        if (this.m.F || this.n > 20 && !this.m.cP()) {
            this.l = true;
            return;
        }
        this.f = (float)this.m.p;
        this.g = (float)this.m.q;
        this.h = (float)this.m.r;
        float f2 = ri.a(this.m.s * this.m.s + this.m.u * this.m.u + this.m.t * this.m.t);
        \u2603 = f2 / 2.0f;
        this.d = (double)f2 >= 0.01 ? ri.a(\u2603 * \u2603, 0.0f, 1.0f) : 0.0f;
        if (this.n < 20) {
            this.d = 0.0f;
        } else if (this.n < 40) {
            this.d = (float)((double)this.d * ((double)(this.n - 20) / 20.0));
        }
        \u2603 = 0.8f;
        this.e = this.d > 0.8f ? 1.0f + (this.d - 0.8f) : 1.0f;
    }
}

