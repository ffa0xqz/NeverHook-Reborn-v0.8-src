/*
 * Decompiled with CFR 0.150.
 */
import java.util.Random;

public class tw {
    private static final Random a = new Random();

    public static void a(ams worldIn, et pos, tt inventory) {
        tw.a(worldIn, (double)pos.p(), (double)pos.q(), (double)pos.r(), inventory);
    }

    public static void a(ams worldIn, ve entityAt, tt inventory) {
        tw.a(worldIn, entityAt.p, entityAt.q, entityAt.r, inventory);
    }

    private static void a(ams worldIn, double x2, double y2, double z2, tt inventory) {
        for (int i2 = 0; i2 < inventory.w_(); ++i2) {
            ain itemstack = inventory.a(i2);
            if (itemstack.b()) continue;
            tw.a(worldIn, x2, y2, z2, itemstack);
        }
    }

    public static void a(ams worldIn, double x2, double y2, double z2, ain stack) {
        float f2 = a.nextFloat() * 0.8f + 0.1f;
        float f1 = a.nextFloat() * 0.8f + 0.1f;
        float f22 = a.nextFloat() * 0.8f + 0.1f;
        while (!stack.b()) {
            acj entityitem = new acj(worldIn, x2 + (double)f2, y2 + (double)f1, z2 + (double)f22, stack.a(a.nextInt(21) + 10));
            float f3 = 0.05f;
            entityitem.s = a.nextGaussian() * (double)0.05f;
            entityitem.t = a.nextGaussian() * (double)0.05f + (double)0.2f;
            entityitem.u = a.nextGaussian() * (double)0.05f;
            worldIn.a(entityitem);
        }
    }
}

