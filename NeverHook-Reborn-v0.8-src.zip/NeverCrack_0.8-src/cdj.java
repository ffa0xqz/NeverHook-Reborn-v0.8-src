/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.apache.commons.io.IOUtils
 */
import java.io.Closeable;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import org.apache.commons.io.IOUtils;

public class cdj {
    public final int a;
    public final int b;

    public cdj(InputStream inputStream) throws IOException {
        DataInputStream dataInputStream = new DataInputStream(inputStream);
        if (dataInputStream.readLong() != -8552249625308161526L) {
            throw new IOException("Bad PNG Signature");
        }
        if (dataInputStream.readInt() != 13) {
            throw new IOException("Bad length for IHDR chunk!");
        }
        if (dataInputStream.readInt() != 1229472850) {
            throw new IOException("Bad type for IHDR chunk!");
        }
        this.a = dataInputStream.readInt();
        this.b = dataInputStream.readInt();
        IOUtils.closeQuietly((InputStream)dataInputStream);
    }

    public static cdj a(cem cem2) throws IOException {
        try {
            cdj cdj2 = new cdj(cem2.b());
            return cdj2;
        }
        finally {
            IOUtils.closeQuietly((Closeable)cem2);
        }
    }
}

