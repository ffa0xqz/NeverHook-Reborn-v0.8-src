/*
 * Decompiled with CFR 0.150.
 */
public class te
implements rs {
    @Override
    public int a() {
        return 505;
    }

    @Override
    public fy a(fy fy2) {
        fy2.a("useVbo", "true");
        return fy2;
    }
}

