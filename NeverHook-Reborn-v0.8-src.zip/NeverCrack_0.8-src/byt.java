/*
 * Decompiled with CFR 0.150.
 */
public class byt
extends cad<zu> {
    private static final nd a = new nd("textures/entity/chicken.png");

    public byt(bzd bzd2) {
        super(bzd2, new bpk(), 0.3f);
    }

    @Override
    protected nd a(zu zu2) {
        return a;
    }

    protected float a(zu zu2, float f2) {
        \u2603 = zu2.bB + (zu2.bx - zu2.bB) * f2;
        \u2603 = zu2.bz + (zu2.by - zu2.bz) * f2;
        return (ri.a(\u2603) + 1.0f) * \u2603;
    }

    @Override
    protected /* synthetic */ float b(vn vn2, float f2) {
        return this.a((zu)vn2, f2);
    }
}

