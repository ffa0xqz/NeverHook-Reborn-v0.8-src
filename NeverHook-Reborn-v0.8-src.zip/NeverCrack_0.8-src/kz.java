/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.apache.commons.lang3.StringUtils
 */
import java.io.IOException;
import javax.annotation.Nullable;
import org.apache.commons.lang3.StringUtils;

public class kz
implements ht<kw> {
    private String a;
    private boolean b;
    @Nullable
    private et c;

    public kz() {
    }

    public kz(String string, @Nullable et et2, boolean bl2) {
        this.a = string;
        this.c = et2;
        this.b = bl2;
    }

    @Override
    public void a(gy gy2) throws IOException {
        this.a = gy2.e(32767);
        this.b = gy2.readBoolean();
        boolean bl2 = gy2.readBoolean();
        if (bl2) {
            this.c = gy2.e();
        }
    }

    @Override
    public void b(gy gy2) throws IOException {
        gy2.a(StringUtils.substring((String)this.a, (int)0, (int)32767));
        gy2.writeBoolean(this.b);
        boolean bl2 = this.c != null;
        gy2.writeBoolean(bl2);
        if (bl2) {
            gy2.a(this.c);
        }
    }

    @Override
    public void a(kw kw2) {
        kw2.a(this);
    }

    public String a() {
        return this.a;
    }

    @Nullable
    public et b() {
        return this.c;
    }

    public boolean c() {
        return this.b;
    }
}

