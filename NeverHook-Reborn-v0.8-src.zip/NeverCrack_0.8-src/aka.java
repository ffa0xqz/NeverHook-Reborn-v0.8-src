/*
 * Decompiled with CFR 0.150.
 */
public enum aka {
    a,
    b,
    c,
    d,
    e;

}

