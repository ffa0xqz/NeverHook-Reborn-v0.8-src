/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  javax.annotation.Nullable
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.common.collect.Lists;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public abstract class anf {
    private static final Logger x = LogManager.getLogger();
    protected static final awr a = aov.b.t();
    protected static final awr b = aov.a.t();
    protected static final awr c = aov.h.t();
    protected static final awr d = aov.n.t();
    protected static final awr e = aov.cM.t();
    protected static final awr f = aov.A.t();
    protected static final awr g = aov.aI.t();
    protected static final awr h = aov.j.t();
    public static final fd<anf> i = new fd();
    protected static final bco j = new bco(new Random(1234L), 1);
    protected static final bco k = new bco(new Random(2345L), 1);
    protected static final azo l = new azo();
    protected static final bav m = new bav(false);
    protected static final azf n = new azf(false);
    protected static final bat o = new bat();
    public static final fh<nd, anf> p = new fh();
    private final String y;
    private final float z;
    private final float A;
    private final float B;
    private final float C;
    private final int D;
    private final boolean E;
    private final boolean F;
    @Nullable
    private final String G;
    public awr q = aov.c.t();
    public awr r = aov.d.t();
    public ani s;
    protected List<c> t = Lists.newArrayList();
    protected List<c> u = Lists.newArrayList();
    protected List<c> v = Lists.newArrayList();
    protected List<c> w = Lists.newArrayList();

    public static int a(anf anf2) {
        return p.a(anf2);
    }

    @Nullable
    public static anf a(int n2) {
        return p.a(n2);
    }

    @Nullable
    public static anf b(anf anf2) {
        return i.a(anf.a(anf2));
    }

    protected anf(a a2) {
        this.y = a2.a;
        this.z = a2.b;
        this.A = a2.c;
        this.B = a2.d;
        this.C = a2.e;
        this.D = a2.f;
        this.E = a2.g;
        this.F = a2.h;
        this.G = a2.i;
        this.s = this.a();
        this.u.add(new c(aae.class, 12, 4, 4));
        this.u.add(new c(aab.class, 10, 4, 4));
        this.u.add(new c(zu.class, 10, 4, 4));
        this.u.add(new c(zv.class, 8, 4, 4));
        this.t.add(new c(adl.class, 100, 4, 4));
        this.t.add(new c(adr.class, 95, 4, 4));
        this.t.add(new c(ads.class, 5, 1, 1));
        this.t.add(new c(adi.class, 100, 4, 4));
        this.t.add(new c(acq.class, 100, 4, 4));
        this.t.add(new c(adj.class, 100, 4, 4));
        this.t.add(new c(acs.class, 10, 1, 4));
        this.t.add(new c(adp.class, 5, 1, 1));
        this.v.add(new c(aah.class, 10, 4, 4));
        this.w.add(new c(zr.class, 10, 8, 8));
    }

    protected ani a() {
        return new ani();
    }

    public boolean b() {
        return this.G != null;
    }

    public aze a(Random random) {
        if (random.nextInt(10) == 0) {
            return n;
        }
        return m;
    }

    public azs b(Random random) {
        return new bau(aul.a.b);
    }

    public aqp.a a(Random random, et et2) {
        if (random.nextInt(3) > 0) {
            return aqp.a.a;
        }
        return aqp.a.b;
    }

    public int a(float f2) {
        f2 /= 3.0f;
        f2 = ri.a(f2, -1.0f, 1.0f);
        return ri.c(0.62222224f - f2 * 0.05f, 0.5f + f2 * 0.1f, 1.0f);
    }

    public List<c> a(vp vp2) {
        switch (vp2) {
            case a: {
                return this.t;
            }
            case b: {
                return this.u;
            }
            case d: {
                return this.v;
            }
            case c: {
                return this.w;
            }
        }
        return Collections.emptyList();
    }

    public boolean c() {
        return this.p();
    }

    public boolean d() {
        if (this.p()) {
            return false;
        }
        return this.F;
    }

    public boolean e() {
        return this.k() > 0.85f;
    }

    public float f() {
        return 0.1f;
    }

    public final float a(et et2) {
        if (et2.q() > 64) {
            float f2 = (float)(j.a((float)et2.p() / 8.0f, (float)et2.r() / 8.0f) * 4.0);
            return this.n() - (f2 + (float)et2.q() - 64.0f) * 0.05f / 30.0f;
        }
        return this.n();
    }

    public void a(ams ams2, Random random, et et2) {
        this.s.a(ams2, random, this, et2);
    }

    public int b(et et2) {
        double d2 = ri.a(this.a(et2), 0.0f, 1.0f);
        \u2603 = ri.a(this.k(), 0.0f, 1.0f);
        return amr.a(d2, \u2603);
    }

    public int c(et et2) {
        double d2 = ri.a(this.a(et2), 0.0f, 1.0f);
        \u2603 = ri.a(this.k(), 0.0f, 1.0f);
        return amo.a(d2, \u2603);
    }

    public void a(ams ams2, Random random, ayu ayu2, int n2, int n3, double d2) {
        this.b(ams2, random, ayu2, n2, n3, d2);
    }

    public final void b(ams ams2, Random random, ayu ayu2, int n2, int n3, double d2) {
        int n4 = ams2.M();
        awr \u26032 = this.q;
        awr \u26033 = this.r;
        n5 = -1;
        \u2603 = (int)(d2 / 3.0 + 3.0 + random.nextDouble() * 0.25);
        \u2603 = n2 & 0xF;
        \u2603 = n3 & 0xF;
        et.a \u26034 = new et.a();
        for (\u2603 = 255; \u2603 >= 0; --\u2603) {
            int n5;
            if (\u2603 <= random.nextInt(5)) {
                ayu2.a(\u2603, \u2603, \u2603, c);
                continue;
            }
            awr awr2 = ayu2.a(\u2603, \u2603, \u2603);
            if (awr2.a() == bcx.a) {
                n5 = -1;
                continue;
            }
            if (awr2.u() != aov.b) continue;
            if (n5 == -1) {
                if (\u2603 <= 0) {
                    \u26032 = b;
                    \u26033 = a;
                } else if (\u2603 >= n4 - 4 && \u2603 <= n4 + 1) {
                    \u26032 = this.q;
                    \u26033 = this.r;
                }
                if (\u2603 < n4 && (\u26032 == null || \u26032.a() == bcx.a)) {
                    \u26032 = this.a(\u26034.c(n2, \u2603, n3)) < 0.15f ? g : h;
                }
                n5 = \u2603;
                if (\u2603 >= n4 - 1) {
                    ayu2.a(\u2603, \u2603, \u2603, \u26032);
                    continue;
                }
                if (\u2603 < n4 - 7 - \u2603) {
                    \u26032 = b;
                    \u26033 = a;
                    ayu2.a(\u2603, \u2603, \u2603, d);
                    continue;
                }
                ayu2.a(\u2603, \u2603, \u2603, \u26033);
                continue;
            }
            if (n5 <= 0) continue;
            ayu2.a(\u2603, \u2603, \u2603, \u26033);
            if (--n5 != 0 || \u26033.u() != aov.m || \u2603 <= 1) continue;
            n5 = random.nextInt(4) + Math.max(0, \u2603 - 63);
            \u26033 = \u26033.c(atl.a) == atl.a.b ? e : f;
        }
    }

    public Class<? extends anf> g() {
        return this.getClass();
    }

    public b h() {
        if ((double)this.n() < 0.2) {
            return anf$b.b;
        }
        if ((double)this.n() < 1.0) {
            return anf$b.c;
        }
        return anf$b.d;
    }

    @Nullable
    public static anf b(int n2) {
        return anf.a(n2, null);
    }

    public static anf a(int n2, anf anf2) {
        \u2603 = anf.a(n2);
        if (\u2603 == null) {
            return anf2;
        }
        return \u2603;
    }

    public boolean i() {
        return false;
    }

    public final float j() {
        return this.z;
    }

    public final float k() {
        return this.C;
    }

    public final String l() {
        return this.y;
    }

    public final float m() {
        return this.A;
    }

    public final float n() {
        return this.B;
    }

    public final int o() {
        return this.D;
    }

    public final boolean p() {
        return this.E;
    }

    public static void q() {
        anf.a(0, "ocean", new any(new a("Ocean").c(-1.0f).d(0.1f)));
        anf.a(1, "plains", new anz(false, new a("Plains").c(0.125f).d(0.05f).a(0.8f).b(0.4f)));
        anf.a(2, "desert", new anm(new a("Desert").c(0.125f).d(0.05f).a(2.0f).b(0.0f).a()));
        anf.a(3, "extreme_hills", new ann(ann.a.a, new a("Extreme Hills").c(1.0f).d(0.5f).a(0.2f).b(0.3f)));
        anf.a(4, "forest", new anp(anp.a.a, new a("Forest").a(0.7f).b(0.8f)));
        anf.a(5, "taiga", new aoe(aoe.a.a, new a("Taiga").c(0.2f).d(0.2f).a(0.25f).b(0.8f)));
        anf.a(6, "swampland", new aod(new a("Swampland").c(-0.2f).d(0.1f).a(0.8f).b(0.9f).a(14745518)));
        anf.a(7, "river", new aoa(new a("River").c(-0.5f).d(0.0f)));
        anf.a(8, "hell", new anq(new a("Hell").a(2.0f).b(0.0f).a()));
        anf.a(9, "sky", new aof(new a("The End").a()));
        anf.a(10, "frozen_ocean", new any(new a("FrozenOcean").c(-1.0f).d(0.1f).a(0.0f).b(0.5f).b()));
        anf.a(11, "frozen_river", new aoa(new a("FrozenRiver").c(-0.5f).d(0.0f).a(0.0f).b(0.5f).b()));
        anf.a(12, "ice_flats", new ans(false, new a("Ice Plains").c(0.125f).d(0.05f).a(0.0f).b(0.5f).b()));
        anf.a(13, "ice_mountains", new ans(false, new a("Ice Mountains").c(0.45f).d(0.3f).a(0.0f).b(0.5f).b()));
        anf.a(14, "mushroom_island", new anv(new a("MushroomIsland").c(0.2f).d(0.3f).a(0.9f).b(1.0f)));
        anf.a(15, "mushroom_island_shore", new anv(new a("MushroomIslandShore").c(0.0f).d(0.025f).a(0.9f).b(1.0f)));
        anf.a(16, "beaches", new ane(new a("Beach").c(0.0f).d(0.025f).a(0.8f).b(0.4f)));
        anf.a(17, "desert_hills", new anm(new a("DesertHills").c(0.45f).d(0.3f).a(2.0f).b(0.0f).a()));
        anf.a(18, "forest_hills", new anp(anp.a.a, new a("ForestHills").c(0.45f).d(0.3f).a(0.7f).b(0.8f)));
        anf.a(19, "taiga_hills", new aoe(aoe.a.a, new a("TaigaHills").a(0.25f).b(0.8f).c(0.45f).d(0.3f)));
        anf.a(20, "smaller_extreme_hills", new ann(ann.a.b, new a("Extreme Hills Edge").c(0.8f).d(0.3f).a(0.2f).b(0.3f)));
        anf.a(21, "jungle", new ant(false, new a("Jungle").a(0.95f).b(0.9f)));
        anf.a(22, "jungle_hills", new ant(false, new a("JungleHills").c(0.45f).d(0.3f).a(0.95f).b(0.9f)));
        anf.a(23, "jungle_edge", new ant(true, new a("JungleEdge").a(0.95f).b(0.8f)));
        anf.a(24, "deep_ocean", new any(new a("Deep Ocean").c(-1.8f).d(0.1f)));
        anf.a(25, "stone_beach", new aoc(new a("Stone Beach").c(0.1f).d(0.8f).a(0.2f).b(0.3f)));
        anf.a(26, "cold_beach", new ane(new a("Cold Beach").c(0.0f).d(0.025f).a(0.05f).b(0.3f).b()));
        anf.a(27, "birch_forest", new anp(anp.a.c, new a("Birch Forest").a(0.6f).b(0.6f)));
        anf.a(28, "birch_forest_hills", new anp(anp.a.c, new a("Birch Forest Hills").c(0.45f).d(0.3f).a(0.6f).b(0.6f)));
        anf.a(29, "roofed_forest", new anp(anp.a.d, new a("Roofed Forest").a(0.7f).b(0.8f)));
        anf.a(30, "taiga_cold", new aoe(aoe.a.a, new a("Cold Taiga").c(0.2f).d(0.2f).a(-0.5f).b(0.4f).b()));
        anf.a(31, "taiga_cold_hills", new aoe(aoe.a.a, new a("Cold Taiga Hills").c(0.45f).d(0.3f).a(-0.5f).b(0.4f).b()));
        anf.a(32, "redwood_taiga", new aoe(aoe.a.b, new a("Mega Taiga").a(0.3f).b(0.8f).c(0.2f).d(0.2f)));
        anf.a(33, "redwood_taiga_hills", new aoe(aoe.a.b, new a("Mega Taiga Hills").c(0.45f).d(0.3f).a(0.3f).b(0.8f)));
        anf.a(34, "extreme_hills_with_trees", new ann(ann.a.b, new a("Extreme Hills+").c(1.0f).d(0.5f).a(0.2f).b(0.3f)));
        anf.a(35, "savanna", new aob(new a("Savanna").c(0.125f).d(0.05f).a(1.2f).b(0.0f).a()));
        anf.a(36, "savanna_rock", new aob(new a("Savanna Plateau").c(1.5f).d(0.025f).a(1.0f).b(0.0f).a()));
        anf.a(37, "mesa", new anu(false, false, new a("Mesa").a(2.0f).b(0.0f).a()));
        anf.a(38, "mesa_rock", new anu(false, true, new a("Mesa Plateau F").c(1.5f).d(0.025f).a(2.0f).b(0.0f).a()));
        anf.a(39, "mesa_clear_rock", new anu(false, false, new a("Mesa Plateau").c(1.5f).d(0.025f).a(2.0f).b(0.0f).a()));
        anf.a(127, "void", new aoh(new a("The Void").a()));
        anf.a(129, "mutated_plains", new anz(true, new a("Sunflower Plains").a("plains").c(0.125f).d(0.05f).a(0.8f).b(0.4f)));
        anf.a(130, "mutated_desert", new anm(new a("Desert M").a("desert").c(0.225f).d(0.25f).a(2.0f).b(0.0f).a()));
        anf.a(131, "mutated_extreme_hills", new ann(ann.a.c, new a("Extreme Hills M").a("extreme_hills").c(1.0f).d(0.5f).a(0.2f).b(0.3f)));
        anf.a(132, "mutated_forest", new anp(anp.a.b, new a("Flower Forest").a("forest").d(0.4f).a(0.7f).b(0.8f)));
        anf.a(133, "mutated_taiga", new aoe(aoe.a.a, new a("Taiga M").a("taiga").c(0.3f).d(0.4f).a(0.25f).b(0.8f)));
        anf.a(134, "mutated_swampland", new aod(new a("Swampland M").a("swampland").c(-0.1f).d(0.3f).a(0.8f).b(0.9f).a(14745518)));
        anf.a(140, "mutated_ice_flats", new ans(true, new a("Ice Plains Spikes").a("ice_flats").c(0.425f).d(0.45000002f).a(0.0f).b(0.5f).b()));
        anf.a(149, "mutated_jungle", new ant(false, new a("Jungle M").a("jungle").c(0.2f).d(0.4f).a(0.95f).b(0.9f)));
        anf.a(151, "mutated_jungle_edge", new ant(true, new a("JungleEdge M").a("jungle_edge").c(0.2f).d(0.4f).a(0.95f).b(0.8f)));
        anf.a(155, "mutated_birch_forest", new anw(new a("Birch Forest M").a("birch_forest").c(0.2f).d(0.4f).a(0.6f).b(0.6f)));
        anf.a(156, "mutated_birch_forest_hills", new anw(new a("Birch Forest Hills M").a("birch_forest_hills").c(0.55f).d(0.5f).a(0.6f).b(0.6f)));
        anf.a(157, "mutated_roofed_forest", new anp(anp.a.d, new a("Roofed Forest M").a("roofed_forest").c(0.2f).d(0.4f).a(0.7f).b(0.8f)));
        anf.a(158, "mutated_taiga_cold", new aoe(aoe.a.a, new a("Cold Taiga M").a("taiga_cold").c(0.3f).d(0.4f).a(-0.5f).b(0.4f).b()));
        anf.a(160, "mutated_redwood_taiga", new aoe(aoe.a.c, new a("Mega Spruce Taiga").a("redwood_taiga").c(0.2f).d(0.2f).a(0.25f).b(0.8f)));
        anf.a(161, "mutated_redwood_taiga_hills", new aoe(aoe.a.c, new a("Redwood Taiga Hills M").a("redwood_taiga_hills").c(0.2f).d(0.2f).a(0.25f).b(0.8f)));
        anf.a(162, "mutated_extreme_hills_with_trees", new ann(ann.a.c, new a("Extreme Hills+ M").a("extreme_hills_with_trees").c(1.0f).d(0.5f).a(0.2f).b(0.3f)));
        anf.a(163, "mutated_savanna", new anx(new a("Savanna M").a("savanna").c(0.3625f).d(1.225f).a(1.1f).b(0.0f).a()));
        anf.a(164, "mutated_savanna_rock", new anx(new a("Savanna Plateau M").a("savanna_rock").c(1.05f).d(1.2125001f).a(1.0f).b(0.0f).a()));
        anf.a(165, "mutated_mesa", new anu(true, false, new a("Mesa (Bryce)").a("mesa").a(2.0f).b(0.0f).a()));
        anf.a(166, "mutated_mesa_rock", new anu(false, true, new a("Mesa Plateau F M").a("mesa_rock").c(0.45f).d(0.3f).a(2.0f).b(0.0f).a()));
        anf.a(167, "mutated_mesa_clear_rock", new anu(false, false, new a("Mesa Plateau M").a("mesa_clear_rock").c(0.45f).d(0.3f).a(2.0f).b(0.0f).a()));
    }

    private static void a(int n2, String string, anf anf2) {
        p.a(n2, new nd(string), anf2);
        if (anf2.b()) {
            i.a(anf2, anf.a(p.c(new nd(anf2.G))));
        }
    }

    public static class a {
        private final String a;
        private float b = 0.1f;
        private float c = 0.2f;
        private float d = 0.5f;
        private float e = 0.5f;
        private int f = 0xFFFFFF;
        private boolean g;
        private boolean h = true;
        @Nullable
        private String i;

        public a(String string) {
            this.a = string;
        }

        protected a a(float f2) {
            if (f2 > 0.1f && f2 < 0.2f) {
                throw new IllegalArgumentException("Please avoid temperatures in the range 0.1 - 0.2 because of snow");
            }
            this.d = f2;
            return this;
        }

        protected a b(float f2) {
            this.e = f2;
            return this;
        }

        protected a c(float f2) {
            this.b = f2;
            return this;
        }

        protected a d(float f2) {
            this.c = f2;
            return this;
        }

        protected a a() {
            this.h = false;
            return this;
        }

        protected a b() {
            this.g = true;
            return this;
        }

        protected a a(int n2) {
            this.f = n2;
            return this;
        }

        protected a a(String string) {
            this.i = string;
            return this;
        }
    }

    public static class c
    extends rq.a {
        public Class<? extends vo> b;
        public int c;
        public int d;

        public c(Class<? extends vo> class_, int n2, int n3, int n4) {
            super(n2);
            this.b = class_;
            this.c = n3;
            this.d = n4;
        }

        public String toString() {
            return this.b.getSimpleName() + "*(" + this.c + "-" + this.d + "):" + this.a;
        }
    }

    public static enum b {
        a,
        b,
        c,
        d;

    }
}

