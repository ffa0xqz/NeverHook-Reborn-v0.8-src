/*
 * Decompiled with CFR 0.150.
 */
import java.util.Arrays;

public class avi
extends avv
implements nv,
ul {
    private static final int[] a = new int[]{3};
    private static final int[] f = new int[]{0, 1, 2, 3};
    private static final int[] g = new int[]{0, 1, 2, 4};
    private fi<ain> h = fi.a(5, ain.a);
    private int i;
    private boolean[] j;
    private ail k;
    private String l;
    private int m;

    @Override
    public String h_() {
        return this.n_() ? this.l : "container.brewing";
    }

    @Override
    public boolean n_() {
        return this.l != null && !this.l.isEmpty();
    }

    public void a(String string) {
        this.l = string;
    }

    @Override
    public int w_() {
        return this.h.size();
    }

    @Override
    public boolean x_() {
        for (ain ain2 : this.h) {
            if (ain2.b()) continue;
            return false;
        }
        return true;
    }

    @Override
    public void e() {
        ain ain2 = this.h.get(4);
        if (this.m <= 0 && ain2.c() == aip.bO) {
            this.m = 20;
            ain2.g(1);
            this.y_();
        }
        boolean \u26032 = this.o();
        boolean \u26033 = this.i > 0;
        \u2603 = this.h.get(3);
        if (\u26033) {
            --this.i;
            boolean bl2 = \u2603 = this.i == 0;
            if (\u2603 && \u26032) {
                this.p();
                this.y_();
            } else if (!\u26032) {
                this.i = 0;
                this.y_();
            } else if (this.k != \u2603.c()) {
                this.i = 0;
                this.y_();
            }
        } else if (\u26032 && this.m > 0) {
            --this.m;
            this.i = 400;
            this.k = \u2603.c();
            this.y_();
        }
        if (!this.b.G && !Arrays.equals(\u2603 = this.n(), this.j)) {
            this.j = \u2603;
            awr awr2 = this.b.o(this.w());
            if (!(awr2.u() instanceof aoz)) {
                return;
            }
            for (int i2 = 0; i2 < aoz.a.length; ++i2) {
                awr2 = awr2.a(aoz.a[i2], \u2603[i2]);
            }
            this.b.a(this.c, awr2, 2);
        }
    }

    public boolean[] n() {
        boolean[] arrbl = new boolean[3];
        for (int i2 = 0; i2 < 3; ++i2) {
            if (this.h.get(i2).b()) continue;
            arrbl[i2] = true;
        }
        return arrbl;
    }

    private boolean o() {
        ain ain2 = this.h.get(3);
        if (ain2.b()) {
            return false;
        }
        if (!akf.a(ain2)) {
            return false;
        }
        for (int i2 = 0; i2 < 3; ++i2) {
            ain ain3 = this.h.get(i2);
            if (ain3.b() || !akf.a(ain3, ain2)) continue;
            return true;
        }
        return false;
    }

    private void p() {
        ain ain2 = this.h.get(3);
        for (int i2 = 0; i2 < 3; ++i2) {
            this.h.set(i2, akf.d(ain2, this.h.get(i2)));
        }
        ain2.g(1);
        et \u26032 = this.w();
        if (ain2.c().r()) {
            \u2603 = new ain(ain2.c().q());
            if (ain2.b()) {
                ain2 = \u2603;
            } else {
                tw.a(this.b, (double)\u26032.p(), (double)\u26032.q(), (double)\u26032.r(), \u2603);
            }
        }
        this.h.set(3, ain2);
        this.b.b(1035, \u26032, 0);
    }

    public static void a(rw rw2) {
        rw2.a(ru.d, (ry)new tl(avi.class, "Items"));
    }

    @Override
    public void a(fy fy2) {
        super.a(fy2);
        this.h = fi.a(this.w_(), ain.a);
        tu.b(fy2, this.h);
        this.i = fy2.g("BrewTime");
        if (fy2.b("CustomName", 8)) {
            this.l = fy2.l("CustomName");
        }
        this.m = fy2.f("Fuel");
    }

    @Override
    public fy b(fy fy2) {
        super.b(fy2);
        fy2.a("BrewTime", (short)this.i);
        tu.a(fy2, this.h);
        if (this.n_()) {
            fy2.a("CustomName", this.l);
        }
        fy2.a("Fuel", (byte)this.m);
        return fy2;
    }

    @Override
    public ain a(int n2) {
        if (n2 >= 0 && n2 < this.h.size()) {
            return this.h.get(n2);
        }
        return ain.a;
    }

    @Override
    public ain a(int n2, int n3) {
        return tu.a(this.h, n2, n3);
    }

    @Override
    public ain c_(int n2) {
        return tu.a(this.h, n2);
    }

    @Override
    public void a(int n2, ain ain2) {
        if (n2 >= 0 && n2 < this.h.size()) {
            this.h.set(n2, ain2);
        }
    }

    @Override
    public int z_() {
        return 64;
    }

    @Override
    public boolean a(aeb aeb2) {
        if (this.b.r(this.c) != this) {
            return false;
        }
        return !(aeb2.d((double)this.c.p() + 0.5, (double)this.c.q() + 0.5, (double)this.c.r() + 0.5) > 64.0);
    }

    @Override
    public void b(aeb aeb2) {
    }

    @Override
    public void c(aeb aeb2) {
    }

    @Override
    public boolean b(int n2, ain ain2) {
        if (n2 == 3) {
            return akf.a(ain2);
        }
        ail ail2 = ain2.c();
        if (n2 == 4) {
            return ail2 == aip.bO;
        }
        return (ail2 == aip.bH || ail2 == aip.bI || ail2 == aip.bJ || ail2 == aip.bK) && this.a(n2).b();
    }

    @Override
    public int[] a(fa fa2) {
        if (fa2 == fa.b) {
            return a;
        }
        if (fa2 == fa.a) {
            return f;
        }
        return g;
    }

    @Override
    public boolean a(int n2, ain ain2, fa fa2) {
        return this.b(n2, ain2);
    }

    @Override
    public boolean b(int n2, ain ain2, fa fa2) {
        if (n2 == 3) {
            return ain2.c() == aip.bK;
        }
        return true;
    }

    @Override
    public String l() {
        return "minecraft:brewing_stand";
    }

    @Override
    public afp a(aea aea2, aeb aeb2) {
        return new afs(aea2, this);
    }

    @Override
    public int c(int n2) {
        switch (n2) {
            case 0: {
                return this.i;
            }
            case 1: {
                return this.m;
            }
        }
        return 0;
    }

    @Override
    public void b(int n2, int n3) {
        switch (n2) {
            case 0: {
                this.i = n3;
                break;
            }
            case 1: {
                this.m = n3;
            }
        }
    }

    @Override
    public int h() {
        return 2;
    }

    @Override
    public void m() {
        this.h.clear();
    }
}

