/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Sets
 *  javax.annotation.Nullable
 */
import com.google.common.collect.Sets;
import java.util.Set;
import javax.annotation.Nullable;

public class bek {
    private final bee a = new bee();
    private final Set<beh> b = Sets.newHashSet();
    private final beh[] c = new beh[32];
    private final bei d;

    public bek(bei bei2) {
        this.d = bei2;
    }

    @Nullable
    public bej a(amw amw2, vo vo2, ve ve2, float f2) {
        return this.a(amw2, vo2, ve2.p, ve2.bw().b, ve2.r, f2);
    }

    @Nullable
    public bej a(amw amw2, vo vo2, et et2, float f2) {
        return this.a(amw2, vo2, (float)et2.p() + 0.5f, (float)et2.q() + 0.5f, (float)et2.r() + 0.5f, f2);
    }

    @Nullable
    private bej a(amw amw2, vo vo2, double d2, double d3, double d4, float f2) {
        this.a.a();
        this.d.a(amw2, vo2);
        beh beh2 = this.d.b();
        \u2603 = this.d.a(d2, d3, d4);
        bej \u26032 = this.a(beh2, \u2603, f2);
        this.d.a();
        return \u26032;
    }

    @Nullable
    private bej a(beh beh2, beh beh3, float f2) {
        beh2.e = 0.0f;
        beh2.g = beh2.f = beh2.c(beh3);
        this.a.a();
        this.b.clear();
        this.a.a(beh2);
        Object object = beh2;
        int \u26032 = 0;
        while (!this.a.e() && ++\u26032 < 200) {
            object2 = this.a.c();
            if (((beh)object2).equals(beh3)) {
                object = beh3;
                break;
            }
            if (((beh)object2).c(beh3) < ((beh)object).c(beh3)) {
                object = object2;
            }
            ((beh)object2).i = true;
            int n2 = this.d.a(this.c, (beh)object2, beh3, f2);
            for (\u2603 = 0; \u2603 < n2; ++\u2603) {
                beh beh4 = this.c[\u2603];
                float \u26033 = ((beh)object2).c(beh4);
                beh4.j = ((beh)object2).j + \u26033;
                beh4.k = \u26033 + beh4.l;
                float \u26034 = ((beh)object2).e + beh4.k;
                if (!(beh4.j < f2) || beh4.a() && !(\u26034 < beh4.e)) continue;
                beh4.h = object2;
                beh4.e = \u26034;
                beh4.f = beh4.c(beh3) + beh4.l;
                if (beh4.a()) {
                    this.a.a(beh4, beh4.e + beh4.f);
                    continue;
                }
                beh4.g = beh4.e + beh4.f;
                this.a.a(beh4);
            }
        }
        if (object == beh2) {
            return null;
        }
        Object object2 = this.a(beh2, (beh)object);
        return object2;
    }

    private bej a(beh beh2, beh beh3) {
        int n2 = 1;
        beh \u26032 = beh3;
        while (\u26032.h != null) {
            ++n2;
            \u26032 = \u26032.h;
        }
        beh[] \u26033 = new beh[n2];
        \u26032 = beh3;
        \u26033[--n2] = \u26032;
        while (\u26032.h != null) {
            \u26032 = \u26032.h;
            \u26033[--n2] = \u26032;
        }
        return new bej(\u26033);
    }
}

