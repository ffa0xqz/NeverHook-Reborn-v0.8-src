/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import java.util.Random;
import javax.annotation.Nullable;

public class bcf {
    private arw a = arw.a;
    private atk b = atk.a;
    private boolean c;
    @Nullable
    private aou d;
    @Nullable
    private aml e;
    @Nullable
    private bbe f;
    private boolean g = true;
    private float h = 1.0f;
    @Nullable
    private Random i;
    @Nullable
    private Long j;

    public bcf a() {
        bcf bcf2 = new bcf();
        bcf2.a = this.a;
        bcf2.b = this.b;
        bcf2.c = this.c;
        bcf2.d = this.d;
        bcf2.e = this.e;
        bcf2.f = this.f;
        bcf2.g = this.g;
        bcf2.h = this.h;
        bcf2.i = this.i;
        bcf2.j = this.j;
        return bcf2;
    }

    public bcf a(arw arw2) {
        this.a = arw2;
        return this;
    }

    public bcf a(atk atk2) {
        this.b = atk2;
        return this;
    }

    public bcf a(boolean bl2) {
        this.c = bl2;
        return this;
    }

    public bcf a(aou aou2) {
        this.d = aou2;
        return this;
    }

    public bcf a(aml aml2) {
        this.e = aml2;
        return this;
    }

    public bcf a(bbe bbe2) {
        this.f = bbe2;
        return this;
    }

    public bcf a(@Nullable Long l2) {
        this.j = l2;
        return this;
    }

    public bcf a(@Nullable Random random) {
        this.i = random;
        return this;
    }

    public bcf a(float f2) {
        this.h = f2;
        return this;
    }

    public arw b() {
        return this.a;
    }

    public bcf b(boolean bl2) {
        this.g = bl2;
        return this;
    }

    public atk c() {
        return this.b;
    }

    public Random a(@Nullable et et2) {
        if (this.i != null) {
            return this.i;
        }
        if (this.j != null) {
            if (this.j == 0L) {
                return new Random(System.currentTimeMillis());
            }
            return new Random(this.j);
        }
        if (et2 == null) {
            return new Random(System.currentTimeMillis());
        }
        int n2 = et2.p();
        \u2603 = et2.r();
        return new Random((long)(n2 * n2 * 4987142 + n2 * 5947611) + (long)(\u2603 * \u2603) * 4392871L + (long)(\u2603 * 389711) ^ 0x3AD8025FL);
    }

    public float f() {
        return this.h;
    }

    public boolean g() {
        return this.c;
    }

    @Nullable
    public aou h() {
        return this.d;
    }

    @Nullable
    public bbe i() {
        if (this.f == null && this.e != null) {
            this.k();
        }
        return this.f;
    }

    public boolean j() {
        return this.g;
    }

    void k() {
        this.f = this.b(this.e);
    }

    @Nullable
    private bbe b(@Nullable aml aml2) {
        if (aml2 == null) {
            return null;
        }
        int n2 = aml2.a * 16;
        \u2603 = aml2.b * 16;
        return new bbe(n2, 0, \u2603, n2 + 16 - 1, 255, \u2603 + 16 - 1);
    }
}

