/*
 * Decompiled with CFR 0.150.
 */
public interface hb {
    public void a(hh var1);
}

