/*
 * Decompiled with CFR 0.150.
 */
import java.io.IOException;

public class ln
implements ht<kw> {
    private boolean a;
    private boolean b;
    private boolean c;
    private boolean d;
    private float e;
    private float f;

    public ln() {
    }

    public ln(adz adz2) {
        this.a(adz2.a);
        this.b(adz2.b);
        this.c(adz2.c);
        this.d(adz2.d);
        this.a(adz2.a());
        this.b(adz2.b());
    }

    @Override
    public void a(gy gy2) throws IOException {
        byte by2 = gy2.readByte();
        this.a((by2 & 1) > 0);
        this.b((by2 & 2) > 0);
        this.c((by2 & 4) > 0);
        this.d((by2 & 8) > 0);
        this.a(gy2.readFloat());
        this.b(gy2.readFloat());
    }

    @Override
    public void b(gy gy2) throws IOException {
        byte by2 = 0;
        if (this.a()) {
            by2 = (byte)(by2 | true ? 1 : 0);
        }
        if (this.b()) {
            by2 = (byte)(by2 | 2);
        }
        if (this.c()) {
            by2 = (byte)(by2 | 4);
        }
        if (this.d()) {
            by2 = (byte)(by2 | 8);
        }
        gy2.writeByte(by2);
        gy2.writeFloat(this.e);
        gy2.writeFloat(this.f);
    }

    @Override
    public void a(kw kw2) {
        kw2.a(this);
    }

    public boolean a() {
        return this.a;
    }

    @Override
    public void a(boolean bl2) {
        this.a = bl2;
    }

    public boolean b() {
        return this.b;
    }

    public void b(boolean bl2) {
        this.b = bl2;
    }

    public boolean c() {
        return this.c;
    }

    public void c(boolean bl2) {
        this.c = bl2;
    }

    public boolean d() {
        return this.d;
    }

    public void d(boolean bl2) {
        this.d = bl2;
    }

    @Override
    public void a(float f2) {
        this.e = f2;
    }

    public void b(float f2) {
        this.f = f2;
    }
}

