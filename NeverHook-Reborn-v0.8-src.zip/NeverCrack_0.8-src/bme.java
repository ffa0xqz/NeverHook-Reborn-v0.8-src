/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Sets
 *  org.lwjgl.input.Keyboard
 *  org.lwjgl.input.Mouse
 */
import com.google.common.collect.Sets;
import java.io.IOException;
import java.util.Set;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import top.nhprem.Main;
import top.nhprem.api.utils.world.TimerHelper;
import top.nhprem.client.features.impl.player.ItemScroller;

public abstract class bme
extends bli {
    public static final nd a = new nd("textures/gui/container/inventory.png");
    protected int f = 176;
    protected int g = 166;
    public afp h;
    protected int i;
    protected int s;
    private agp v;
    private agp w;
    private boolean x;
    private ain y = ain.a;
    private int z;
    private int A;
    private agp B;
    private long C;
    private ain D = ain.a;
    private agp E;
    private long F;
    protected final Set<agp> t = Sets.newHashSet();
    protected boolean u;
    private int G;
    private int H;
    private boolean I;
    private int J;
    private long K;
    private agp L;
    private int M;
    private boolean N;
    private ain O = ain.a;
    private final TimerHelper timerHelper = new TimerHelper();

    public bme(afp inventorySlotsIn) {
        this.h = inventorySlotsIn;
        this.I = true;
    }

    @Override
    public void b() {
        super.b();
        this.j.h.by = this.h;
        this.i = (this.l - this.f) / 2;
        this.s = (this.m - this.g) / 2;
    }

    @Override
    public void a(int mouseX, int mouseY, float partialTicks) {
        ain itemstack;
        int i2 = this.i;
        int j2 = this.s;
        this.a(partialTicks, mouseX, mouseY);
        buq.E();
        bhx.a();
        buq.g();
        buq.j();
        super.a(mouseX, mouseY, partialTicks);
        bhx.c();
        buq.G();
        buq.c((float)i2, (float)j2, 0.0f);
        buq.c(1.0f, 1.0f, 1.0f, 1.0f);
        buq.D();
        this.v = null;
        int k2 = 240;
        int l2 = 240;
        cig.a(cig.r, 240.0f, 240.0f);
        buq.c(1.0f, 1.0f, 1.0f, 1.0f);
        for (int i1 = 0; i1 < this.h.c.size(); ++i1) {
            agp slot = this.h.c.get(i1);
            if (slot.b()) {
                this.a(slot);
            }
            if (!this.a(slot, mouseX, mouseY) || !slot.b()) continue;
            if (Main.instance.featureDirector.getFeatureByClass(ItemScroller.class).isToggled() && Mouse.isButtonDown((int)0) && Keyboard.isKeyDown((int)this.j.t.Y.j()) && this.j.m != null && this.timerHelper.hasReached(ItemScroller.scrollerDelay.getNumberValue())) {
                this.a(slot, slot.e, 0, afu.b);
                this.timerHelper.reset();
            }
            this.v = slot;
            buq.g();
            buq.j();
            int j1 = slot.f;
            int k1 = slot.g;
            buq.a(true, true, true, false);
            bme.drawGradientRect(j1, k1, j1 + 16, k1 + 16, -2130706433, -2130706433);
            buq.a(true, true, true, true);
            buq.f();
            buq.k();
        }
        bhx.a();
        this.c(mouseX, mouseY);
        bhx.c();
        aea inventoryplayer = this.j.h.bv;
        ain ain2 = itemstack = this.y.isEmpty() ? inventoryplayer.q() : this.y;
        if (!itemstack.isEmpty()) {
            int j22 = 8;
            int k22 = this.y.isEmpty() ? 8 : 16;
            String s2 = null;
            if (!this.y.isEmpty() && this.x) {
                itemstack = itemstack.l();
                itemstack.e(ri.f((float)itemstack.getCount() / 2.0f));
            } else if (this.u && this.t.size() > 1) {
                itemstack = itemstack.l();
                itemstack.e(this.J);
                if (itemstack.isEmpty()) {
                    s2 = "" + (Object)((Object)a.o) + "0";
                }
            }
            this.a(itemstack, mouseX - i2 - 8, mouseY - j2 - k22, s2);
        }
        if (!this.D.isEmpty()) {
            float f2 = (float)(bhz.I() - this.C) / 100.0f;
            if (f2 >= 1.0f) {
                f2 = 1.0f;
                this.D = ain.a;
            }
            int l22 = this.B.f - this.z;
            int i3 = this.B.g - this.A;
            int l1 = this.z + (int)((float)l22 * f2);
            int i22 = this.A + (int)((float)i3 * f2);
            this.a(this.D, l1, i22, (String)null);
        }
        buq.H();
        buq.f();
        buq.k();
        bhx.b();
    }

    protected void b(int p_191948_1_, int p_191948_2_) {
        if (this.j.h.bv.q().isEmpty() && this.v != null && this.v.e()) {
            this.a(this.v.d(), p_191948_1_, p_191948_2_);
        }
    }

    private void a(ain stack, int x2, int y2, String altText) {
        buq.c(0.0f, 0.0f, 32.0f);
        e = 200.0f;
        this.k.a = 200.0f;
        this.k.b(stack, x2, y2);
        this.k.a(this.q, stack, x2, y2 - (this.y.isEmpty() ? 0 : 8), altText);
        e = 0.0f;
        this.k.a = 0.0f;
    }

    protected void c(int mouseX, int mouseY) {
    }

    protected abstract void a(float var1, int var2, int var3);

    private void a(agp slotIn) {
        String s1;
        int i2 = slotIn.f;
        int j2 = slotIn.g;
        ain itemstack = slotIn.d();
        boolean flag = false;
        boolean flag1 = slotIn == this.w && !this.y.isEmpty() && !this.x;
        ain itemstack1 = this.j.h.bv.q();
        String s2 = null;
        if (slotIn == this.w && !this.y.isEmpty() && this.x && !itemstack.isEmpty()) {
            itemstack = itemstack.l();
            itemstack.e(itemstack.getCount() / 2);
        } else if (this.u && this.t.contains(slotIn) && !itemstack1.isEmpty()) {
            if (this.t.size() == 1) {
                return;
            }
            if (afp.a(slotIn, itemstack1, true) && this.h.b(slotIn)) {
                itemstack = itemstack1.l();
                flag = true;
                afp.a(this.t, this.G, itemstack, slotIn.d().isEmpty() ? 0 : slotIn.d().getCount());
                int k2 = Math.min(itemstack.d(), slotIn.b(itemstack));
                if (itemstack.getCount() > k2) {
                    s2 = a.o.toString() + k2;
                    itemstack.e(k2);
                }
            } else {
                this.t.remove(slotIn);
                this.a();
            }
        }
        e = 100.0f;
        this.k.a = 100.0f;
        if (itemstack.isEmpty() && slotIn.b() && (s1 = slotIn.c()) != null) {
            cdo textureatlassprite = this.j.R().a(s1);
            buq.g();
            this.j.N().a(cdn.g);
            this.a(i2, j2, textureatlassprite, 16, 16);
            buq.f();
            flag1 = true;
        }
        if (!flag1) {
            if (flag) {
                bme.drawRect(i2, j2, i2 + 16, j2 + 16, -2130706433);
            }
            buq.k();
            this.k.a(this.j.h, itemstack, i2, j2);
            this.k.a(this.q, itemstack, i2, j2, s2);
        }
        this.k.a = 0.0f;
        e = 0.0f;
    }

    private void a() {
        ain itemstack = this.j.h.bv.q();
        if (!itemstack.isEmpty() && this.u) {
            if (this.G == 2) {
                this.J = itemstack.d();
            } else {
                this.J = itemstack.getCount();
                for (agp slot : this.t) {
                    ain itemstack1 = itemstack.l();
                    ain itemstack2 = slot.d();
                    int i2 = itemstack2.isEmpty() ? 0 : itemstack2.getCount();
                    afp.a(this.t, this.G, itemstack1, i2);
                    int j2 = Math.min(itemstack1.d(), slot.b(itemstack1));
                    if (itemstack1.getCount() > j2) {
                        itemstack1.e(j2);
                    }
                    this.J -= itemstack1.getCount() - i2;
                }
            }
        }
    }

    private agp d(int x2, int y2) {
        for (int i2 = 0; i2 < this.h.c.size(); ++i2) {
            agp slot = this.h.c.get(i2);
            if (!this.a(slot, x2, y2) || !slot.b()) continue;
            return slot;
        }
        return null;
    }

    @Override
    protected void a(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.a(mouseX, mouseY, mouseButton);
        boolean flag = mouseButton == this.j.t.af.j() + 100;
        agp slot = this.d(mouseX, mouseY);
        long i2 = bhz.I();
        this.N = this.L == slot && i2 - this.K < 250L && this.M == mouseButton;
        this.I = false;
        if (mouseButton == 0 || mouseButton == 1 || flag) {
            int j2 = this.i;
            int k2 = this.s;
            boolean flag1 = this.c(mouseX, mouseY, j2, k2);
            int l2 = -1;
            if (slot != null) {
                l2 = slot.e;
            }
            if (flag1) {
                l2 = -999;
            }
            if (this.j.t.B && flag1 && this.j.h.bv.q().isEmpty()) {
                this.j.a((bli)null);
                return;
            }
            if (l2 != -1) {
                if (this.j.t.B) {
                    if (slot != null && slot.e()) {
                        this.w = slot;
                        this.y = ain.a;
                        this.x = mouseButton == 1;
                    } else {
                        this.w = null;
                    }
                } else if (!this.u) {
                    if (this.j.h.bv.q().isEmpty()) {
                        if (mouseButton == this.j.t.af.j() + 100) {
                            this.a(slot, l2, mouseButton, afu.d);
                        } else {
                            boolean flag2 = l2 != -999 && (Keyboard.isKeyDown((int)42) || Keyboard.isKeyDown((int)54));
                            afu clicktype = afu.a;
                            if (flag2) {
                                this.O = slot != null && slot.e() ? slot.d().l() : ain.a;
                                clicktype = afu.b;
                            } else if (l2 == -999) {
                                clicktype = afu.e;
                            }
                            this.a(slot, l2, mouseButton, clicktype);
                        }
                        this.I = true;
                    } else {
                        this.u = true;
                        this.H = mouseButton;
                        this.t.clear();
                        if (mouseButton == 0) {
                            this.G = 0;
                        } else if (mouseButton == 1) {
                            this.G = 1;
                        } else if (mouseButton == this.j.t.af.j() + 100) {
                            this.G = 2;
                        }
                    }
                }
            }
        }
        this.L = slot;
        this.K = i2;
        this.M = mouseButton;
    }

    protected boolean c(int p_193983_1_, int p_193983_2_, int p_193983_3_, int p_193983_4_) {
        return p_193983_1_ < p_193983_3_ || p_193983_2_ < p_193983_4_ || p_193983_1_ >= p_193983_3_ + this.f || p_193983_2_ >= p_193983_4_ + this.g;
    }

    @Override
    protected void a(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick) {
        agp slot = this.d(mouseX, mouseY);
        ain itemstack = this.j.h.bv.q();
        if (this.w != null && this.j.t.B) {
            if (clickedMouseButton == 0 || clickedMouseButton == 1) {
                if (this.y.isEmpty()) {
                    if (slot != this.w && !this.w.d().isEmpty()) {
                        this.y = this.w.d().l();
                    }
                } else if (this.y.getCount() > 1 && slot != null && afp.a(slot, this.y, false)) {
                    long i2 = bhz.I();
                    if (this.E == slot) {
                        if (i2 - this.F > 500L) {
                            this.a(this.w, this.w.e, 0, afu.a);
                            this.a(slot, slot.e, 1, afu.a);
                            this.a(this.w, this.w.e, 0, afu.a);
                            this.F = i2 + 750L;
                            this.y.g(1);
                        }
                    } else {
                        this.E = slot;
                        this.F = i2;
                    }
                }
            }
        } else if (this.u && slot != null && !itemstack.isEmpty() && (itemstack.getCount() > this.t.size() || this.G == 2) && afp.a(slot, itemstack, true) && slot.a(itemstack) && this.h.b(slot)) {
            this.t.add(slot);
            this.a();
        }
    }

    @Override
    protected void b(int mouseX, int mouseY, int state) {
        agp slot = this.d(mouseX, mouseY);
        int i2 = this.i;
        int j2 = this.s;
        boolean flag = this.c(mouseX, mouseY, i2, j2);
        int k2 = -1;
        if (slot != null) {
            k2 = slot.e;
        }
        if (flag) {
            k2 = -999;
        }
        if (this.N && slot != null && state == 0 && this.h.a(ain.a, slot)) {
            if (bme.s()) {
                if (!this.O.isEmpty()) {
                    for (agp slot2 : this.h.c) {
                        if (slot2 == null || !slot2.a(this.j.h) || !slot2.e() || slot2.d != slot.d || !afp.a(slot2, this.O, true)) continue;
                        this.a(slot2, slot2.e, state, afu.b);
                    }
                }
            } else {
                this.a(slot, k2, state, afu.g);
            }
            this.N = false;
            this.K = 0L;
        } else {
            if (this.u && this.H != state) {
                this.u = false;
                this.t.clear();
                this.I = true;
                return;
            }
            if (this.I) {
                this.I = false;
                return;
            }
            if (this.w != null && this.j.t.B) {
                if (state == 0 || state == 1) {
                    if (this.y.isEmpty() && slot != this.w) {
                        this.y = this.w.d();
                    }
                    boolean flag2 = afp.a(slot, this.y, false);
                    if (k2 != -1 && !this.y.isEmpty() && flag2) {
                        this.a(this.w, this.w.e, state, afu.a);
                        this.a(slot, k2, 0, afu.a);
                        if (this.j.h.bv.q().isEmpty()) {
                            this.D = ain.a;
                        } else {
                            this.a(this.w, this.w.e, state, afu.a);
                            this.z = mouseX - i2;
                            this.A = mouseY - j2;
                            this.B = this.w;
                            this.D = this.y;
                            this.C = bhz.I();
                        }
                    } else if (!this.y.isEmpty()) {
                        this.z = mouseX - i2;
                        this.A = mouseY - j2;
                        this.B = this.w;
                        this.D = this.y;
                        this.C = bhz.I();
                    }
                    this.y = ain.a;
                    this.w = null;
                }
            } else if (this.u && !this.t.isEmpty()) {
                this.a((agp)null, -999, afp.d(0, this.G), afu.f);
                for (agp slot1 : this.t) {
                    this.a(slot1, slot1.e, afp.d(1, this.G), afu.f);
                }
                this.a((agp)null, -999, afp.d(2, this.G), afu.f);
            } else if (!this.j.h.bv.q().isEmpty()) {
                if (state == this.j.t.af.j() + 100) {
                    this.a(slot, k2, state, afu.d);
                } else {
                    boolean flag1;
                    boolean bl2 = flag1 = k2 != -999 && (Keyboard.isKeyDown((int)42) || Keyboard.isKeyDown((int)54));
                    if (flag1) {
                        this.O = slot != null && slot.e() ? slot.d().l() : ain.a;
                    }
                    this.a(slot, k2, state, flag1 ? afu.b : afu.a);
                }
            }
        }
        if (this.j.h.bv.q().isEmpty()) {
            this.K = 0L;
        }
        this.u = false;
    }

    private boolean a(agp slotIn, int mouseX, int mouseY) {
        return this.c(slotIn.f, slotIn.g, 16, 16, mouseX, mouseY);
    }

    protected boolean c(int rectX, int rectY, int rectWidth, int rectHeight, int pointX, int pointY) {
        int i2 = this.i;
        int j2 = this.s;
        return (pointX -= i2) >= rectX - 1 && pointX < rectX + rectWidth + 1 && (pointY -= j2) >= rectY - 1 && pointY < rectY + rectHeight + 1;
    }

    public void a(agp slotIn, int slotId, int mouseButton, afu type) {
        if (slotIn != null) {
            slotId = slotIn.e;
        }
        this.j.c.a(this.h.d, slotId, mouseButton, type, this.j.h);
    }

    @Override
    protected void a(char typedChar, int keyCode) throws IOException {
        if (keyCode == 1 || keyCode == this.j.t.aa.j()) {
            this.j.h.p();
        }
        this.b(keyCode);
        if (this.v != null && this.v.e()) {
            if (keyCode == this.j.t.af.j()) {
                this.a(this.v, this.v.e, 0, afu.d);
            } else if (keyCode == this.j.t.ac.j()) {
                this.a(this.v, this.v.e, bme.r() ? 1 : 0, afu.e);
            }
        }
    }

    protected boolean b(int keyCode) {
        if (this.j.h.bv.q().isEmpty() && this.v != null) {
            for (int i2 = 0; i2 < 9; ++i2) {
                if (keyCode != this.j.t.ap[i2].j()) continue;
                this.a(this.v, this.v.e, i2, afu.c);
                return true;
            }
        }
        return false;
    }

    @Override
    public void m() {
        if (this.j.h != null) {
            this.h.b(this.j.h);
        }
    }

    @Override
    public boolean d() {
        return false;
    }

    @Override
    public void e() {
        super.e();
        if (!this.j.h.aC() || this.j.h.F) {
            this.j.h.p();
        }
    }
}

