/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 *  org.apache.logging.log4j.Marker
 *  org.apache.logging.log4j.MarkerManager
 */
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import java.io.IOException;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.MarkerManager;

public class gz
extends ByteToMessageDecoder {
    private static final Logger a = LogManager.getLogger();
    private static final Marker b = MarkerManager.getMarker((String)"PACKET_RECEIVED", (Marker)gw.b);
    private final hu c;

    public gz(hu hu2) {
        this.c = hu2;
    }

    @Override
    protected void decode(ChannelHandlerContext channelHandlerContext, ByteBuf byteBuf, List<Object> list) throws Exception {
        if (byteBuf.readableBytes() == 0) {
            return;
        }
        gy gy2 = new gy(byteBuf);
        int \u26032 = gy2.g();
        ht<?> \u26033 = channelHandlerContext.channel().attr(gw.c).get().a(this.c, \u26032);
        if (\u26033 == null) {
            throw new IOException("Bad packet id " + \u26032);
        }
        \u26033.a(gy2);
        if (gy2.readableBytes() > 0) {
            throw new IOException("Packet " + channelHandlerContext.channel().attr(gw.c).get().a() + "/" + \u26032 + " (" + \u26033.getClass().getSimpleName() + ") was larger than I expected, found " + gy2.readableBytes() + " bytes extra whilst reading packet " + \u26032);
        }
        list.add(\u26033);
        if (a.isDebugEnabled()) {
            a.debug(b, " IN: [{}:{}] {}", (Object)channelHandlerContext.channel().attr(gw.c).get(), (Object)\u26032, (Object)\u26033.getClass().getName());
        }
    }
}

