/*
 * Decompiled with CFR 0.150.
 */
import java.util.Random;

public class asc
extends apa {
    public static final axg a = axg.a("age", 0, 3);
    private static final bgz[] c = new bgz[]{new bgz(0.0, 0.0, 0.0, 1.0, 0.3125, 1.0), new bgz(0.0, 0.0, 0.0, 1.0, 0.5, 1.0), new bgz(0.0, 0.0, 0.0, 1.0, 0.6875, 1.0), new bgz(0.0, 0.0, 0.0, 1.0, 0.875, 1.0)};

    protected asc() {
        super(bcx.k, bcy.E);
        this.w(this.A.b().a(a, 0));
        this.a(true);
        this.a((ahn)null);
    }

    @Override
    public bgz b(awr awr2, amw amw2, et et2) {
        return c[awr2.c(a)];
    }

    @Override
    protected boolean x(awr awr2) {
        return awr2.u() == aov.aW;
    }

    @Override
    public boolean f(ams ams2, et et2, awr awr2) {
        return this.x(ams2.o(et2.b()));
    }

    @Override
    public void b(ams ams22, et et2, awr awr22, Random random) {
        ams ams22;
        int n2 = awr22.c(a);
        if (n2 < 3 && random.nextInt(10) == 0) {
            awr awr22 = awr22.a(a, n2 + 1);
            ams22.a(et2, awr22, 2);
        }
        super.b(ams22, et2, awr22, random);
    }

    @Override
    public void a(ams ams2, et et2, awr awr2, float f2, int n2) {
        if (ams2.G) {
            return;
        }
        \u2603 = 1;
        if (awr2.c(a) >= 3) {
            \u2603 = 2 + ams2.r.nextInt(3);
            if (n2 > 0) {
                \u2603 += ams2.r.nextInt(n2 + 1);
            }
        }
        for (\u2603 = 0; \u2603 < \u2603; ++\u2603) {
            asc.a(ams2, et2, new ain(aip.bG));
        }
    }

    @Override
    public ail a(awr awr2, Random random, int n2) {
        return aip.a;
    }

    @Override
    public int a(Random random) {
        return 0;
    }

    @Override
    public ain a(ams ams2, et et2, awr awr2) {
        return new ain(aip.bG);
    }

    @Override
    public awr a(int n2) {
        return this.t().a(a, n2);
    }

    @Override
    public int e(awr awr2) {
        return awr2.c(a);
    }

    @Override
    protected aws b() {
        return new aws((aou)this, a);
    }
}

