/*
 * Decompiled with CFR 0.150.
 */
public interface eu
extends fe {
    @Override
    public double a();

    @Override
    public double b();

    @Override
    public double c();

    public et d();

    public awr e();

    public <T extends avh> T g();
}

