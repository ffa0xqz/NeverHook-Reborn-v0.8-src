/*
 * Decompiled with CFR 0.150.
 */
public class bju
extends bip
implements bor {
    private static final nd f = new nd("textures/gui/widgets.png");
    public static final nd a = new nd("textures/gui/spectator_widgets.png");
    private final bhz g;
    private long h;
    private boo i;

    public bju(bhz mcIn) {
        this.g = mcIn;
    }

    public void a(int p_175260_1_) {
        this.h = bhz.I();
        if (this.i != null) {
            this.i.b(p_175260_1_);
        } else {
            this.i = new boo(this);
        }
    }

    private float c() {
        long i2 = this.h - bhz.I() + 5000L;
        return ri.a((float)i2 / 2000.0f, 0.0f, 1.0f);
    }

    public void a(bir p_175264_1_, float p_175264_2_) {
        if (this.i != null) {
            float f2 = this.c();
            if (f2 <= 0.0f) {
                this.i.d();
            } else {
                int i2 = p_175264_1_.a() / 2;
                float f1 = e;
                e = -90.0f;
                float f22 = (float)p_175264_1_.b() - 22.0f * f2;
                bos spectatordetails = this.i.f();
                this.a(p_175264_1_, f2, i2, f22, spectatordetails);
                e = f1;
            }
        }
    }

    protected void a(bir p_175258_1_, float p_175258_2_, int p_175258_3_, float p_175258_4_, bos p_175258_5_) {
        buq.D();
        buq.m();
        buq.a(buq.r.l, buq.l.j, buq.r.e, buq.l.n);
        buq.c(1.0f, 1.0f, 1.0f, p_175258_2_);
        this.g.N().a(f);
        bju.a(p_175258_3_ - 91, p_175258_4_, 0, 0, 182, 22);
        if (p_175258_5_.b() >= 0) {
            bju.a(p_175258_3_ - 91 - 1 + p_175258_5_.b() * 20, p_175258_4_ - 1.0f, 0, 22, 24, 22);
        }
        bhx.c();
        for (int i2 = 0; i2 < 9; ++i2) {
            this.a(i2, p_175258_1_.a() / 2 - 90 + i2 * 20 + 2, p_175258_4_ + 3.0f, p_175258_2_, p_175258_5_.a(i2));
        }
        bhx.a();
        buq.E();
        buq.l();
    }

    private void a(int p_175266_1_, int p_175266_2_, float p_175266_3_, float p_175266_4_, boq p_175266_5_) {
        this.g.N().a(a);
        if (p_175266_5_ != boo.a) {
            int i2 = (int)(p_175266_4_ * 255.0f);
            buq.G();
            buq.c((float)p_175266_2_, p_175266_3_, 0.0f);
            float f2 = p_175266_5_.K_() ? 1.0f : 0.25f;
            buq.c(f2, f2, f2, p_175266_4_);
            p_175266_5_.a(f2, i2);
            buq.H();
            String s2 = String.valueOf(bib.a(this.g.t.ap[p_175266_1_].j()));
            if (i2 > 3 && p_175266_5_.K_()) {
                bhz.k.a(s2, p_175266_2_ + 19 - 2 - bhz.k.a(s2), p_175266_3_ + 6.0f + 3.0f, 0xFFFFFF + (i2 << 24));
            }
        }
    }

    public void a(bir p_175263_1_) {
        int i2 = (int)(this.c() * 255.0f);
        if (i2 > 3 && this.i != null) {
            String s2;
            boq ispectatormenuobject = this.i.b();
            String string = s2 = ispectatormenuobject == boo.a ? this.i.c().b().d() : ispectatormenuobject.J_().d();
            if (s2 != null) {
                int j2 = (p_175263_1_.a() - bhz.k.a(s2)) / 2;
                int k2 = p_175263_1_.b() - 35;
                buq.G();
                buq.m();
                buq.a(buq.r.l, buq.l.j, buq.r.e, buq.l.n);
                bhz.k.a(s2, j2, k2, 0xFFFFFF + (i2 << 24));
                buq.l();
                buq.H();
            }
        }
    }

    @Override
    public void a(boo p_175257_1_) {
        this.i = null;
        this.h = 0L;
    }

    public boolean a() {
        return this.i != null;
    }

    public void b(int p_175259_1_) {
        int i2;
        for (i2 = this.i.e() + p_175259_1_; !(i2 < 0 || i2 > 8 || this.i.a(i2) != boo.a && this.i.a(i2).K_()); i2 += p_175259_1_) {
        }
        if (i2 >= 0 && i2 <= 8) {
            this.i.b(i2);
            this.h = bhz.I();
        }
    }

    public void b() {
        this.h = bhz.I();
        if (this.a()) {
            int i2 = this.i.e();
            if (i2 != -1) {
                this.i.b(i2);
            }
        } else {
            this.i = new boo(this);
        }
    }
}

