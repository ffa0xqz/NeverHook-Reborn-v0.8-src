/*
 * Decompiled with CFR 0.150.
 */
import java.io.IOException;

public class lo
implements ht<kw> {
    private et a;
    private fa b;
    private a c;

    public lo() {
    }

    public lo(a a2, et et2, fa fa2) {
        this.c = a2;
        this.a = et2;
        this.b = fa2;
    }

    @Override
    public void a(gy gy2) throws IOException {
        this.c = gy2.a(a.class);
        this.a = gy2.e();
        this.b = fa.a(gy2.readUnsignedByte());
    }

    @Override
    public void b(gy gy2) throws IOException {
        gy2.a(this.c);
        gy2.a(this.a);
        gy2.writeByte(this.b.a());
    }

    @Override
    public void a(kw kw2) {
        kw2.a(this);
    }

    public et a() {
        return this.a;
    }

    public fa b() {
        return this.b;
    }

    public a c() {
        return this.c;
    }

    public static enum a {
        a,
        b,
        c,
        d,
        e,
        f,
        g;

    }
}

