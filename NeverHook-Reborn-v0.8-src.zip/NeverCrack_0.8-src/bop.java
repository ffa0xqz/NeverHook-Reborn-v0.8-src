/*
 * Decompiled with CFR 0.150.
 */
import java.util.List;

public interface bop {
    public List<boq> a();

    public hh b();
}

