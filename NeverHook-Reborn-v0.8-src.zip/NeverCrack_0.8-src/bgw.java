/*
 * Decompiled with CFR 0.150.
 */
public interface bgw {
    public boolean a();
}

