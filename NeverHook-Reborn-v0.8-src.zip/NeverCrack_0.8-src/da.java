/*
 * Decompiled with CFR 0.150.
 */
import net.minecraft.server.MinecraftServer;

public class da
extends bi {
    @Override
    public String c() {
        return "reload";
    }

    @Override
    public int a() {
        return 3;
    }

    @Override
    public String b(bn bn2) {
        return "commands.reload.usage";
    }

    @Override
    public void a(MinecraftServer minecraftServer, bn bn2, String[] arrstring) throws ei {
        if (arrstring.length > 0) {
            throw new ep("commands.reload.usage", new Object[0]);
        }
        minecraftServer.aM();
        da.a(bn2, (bk)this, "commands.reload.success", new Object[0]);
    }
}

