/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 */
import com.google.common.collect.Lists;
import java.io.IOException;
import java.util.List;

public class jr
implements ht<hw> {
    private a a;
    private List<akr> b;
    private List<akr> c;
    private boolean d;
    private boolean e;

    public jr() {
    }

    public jr(a a2, List<akr> list, List<akr> list2, boolean bl2, boolean bl3) {
        this.a = a2;
        this.b = list;
        this.c = list2;
        this.d = bl2;
        this.e = bl3;
    }

    @Override
    public void a(hw hw2) {
        hw2.a(this);
    }

    @Override
    public void a(gy gy2) throws IOException {
        this.a = gy2.a(a.class);
        this.d = gy2.readBoolean();
        this.e = gy2.readBoolean();
        int n2 = gy2.g();
        this.b = Lists.newArrayList();
        for (\u2603 = 0; \u2603 < n2; ++\u2603) {
            this.b.add(aks.a(gy2.g()));
        }
        if (this.a == jr$a.a) {
            n2 = gy2.g();
            this.c = Lists.newArrayList();
            for (\u2603 = 0; \u2603 < n2; ++\u2603) {
                this.c.add(aks.a(gy2.g()));
            }
        }
    }

    @Override
    public void b(gy gy22) throws IOException {
        gy22.a(this.a);
        gy22.writeBoolean(this.d);
        gy22.writeBoolean(this.e);
        gy22.d(this.b.size());
        for (akr akr2 : this.b) {
            gy22.d(aks.a(akr2));
        }
        if (this.a == jr$a.a) {
            gy gy22;
            gy22.d(this.c.size());
            for (akr akr2 : this.c) {
                gy22.d(aks.a(akr2));
            }
        }
    }

    public List<akr> a() {
        return this.b;
    }

    public List<akr> b() {
        return this.c;
    }

    public boolean c() {
        return this.d;
    }

    public boolean d() {
        return this.e;
    }

    public a e() {
        return this.a;
    }

    public static enum a {
        a,
        b,
        c;

    }
}

