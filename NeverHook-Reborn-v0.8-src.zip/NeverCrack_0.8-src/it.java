/*
 * Decompiled with CFR 0.150.
 */
import java.io.IOException;

public class it
implements ht<hw> {
    private int a;
    private int b;
    private int c;

    public it() {
    }

    public it(int n2, int n3, int n4) {
        this.a = n2;
        this.b = n3;
        this.c = n4;
    }

    @Override
    public void a(hw hw2) {
        hw2.a(this);
    }

    @Override
    public void a(gy gy2) throws IOException {
        this.a = gy2.readUnsignedByte();
        this.b = gy2.readShort();
        this.c = gy2.readShort();
    }

    @Override
    public void b(gy gy2) throws IOException {
        gy2.writeByte(this.a);
        gy2.writeShort(this.b);
        gy2.writeShort(this.c);
    }

    public int a() {
        return this.a;
    }

    public int b() {
        return this.b;
    }

    public int c() {
        return this.c;
    }
}

