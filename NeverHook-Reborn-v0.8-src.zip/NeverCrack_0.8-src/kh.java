/*
 * Decompiled with CFR 0.150.
 */
import java.io.IOException;

public class kh
implements ht<hw> {
    private float a;
    private int b;
    private float c;

    public kh() {
    }

    public kh(float f2, int n2, float f3) {
        this.a = f2;
        this.b = n2;
        this.c = f3;
    }

    @Override
    public void a(gy gy2) throws IOException {
        this.a = gy2.readFloat();
        this.b = gy2.g();
        this.c = gy2.readFloat();
    }

    @Override
    public void b(gy gy2) throws IOException {
        gy2.writeFloat(this.a);
        gy2.d(this.b);
        gy2.writeFloat(this.c);
    }

    @Override
    public void a(hw hw2) {
        hw2.a(this);
    }

    public float a() {
        return this.a;
    }

    public int b() {
        return this.b;
    }

    public float c() {
        return this.c;
    }
}

