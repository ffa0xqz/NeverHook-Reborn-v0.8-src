/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 */
import com.google.common.collect.Maps;
import java.util.Map;

public class vr {
    private static final Map<Class<?>, vo.a> a = Maps.newHashMap();

    public static vo.a a(Class<?> class_) {
        return a.get(class_);
    }

    static {
        a.put(zr.class, vo.a.a);
        a.put(zu.class, vo.a.a);
        a.put(zv.class, vo.a.a);
        a.put(aao.class, vo.a.a);
        a.put(aas.class, vo.a.a);
        a.put(aau.class, vo.a.a);
        a.put(aan.class, vo.a.a);
        a.put(aar.class, vo.a.a);
        a.put(zy.class, vo.a.a);
        a.put(zz.class, vo.a.a);
        a.put(aab.class, vo.a.a);
        a.put(aad.class, vo.a.a);
        a.put(aaa.class, vo.a.a);
        a.put(aae.class, vo.a.a);
        a.put(aag.class, vo.a.a);
        a.put(aah.class, vo.a.c);
        a.put(aai.class, vo.a.a);
        a.put(aak.class, vo.a.a);
        a.put(adw.class, vo.a.a);
        a.put(abb.class, vo.a.a);
        a.put(abv.class, vo.a.a);
        a.put(aco.class, vo.a.a);
        a.put(acp.class, vo.a.a);
        a.put(acq.class, vo.a.a);
        a.put(acs.class, vo.a.a);
        a.put(act.class, vo.a.a);
        a.put(acw.class, vo.a.a);
        a.put(acx.class, vo.a.a);
        a.put(acy.class, vo.a.c);
        a.put(adb.class, vo.a.a);
        a.put(add.class, vo.a.a);
        a.put(adh.class, vo.a.a);
        a.put(adi.class, vo.a.a);
        a.put(adq.class, vo.a.a);
        a.put(adm.class, vo.a.a);
        a.put(adj.class, vo.a.a);
        a.put(adl.class, vo.a.a);
        a.put(adp.class, vo.a.a);
        a.put(adr.class, vo.a.a);
        a.put(ads.class, vo.a.a);
        a.put(acz.class, vo.a.a);
    }
}

