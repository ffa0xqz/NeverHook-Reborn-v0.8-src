/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonDeserializationContext
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonSerializationContext
 */
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import java.util.Random;

public class bfw
extends bfx {
    private final bfu a;
    private final boolean b;

    public bfw(bgj[] arrbgj, bfu bfu2, boolean bl2) {
        super(arrbgj);
        this.a = bfu2;
        this.b = bl2;
    }

    @Override
    public ain a(ain ain2, Random random, bfr bfr2) {
        return alk.a(random, ain2, this.a.a(random), this.b);
    }

    public static class a
    extends bfx.a<bfw> {
        public a() {
            super(new nd("enchant_with_levels"), bfw.class);
        }

        @Override
        public void a(JsonObject jsonObject, bfw bfw2, JsonSerializationContext jsonSerializationContext) {
            jsonObject.add("levels", jsonSerializationContext.serialize((Object)bfw2.a));
            jsonObject.addProperty("treasure", Boolean.valueOf(bfw2.b));
        }

        public bfw a(JsonObject jsonObject, JsonDeserializationContext jsonDeserializationContext, bgj[] arrbgj) {
            bfu bfu2 = ra.a(jsonObject, "levels", jsonDeserializationContext, bfu.class);
            boolean \u26032 = ra.a(jsonObject, "treasure", false);
            return new bfw(arrbgj, bfu2, \u26032);
        }

        @Override
        public /* synthetic */ bfx b(JsonObject jsonObject, JsonDeserializationContext jsonDeserializationContext, bgj[] arrbgj) {
            return this.a(jsonObject, jsonDeserializationContext, arrbgj);
        }
    }
}

