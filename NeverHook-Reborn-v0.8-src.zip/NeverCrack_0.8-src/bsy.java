/*
 * Decompiled with CFR 0.150.
 */
import optifine.Config;
import shadersmod.client.Shaders;

public class bsy
extends btd {
    private final ve a;
    private final ve b;
    private int L;
    private final int M;
    private final float N;
    private final bzd O = bhz.z().ac();

    public bsy(ams worldIn, ve p_i1233_2_, ve p_i1233_3_, float p_i1233_4_) {
        super(worldIn, p_i1233_2_.p, p_i1233_2_.q, p_i1233_2_.r, p_i1233_2_.s, p_i1233_2_.t, p_i1233_2_.u);
        this.a = p_i1233_2_;
        this.b = p_i1233_3_;
        this.M = 3;
        this.N = p_i1233_4_;
    }

    @Override
    public void a(bui worldRendererIn, ve entityIn, float partialTicks, float rotationX, float rotationZ, float rotationYZ, float rotationXY, float rotationXZ) {
        int i2 = 0;
        if (Config.isShaders()) {
            i2 = Shaders.activeProgram;
            Shaders.nextEntity(this.a);
        }
        float f2 = ((float)this.L + partialTicks) / (float)this.M;
        f2 *= f2;
        double d0 = this.a.p;
        double d1 = this.a.q;
        double d2 = this.a.r;
        double d3 = this.b.M + (this.b.p - this.b.M) * (double)partialTicks;
        double d4 = this.b.N + (this.b.q - this.b.N) * (double)partialTicks + (double)this.N;
        double d5 = this.b.O + (this.b.r - this.b.O) * (double)partialTicks;
        double d6 = d0 + (d3 - d0) * (double)f2;
        double d7 = d1 + (d4 - d1) * (double)f2;
        double d8 = d2 + (d5 - d2) * (double)f2;
        int j2 = this.a(partialTicks);
        int k2 = j2 % 65536;
        int l2 = j2 / 65536;
        cig.a(cig.r, k2, (float)l2);
        buq.c(1.0f, 1.0f, 1.0f, 1.0f);
        buq.f();
        this.O.a(this.a, d6 -= H, d7 -= I, d8 -= J, this.a.v, partialTicks, false);
        if (Config.isShaders()) {
            Shaders.useProgram(i2);
        }
    }

    @Override
    public void a() {
        ++this.L;
        if (this.L == this.M) {
            this.i();
        }
    }

    @Override
    public int b() {
        return 3;
    }
}

