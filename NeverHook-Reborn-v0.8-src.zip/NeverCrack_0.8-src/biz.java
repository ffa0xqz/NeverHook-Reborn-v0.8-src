/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  javax.annotation.Nullable
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import top.nhprem.client.features.impl.display.HUD;

public class biz
extends bip {
    private static final Logger a = LogManager.getLogger();
    private final bhz f;
    private final List<String> g = Lists.newArrayList();
    private final List<bhv> h = Lists.newArrayList();
    private final List<bhv> i = Lists.newArrayList();
    private int j;
    private boolean k;
    private float offset;
    private double deltaY;

    public biz(bhz mcIn) {
        this.f = mcIn;
    }

    public void a(int p_146230_1_) {
        this.offset = (float)((double)this.offset + this.deltaY);
        this.deltaY /= Math.pow(0.99, -bhz.frameTime);
        if ((int)this.offset != 0 && (int)this.offset % 8 == 0) {
            this.offset = 8.0f;
        }
        if (this.f.t.o != aeb.b.c) {
            int i2 = this.h();
            boolean flag = false;
            int j2 = 0;
            int k2 = this.i.size();
            float f2 = this.f.t.s * 0.9f + 0.1f;
            if (k2 > 0) {
                if (this.d()) {
                    flag = true;
                }
                float f1 = this.g();
                int l2 = ri.ceiling_float_int((float)this.e() / f1);
                buq.G();
                buq.c(2.0f, 8.0f, 0.0f);
                buq.b(f1, f1, 1.0f);
                for (int i1 = 0; i1 + this.j < this.i.size() && i1 < i2; ++i1) {
                    int j1;
                    bhv chatline = this.i.get(i1 + this.j);
                    if (chatline == null || (j1 = p_146230_1_ - chatline.b()) >= 200 && !flag) continue;
                    double d0 = (double)j1 / 200.0;
                    d0 = 1.0 - d0;
                    d0 *= 10.0;
                    d0 = ri.a(d0, 0.0, 1.0);
                    d0 *= d0;
                    int l1 = (int)(255.0 * d0);
                    if (flag) {
                        l1 = 255;
                    }
                    l1 = (int)((float)l1 * f2);
                    ++j2;
                    if (l1 <= 3) continue;
                    boolean i22 = false;
                    int j22 = -i1 * 9;
                    biz.drawRect((double)i22, (float)(j22 - 1) - this.offset - HUD.globalOffset / 5.0f, l2 + 4, (float)(j22 + 8) - this.offset - HUD.globalOffset / 5.0f, l1 / 2 << 24);
                    String s2 = chatline.a().d();
                    buq.m();
                    bhz.k.a(s2, (float)i22, (float)j22 - this.offset - HUD.globalOffset / 5.0f, 0xFFFFFF + (l1 << 24));
                    buq.d();
                    buq.l();
                }
                if (flag) {
                    int k22 = bhz.k.a;
                    buq.c(-3.0f, 0.0f, 0.0f);
                    int l22 = k2 * k22 + k2;
                    int i3 = j2 * k22 + j2;
                    int j3 = this.j * i3 / k2;
                    int k1 = i3 * i3 / l22;
                    if (l22 != i3) {
                        int k3 = j3 > 0 ? 170 : 96;
                        int l3 = this.k ? 0xCC3333 : 0x3333AA;
                        biz.drawRect(0.0, -j3, 2.0, -j3 - k1, l3 + (k3 << 24));
                        biz.drawRect(2.0, -j3, 1.0, -j3 - k1, 0xCCCCCC + (k3 << 24));
                    }
                }
                buq.H();
            }
        }
    }

    public void a(boolean p_146231_1_) {
        this.i.clear();
        this.h.clear();
        if (p_146231_1_) {
            this.g.clear();
        }
    }

    public void a(hh chatComponent) {
        this.deltaY = 1.0;
        this.offset = 0.0f;
        this.a(chatComponent, 0);
    }

    public void a(hh chatComponent, int chatLineId) {
        this.a(chatComponent, chatLineId, this.f.q.e(), false);
        a.info("[CHAT] {}", (Object)chatComponent.c().replaceAll("\r", "\\\\r").replaceAll("\n", "\\\\n"));
    }

    private void a(hh chatComponent, int chatLineId, int updateCounter, boolean displayOnly) {
        if (chatLineId != 0) {
            this.c(chatLineId);
        }
        int i2 = ri.d((float)this.e() / this.g());
        List<hh> list = bja.a(chatComponent, i2, bhz.k, false, false);
        boolean flag = this.d();
        for (hh itextcomponent : list) {
            if (flag && this.j > 0) {
                this.k = true;
                this.b(1);
            }
            this.i.add(0, new bhv(updateCounter, itextcomponent, chatLineId));
        }
        while (this.i.size() > 100) {
            this.i.remove(this.i.size() - 1);
        }
        if (!displayOnly) {
            this.h.add(0, new bhv(updateCounter, chatComponent, chatLineId));
            while (this.h.size() > 100) {
                this.h.remove(this.h.size() - 1);
            }
        }
    }

    public void a() {
        this.i.clear();
        this.c();
        for (int i2 = this.h.size() - 1; i2 >= 0; --i2) {
            bhv chatline = this.h.get(i2);
            this.a(chatline.a(), chatline.c(), chatline.b(), true);
        }
    }

    public List<String> b() {
        return this.g;
    }

    public void a(String message) {
        if (this.g.isEmpty() || !this.g.get(this.g.size() - 1).equals(message)) {
            this.g.add(message);
        }
    }

    public void c() {
        this.j = 0;
        this.k = false;
    }

    public void b(int amount) {
        this.j += amount;
        int i2 = this.i.size();
        if (this.j > i2 - this.h()) {
            this.j = i2 - this.h();
        }
        if (this.j <= 0) {
            this.j = 0;
            this.k = false;
        }
    }

    @Nullable
    public hh a(int mouseX, int mouseY) {
        if (!this.d()) {
            return null;
        }
        bir scaledresolution = new bir(this.f);
        int i2 = bir.e();
        float f2 = this.g();
        int j2 = mouseX / i2 - 2;
        int k2 = mouseY / i2 - 40;
        j2 = ri.d((float)j2 / f2);
        k2 = ri.d((float)k2 / f2);
        if (j2 >= 0 && k2 >= 0) {
            int l2 = Math.min(this.h(), this.i.size());
            if (j2 <= ri.d((float)this.e() / this.g())) {
                if (k2 < bhz.k.a * l2 + l2) {
                    int i1 = k2 / bhz.k.a + this.j;
                    if (i1 >= 0 && i1 < this.i.size()) {
                        bhv chatline = this.i.get(i1);
                        int j1 = 0;
                        for (hh itextcomponent : chatline.a()) {
                            if (!(itextcomponent instanceof ho)) continue;
                            if ((j1 += bhz.k.a(bja.a(((ho)itextcomponent).g(), false))) <= j2) continue;
                            return itextcomponent;
                        }
                    }
                    return null;
                }
            }
            return null;
        }
        return null;
    }

    public boolean d() {
        return this.f.m instanceof bkl;
    }

    public void c(int id2) {
        Iterator<bhv> iterator = this.i.iterator();
        while (iterator.hasNext()) {
            bhv chatline = iterator.next();
            if (chatline.c() != id2) continue;
            iterator.remove();
        }
        iterator = this.h.iterator();
        while (iterator.hasNext()) {
            bhv chatline1 = iterator.next();
            if (chatline1.c() != id2) continue;
            iterator.remove();
            break;
        }
    }

    public int e() {
        return biz.a(this.f.t.H);
    }

    public int f() {
        return biz.b(this.d() ? this.f.t.J : this.f.t.I);
    }

    public float g() {
        return this.f.t.G;
    }

    public static int a(float scale) {
        int i2 = 320;
        int j2 = 40;
        return ri.d(scale * 280.0f + 40.0f);
    }

    public static int b(float scale) {
        int i2 = 180;
        int j2 = 20;
        return ri.d(scale * 160.0f + 20.0f);
    }

    public int h() {
        return this.f() / 9;
    }
}

