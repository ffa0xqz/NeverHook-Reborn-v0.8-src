/*
 * Decompiled with CFR 0.150.
 */
public enum ub {
    a,
    b,
    c;

}

