/*
 * Decompiled with CFR 0.150.
 */
public class cbm
extends bzp<ads> {
    private static final nd a = new nd("textures/entity/zombie_villager/zombie_villager.png");
    private static final nd j = new nd("textures/entity/zombie_villager/zombie_farmer.png");
    private static final nd k = new nd("textures/entity/zombie_villager/zombie_librarian.png");
    private static final nd l = new nd("textures/entity/zombie_villager/zombie_priest.png");
    private static final nd m = new nd("textures/entity/zombie_villager/zombie_smith.png");
    private static final nd n = new nd("textures/entity/zombie_villager/zombie_butcher.png");

    public cbm(bzd bzd2) {
        super(bzd2, new brf(), 0.5f);
        this.a(new cck(this));
    }

    @Override
    protected nd a(ads ads2) {
        switch (ads2.dp()) {
            case 0: {
                return j;
            }
            case 1: {
                return k;
            }
            case 2: {
                return l;
            }
            case 3: {
                return m;
            }
            case 4: {
                return n;
            }
        }
        return a;
    }

    @Override
    protected void a(ads ads2, float f2, float f3, float f4) {
        if (ads2.ds()) {
            f3 += (float)(Math.cos((double)ads2.T * 3.25) * Math.PI * 0.25);
        }
        super.a(ads2, f2, f3, f4);
    }
}

