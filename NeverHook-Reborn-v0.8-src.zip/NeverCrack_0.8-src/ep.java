/*
 * Decompiled with CFR 0.150.
 */
public class ep
extends em {
    public ep(String string, Object ... arrobject) {
        super(string, arrobject);
    }

    @Override
    public synchronized Throwable fillInStackTrace() {
        return this;
    }
}

