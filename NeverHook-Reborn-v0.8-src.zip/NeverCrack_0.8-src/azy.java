/*
 * Decompiled with CFR 0.150.
 */
import java.util.Random;

public class azy
extends azs {
    private final aou a;
    private final boolean b;

    public azy(aou aou2, boolean bl2) {
        this.a = aou2;
        this.b = bl2;
    }

    @Override
    public boolean b(ams ams2, Random random, et et2) {
        if (ams2.o(et2.a()).u() != aov.aV) {
            return false;
        }
        if (ams2.o(et2).a() != bcx.a && ams2.o(et2).u() != aov.aV) {
            return false;
        }
        int n2 = 0;
        if (ams2.o(et2.e()).u() == aov.aV) {
            ++n2;
        }
        if (ams2.o(et2.f()).u() == aov.aV) {
            ++n2;
        }
        if (ams2.o(et2.c()).u() == aov.aV) {
            ++n2;
        }
        if (ams2.o(et2.d()).u() == aov.aV) {
            ++n2;
        }
        if (ams2.o(et2.b()).u() == aov.aV) {
            ++n2;
        }
        \u2603 = 0;
        if (ams2.d(et2.e())) {
            ++\u2603;
        }
        if (ams2.d(et2.f())) {
            ++\u2603;
        }
        if (ams2.d(et2.c())) {
            ++\u2603;
        }
        if (ams2.d(et2.d())) {
            ++\u2603;
        }
        if (ams2.d(et2.b())) {
            ++\u2603;
        }
        if (!this.b && n2 == 4 && \u2603 == 1 || n2 == 5) {
            awr awr2 = this.a.t();
            ams2.a(et2, awr2, 2);
            ams2.a(et2, awr2, random);
        }
        return true;
    }
}

