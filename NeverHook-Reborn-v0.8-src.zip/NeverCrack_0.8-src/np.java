/*
 * Decompiled with CFR 0.150.
 */
public final class np
extends RuntimeException {
    public static final np a = new np();

    private np() {
        this.setStackTrace(new StackTraceElement[0]);
    }

    @Override
    public synchronized Throwable fillInStackTrace() {
        this.setStackTrace(new StackTraceElement[0]);
        return this;
    }
}

