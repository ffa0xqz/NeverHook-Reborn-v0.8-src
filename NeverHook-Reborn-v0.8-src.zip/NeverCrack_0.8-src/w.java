/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Maps
 *  com.google.common.collect.Sets
 *  com.google.gson.JsonDeserializationContext
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonSyntaxException
 *  javax.annotation.Nullable
 */
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nullable;

public class w
implements p<b> {
    private static final nd a = new nd("brewed_potion");
    private final Map<nn, a> b = Maps.newHashMap();

    @Override
    public nd a() {
        return a;
    }

    @Override
    public void a(nn nn2, p.a<b> a2) {
        a a3 = this.b.get(nn2);
        if (a3 == null) {
            a3 = new a(nn2);
            this.b.put(nn2, a3);
        }
        a3.a(a2);
    }

    @Override
    public void b(nn nn2, p.a<b> a2) {
        a a3 = this.b.get(nn2);
        if (a3 != null) {
            a3.b(a2);
            if (a3.a()) {
                this.b.remove(nn2);
            }
        }
    }

    @Override
    public void a(nn nn2) {
        this.b.remove(nn2);
    }

    public b b(JsonObject jsonObject, JsonDeserializationContext jsonDeserializationContext) {
        ake \u26032 = null;
        if (jsonObject.has("potion")) {
            nd nd2 = new nd(ra.h(jsonObject, "potion"));
            if (!ake.a.d(nd2)) {
                throw new JsonSyntaxException("Unknown potion '" + nd2 + "'");
            }
            \u26032 = ake.a.c(nd2);
        }
        return new b(\u26032);
    }

    public void a(oo oo2, ake ake2) {
        a a2 = this.b.get(oo2.P());
        if (a2 != null) {
            a2.a(ake2);
        }
    }

    @Override
    public /* synthetic */ q a(JsonObject jsonObject, JsonDeserializationContext jsonDeserializationContext) {
        return this.b(jsonObject, jsonDeserializationContext);
    }

    static class a {
        private final nn a;
        private final Set<p.a<b>> b = Sets.newHashSet();

        public a(nn nn2) {
            this.a = nn2;
        }

        public boolean a() {
            return this.b.isEmpty();
        }

        public void a(p.a<b> a2) {
            this.b.add(a2);
        }

        public void b(p.a<b> a2) {
            this.b.remove(a2);
        }

        public void a(ake ake2) {
            List list = null;
            for (p.a<b> a2 : this.b) {
                if (!a2.a().a(ake2)) continue;
                if (list == null) {
                    list = Lists.newArrayList();
                }
                list.add(a2);
            }
            if (list != null) {
                for (p.a<b> a2 : list) {
                    a2.a(this.a);
                }
            }
        }
    }

    public static class b
    extends u {
        private final ake a;

        public b(@Nullable ake ake2) {
            super(a);
            this.a = ake2;
        }

        public boolean a(ake ake2) {
            return this.a == null || this.a == ake2;
        }
    }
}

