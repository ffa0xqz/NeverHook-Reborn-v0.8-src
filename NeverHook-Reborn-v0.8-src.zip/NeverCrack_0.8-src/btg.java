/*
 * Decompiled with CFR 0.150.
 */
public class btg
extends btd {
    float a;

    protected btg(ams ams2, double d2, double d3, double d4, double d5, double d6, double d7) {
        super(ams2, d2, d3, d4, 0.0, 0.0, 0.0);
        float f2 = 2.5f;
        this.j *= (double)0.1f;
        this.k *= (double)0.1f;
        this.l *= (double)0.1f;
        this.j += d5;
        this.k += d6;
        this.l += d7;
        this.A = \u2603 = 1.0f - (float)(Math.random() * (double)0.3f);
        this.B = \u2603;
        this.C = \u2603;
        this.y *= 0.75f;
        this.y *= 2.5f;
        this.a = this.y;
        this.x = (int)(8.0 / (Math.random() * 0.8 + 0.3));
        this.x = (int)((float)this.x * 2.5f);
    }

    @Override
    public void a(bui bui2, ve ve2, float f2, float f3, float f4, float f5, float f6, float f7) {
        \u2603 = ((float)this.w + f2) / (float)this.x * 32.0f;
        \u2603 = ri.a(\u2603, 0.0f, 1.0f);
        this.y = this.a * \u2603;
        super.a(bui2, ve2, f2, f3, f4, f5, f6, f7);
    }

    @Override
    public void a() {
        this.d = this.g;
        this.e = this.h;
        this.f = this.i;
        if (this.w++ >= this.x) {
            this.i();
        }
        this.b(7 - this.w * 8 / this.x);
        this.a(this.j, this.k, this.l);
        this.j *= (double)0.96f;
        this.k *= (double)0.96f;
        this.l *= (double)0.96f;
        aeb aeb2 = this.c.a(this.g, this.h, this.i, 2.0, false);
        if (aeb2 != null) {
            bgz bgz2 = aeb2.bw();
            if (this.h > bgz2.b) {
                this.h += (bgz2.b - this.h) * 0.2;
                this.k += (aeb2.t - this.k) * 0.2;
                this.b(this.g, this.h, this.i);
            }
        }
        if (this.m) {
            this.j *= (double)0.7f;
            this.l *= (double)0.7f;
        }
    }

    public static class a
    implements btf {
        @Override
        public btd a(int n2, ams ams2, double d2, double d3, double d4, double d5, double d6, double d7, int ... arrn) {
            return new btg(ams2, d2, d3, d4, d5, d6, d7);
        }
    }
}

