/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 */
import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.List;

public class bja {
    public static String a(String string, boolean bl2) {
        if (bl2 || bhz.z().t.p) {
            return string;
        }
        return a.a(string);
    }

    public static List<hh> a(hh hh2, int n2, bin bin2, boolean bl2, boolean bl3) {
        int n3 = 0;
        ho \u26032 = new ho("");
        ArrayList \u26033 = Lists.newArrayList();
        ArrayList \u26034 = Lists.newArrayList((Iterable)hh2);
        for (\u2603 = 0; \u2603 < \u26034.size(); ++\u2603) {
            String \u26037;
            hh hh3 = (hh)\u26034.get(\u2603);
            String \u26035 = hh3.e();
            boolean \u26036 = false;
            if (\u26035.contains("\n")) {
                int n4 = \u26035.indexOf(10);
                \u26037 = \u26035.substring(n4 + 1);
                \u26035 = \u26035.substring(0, n4 + 1);
                ho \u26038 = new ho(\u26037);
                \u26038.a(hh3.b().m());
                \u26034.add(\u2603 + 1, \u26038);
                \u26036 = true;
            }
            \u26037 = (\u2603 = bja.a(hh3.b().k() + \u26035, bl3)).endsWith("\n") ? \u2603.substring(0, \u2603.length() - 1) : \u2603;
            n6 = bin2.a(\u26037);
            ho \u260310 = new ho(\u26037);
            \u260310.a(hh3.b().m());
            if (n3 + n6 > n2) {
                String string = bin2.a(\u2603, n2 - n3, false);
                String string2 = string3 = string.length() < \u2603.length() ? \u2603.substring(string.length()) : null;
                if (string3 != null && !string3.isEmpty()) {
                    String string3;
                    int n5 = string.lastIndexOf(32);
                    if (n5 >= 0 && bin2.a(\u2603.substring(0, n5)) > 0) {
                        string = \u2603.substring(0, n5);
                        if (bl2) {
                            ++n5;
                        }
                        string3 = \u2603.substring(n5);
                    } else if (n3 > 0 && !\u2603.contains(" ")) {
                        string = "";
                        string3 = \u2603;
                    }
                    ho \u26039 = new ho(string3);
                    \u26039.a(hh3.b().m());
                    \u26034.add(\u2603 + 1, \u26039);
                }
                \u2603 = string;
                int n6 = bin2.a(\u2603);
                \u260310 = new ho(\u2603);
                \u260310.a(hh3.b().m());
                \u26036 = true;
            }
            if (n3 + n6 <= n2) {
                n3 += n6;
                \u26032.a(\u260310);
            } else {
                \u26036 = true;
            }
            if (!\u26036) continue;
            \u26033.add(\u26032);
            n3 = 0;
            \u26032 = new ho("");
        }
        \u26033.add(\u26032);
        return \u26033;
    }
}

