/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import javax.annotation.Nullable;

public class bss {

    public static class d
    implements btf {
        @Override
        public btd a(int n2, ams ams2, double d2, double d3, double d4, double d5, double d6, double d7, int ... arrn) {
            b b2 = new b(ams2, d2, d3, d4, d5, d6, d7, bhz.z().j);
            b2.e(0.99f);
            return b2;
        }
    }

    public static class a
    extends btd {
        protected a(ams ams2, double d2, double d3, double d4) {
            super(ams2, d2, d3, d4);
            this.x = 4;
        }

        @Override
        public void a(bui bui2, ve ve2, float f2, float f3, float f4, float f5, float f6, float f7) {
            \u2603 = 0.25f;
            \u2603 = 0.5f;
            \u2603 = 0.125f;
            \u2603 = 0.375f;
            \u2603 = 7.1f * ri.a(((float)this.w + f2 - 1.0f) * 0.25f * (float)Math.PI);
            this.e(0.6f - ((float)this.w + f2 - 1.0f) * 0.25f * 0.5f);
            \u2603 = (float)(this.d + (this.g - this.d) * (double)f2 - H);
            \u2603 = (float)(this.e + (this.h - this.e) * (double)f2 - I);
            \u2603 = (float)(this.f + (this.i - this.f) * (double)f2 - J);
            int n2 = this.a(f2);
            \u2603 = n2 >> 16 & 0xFFFF;
            \u2603 = n2 & 0xFFFF;
            bui2.b((double)(\u2603 - f3 * \u2603 - f6 * \u2603), (double)(\u2603 - f4 * \u2603), (double)(\u2603 - f5 * \u2603 - f7 * \u2603)).a(0.5, 0.375).a(this.A, this.B, this.C, this.D).a(\u2603, \u2603).d();
            bui2.b((double)(\u2603 - f3 * \u2603 + f6 * \u2603), (double)(\u2603 + f4 * \u2603), (double)(\u2603 - f5 * \u2603 + f7 * \u2603)).a(0.5, 0.125).a(this.A, this.B, this.C, this.D).a(\u2603, \u2603).d();
            bui2.b((double)(\u2603 + f3 * \u2603 + f6 * \u2603), (double)(\u2603 + f4 * \u2603), (double)(\u2603 + f5 * \u2603 + f7 * \u2603)).a(0.25, 0.125).a(this.A, this.B, this.C, this.D).a(\u2603, \u2603).d();
            bui2.b((double)(\u2603 + f3 * \u2603 - f6 * \u2603), (double)(\u2603 - f4 * \u2603), (double)(\u2603 + f5 * \u2603 - f7 * \u2603)).a(0.25, 0.375).a(this.A, this.B, this.C, this.D).a(\u2603, \u2603).d();
        }
    }

    public static class b
    extends btj {
        private boolean a;
        private boolean b;
        private final bte L;
        private float M;
        private float N;
        private float O;
        private boolean P;

        public b(ams ams2, double d2, double d3, double d4, double d5, double d6, double d7, bte bte2) {
            super(ams2, d2, d3, d4, 160, 8, -0.004f);
            this.j = d5;
            this.k = d6;
            this.l = d7;
            this.L = bte2;
            this.y *= 0.75f;
            this.x = 48 + this.r.nextInt(12);
        }

        public void a(boolean bl2) {
            this.a = bl2;
        }

        public void b(boolean bl2) {
            this.b = bl2;
        }

        @Override
        public boolean c() {
            return true;
        }

        @Override
        public void a(bui bui2, ve ve2, float f2, float f3, float f4, float f5, float f6, float f7) {
            if (!this.b || this.w < this.x / 3 || (this.w + this.x) / 3 % 2 == 0) {
                super.a(bui2, ve2, f2, f3, f4, f5, f6, f7);
            }
        }

        @Override
        public void a() {
            super.a();
            if (this.a && this.w < this.x / 2 && (this.w + this.x) % 2 == 0) {
                b b2 = new b(this.c, this.g, this.h, this.i, 0.0, 0.0, 0.0, this.L);
                b2.e(0.99f);
                b2.a(this.A, this.B, this.C);
                b2.w = b2.x / 2;
                if (this.P) {
                    b2.P = true;
                    b2.M = this.M;
                    b2.N = this.N;
                    b2.O = this.O;
                }
                b2.b = this.b;
                this.L.a(b2);
            }
        }
    }

    public static class c
    extends btd {
        private int b;
        private final bte L;
        private ge M;
        boolean a;

        public c(ams ams2, double d2, double d3, double d4, double d5, double d6, double d7, bte bte2, @Nullable fy fy2) {
            super(ams2, d2, d3, d4, 0.0, 0.0, 0.0);
            this.j = d5;
            this.k = d6;
            this.l = d7;
            this.L = bte2;
            this.x = 8;
            if (fy2 != null) {
                this.M = fy2.c("Explosions", 10);
                if (this.M.b_()) {
                    this.M = null;
                } else {
                    this.x = this.M.c() * 2 - 1;
                    for (int i2 = 0; i2 < this.M.c(); ++i2) {
                        fy fy3 = this.M.b(i2);
                        if (!fy3.q("Flicker")) continue;
                        this.a = true;
                        this.x += 15;
                        break;
                    }
                }
            }
        }

        @Override
        public void a(bui bui2, ve ve2, float f2, float f3, float f4, float f5, float f6, float f7) {
        }

        @Override
        public void a() {
            if (this.b == 0 && this.M != null) {
                int n2 = this.m();
                boolean \u26032 = false;
                if (this.M.c() >= 3) {
                    \u26032 = true;
                } else {
                    for (\u2603 = 0; \u2603 < this.M.c(); ++\u2603) {
                        fy fy2 = this.M.b(\u2603);
                        if (fy2.f("Type") != 1) continue;
                        \u26032 = true;
                        break;
                    }
                }
                qc \u26033 = \u26032 ? (n2 != 0 ? qd.bH : qd.bG) : (n2 != 0 ? qd.bF : qd.bE);
                this.c.a(this.g, this.h, this.i, \u26033, qe.i, 20.0f, 0.95f + this.r.nextFloat() * 0.1f, true);
            }
            if (this.b % 2 == 0 && this.M != null && this.b / 2 < this.M.c()) {
                n2 = this.b / 2;
                fy \u26034 = this.M.b(n2);
                byte \u26035 = \u26034.f("Type");
                boolean \u26036 = \u26034.q("Trail");
                boolean \u26037 = \u26034.q("Flicker");
                int[] \u26038 = \u26034.n("Colors");
                int[] \u26039 = \u26034.n("FadeColors");
                if (\u26038.length == 0) {
                    \u26038 = new int[]{ahr.a[0]};
                }
                if (\u26035 == 1) {
                    this.a(0.5, 4, \u26038, \u26039, \u26036, \u26037);
                } else if (\u26035 == 2) {
                    this.a(0.5, new double[][]{{0.0, 1.0}, {0.3455, 0.309}, {0.9511, 0.309}, {0.3795918367346939, -0.12653061224489795}, {0.6122448979591837, -0.8040816326530612}, {0.0, -0.35918367346938773}}, \u26038, \u26039, \u26036, \u26037, false);
                } else if (\u26035 == 3) {
                    this.a(0.5, new double[][]{{0.0, 0.2}, {0.2, 0.2}, {0.2, 0.6}, {0.6, 0.6}, {0.6, 0.2}, {0.2, 0.2}, {0.2, 0.0}, {0.4, 0.0}, {0.4, -0.6}, {0.2, -0.6}, {0.2, -0.4}, {0.0, -0.4}}, \u26038, \u26039, \u26036, \u26037, true);
                } else if (\u26035 == 4) {
                    this.a(\u26038, \u26039, \u26036, \u26037);
                } else {
                    this.a(0.25, 2, \u26038, \u26039, \u26036, \u26037);
                }
                \u2603 = \u26038[0];
                float \u260310 = (float)((\u2603 & 0xFF0000) >> 16) / 255.0f;
                float \u260311 = (float)((\u2603 & 0xFF00) >> 8) / 255.0f;
                float \u260312 = (float)((\u2603 & 0xFF) >> 0) / 255.0f;
                a \u260313 = new a(this.c, this.g, this.h, this.i);
                \u260313.a(\u260310, \u260311, \u260312);
                this.L.a(\u260313);
            }
            ++this.b;
            if (this.b > this.x) {
                if (this.a) {
                    n2 = this.m() ? 1 : 0;
                    qc qc2 = n2 != 0 ? qd.bL : qd.bK;
                    this.c.a(this.g, this.h, this.i, qc2, qe.i, 20.0f, 0.9f + this.r.nextFloat() * 0.15f, true);
                }
                this.i();
            }
        }

        private boolean m() {
            bhz bhz2 = bhz.z();
            return bhz2 == null || bhz2.aa() == null || !(bhz2.aa().d(this.g, this.h, this.i) < 256.0);
        }

        private void a(double d2, double d3, double d4, double d5, double d6, double d7, int[] arrn, int[] arrn2, boolean bl2, boolean bl3) {
            b b2 = new b(this.c, d2, d3, d4, d5, d6, d7, this.L);
            b2.e(0.99f);
            b2.a(bl2);
            b2.b(bl3);
            int \u26032 = this.r.nextInt(arrn.length);
            b2.c(arrn[\u26032]);
            if (arrn2 != null && arrn2.length > 0) {
                b2.d(arrn2[this.r.nextInt(arrn2.length)]);
            }
            this.L.a(b2);
        }

        private void a(double d2, int n2, int[] arrn, int[] arrn2, boolean bl2, boolean bl3) {
            double d3 = this.g;
            \u2603 = this.h;
            \u2603 = this.i;
            for (int i2 = -n2; i2 <= n2; ++i2) {
                for (\u2603 = -n2; \u2603 <= n2; ++\u2603) {
                    for (\u2603 = -n2; \u2603 <= n2; ++\u2603) {
                        double d4 = (double)\u2603 + (this.r.nextDouble() - this.r.nextDouble()) * 0.5;
                        \u2603 = (double)i2 + (this.r.nextDouble() - this.r.nextDouble()) * 0.5;
                        \u2603 = (double)\u2603 + (this.r.nextDouble() - this.r.nextDouble()) * 0.5;
                        \u2603 = (double)ri.a(d4 * d4 + \u2603 * \u2603 + \u2603 * \u2603) / d2 + this.r.nextGaussian() * 0.05;
                        this.a(d3, \u2603, \u2603, d4 / \u2603, \u2603 / \u2603, \u2603 / \u2603, arrn, arrn2, bl2, bl3);
                        if (i2 == -n2 || i2 == n2 || \u2603 == -n2 || \u2603 == n2) continue;
                        \u2603 += n2 * 2 - 1;
                    }
                }
            }
        }

        private void a(double d2, double[][] arrd, int[] arrn, int[] arrn2, boolean bl2, boolean bl3, boolean bl4) {
            double d3 = arrd[0][0];
            \u2603 = arrd[0][1];
            this.a(this.g, this.h, this.i, d3 * d2, \u2603 * d2, 0.0, arrn, arrn2, bl2, bl3);
            float \u26032 = this.r.nextFloat() * (float)Math.PI;
            \u2603 = bl4 ? 0.034 : 0.34;
            for (int i2 = 0; i2 < 3; ++i2) {
                double d4 = (double)\u26032 + (double)((float)i2 * (float)Math.PI) * \u2603;
                \u2603 = d3;
                \u2603 = \u2603;
                for (int i3 = 1; i3 < arrd.length; ++i3) {
                    double d5 = arrd[i3][0];
                    \u2603 = arrd[i3][1];
                    for (\u2603 = 0.25; \u2603 <= 1.0; \u2603 += 0.25) {
                        \u2603 = (\u2603 + (d5 - \u2603) * \u2603) * d2;
                        \u2603 = (\u2603 + (\u2603 - \u2603) * \u2603) * d2;
                        \u2603 = \u2603 * Math.sin(d4);
                        \u2603 *= Math.cos(d4);
                        for (\u2603 = -1.0; \u2603 <= 1.0; \u2603 += 2.0) {
                            this.a(this.g, this.h, this.i, \u2603 * \u2603, \u2603, \u2603 * \u2603, arrn, arrn2, bl2, bl3);
                        }
                    }
                    \u2603 = d5;
                    \u2603 = \u2603;
                }
            }
        }

        private void a(int[] arrn, int[] arrn2, boolean bl2, boolean bl3) {
            double d2 = this.r.nextGaussian() * 0.05;
            \u2603 = this.r.nextGaussian() * 0.05;
            for (int i2 = 0; i2 < 70; ++i2) {
                double d3 = this.j * 0.5 + this.r.nextGaussian() * 0.15 + d2;
                \u2603 = this.l * 0.5 + this.r.nextGaussian() * 0.15 + \u2603;
                \u2603 = this.k * 0.5 + this.r.nextDouble() * 0.5;
                this.a(this.g, this.h, this.i, d3, \u2603, \u2603, arrn, arrn2, bl2, bl3);
            }
        }

        @Override
        public int b() {
            return 0;
        }
    }
}

