/*
 * Decompiled with CFR 0.150.
 */
public class are
extends aui {
    @Override
    public boolean e() {
        return false;
    }
}

