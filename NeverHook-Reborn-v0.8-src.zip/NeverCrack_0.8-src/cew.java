/*
 * Decompiled with CFR 0.150.
 */
import java.util.Map;

public class cew {
    private static cez a;

    static void a(cez i18nLocaleIn) {
        a = i18nLocaleIn;
    }

    public static String a(String translateKey, Object ... parameters) {
        return a.a(translateKey, parameters);
    }

    public static boolean a(String key) {
        return a.a(key);
    }

    public static Map getLocaleProperties() {
        return cew.a.a;
    }
}

