/*
 * Decompiled with CFR 0.150.
 */
public abstract class cgi
extends cgh
implements cgs {
    protected boolean l;

    protected cgi(qc qc2, qe qe2) {
        super(qc2, qe2);
    }

    @Override
    public boolean m() {
        return this.l;
    }
}

