/*
 * Decompiled with CFR 0.150.
 */
public interface afv {
    public void a(afp var1, fi<ain> var2);

    public void a(afp var1, int var2, ain var3);

    public void a(afp var1, int var2, int var3);

    public void a(afp var1, tt var2);
}

