/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

public class agz
extends ail {
    protected final aou a;

    public agz(aou aou2) {
        this.a = aou2;
    }

    @Override
    public ub a(aeb aeb2, ams ams2, et et22, tz tz2, fa fa2, float f2, float f3, float f4) {
        ain ain2;
        awr awr2 = ams2.o(et22);
        aou \u26032 = awr2.u();
        if (!\u26032.a((amw)ams2, et22)) {
            et et22 = et22.a(fa2);
        }
        if ((ain2 = aeb2.b(tz2)).b() || !aeb2.a(et22, fa2, ain2) || !ams2.a(this.a, et22, false, fa2, null)) {
            return ub.c;
        }
        int \u26033 = this.a(ain2.j());
        awr \u26034 = this.a.a(ams2, et22, fa2, f2, f3, f4, \u26033, aeb2);
        if (ams2.a(et22, \u26034, 11)) {
            \u26034 = ams2.o(et22);
            if (\u26034.u() == this.a) {
                agz.a(ams2, aeb2, et22, ain2);
                this.a.a(ams2, et22, \u26034, aeb2, ain2);
                if (aeb2 instanceof oo) {
                    m.x.a((oo)aeb2, et22, ain2);
                }
            }
            atw atw2 = this.a.v();
            ams2.a(aeb2, et22, atw2.e(), qe.e, (atw2.a() + 1.0f) / 2.0f, atw2.b() * 0.8f);
            ain2.g(1);
        }
        return ub.a;
    }

    public static boolean a(ams ams2, @Nullable aeb aeb2, et et2, ain ain2) {
        MinecraftServer minecraftServer = ams2.u();
        if (minecraftServer == null) {
            return false;
        }
        fy \u26032 = ain2.d("BlockEntityTag");
        if (\u26032 != null && (\u2603 = ams2.r(et2)) != null) {
            if (!(ams2.G || !\u2603.C() || aeb2 != null && aeb2.dv())) {
                return false;
            }
            fy fy2 = \u2603.b(new fy());
            \u2603 = fy2.g();
            fy2.a(\u26032);
            fy2.a("x", et2.p());
            fy2.a("y", et2.q());
            fy2.a("z", et2.r());
            if (!fy2.equals(\u2603)) {
                \u2603.a(fy2);
                \u2603.y_();
                return true;
            }
        }
        return false;
    }

    public boolean a(ams ams22, et et22, fa fa22, aeb aeb2, ain ain2) {
        ams ams22;
        aou aou2 = ams22.o(et22).u();
        if (aou2 == aov.aH) {
            fa fa22 = fa.b;
        } else if (!aou2.a((amw)ams22, et22)) {
            et et22 = et22.a(fa22);
        }
        return ams22.a(this.a, et22, false, fa22, null);
    }

    @Override
    public String a(ain ain2) {
        return this.a.a();
    }

    @Override
    public String a() {
        return this.a.a();
    }

    @Override
    public ahn b() {
        return this.a.q();
    }

    @Override
    public void a(ahn ahn2, fi<ain> fi2) {
        if (this.a(ahn2)) {
            this.a.a(ahn2, fi2);
        }
    }

    @Override
    public void a(ain ain2, @Nullable ams ams2, List<String> list, ajz ajz2) {
        super.a(ain2, ams2, list, ajz2);
        this.a.a(ain2, ams2, list, ajz2);
    }

    public aou d() {
        return this.a;
    }
}

