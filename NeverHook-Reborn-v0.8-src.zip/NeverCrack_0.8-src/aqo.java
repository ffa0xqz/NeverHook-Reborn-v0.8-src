/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 *  javax.annotation.Nullable
 */
import com.google.common.collect.Maps;
import java.util.Map;
import java.util.Random;
import javax.annotation.Nullable;

public class aqo
extends aou {
    public static final axg a = axg.a("age", 0, 15);
    public static final axd b = axd.a("north");
    public static final axd c = axd.a("east");
    public static final axd d = axd.a("south");
    public static final axd e = axd.a("west");
    public static final axd f = axd.a("up");
    private final Map<aou, Integer> g = Maps.newIdentityHashMap();
    private final Map<aou, Integer> B = Maps.newIdentityHashMap();

    @Override
    public awr d(awr awr2, amw amw2, et et2) {
        if (amw2.o(et2.b()).q() || aov.ab.c(amw2, et2.b())) {
            return this.t();
        }
        return awr2.a(b, this.c(amw2, et2.c())).a(c, this.c(amw2, et2.f())).a(d, this.c(amw2, et2.d())).a(e, this.c(amw2, et2.e())).a(f, this.c(amw2, et2.a()));
    }

    protected aqo() {
        super(bcx.o);
        this.w(this.A.b().a(a, 0).a(b, false).a(c, false).a(d, false).a(e, false).a(f, false));
        this.a(true);
    }

    public static void e() {
        aov.ab.a(aov.f, 5, 20);
        aov.ab.a(aov.bL, 5, 20);
        aov.ab.a(aov.bM, 5, 20);
        aov.ab.a(aov.bo, 5, 20);
        aov.ab.a(aov.bp, 5, 20);
        aov.ab.a(aov.bq, 5, 20);
        aov.ab.a(aov.br, 5, 20);
        aov.ab.a(aov.bs, 5, 20);
        aov.ab.a(aov.bt, 5, 20);
        aov.ab.a(aov.aO, 5, 20);
        aov.ab.a(aov.aP, 5, 20);
        aov.ab.a(aov.aQ, 5, 20);
        aov.ab.a(aov.aR, 5, 20);
        aov.ab.a(aov.aS, 5, 20);
        aov.ab.a(aov.aT, 5, 20);
        aov.ab.a(aov.ad, 5, 20);
        aov.ab.a(aov.bV, 5, 20);
        aov.ab.a(aov.bU, 5, 20);
        aov.ab.a(aov.bW, 5, 20);
        aov.ab.a(aov.cC, 5, 20);
        aov.ab.a(aov.cD, 5, 20);
        aov.ab.a(aov.r, 5, 5);
        aov.ab.a(aov.s, 5, 5);
        aov.ab.a(aov.t, 30, 60);
        aov.ab.a(aov.u, 30, 60);
        aov.ab.a(aov.X, 30, 20);
        aov.ab.a(aov.W, 15, 100);
        aov.ab.a(aov.H, 60, 100);
        aov.ab.a(aov.cF, 60, 100);
        aov.ab.a(aov.N, 60, 100);
        aov.ab.a(aov.O, 60, 100);
        aov.ab.a(aov.I, 60, 100);
        aov.ab.a(aov.L, 30, 60);
        aov.ab.a(aov.bn, 15, 100);
        aov.ab.a(aov.cA, 5, 5);
        aov.ab.a(aov.cx, 60, 20);
        aov.ab.a(aov.cy, 60, 20);
    }

    public void a(aou aou2, int n2, int n3) {
        this.g.put(aou2, n2);
        this.B.put(aou2, n3);
    }

    @Override
    @Nullable
    public bgz a(awr awr2, amw amw2, et et2) {
        return k;
    }

    @Override
    public boolean b(awr awr2) {
        return false;
    }

    @Override
    public boolean c(awr awr2) {
        return false;
    }

    @Override
    public int a(Random random) {
        return 0;
    }

    @Override
    public int a(ams ams2) {
        return 30;
    }

    @Override
    public void b(ams ams2, et et2, awr awr22, Random random) {
        awr awr22;
        if (!ams2.W().b("doFireTick")) {
            return;
        }
        if (!this.a(ams2, et2)) {
            ams2.g(et2);
        }
        boolean bl2 = bl3 = (\u2603 = ams2.o(et2.b()).u()) == aov.aV || \u2603 == aov.df;
        if (ams2.s instanceof ayq && \u2603 == aov.h) {
            boolean bl3 = true;
        }
        int \u26032 = awr22.c(a);
        if (!bl3 && ams2.Y() && this.b(ams2, et2) && random.nextFloat() < 0.2f + (float)\u26032 * 0.03f) {
            ams2.g(et2);
            return;
        }
        if (\u26032 < 15) {
            awr22 = awr22.a(a, \u26032 + random.nextInt(3) / 2);
            ams2.a(et2, awr22, 4);
        }
        ams2.a(et2, (aou)this, this.a(ams2) + random.nextInt(10));
        if (!bl3) {
            if (!this.c(ams2, et2)) {
                if (!ams2.o(et2.b()).q() || \u26032 > 3) {
                    ams2.g(et2);
                }
                return;
            }
            if (!this.c((amw)ams2, et2.b()) && \u26032 == 15 && random.nextInt(4) == 0) {
                ams2.g(et2);
                return;
            }
        }
        boolean \u26033 = ams2.C(et2);
        int \u26034 = 0;
        if (\u26033) {
            \u26034 = -50;
        }
        this.a(ams2, et2.f(), 300 + \u26034, random, \u26032);
        this.a(ams2, et2.e(), 300 + \u26034, random, \u26032);
        this.a(ams2, et2.b(), 250 + \u26034, random, \u26032);
        this.a(ams2, et2.a(), 250 + \u26034, random, \u26032);
        this.a(ams2, et2.c(), 300 + \u26034, random, \u26032);
        this.a(ams2, et2.d(), 300 + \u26034, random, \u26032);
        for (int i2 = -1; i2 <= 1; ++i2) {
            for (\u2603 = -1; \u2603 <= 1; ++\u2603) {
                for (\u2603 = -1; \u2603 <= 4; ++\u2603) {
                    if (i2 == 0 && \u2603 == 0 && \u2603 == 0) continue;
                    \u2603 = 100;
                    if (\u2603 > 1) {
                        \u2603 += (\u2603 - 1) * 100;
                    }
                    if ((\u2603 = this.d(ams2, \u2603 = et2.a(i2, \u2603, \u2603))) <= 0) continue;
                    \u2603 = (\u2603 + 40 + ams2.ag().a() * 7) / (\u26032 + 30);
                    if (\u26033) {
                        \u2603 /= 2;
                    }
                    if (\u2603 <= 0 || random.nextInt(\u2603) > \u2603 || ams2.Y() && this.b(ams2, \u2603)) continue;
                    \u2603 = \u26032 + random.nextInt(5) / 4;
                    if (\u2603 > 15) {
                        \u2603 = 15;
                    }
                    ams2.a(\u2603, awr22.a(a, \u2603), 3);
                }
            }
        }
    }

    protected boolean b(ams ams2, et et2) {
        return ams2.B(et2) || ams2.B(et2.e()) || ams2.B(et2.f()) || ams2.B(et2.c()) || ams2.B(et2.d());
    }

    @Override
    public boolean r() {
        return false;
    }

    private int e(aou aou2) {
        Integer n2 = this.B.get(aou2);
        return n2 == null ? 0 : n2;
    }

    private int f(aou aou2) {
        Integer n2 = this.g.get(aou2);
        return n2 == null ? 0 : n2;
    }

    private void a(ams ams22, et et2, int n2, Random random, int n3) {
        \u2603 = this.e(ams22.o(et2).u());
        if (random.nextInt(n2) < \u2603) {
            awr awr2 = ams22.o(et2);
            if (random.nextInt(n3 + 10) < 5 && !ams22.B(et2)) {
                int n4 = n3 + random.nextInt(5) / 4;
                if (n4 > 15) {
                    n4 = 15;
                }
                ams22.a(et2, this.t().a(a, n4), 3);
            } else {
                ams ams22;
                ams22.g(et2);
            }
            if (awr2.u() == aov.W) {
                aov.W.d(ams22, et2, awr2.a(aun.a, true));
            }
        }
    }

    private boolean c(ams ams2, et et2) {
        for (fa fa2 : fa.values()) {
            if (!this.c((amw)ams2, et2.a(fa2))) continue;
            return true;
        }
        return false;
    }

    private int d(ams ams2, et et2) {
        if (!ams2.d(et2)) {
            return 0;
        }
        int n2 = 0;
        for (fa fa2 : fa.values()) {
            n2 = Math.max(this.f(ams2.o(et2.a(fa2)).u()), n2);
        }
        return n2;
    }

    @Override
    public boolean m() {
        return false;
    }

    public boolean c(amw amw2, et et2) {
        return this.f(amw2.o(et2).u()) > 0;
    }

    @Override
    public boolean a(ams ams2, et et2) {
        return ams2.o(et2.b()).q() || this.c(ams2, et2);
    }

    @Override
    public void a(awr awr2, ams ams2, et et2, aou aou2, et et3) {
        if (!ams2.o(et2.b()).q() && !this.c(ams2, et2)) {
            ams2.g(et2);
        }
    }

    @Override
    public void c(ams ams2, et et2, awr awr2) {
        if (ams2.s.q().a() <= 0 && aov.aY.b(ams2, et2)) {
            return;
        }
        if (!ams2.o(et2.b()).q() && !this.c(ams2, et2)) {
            ams2.g(et2);
            return;
        }
        ams2.a(et2, (aou)this, this.a(ams2) + ams2.r.nextInt(10));
    }

    @Override
    public void a(awr awr2, ams ams22, et et2, Random random) {
        block12: {
            double d2;
            int n2;
            ams ams22;
            block11: {
                if (random.nextInt(24) == 0) {
                    ams22.a((float)et2.p() + 0.5f, (double)((float)et2.q() + 0.5f), (double)((float)et2.r() + 0.5f), qd.bM, qe.e, 1.0f + random.nextFloat(), random.nextFloat() * 0.7f + 0.3f, false);
                }
                if (!ams22.o(et2.b()).q() && !aov.ab.c((amw)ams22, et2.b())) break block11;
                for (int i2 = 0; i2 < 3; ++i2) {
                    double d3 = (double)et2.p() + random.nextDouble();
                    \u2603 = (double)et2.q() + random.nextDouble() * 0.5 + 0.5;
                    \u2603 = (double)et2.r() + random.nextDouble();
                    ams22.a(fj.m, d3, \u2603, \u2603, 0.0, 0.0, 0.0, new int[0]);
                }
                break block12;
            }
            if (aov.ab.c((amw)ams22, et2.e())) {
                for (n2 = 0; n2 < 2; ++n2) {
                    d2 = (double)et2.p() + random.nextDouble() * (double)0.1f;
                    \u2603 = (double)et2.q() + random.nextDouble();
                    \u2603 = (double)et2.r() + random.nextDouble();
                    ams22.a(fj.m, d2, \u2603, \u2603, 0.0, 0.0, 0.0, new int[0]);
                }
            }
            if (aov.ab.c((amw)ams22, et2.f())) {
                for (n2 = 0; n2 < 2; ++n2) {
                    d2 = (double)(et2.p() + 1) - random.nextDouble() * (double)0.1f;
                    \u2603 = (double)et2.q() + random.nextDouble();
                    \u2603 = (double)et2.r() + random.nextDouble();
                    ams22.a(fj.m, d2, \u2603, \u2603, 0.0, 0.0, 0.0, new int[0]);
                }
            }
            if (aov.ab.c((amw)ams22, et2.c())) {
                for (n2 = 0; n2 < 2; ++n2) {
                    d2 = (double)et2.p() + random.nextDouble();
                    \u2603 = (double)et2.q() + random.nextDouble();
                    \u2603 = (double)et2.r() + random.nextDouble() * (double)0.1f;
                    ams22.a(fj.m, d2, \u2603, \u2603, 0.0, 0.0, 0.0, new int[0]);
                }
            }
            if (aov.ab.c((amw)ams22, et2.d())) {
                for (n2 = 0; n2 < 2; ++n2) {
                    d2 = (double)et2.p() + random.nextDouble();
                    \u2603 = (double)et2.q() + random.nextDouble();
                    \u2603 = (double)(et2.r() + 1) - random.nextDouble() * (double)0.1f;
                    ams22.a(fj.m, d2, \u2603, \u2603, 0.0, 0.0, 0.0, new int[0]);
                }
            }
            if (!aov.ab.c((amw)ams22, et2.a())) break block12;
            for (n2 = 0; n2 < 2; ++n2) {
                d2 = (double)et2.p() + random.nextDouble();
                \u2603 = (double)(et2.q() + 1) - random.nextDouble() * (double)0.1f;
                \u2603 = (double)et2.r() + random.nextDouble();
                ams22.a(fj.m, d2, \u2603, \u2603, 0.0, 0.0, 0.0, new int[0]);
            }
        }
    }

    @Override
    public bcy c(awr awr2, amw amw2, et et2) {
        return bcy.g;
    }

    @Override
    public amk f() {
        return amk.c;
    }

    @Override
    public awr a(int n2) {
        return this.t().a(a, n2);
    }

    @Override
    public int e(awr awr2) {
        return awr2.c(a);
    }

    @Override
    protected aws b() {
        return new aws((aou)this, a, b, c, d, e, f);
    }

    @Override
    public awp a(amw amw2, awr awr2, et et2, fa fa2) {
        return awp.i;
    }
}

