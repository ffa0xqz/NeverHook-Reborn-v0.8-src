/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Maps
 *  javax.annotation.Nullable
 *  org.apache.commons.lang3.ObjectUtils
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import io.netty.handler.codec.DecoderException;
import io.netty.handler.codec.EncoderException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import javax.annotation.Nullable;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class na {
    private static final Logger a = LogManager.getLogger();
    private static final Map<Class<? extends ve>, Integer> b = Maps.newHashMap();
    private final ve c;
    private final Map<Integer, a<?>> d = Maps.newHashMap();
    private final ReadWriteLock e = new ReentrantReadWriteLock();
    private boolean f = true;
    private boolean g;

    public na(ve ve2) {
        this.c = ve2;
    }

    public static <T> mx<T> a(Class<? extends ve> class_2, my<T> my2) {
        Class<? extends ve> class_2;
        if (a.isDebugEnabled()) {
            try {
                Class<?> class_3 = Class.forName(Thread.currentThread().getStackTrace()[2].getClassName());
                if (!class_3.equals(class_2)) {
                    a.debug("defineId called for: {} from {}", class_2, class_3, (Object)new RuntimeException());
                }
            }
            catch (ClassNotFoundException class_3) {
                // empty catch block
            }
        }
        if (b.containsKey(class_2)) {
            int n2 = b.get(class_2) + 1;
        } else {
            int n3 = 0;
            Class<? extends ve> \u26032 = class_2;
            while (\u26032 != ve.class) {
                if (!b.containsKey(\u26032 = \u26032.getSuperclass())) continue;
                n3 = b.get(\u26032) + 1;
                break;
            }
            n2 = n3;
        }
        if (n2 > 254) {
            throw new IllegalArgumentException("Data value id is too big with " + n2 + "! (Max is " + 254 + ")");
        }
        b.put(class_2, n2);
        return my2.a(n2);
    }

    public <T> void a(mx<T> mx2, T t2) {
        int n2 = mx2.a();
        if (n2 > 254) {
            throw new IllegalArgumentException("Data value id is too big with " + n2 + "! (Max is " + 254 + ")");
        }
        if (this.d.containsKey(n2)) {
            throw new IllegalArgumentException("Duplicate id value for " + n2 + "!");
        }
        if (mz.b(mx2.b()) < 0) {
            throw new IllegalArgumentException("Unregistered serializer " + mx2.b() + " for " + n2 + "!");
        }
        this.c(mx2, t2);
    }

    private <T> void c(mx<T> mx2, T t2) {
        a<T> a2 = new a<T>(mx2, t2);
        this.e.writeLock().lock();
        this.d.put(mx2.a(), a2);
        this.f = false;
        this.e.writeLock().unlock();
    }

    private <T> a<T> c(mx<T> mx2) {
        this.e.readLock().lock();
        try {
            a<?> a2 = this.d.get(mx2.a());
        }
        catch (Throwable throwable) {
            b b2 = b.a(throwable, "Getting synched entity data");
            c \u26032 = b2.a("Synched entity data");
            \u26032.a("Data ID", mx2);
            throw new f(b2);
        }
        this.e.readLock().unlock();
        return a2;
    }

    public <T> T a(mx<T> mx2) {
        return this.c(mx2).b();
    }

    public <T> void b(mx<T> mx2, T t2) {
        a<T> a2 = this.c(mx2);
        if (ObjectUtils.notEqual(t2, a2.b())) {
            a2.a(t2);
            this.c.a(mx2);
            a2.a(true);
            this.g = true;
        }
    }

    public <T> void b(mx<T> mx2) {
        ((a)this.c(mx2)).c = true;
        this.g = true;
    }

    public boolean a() {
        return this.g;
    }

    public static void a(List<a<?>> list, gy gy22) throws IOException {
        gy gy22;
        if (list != null) {
            int n2 = list.size();
            for (\u2603 = 0; \u2603 < n2; ++\u2603) {
                a<?> a2 = list.get(\u2603);
                na.a(gy22, a2);
            }
        }
        gy22.writeByte(255);
    }

    @Nullable
    public List<a<?>> b() {
        ArrayList arrayList = null;
        if (this.g) {
            this.e.readLock().lock();
            for (a<?> a2 : this.d.values()) {
                if (!a2.c()) continue;
                a2.a(false);
                if (arrayList == null) {
                    arrayList = Lists.newArrayList();
                }
                arrayList.add(a2.d());
            }
            this.e.readLock().unlock();
        }
        this.g = false;
        return arrayList;
    }

    public void a(gy gy22) throws IOException {
        gy gy22;
        this.e.readLock().lock();
        for (a<?> a2 : this.d.values()) {
            na.a(gy22, a2);
        }
        this.e.readLock().unlock();
        gy22.writeByte(255);
    }

    @Nullable
    public List<a<?>> c() {
        ArrayList arrayList = null;
        this.e.readLock().lock();
        for (a<?> a2 : this.d.values()) {
            if (arrayList == null) {
                arrayList = Lists.newArrayList();
            }
            arrayList.add(a2.d());
        }
        this.e.readLock().unlock();
        return arrayList;
    }

    private static <T> void a(gy gy2, a<T> a2) throws IOException {
        mx<T> mx2 = a2.a();
        int \u26032 = mz.b(mx2.b());
        if (\u26032 < 0) {
            throw new EncoderException("Unknown serializer type " + mx2.b());
        }
        gy2.writeByte(mx2.a());
        gy2.d(\u26032);
        mx2.b().a(gy2, a2.b());
    }

    @Nullable
    public static List<a<?>> b(gy gy2) throws IOException {
        ArrayList arrayList = null;
        while ((\u2603 = gy2.readUnsignedByte()) != 255) {
            if (arrayList == null) {
                arrayList = Lists.newArrayList();
            }
            if ((\u2603 = mz.a(\u2603 = gy2.g())) == null) {
                throw new DecoderException("Unknown serializer type " + \u2603);
            }
            arrayList.add(new a<gy>((mx<gy>)\u2603.a(\u2603), \u2603.a(gy2)));
        }
        return arrayList;
    }

    public void a(List<a<?>> list) {
        this.e.writeLock().lock();
        for (a<?> a2 : list) {
            \u2603 = this.d.get(a2.a().a());
            if (\u2603 == null) continue;
            this.a(\u2603, a2);
            this.c.a(a2.a());
        }
        this.e.writeLock().unlock();
        this.g = true;
    }

    protected <T> void a(a<T> a2, a<?> a3) {
        a2.a(a3.b());
    }

    public boolean d() {
        return this.f;
    }

    public void e() {
        this.g = false;
        this.e.readLock().lock();
        for (a<?> a2 : this.d.values()) {
            a2.a(false);
        }
        this.e.readLock().unlock();
    }

    public static class a<T> {
        private final mx<T> a;
        private T b;
        private boolean c;

        public a(mx<T> mx2, T t2) {
            this.a = mx2;
            this.b = t2;
            this.c = true;
        }

        public mx<T> a() {
            return this.a;
        }

        public void a(T t2) {
            this.b = t2;
        }

        public T b() {
            return this.b;
        }

        public boolean c() {
            return this.c;
        }

        public void a(boolean bl2) {
            this.c = bl2;
        }

        public a<T> d() {
            return new a<T>(this.a, this.a.b().a(this.b));
        }
    }
}

