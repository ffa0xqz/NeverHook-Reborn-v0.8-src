/*
 * Decompiled with CFR 0.150.
 */
public class ari
extends atj {
    public ari() {
        super(bcx.b, bcy.u);
        this.w(this.A.b().a(c, fa.a.b));
        this.a(ahn.b);
    }

    @Override
    public void a(ams ams2, et et2, ve ve2, float f2) {
        ve2.e(f2, 0.2f);
    }
}

