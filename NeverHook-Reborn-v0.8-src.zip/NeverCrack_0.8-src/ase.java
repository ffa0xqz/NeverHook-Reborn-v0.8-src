/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 *  javax.annotation.Nullable
 */
import com.google.common.base.Predicate;
import javax.annotation.Nullable;

public class ase
extends arp {
    public static final axf<asp.a> e = axf.a("variant", asp.a.class, new Predicate<asp.a>(){

        public boolean a(@Nullable asp.a a2) {
            return a2.a() >= 4;
        }

        public /* synthetic */ boolean apply(@Nullable Object object) {
            return this.a((asp.a)object);
        }
    });

    public ase() {
        this.w(this.A.b().a(e, asp.a.e).a(b, true).a(a, true));
    }

    @Override
    protected void a(ams ams2, et et2, awr awr2, int n2) {
        if (awr2.c(e) == asp.a.f && ams2.r.nextInt(n2) == 0) {
            ase.a(ams2, et2, new ain(aip.f));
        }
    }

    @Override
    public int d(awr awr2) {
        return awr2.c(e).a();
    }

    @Override
    public ain a(ams ams2, et et2, awr awr2) {
        return new ain(this, 1, awr2.u().e(awr2) & 3);
    }

    @Override
    public void a(ahn ahn2, fi<ain> fi2) {
        fi2.add(new ain(this, 1, 0));
        fi2.add(new ain(this, 1, 1));
    }

    @Override
    protected ain u(awr awr2) {
        return new ain(ail.a(this), 1, awr2.c(e).a() - 4);
    }

    @Override
    public awr a(int n2) {
        return this.t().a(e, this.b(n2)).a(a, (n2 & 4) == 0).a(b, (n2 & 8) > 0);
    }

    @Override
    public int e(awr awr2) {
        int n2 = 0;
        n2 |= awr2.c(e).a() - 4;
        if (!awr2.c(a).booleanValue()) {
            n2 |= 4;
        }
        if (awr2.c(b).booleanValue()) {
            n2 |= 8;
        }
        return n2;
    }

    @Override
    public asp.a b(int n2) {
        return asp.a.a((n2 & 3) + 4);
    }

    @Override
    protected aws b() {
        return new aws((aou)this, e, b, a);
    }

    @Override
    public void a(ams ams2, aeb aeb2, et et2, awr awr2, @Nullable avh avh2, ain ain2) {
        if (!ams2.G && ain2.c() == aip.bm) {
            aeb2.b(qq.a(this));
            ase.a(ams2, et2, new ain(ail.a(this), 1, awr2.c(e).a() - 4));
            return;
        }
        super.a(ams2, aeb2, et2, awr2, avh2, ain2);
    }
}

