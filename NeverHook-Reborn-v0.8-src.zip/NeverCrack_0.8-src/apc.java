/*
 * Decompiled with CFR 0.150.
 */
import java.util.Random;

public class apc
extends aou {
    public static final axg a = axg.a("age", 0, 15);
    protected static final bgz b = new bgz(0.0625, 0.0, 0.0625, 0.9375, 0.9375, 0.9375);
    protected static final bgz c = new bgz(0.0625, 0.0, 0.0625, 0.9375, 1.0, 0.9375);

    protected apc() {
        super(bcx.A);
        this.w(this.A.b().a(a, 0));
        this.a(true);
        this.a(ahn.c);
    }

    @Override
    public void b(ams ams22, et et2, awr awr2, Random random) {
        et et3 = et2.a();
        if (!ams22.d(et3)) {
            return;
        }
        int \u26032 = 1;
        while (ams22.o(et2.c(\u26032)).u() == this) {
            ++\u26032;
        }
        if (\u26032 >= 3) {
            return;
        }
        int \u26033 = awr2.c(a);
        if (\u26033 == 15) {
            ams22.a(et3, this.t());
            awr awr3 = awr2.a(a, 0);
            ams22.a(et2, awr3, 4);
            awr3.a(ams22, et3, this, et2);
        } else {
            ams ams22;
            ams22.a(et2, awr2.a(a, \u26033 + 1), 4);
        }
    }

    @Override
    public bgz a(awr awr2, amw amw2, et et2) {
        return b;
    }

    @Override
    public bgz b(awr awr2, ams ams2, et et2) {
        return c.a(et2);
    }

    @Override
    public boolean c(awr awr2) {
        return false;
    }

    @Override
    public boolean b(awr awr2) {
        return false;
    }

    @Override
    public boolean a(ams ams2, et et2) {
        if (super.a(ams2, et2)) {
            return this.b(ams2, et2);
        }
        return false;
    }

    @Override
    public void a(awr awr2, ams ams2, et et2, aou aou2, et et3) {
        if (!this.b(ams2, et2)) {
            ams2.b(et2, true);
        }
    }

    public boolean b(ams ams22, et et2) {
        ams ams22;
        for (fa fa2 : fa.c.a) {
            bcx bcx2 = ams22.o(et2.a(fa2)).a();
            if (!bcx2.a() && bcx2 != bcx.i) continue;
            return false;
        }
        aou \u26032 = ams22.o(et2.b()).u();
        return \u26032 == aov.aK || \u26032 == aov.m && !ams22.o(et2.a()).a().d();
    }

    @Override
    public void a(ams ams2, et et2, awr awr2, ve ve2) {
        ve2.a(up.j, 1.0f);
    }

    @Override
    public amk f() {
        return amk.c;
    }

    @Override
    public awr a(int n2) {
        return this.t().a(a, n2);
    }

    @Override
    public int e(awr awr2) {
        return awr2.c(a);
    }

    @Override
    protected aws b() {
        return new aws((aou)this, a);
    }

    @Override
    public awp a(amw amw2, awr awr2, et et2, fa fa2) {
        return awp.i;
    }
}

