/*
 * Decompiled with CFR 0.150.
 */
public class bzm
extends cad<acx> {
    private static final nd a = new nd("textures/entity/zombie/zombie.png");
    private final float j;

    public bzm(bzd bzd2, float f2) {
        super(bzd2, new brj(), 0.5f * f2);
        this.j = f2;
        this.a(new cca(this));
        this.a(new cbz(this){

            @Override
            protected void M_() {
                this.c = new brj(0.5f, true);
                this.d = new brj(1.0f, true);
            }
        });
    }

    @Override
    public void N_() {
        buq.c(0.0f, 0.1875f, 0.0f);
    }

    @Override
    protected void a(acx acx2, float f2) {
        buq.b(this.j, this.j, this.j);
    }

    @Override
    protected nd a(acx acx2) {
        return a;
    }
}

