/*
 * Decompiled with CFR 0.150.
 */
public class atw {
    public static final atw a = new atw(1.0f, 1.0f, qd.iZ, qd.jh, qd.je, qd.jd, qd.jc);
    public static final atw b = new atw(1.0f, 1.0f, qd.cr, qd.cv, qd.cu, qd.ct, qd.cs);
    public static final atw c = new atw(1.0f, 1.0f, qd.cm, qd.cq, qd.cp, qd.co, qd.cn);
    public static final atw d = new atw(1.0f, 1.0f, qd.hI, qd.hQ, qd.hN, qd.hM, qd.hL);
    public static final atw e = new atw(1.0f, 1.5f, qd.dZ, qd.ef, qd.ec, qd.eb, qd.ea);
    public static final atw f = new atw(1.0f, 1.0f, qd.ch, qd.cl, qd.ck, qd.cj, qd.ci);
    public static final atw g = new atw(1.0f, 1.0f, qd.al, qd.ap, qd.ao, qd.an, qd.am);
    public static final atw h = new atw(1.0f, 1.0f, qd.gn, qd.gr, qd.gq, qd.gp, qd.go);
    public static final atw i = new atw(1.0f, 1.0f, qd.hu, qd.hy, qd.hx, qd.hw, qd.hv);
    public static final atw j = new atw(1.0f, 1.0f, qd.dy, qd.dC, qd.dB, qd.dA, qd.dz);
    public static final atw k = new atw(0.3f, 1.0f, qd.b, qd.h, qd.g, qd.e, qd.d);
    public static final atw l = new atw(1.0f, 1.0f, qd.gZ, qd.hh, qd.hf, qd.hc, qd.hb);
    public final float m;
    public final float n;
    private final qc o;
    private final qc p;
    private final qc q;
    private final qc r;
    private final qc s;

    public atw(float f2, float f3, qc qc2, qc qc3, qc qc4, qc qc5, qc qc6) {
        this.m = f2;
        this.n = f3;
        this.o = qc2;
        this.p = qc3;
        this.q = qc4;
        this.r = qc5;
        this.s = qc6;
    }

    public float a() {
        return this.m;
    }

    public float b() {
        return this.n;
    }

    public qc c() {
        return this.o;
    }

    public qc d() {
        return this.p;
    }

    public qc e() {
        return this.q;
    }

    public qc f() {
        return this.r;
    }

    public qc g() {
        return this.s;
    }
}

