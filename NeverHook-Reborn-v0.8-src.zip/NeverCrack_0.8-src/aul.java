/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import java.util.Random;
import javax.annotation.Nullable;

public class aul
extends apa
implements aox {
    public static final axf<a> a = axf.a("type", a.class);
    protected static final bgz c = new bgz(0.09999999403953552, 0.0, 0.09999999403953552, 0.9f, 0.8f, 0.9f);

    protected aul() {
        super(bcx.l);
        this.w(this.A.b().a(a, aul$a.a));
    }

    @Override
    public bgz b(awr awr2, amw amw2, et et2) {
        return c;
    }

    @Override
    public boolean f(ams ams2, et et2, awr awr2) {
        return this.x(ams2.o(et2.b()));
    }

    @Override
    public boolean a(amw amw2, et et2) {
        return true;
    }

    @Override
    public ail a(awr awr2, Random random, int n2) {
        if (random.nextInt(8) == 0) {
            return aip.Q;
        }
        return aip.a;
    }

    @Override
    public int a(int n2, Random random) {
        return 1 + random.nextInt(n2 * 2 + 1);
    }

    @Override
    public void a(ams ams2, aeb aeb2, et et2, awr awr2, @Nullable avh avh2, ain ain2) {
        if (!ams2.G && ain2.c() == aip.bm) {
            aeb2.b(qq.a(this));
            aul.a(ams2, et2, new ain(aov.H, 1, awr2.c(a).a()));
        } else {
            super.a(ams2, aeb2, et2, awr2, avh2, ain2);
        }
    }

    @Override
    public ain a(ams ams2, et et2, awr awr2) {
        return new ain(this, 1, awr2.u().e(awr2));
    }

    @Override
    public void a(ahn ahn2, fi<ain> fi2) {
        for (int i2 = 1; i2 < 3; ++i2) {
            fi2.add(new ain(this, 1, i2));
        }
    }

    @Override
    public boolean a(ams ams2, et et2, awr awr2, boolean bl2) {
        return awr2.c(a) != aul$a.a;
    }

    @Override
    public boolean a(ams ams2, Random random, et et2, awr awr2) {
        return true;
    }

    @Override
    public void b(ams ams2, Random random, et et2, awr awr2) {
        apz.b b2 = apz.b.c;
        if (awr2.c(a) == aul$a.c) {
            b2 = apz.b.d;
        }
        if (aov.cF.a(ams2, et2)) {
            aov.cF.a(ams2, et2, b2, 2);
        }
    }

    @Override
    public awr a(int n2) {
        return this.t().a(a, aul$a.a(n2));
    }

    @Override
    public int e(awr awr2) {
        return awr2.c(a).a();
    }

    @Override
    protected aws b() {
        return new aws((aou)this, a);
    }

    @Override
    public aou.a u() {
        return aou.a.c;
    }

    public static enum a implements rm
    {
        a(0, "dead_bush"),
        b(1, "tall_grass"),
        c(2, "fern");

        private static final a[] d;
        private final int e;
        private final String f;

        private a(int n3, String string2) {
            this.e = n3;
            this.f = string2;
        }

        public int a() {
            return this.e;
        }

        public String toString() {
            return this.f;
        }

        public static a a(int n2) {
            if (n2 < 0 || n2 >= d.length) {
                n2 = 0;
            }
            return d[n2];
        }

        @Override
        public String m() {
            return this.f;
        }

        static {
            d = new a[aul$a.values().length];
            a[] arra = aul$a.values();
            int n2 = arra.length;
            for (int i2 = 0; i2 < n2; ++i2) {
                a a2;
                aul$a.d[a2.a()] = a2 = arra[i2];
            }
        }
    }
}

