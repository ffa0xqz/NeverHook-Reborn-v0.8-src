/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ComparisonChain
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.common.collect.ComparisonChain;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class uy
implements Comparable<uy> {
    private static final Logger a = LogManager.getLogger();
    private final ux b;
    private int c;
    private int d;
    private boolean e;
    private boolean f;
    private boolean g;
    private boolean h;

    public uy(ux ux2) {
        this(ux2, 0, 0);
    }

    public uy(ux ux2, int n2) {
        this(ux2, n2, 0);
    }

    public uy(ux ux2, int n2, int n3) {
        this(ux2, n2, n3, false, true);
    }

    public uy(ux ux2, int n2, int n3, boolean bl2, boolean bl3) {
        this.b = ux2;
        this.c = n2;
        this.d = n3;
        this.f = bl2;
        this.h = bl3;
    }

    public uy(uy uy2) {
        this.b = uy2.b;
        this.c = uy2.c;
        this.d = uy2.d;
        this.f = uy2.f;
        this.h = uy2.h;
    }

    public void a(uy uy2) {
        if (this.b != uy2.b) {
            a.warn("This method should only be called for matching effects!");
        }
        if (uy2.d > this.d) {
            this.d = uy2.d;
            this.c = uy2.c;
        } else if (uy2.d == this.d && this.c < uy2.c) {
            this.c = uy2.c;
        } else if (!uy2.f && this.f) {
            this.f = uy2.f;
        }
        this.h = uy2.h;
    }

    public ux a() {
        return this.b;
    }

    public int b() {
        return this.c;
    }

    public int c() {
        return this.d;
    }

    public boolean d() {
        return this.f;
    }

    public boolean e() {
        return this.h;
    }

    public boolean a(vn vn2) {
        if (this.c > 0) {
            if (this.b.a(this.c, this.d)) {
                this.b(vn2);
            }
            this.h();
        }
        return this.c > 0;
    }

    private int h() {
        return --this.c;
    }

    public void b(vn vn2) {
        if (this.c > 0) {
            this.b.a(vn2, this.d);
        }
    }

    public String f() {
        return this.b.a();
    }

    public String toString() {
        String string = this.d > 0 ? this.f() + " x " + (this.d + 1) + ", Duration: " + this.c : this.f() + ", Duration: " + this.c;
        if (this.e) {
            string = string + ", Splash: true";
        }
        if (!this.h) {
            string = string + ", Particles: false";
        }
        return string;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object instanceof uy) {
            uy uy2 = (uy)object;
            return this.c == uy2.c && this.d == uy2.d && this.e == uy2.e && this.f == uy2.f && this.b.equals(uy2.b);
        }
        return false;
    }

    public int hashCode() {
        int n2 = this.b.hashCode();
        n2 = 31 * n2 + this.c;
        n2 = 31 * n2 + this.d;
        n2 = 31 * n2 + (this.e ? 1 : 0);
        n2 = 31 * n2 + (this.f ? 1 : 0);
        return n2;
    }

    public fy a(fy fy2) {
        fy2.a("Id", (byte)ux.a(this.a()));
        fy2.a("Amplifier", (byte)this.c());
        fy2.a("Duration", this.b());
        fy2.a("Ambient", this.d());
        fy2.a("ShowParticles", this.e());
        return fy2;
    }

    public static uy b(fy fy2) {
        byte by2 = fy2.f("Id");
        ux \u26032 = ux.a(by2);
        if (\u26032 == null) {
            return null;
        }
        \u2603 = fy2.f("Amplifier");
        int \u26033 = fy2.h("Duration");
        boolean \u26034 = fy2.q("Ambient");
        boolean \u26035 = true;
        if (fy2.b("ShowParticles", 1)) {
            \u26035 = fy2.q("ShowParticles");
        }
        return new uy(\u26032, \u26033, \u2603 < 0 ? (byte)0 : \u2603, \u26034, \u26035);
    }

    public void b(boolean bl2) {
        this.g = bl2;
    }

    public boolean g() {
        return this.g;
    }

    public int b(uy uy2) {
        int n2 = 32147;
        if (this.b() > 32147 && uy2.b() > 32147 || this.d() && uy2.d()) {
            return ComparisonChain.start().compare(Boolean.valueOf(this.d()), Boolean.valueOf(uy2.d())).compare(this.a().g(), uy2.a().g()).result();
        }
        return ComparisonChain.start().compare(Boolean.valueOf(this.d()), Boolean.valueOf(uy2.d())).compare(this.b(), uy2.b()).compare(this.a().g(), uy2.a().g()).result();
    }

    @Override
    public /* synthetic */ int compareTo(Object object) {
        return this.b((uy)object);
    }
}

