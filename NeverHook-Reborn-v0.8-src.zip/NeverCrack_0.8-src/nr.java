/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 *  com.google.common.io.Files
 *  javax.annotation.Nullable
 *  org.apache.commons.io.FileUtils
 *  org.apache.commons.io.FilenameUtils
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.common.collect.Maps;
import com.google.common.io.Files;
import java.io.File;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class nr
implements nv {
    private static final Logger a = LogManager.getLogger();
    private final File b;
    private final MinecraftServer c;
    private final Map<nd, bm> d = Maps.newHashMap();
    private String e = "-";
    private bm f;
    private final ArrayDeque<a> g = new ArrayDeque();
    private boolean h = false;
    private final bn i = new bn(){

        @Override
        public String h_() {
            return nr.this.e;
        }

        @Override
        public boolean a(int n2, String string) {
            return n2 <= 2;
        }

        @Override
        public ams e() {
            return ((nr)nr.this).c.d[0];
        }

        @Override
        public MinecraftServer C_() {
            return nr.this.c;
        }
    };

    public nr(@Nullable File file, MinecraftServer minecraftServer) {
        this.b = file;
        this.c = minecraftServer;
        this.f();
    }

    @Nullable
    public bm a(nd nd2) {
        return this.d.get(nd2);
    }

    public bl a() {
        return this.c.N();
    }

    public int c() {
        return this.c.d[0].W().c("maxCommandChainLength");
    }

    public Map<nd, bm> d() {
        return this.d;
    }

    @Override
    public void e() {
        String string = this.c.d[0].W().a("gameLoopFunction");
        if (!string.equals(this.e)) {
            this.e = string;
            this.f = this.a(new nd(string));
        }
        if (this.f != null) {
            this.a(this.f, this.i);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public int a(bm bm2, bn bn2) {
        int n2 = this.c();
        if (this.h) {
            if (this.g.size() < n2) {
                this.g.addFirst(new a(this, bn2, new bm.d(bm2)));
            }
            return 0;
        }
        try {
            int n3;
            int n4;
            this.h = true;
            n3 = 0;
            bm.c[] arrc = bm2.a();
            for (int i2 = arrc.length - 1; i2 >= 0; --i2) {
                this.g.push(new a(this, bn2, arrc[i2]));
            }
            while (!this.g.isEmpty()) {
                this.g.removeFirst().a(this.g, n2);
                if (++n3 < n2) continue;
                n4 = n3;
                return n4;
            }
            n4 = n3;
            return n4;
        }
        finally {
            this.g.clear();
            this.h = false;
        }
    }

    public void f() {
        this.d.clear();
        this.f = null;
        this.e = "-";
        this.h();
    }

    private void h() {
        if (this.b == null) {
            return;
        }
        this.b.mkdirs();
        for (File file : FileUtils.listFiles((File)this.b, (String[])new String[]{"mcfunction"}, (boolean)true)) {
            String string = FilenameUtils.removeExtension((String)this.b.toURI().relativize(file.toURI()).toString());
            String[] \u26032 = string.split("/", 2);
            if (\u26032.length != 2) continue;
            nd \u26033 = new nd(\u26032[0], \u26032[1]);
            try {
                this.d.put(\u26033, bm.a(this, Files.readLines((File)file, (Charset)StandardCharsets.UTF_8)));
            }
            catch (Throwable \u26034) {
                a.error("Couldn't read custom function " + \u26033 + " from " + file, \u26034);
            }
        }
        if (!this.d.isEmpty()) {
            a.info("Loaded " + this.d.size() + " custom command functions");
        }
    }

    public static class a {
        private final nr a;
        private final bn b;
        private final bm.c c;

        public a(nr nr2, bn bn2, bm.c c2) {
            this.a = nr2;
            this.b = bn2;
            this.c = c2;
        }

        public void a(ArrayDeque<a> arrayDeque, int n2) {
            this.c.a(this.a, this.b, arrayDeque, n2);
        }

        public String toString() {
            return this.c.toString();
        }
    }
}

