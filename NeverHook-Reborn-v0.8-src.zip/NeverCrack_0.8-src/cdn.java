/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Maps
 *  javax.annotation.Nullable
 *  org.apache.commons.io.IOUtils
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import javax.annotation.Nullable;
import optifine.BetterGrass;
import optifine.Config;
import optifine.ConnectedTextures;
import optifine.CustomItems;
import optifine.Reflector;
import optifine.ReflectorForge;
import optifine.SpriteDependencies;
import optifine.TextureUtils;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import shadersmod.client.ShadersTex;

public class cdn
extends cdd
implements cdt {
    private static final Logger h = LogManager.getLogger();
    public static final nd f = new nd("missingno");
    public static final nd g = new nd("textures/atlas/blocks.png");
    private final List<cdo> i = Lists.newArrayList();
    private final Map<String, cdo> j = Maps.newHashMap();
    private final Map<String, cdo> k = Maps.newHashMap();
    private final String l;
    private final cdg m;
    private int n;
    private final cdo o = new cdo("missingno");
    private cdo[] iconGrid = null;
    private int iconGridSize = -1;
    private int iconGridCountX = -1;
    private int iconGridCountY = -1;
    private double iconGridSizeU = -1.0;
    private double iconGridSizeV = -1.0;
    private int counterIndexInMap = 0;
    public int atlasWidth = 0;
    public int atlasHeight = 0;

    public cdn(String basePathIn) {
        this(basePathIn, null);
    }

    public cdn(String p_i3_1_, boolean p_i3_2_) {
        this(p_i3_1_, null, p_i3_2_);
    }

    public cdn(String basePathIn, @Nullable cdg iconCreatorIn) {
        this(basePathIn, iconCreatorIn, false);
    }

    public cdn(String p_i4_1_, cdg p_i4_2_, boolean p_i4_3_) {
        this.l = p_i4_1_;
        this.m = p_i4_2_;
    }

    private void g() {
        int i2 = this.getMinSpriteSize();
        int[] aint = this.getMissingImageData(i2);
        this.o.b(i2);
        this.o.c(i2);
        int[][] aint1 = new int[this.n + 1][];
        aint1[0] = aint;
        this.o.a(Lists.newArrayList((Object[])new int[][][]{aint1}));
        this.o.setIndexInMap(this.counterIndexInMap++);
    }

    @Override
    public void a(cen resourceManager) throws IOException {
        ShadersTex.resManager = resourceManager;
        if (this.m != null) {
            this.a(resourceManager, this.m);
        }
    }

    public void a(cen resourceManager, cdg iconCreatorIn) {
        this.j.clear();
        this.counterIndexInMap = 0;
        Reflector.callVoid(Reflector.ForgeHooksClient_onTextureStitchedPre, this);
        iconCreatorIn.a(this);
        if (this.n >= 4) {
            this.n = this.detectMaxMipmapLevel(this.j, resourceManager);
            Config.log("Mipmap levels: " + this.n);
        }
        this.g();
        this.c();
        this.b(resourceManager);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void b(cen resourceManager) {
        int j2;
        ShadersTex.resManager = resourceManager;
        Config.dbg("Multitexture: " + Config.isMultiTexture());
        if (Config.isMultiTexture()) {
            for (cdo textureatlassprite : this.k.values()) {
                textureatlassprite.deleteSpriteTexture();
            }
        }
        ConnectedTextures.updateIcons(this);
        CustomItems.updateIcons(this);
        BetterGrass.updateIcons(this);
        int k1 = TextureUtils.getGLMaximumTextureSize();
        cdl stitcher = new cdl(k1, k1, 0, this.n);
        this.k.clear();
        this.i.clear();
        int i2 = Integer.MAX_VALUE;
        this.iconGridSize = j2 = this.getMinSpriteSize();
        int k2 = 1 << this.n;
        ArrayList<cdo> list = new ArrayList<cdo>(this.j.values());
        for (int l2 = 0; l2 < list.size(); ++l2) {
            nd resourcelocation;
            cdo textureatlassprite1;
            block37: {
                textureatlassprite1 = SpriteDependencies.resolveDependencies(list, l2, this);
                resourcelocation = this.a(textureatlassprite1);
                Object iresource = null;
                if (textureatlassprite1.getIndexInMap() < 0) {
                    textureatlassprite1.setIndexInMap(this.counterIndexInMap++);
                }
                if (textureatlassprite1.hasCustomLoader(resourceManager, resourcelocation)) {
                    if (textureatlassprite1.load(resourceManager, resourcelocation, p_lambda$loadTextureAtlas$0_1_ -> this.j.get(p_lambda$loadTextureAtlas$0_1_.toString()))) {
                        Config.dbg("Custom loader (skipped): " + textureatlassprite1);
                        continue;
                    }
                    Config.dbg("Custom loader: " + textureatlassprite1);
                } else {
                    cdj pngsizeinfo = cdj.a(resourceManager.a(resourcelocation));
                    iresource = Config.isShaders() ? ShadersTex.loadResource(resourceManager, resourcelocation) : resourceManager.a(resourcelocation);
                    boolean flag = iresource.a("animation") != null;
                    textureatlassprite1.a(pngsizeinfo, flag);
                    IOUtils.closeQuietly((Closeable)iresource);
                }
                break block37;
                catch (RuntimeException runtimeexception) {
                    h.error("Unable to parse metadata from {}", (Object)resourcelocation, (Object)runtimeexception);
                    ReflectorForge.FMLClientHandler_trackBrokenTexture(resourcelocation, runtimeexception.getMessage());
                    {
                        catch (Throwable throwable) {
                            IOUtils.closeQuietly(iresource);
                            throw throwable;
                        }
                    }
                    IOUtils.closeQuietly((Closeable)iresource);
                    continue;
                    catch (IOException ioexception) {
                        h.error("Using missing texture, unable to load " + resourcelocation + ", " + ioexception.getClass().getName());
                        ReflectorForge.FMLClientHandler_trackMissingTexture(resourcelocation);
                        IOUtils.closeQuietly((Closeable)iresource);
                        continue;
                    }
                }
            }
            int k22 = textureatlassprite1.c();
            int i3 = textureatlassprite1.d();
            if (k22 >= 1 && i3 >= 1) {
                if (k22 < j2 || this.n > 0) {
                    int i1;
                    int n2 = i1 = this.n > 0 ? TextureUtils.scaleToPowerOfTwo(k22, j2) : TextureUtils.scaleMinTo(k22, j2);
                    if (i1 != k22) {
                        if (!TextureUtils.isPowerOfTwo(k22)) {
                            Config.log("Scaled non power of 2: " + textureatlassprite1.i() + ", " + k22 + " -> " + i1);
                        } else {
                            Config.log("Scaled too small texture: " + textureatlassprite1.i() + ", " + k22 + " -> " + i1);
                        }
                        int j1 = i3 * i1 / k22;
                        textureatlassprite1.b(i1);
                        textureatlassprite1.c(j1);
                    }
                }
                i2 = Math.min(i2, Math.min(textureatlassprite1.c(), textureatlassprite1.d()));
                int j3 = Math.min(Integer.lowestOneBit(textureatlassprite1.c()), Integer.lowestOneBit(textureatlassprite1.d()));
                if (j3 < k2) {
                    h.warn("Texture {} with size {}x{} limits mip level from {} to {}", (Object)resourcelocation, (Object)textureatlassprite1.c(), (Object)textureatlassprite1.d(), (Object)ri.e(k2), (Object)ri.e(j3));
                    k2 = j3;
                }
                if (!this.a(resourceManager, textureatlassprite1)) continue;
                stitcher.a(textureatlassprite1);
                continue;
            }
            Config.warn("Invalid sprite size: " + textureatlassprite1);
        }
        int l1 = Math.min(i2, k2);
        int i22 = ri.e(l1);
        if (i22 < 0) {
            i22 = 0;
        }
        if (i22 < this.n) {
            h.warn("{}: dropping miplevel from {} to {}, because of minimum power of two: {}", (Object)this.l, (Object)this.n, (Object)i22, (Object)l1);
            this.n = i22;
        }
        this.o.d(this.n);
        stitcher.a(this.o);
        stitcher.c();
        h.info("Created: {}x{} {}-atlas", (Object)stitcher.a(), (Object)stitcher.b(), (Object)this.l);
        if (Config.isShaders()) {
            ShadersTex.allocateTextureMap(this.b(), this.n, stitcher.a(), stitcher.b(), stitcher, this);
        } else {
            cdr.a(this.b(), this.n, stitcher.a(), stitcher.b());
        }
        HashMap map = Maps.newHashMap(this.j);
        for (cdo textureatlassprite2 : stitcher.d()) {
            if (Config.isShaders()) {
                ShadersTex.setIconName(ShadersTex.setSprite(textureatlassprite2).i());
            }
            String s2 = textureatlassprite2.i();
            map.remove(s2);
            this.k.put(s2, textureatlassprite2);
            try {
                if (Config.isShaders()) {
                    ShadersTex.uploadTexSubForLoadAtlas(textureatlassprite2.a(0), textureatlassprite2.c(), textureatlassprite2.d(), textureatlassprite2.a(), textureatlassprite2.b(), false, false);
                } else {
                    cdr.a(textureatlassprite2.a(0), textureatlassprite2.c(), textureatlassprite2.d(), textureatlassprite2.a(), textureatlassprite2.b(), false, false);
                }
            }
            catch (Throwable throwable) {
                b crashreport = b.a(throwable, "Stitching texture atlas");
                c crashreportcategory = crashreport.a("Texture being stitched together");
                crashreportcategory.a("Atlas path", this.l);
                crashreportcategory.a("Sprite", textureatlassprite2);
                throw new f(crashreport);
            }
            if (!textureatlassprite2.m()) continue;
            this.i.add(textureatlassprite2);
        }
        for (cdo textureatlassprite3 : map.values()) {
            textureatlassprite3.a(this.o);
        }
        if (Config.isMultiTexture()) {
            int j22 = stitcher.a();
            int l2 = stitcher.b();
            for (cdo textureatlassprite4 : stitcher.d()) {
                textureatlassprite4.sheetWidth = j22;
                textureatlassprite4.sheetHeight = l2;
                textureatlassprite4.mipmapLevels = this.n;
                cdo textureatlassprite5 = textureatlassprite4.spriteSingle;
                if (textureatlassprite5 == null) continue;
                if (textureatlassprite5.c() <= 0) {
                    textureatlassprite5.b(textureatlassprite4.c());
                    textureatlassprite5.c(textureatlassprite4.d());
                    textureatlassprite5.a(textureatlassprite4.c(), textureatlassprite4.d(), 0, 0, false);
                    textureatlassprite5.l();
                    List<int[][]> list1 = textureatlassprite4.getFramesTextureData();
                    textureatlassprite5.a(list1);
                    textureatlassprite5.setAnimationMetadata(textureatlassprite4.getAnimationMetadata());
                }
                textureatlassprite5.sheetWidth = j22;
                textureatlassprite5.sheetHeight = l2;
                textureatlassprite5.mipmapLevels = this.n;
                textureatlassprite4.bindSpriteTexture();
                boolean flag2 = false;
                boolean flag1 = true;
                try {
                    cdr.a(textureatlassprite5.a(0), textureatlassprite5.c(), textureatlassprite5.d(), textureatlassprite5.a(), textureatlassprite5.b(), flag2, flag1);
                }
                catch (Exception exception) {
                    Config.dbg("Error uploading sprite single: " + textureatlassprite5 + ", parent: " + textureatlassprite4);
                    exception.printStackTrace();
                }
            }
            Config.getMinecraft().N().a(g);
        }
        Reflector.callVoid(Reflector.ForgeHooksClient_onTextureStitchedPost, this);
        this.updateIconGrid(stitcher.a(), stitcher.b());
        if (!Config.equals(System.getProperty("saveTextureMap"), "true")) return;
        Config.dbg("Exporting texture map: " + this.l);
        TextureUtils.saveGlTexture("debug/" + this.l.replaceAll("/", "_"), this.b(), this.n, stitcher.a(), stitcher.b());
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public boolean a(cen resourceManager, final cdo texture) {
        block11: {
            nd resourcelocation1 = this.a(texture);
            cem iresource1 = null;
            if (texture.hasCustomLoader(resourceManager, resourcelocation1)) {
                TextureUtils.generateCustomMipmaps(texture, this.n);
            } else {
                boolean flag4;
                try {
                    iresource1 = resourceManager.a(resourcelocation1);
                    texture.a(iresource1, this.n + 1);
                    break block11;
                }
                catch (RuntimeException runtimeexception1) {
                    h.error("Unable to parse metadata from {}", (Object)resourcelocation1, (Object)runtimeexception1);
                    flag4 = false;
                }
                catch (IOException ioexception1) {
                    boolean flag42;
                    boolean crashreportcategory;
                    h.error("Using missing texture, unable to load {}", (Object)resourcelocation1, (Object)ioexception1);
                    boolean bl2 = crashreportcategory = (flag42 = false);
                    return bl2;
                }
                finally {
                    IOUtils.closeQuietly((Closeable)iresource1);
                }
                return flag4;
            }
        }
        try {
            texture.d(this.n);
            return true;
        }
        catch (Throwable throwable1) {
            b crashreport1 = b.a(throwable1, "Applying mipmap");
            c crashreportcategory1 = crashreport1.a("Sprite being mipmapped");
            crashreportcategory1.a("Sprite name", new d<String>(){

                public String a() throws Exception {
                    return texture.i();
                }
            });
            crashreportcategory1.a("Sprite size", new d<String>(){

                public String a() throws Exception {
                    return texture.c() + " x " + texture.d();
                }
            });
            crashreportcategory1.a("Sprite frames", new d<String>(){

                public String a() throws Exception {
                    return texture.k() + " frames";
                }
            });
            crashreportcategory1.a("Mipmap levels", this.n);
            throw new f(crashreport1);
        }
    }

    public nd a(cdo p_184396_1_) {
        nd resourcelocation1 = new nd(p_184396_1_.i());
        return this.completeResourceLocation(resourcelocation1);
    }

    public nd completeResourceLocation(nd p_completeResourceLocation_1_) {
        return this.isAbsoluteLocation(p_completeResourceLocation_1_) ? new nd(p_completeResourceLocation_1_.b(), p_completeResourceLocation_1_.a() + ".png") : new nd(p_completeResourceLocation_1_.b(), String.format("%s/%s%s", this.l, p_completeResourceLocation_1_.a(), ".png"));
    }

    public cdo a(String iconName) {
        cdo textureatlassprite6 = this.k.get(iconName);
        if (textureatlassprite6 == null) {
            textureatlassprite6 = this.o;
        }
        return textureatlassprite6;
    }

    public void d() {
        if (Config.isShaders()) {
            ShadersTex.updatingTex = this.getMultiTexID();
        }
        boolean flag3 = false;
        boolean flag4 = false;
        cdr.b(this.b());
        for (cdo textureatlassprite6 : this.i) {
            if (!this.isTerrainAnimationActive(textureatlassprite6)) continue;
            textureatlassprite6.j();
            if (textureatlassprite6.spriteNormal != null) {
                flag3 = true;
            }
            if (textureatlassprite6.spriteSpecular == null) continue;
            flag4 = true;
        }
        if (Config.isMultiTexture()) {
            for (cdo textureatlassprite8 : this.i) {
                cdo textureatlassprite7;
                if (!this.isTerrainAnimationActive(textureatlassprite8) || (textureatlassprite7 = textureatlassprite8.spriteSingle) == null) continue;
                if (textureatlassprite8 == TextureUtils.iconClock || textureatlassprite8 == TextureUtils.iconCompass) {
                    textureatlassprite7.h = textureatlassprite8.h;
                }
                textureatlassprite8.bindSpriteTexture();
                textureatlassprite7.j();
            }
            cdr.b(this.b());
        }
        if (Config.isShaders()) {
            if (flag3) {
                cdr.b(this.getMultiTexID().norm);
                for (cdo textureatlassprite9 : this.i) {
                    if (textureatlassprite9.spriteNormal == null || !this.isTerrainAnimationActive(textureatlassprite9)) continue;
                    if (textureatlassprite9 == TextureUtils.iconClock || textureatlassprite9 == TextureUtils.iconCompass) {
                        textureatlassprite9.spriteNormal.h = textureatlassprite9.h;
                    }
                    textureatlassprite9.spriteNormal.j();
                }
            }
            if (flag4) {
                cdr.b(this.getMultiTexID().spec);
                for (cdo textureatlassprite10 : this.i) {
                    if (textureatlassprite10.spriteSpecular == null || !this.isTerrainAnimationActive(textureatlassprite10)) continue;
                    if (textureatlassprite10 == TextureUtils.iconClock || textureatlassprite10 == TextureUtils.iconCompass) {
                        textureatlassprite10.spriteNormal.h = textureatlassprite10.h;
                    }
                    textureatlassprite10.spriteSpecular.j();
                }
            }
            if (flag3 || flag4) {
                cdr.b(this.b());
            }
        }
        if (Config.isShaders()) {
            ShadersTex.updatingTex = null;
        }
    }

    public cdo a(nd location) {
        if (location == null) {
            throw new IllegalArgumentException("Location cannot be null!");
        }
        cdo textureatlassprite6 = this.j.get(location.toString());
        if (textureatlassprite6 == null) {
            textureatlassprite6 = cdo.a(location);
            this.j.put(location.toString(), textureatlassprite6);
            if (textureatlassprite6.getIndexInMap() < 0) {
                textureatlassprite6.setIndexInMap(this.counterIndexInMap++);
            }
        }
        return textureatlassprite6;
    }

    @Override
    public void e() {
        this.d();
    }

    public void a(int mipmapLevelsIn) {
        this.n = mipmapLevelsIn;
    }

    public cdo f() {
        return this.o;
    }

    @Nullable
    public cdo getTextureExtry(String p_getTextureExtry_1_) {
        return this.j.get(p_getTextureExtry_1_);
    }

    public boolean setTextureEntry(cdo p_setTextureEntry_1_) {
        String s1 = p_setTextureEntry_1_.i();
        if (!this.j.containsKey(s1)) {
            this.j.put(s1, p_setTextureEntry_1_);
            if (p_setTextureEntry_1_.getIndexInMap() < 0) {
                p_setTextureEntry_1_.setIndexInMap(this.counterIndexInMap++);
            }
            return true;
        }
        return false;
    }

    public String getBasePath() {
        return this.l;
    }

    public int getMipmapLevels() {
        return this.n;
    }

    private boolean isAbsoluteLocation(nd p_isAbsoluteLocation_1_) {
        String s1 = p_isAbsoluteLocation_1_.a();
        return this.isAbsoluteLocationPath(s1);
    }

    private boolean isAbsoluteLocationPath(String p_isAbsoluteLocationPath_1_) {
        String s1 = p_isAbsoluteLocationPath_1_.toLowerCase();
        return s1.startsWith("mcpatcher/") || s1.startsWith("optifine/");
    }

    public cdo getSpriteSafe(String p_getSpriteSafe_1_) {
        nd resourcelocation1 = new nd(p_getSpriteSafe_1_);
        return this.j.get(resourcelocation1.toString());
    }

    public cdo getRegisteredSprite(nd p_getRegisteredSprite_1_) {
        return this.j.get(p_getRegisteredSprite_1_.toString());
    }

    private boolean isTerrainAnimationActive(cdo p_isTerrainAnimationActive_1_) {
        if (p_isTerrainAnimationActive_1_ != TextureUtils.iconWaterStill && p_isTerrainAnimationActive_1_ != TextureUtils.iconWaterFlow) {
            if (p_isTerrainAnimationActive_1_ != TextureUtils.iconLavaStill && p_isTerrainAnimationActive_1_ != TextureUtils.iconLavaFlow) {
                if (p_isTerrainAnimationActive_1_ != TextureUtils.iconFireLayer0 && p_isTerrainAnimationActive_1_ != TextureUtils.iconFireLayer1) {
                    if (p_isTerrainAnimationActive_1_ == TextureUtils.iconPortal) {
                        return Config.isAnimatedPortal();
                    }
                    return p_isTerrainAnimationActive_1_ != TextureUtils.iconClock && p_isTerrainAnimationActive_1_ != TextureUtils.iconCompass ? Config.isAnimatedTerrain() : true;
                }
                return Config.isAnimatedFire();
            }
            return Config.isAnimatedLava();
        }
        return Config.isAnimatedWater();
    }

    public int getCountRegisteredSprites() {
        return this.counterIndexInMap;
    }

    private int detectMaxMipmapLevel(Map p_detectMaxMipmapLevel_1_, cen p_detectMaxMipmapLevel_2_) {
        int l3;
        int k3 = this.detectMinimumSpriteSize(p_detectMaxMipmapLevel_1_, p_detectMaxMipmapLevel_2_, 20);
        if (k3 < 16) {
            k3 = 16;
        }
        if ((k3 = ri.c(k3)) > 16) {
            Config.log("Sprite size: " + k3);
        }
        if ((l3 = ri.e(k3)) < 4) {
            l3 = 4;
        }
        return l3;
    }

    private int detectMinimumSpriteSize(Map p_detectMinimumSpriteSize_1_, cen p_detectMinimumSpriteSize_2_, int p_detectMinimumSpriteSize_3_) {
        HashMap<Integer, Integer> map1 = new HashMap<Integer, Integer>();
        for (Map.Entry entry : p_detectMinimumSpriteSize_1_.entrySet()) {
            cdo textureatlassprite6 = (cdo)entry.getValue();
            nd resourcelocation1 = new nd(textureatlassprite6.i());
            nd resourcelocation2 = this.completeResourceLocation(resourcelocation1);
            if (textureatlassprite6.hasCustomLoader(p_detectMinimumSpriteSize_2_, resourcelocation1)) continue;
            try {
                Dimension dimension;
                InputStream inputstream;
                cem iresource1 = p_detectMinimumSpriteSize_2_.a(resourcelocation2);
                if (iresource1 == null || (inputstream = iresource1.b()) == null || (dimension = TextureUtils.getImageSize(inputstream, "png")) == null) continue;
                int k3 = dimension.width;
                int l3 = ri.c(k3);
                if (!map1.containsKey(l3)) {
                    map1.put(l3, 1);
                    continue;
                }
                int i4 = (Integer)map1.get(l3);
                map1.put(l3, i4 + 1);
            }
            catch (Exception iresource1) {}
        }
        int j4 = 0;
        Set set = map1.keySet();
        TreeSet set1 = new TreeSet(set);
        Iterator iterator = set1.iterator();
        while (iterator.hasNext()) {
            int l4 = (Integer)iterator.next();
            int j5 = (Integer)map1.get(l4);
            j4 += j5;
        }
        int k4 = 16;
        int i5 = 0;
        int j5 = j4 * p_detectMinimumSpriteSize_3_ / 100;
        Iterator iterator1 = set1.iterator();
        while (iterator1.hasNext()) {
            int k5 = (Integer)iterator1.next();
            int l5 = (Integer)map1.get(k5);
            i5 += l5;
            if (k5 > k4) {
                k4 = k5;
            }
            if (i5 <= j5) continue;
            return k4;
        }
        return k4;
    }

    private int getMinSpriteSize() {
        int k3 = 1 << this.n;
        if (k3 < 8) {
            k3 = 8;
        }
        return k3;
    }

    private int[] getMissingImageData(int p_getMissingImageData_1_) {
        BufferedImage bufferedimage = new BufferedImage(16, 16, 2);
        bufferedimage.setRGB(0, 0, 16, 16, cdr.b, 0, 16);
        BufferedImage bufferedimage1 = TextureUtils.scaleToPowerOfTwo(bufferedimage, p_getMissingImageData_1_);
        int[] aint = new int[p_getMissingImageData_1_ * p_getMissingImageData_1_];
        bufferedimage1.getRGB(0, 0, p_getMissingImageData_1_, p_getMissingImageData_1_, aint, 0, p_getMissingImageData_1_);
        return aint;
    }

    public boolean isTextureBound() {
        int l3;
        int k3 = buq.getBoundTexture();
        return k3 == (l3 = this.b());
    }

    private void updateIconGrid(int p_updateIconGrid_1_, int p_updateIconGrid_2_) {
        this.iconGridCountX = -1;
        this.iconGridCountY = -1;
        this.iconGrid = null;
        if (this.iconGridSize > 0) {
            this.iconGridCountX = p_updateIconGrid_1_ / this.iconGridSize;
            this.iconGridCountY = p_updateIconGrid_2_ / this.iconGridSize;
            this.iconGrid = new cdo[this.iconGridCountX * this.iconGridCountY];
            this.iconGridSizeU = 1.0 / (double)this.iconGridCountX;
            this.iconGridSizeV = 1.0 / (double)this.iconGridCountY;
            for (cdo textureatlassprite6 : this.k.values()) {
                double d0 = 0.5 / (double)p_updateIconGrid_1_;
                double d1 = 0.5 / (double)p_updateIconGrid_2_;
                double d2 = (double)Math.min(textureatlassprite6.e(), textureatlassprite6.f()) + d0;
                double d3 = (double)Math.min(textureatlassprite6.g(), textureatlassprite6.h()) + d1;
                double d4 = (double)Math.max(textureatlassprite6.e(), textureatlassprite6.f()) - d0;
                double d5 = (double)Math.max(textureatlassprite6.g(), textureatlassprite6.h()) - d1;
                int k3 = (int)(d2 / this.iconGridSizeU);
                int l3 = (int)(d3 / this.iconGridSizeV);
                int i4 = (int)(d4 / this.iconGridSizeU);
                int j4 = (int)(d5 / this.iconGridSizeV);
                for (int k4 = k3; k4 <= i4; ++k4) {
                    if (k4 >= 0 && k4 < this.iconGridCountX) {
                        for (int l4 = l3; l4 <= j4; ++l4) {
                            if (l4 >= 0 && l4 < this.iconGridCountX) {
                                int i5 = l4 * this.iconGridCountX + k4;
                                this.iconGrid[i5] = textureatlassprite6;
                                continue;
                            }
                            Config.warn("Invalid grid V: " + l4 + ", icon: " + textureatlassprite6.i());
                        }
                        continue;
                    }
                    Config.warn("Invalid grid U: " + k4 + ", icon: " + textureatlassprite6.i());
                }
            }
        }
    }

    public cdo getIconByUV(double p_getIconByUV_1_, double p_getIconByUV_3_) {
        if (this.iconGrid == null) {
            return null;
        }
        int l3 = (int)(p_getIconByUV_3_ / this.iconGridSizeV);
        int k3 = (int)(p_getIconByUV_1_ / this.iconGridSizeU);
        int i4 = l3 * this.iconGridCountX + k3;
        return i4 >= 0 && i4 <= this.iconGrid.length ? this.iconGrid[i4] : null;
    }
}

