/*
 * Decompiled with CFR 0.150.
 */
public class tb
implements rs {
    @Override
    public int a() {
        return 820;
    }

    @Override
    public fy a(fy fy2) {
        if ("minecraft:totem".equals(fy2.l("id"))) {
            fy2.a("id", "minecraft:totem_of_undying");
        }
        return fy2;
    }
}

