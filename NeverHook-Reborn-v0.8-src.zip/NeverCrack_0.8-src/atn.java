/*
 * Decompiled with CFR 0.150.
 */
import java.util.Random;

public class atn
extends apa
implements aox {
    public static final axf<asp.a> a = axf.a("type", asp.a.class);
    public static final axg c = axg.a("stage", 0, 1);
    protected static final bgz d = new bgz(0.09999999403953552, 0.0, 0.09999999403953552, 0.9f, 0.8f, 0.9f);

    protected atn() {
        this.w(this.A.b().a(a, asp.a.a).a(c, 0));
        this.a(ahn.c);
    }

    @Override
    public bgz b(awr awr2, amw amw2, et et2) {
        return d;
    }

    @Override
    public String c() {
        return ft.a(this.a() + "." + asp.a.a.d() + ".name");
    }

    @Override
    public void b(ams ams2, et et2, awr awr2, Random random) {
        if (ams2.G) {
            return;
        }
        super.b(ams2, et2, awr2, random);
        if (ams2.k(et2.a()) >= 9 && random.nextInt(7) == 0) {
            this.c(ams2, et2, awr2, random);
        }
    }

    public void c(ams ams2, et et2, awr awr2, Random random) {
        if (awr2.c(c) == 0) {
            ams2.a(et2, awr2.a(c), 4);
        } else {
            this.d(ams2, et2, awr2, random);
        }
    }

    public void d(ams ams2, et et2, awr awr2, Random random2) {
        awr awr3;
        aze \u26035 = random2.nextInt(10) == 0 ? new azf(true) : new bav(true);
        int \u26032 = 0;
        int \u26033 = 0;
        boolean \u26034 = false;
        switch (awr2.c(a)) {
            case b: {
                block7: for (\u26032 = 0; \u26032 >= -1; --\u26032) {
                    for (\u26033 = 0; \u26033 >= -1; --\u26033) {
                        if (!this.a(ams2, et2, \u26032, \u26033, asp.a.b)) continue;
                        \u26035 = new baf(false, random2.nextBoolean());
                        \u26034 = true;
                        break block7;
                    }
                }
                if (\u26034) break;
                \u26032 = 0;
                \u26033 = 0;
                \u26035 = new bas(true);
                break;
            }
            case c: {
                \u26035 = new azg(true, false);
                break;
            }
            case d: {
                Random random2;
                awr3 = aov.r.t().a(asm.b, asp.a.d);
                \u2603 = aov.t.t().a(asl.e, asp.a.d).a(arp.b, false);
                block9: for (\u26032 = 0; \u26032 >= -1; --\u26032) {
                    for (\u26033 = 0; \u26033 >= -1; --\u26033) {
                        if (!this.a(ams2, et2, \u26032, \u26033, asp.a.d)) continue;
                        \u26035 = new bae(true, 10, 20, awr3, \u2603);
                        \u26034 = true;
                        break block9;
                    }
                }
                if (\u26034) break;
                \u26032 = 0;
                \u26033 = 0;
                \u26035 = new bav(true, 4 + random2.nextInt(7), awr3, \u2603, false);
                break;
            }
            case e: {
                \u26035 = new bap(true);
                break;
            }
            case f: {
                block11: for (\u26032 = 0; \u26032 >= -1; --\u26032) {
                    for (\u26033 = 0; \u26033 >= -1; --\u26033) {
                        if (!this.a(ams2, et2, \u26032, \u26033, asp.a.f)) continue;
                        \u26035 = new ban(true);
                        \u26034 = true;
                        break block11;
                    }
                }
                if (\u26034) break;
                return;
            }
        }
        awr3 = aov.a.t();
        if (\u26034) {
            ams2.a(et2.a(\u26032, 0, \u26033), awr3, 4);
            ams2.a(et2.a(\u26032 + 1, 0, \u26033), awr3, 4);
            ams2.a(et2.a(\u26032, 0, \u26033 + 1), awr3, 4);
            ams2.a(et2.a(\u26032 + 1, 0, \u26033 + 1), awr3, 4);
        } else {
            ams2.a(et2, awr3, 4);
        }
        if (!((azs)\u26035).b(ams2, random2, et2.a(\u26032, 0, \u26033))) {
            if (\u26034) {
                ams2.a(et2.a(\u26032, 0, \u26033), awr2, 4);
                ams2.a(et2.a(\u26032 + 1, 0, \u26033), awr2, 4);
                ams2.a(et2.a(\u26032, 0, \u26033 + 1), awr2, 4);
                ams2.a(et2.a(\u26032 + 1, 0, \u26033 + 1), awr2, 4);
            } else {
                ams2.a(et2, awr2, 4);
            }
        }
    }

    private boolean a(ams ams2, et et2, int n2, int n3, asp.a a2) {
        return this.a(ams2, et2.a(n2, 0, n3), a2) && this.a(ams2, et2.a(n2 + 1, 0, n3), a2) && this.a(ams2, et2.a(n2, 0, n3 + 1), a2) && this.a(ams2, et2.a(n2 + 1, 0, n3 + 1), a2);
    }

    public boolean a(ams ams2, et et2, asp.a a2) {
        awr awr2 = ams2.o(et2);
        return awr2.u() == this && awr2.c(a) == a2;
    }

    @Override
    public int d(awr awr2) {
        return awr2.c(a).a();
    }

    @Override
    public void a(ahn ahn2, fi<ain> fi2) {
        for (asp.a a2 : asp.a.values()) {
            fi2.add(new ain(this, 1, a2.a()));
        }
    }

    @Override
    public boolean a(ams ams2, et et2, awr awr2, boolean bl2) {
        return true;
    }

    @Override
    public boolean a(ams ams2, Random random, et et2, awr awr2) {
        return (double)ams2.r.nextFloat() < 0.45;
    }

    @Override
    public void b(ams ams2, Random random, et et2, awr awr2) {
        this.c(ams2, et2, awr2, random);
    }

    @Override
    public awr a(int n2) {
        return this.t().a(a, asp.a.a(n2 & 7)).a(c, (n2 & 8) >> 3);
    }

    @Override
    public int e(awr awr2) {
        int n2 = 0;
        n2 |= awr2.c(a).a();
        return n2 |= awr2.c(c) << 3;
    }

    @Override
    protected aws b() {
        return new aws((aou)this, a, c);
    }
}

