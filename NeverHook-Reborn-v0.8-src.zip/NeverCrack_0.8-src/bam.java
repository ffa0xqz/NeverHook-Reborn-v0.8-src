/*
 * Decompiled with CFR 0.150.
 */
import java.util.Random;

public class bam
extends azs {
    @Override
    public boolean b(ams ams2, Random random, et et2) {
        for (int i2 = 0; i2 < 20; ++i2) {
            et et3 = et2.a(random.nextInt(4) - random.nextInt(4), 0, random.nextInt(4) - random.nextInt(4));
            if (!ams2.d(et3) || ams2.o((\u2603 = et3.b()).e()).a() != bcx.h && ams2.o(\u2603.f()).a() != bcx.h && ams2.o(\u2603.c()).a() != bcx.h && ams2.o(\u2603.d()).a() != bcx.h) continue;
            int \u26032 = 2 + random.nextInt(random.nextInt(3) + 1);
            for (int i3 = 0; i3 < \u26032; ++i3) {
                if (!aov.aM.b(ams2, et3)) continue;
                ams2.a(et3.b(i3), aov.aM.t(), 2);
            }
        }
        return true;
    }
}

