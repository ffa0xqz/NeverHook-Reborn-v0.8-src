/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 */
import com.google.common.collect.Lists;
import java.util.Collections;
import java.util.List;

public class bnl
extends bip {
    private static final nd a = new nd("textures/gui/recipe_book.png");
    private final List<a> f = Lists.newArrayList();
    private boolean g;
    private int h;
    private int i;
    private bhz j;
    private bnq k;
    private akr l;
    private float m;

    public void a(bhz bhz2, bnq bnq2, int n2, int n3, int n4, int n5, float f2, qj qj2) {
        this.j = bhz2;
        this.k = bnq2;
        boolean bl2 = qj2.b();
        List<akr> \u26032 = bnq2.b(true);
        List \u26033 = bl2 ? Collections.emptyList() : bnq2.b(false);
        int \u26034 = \u26032.size();
        int \u26035 = \u26034 + \u26033.size();
        int \u26036 = \u26035 <= 16 ? 4 : 5;
        int \u26037 = (int)Math.ceil((float)\u26035 / (float)\u26036);
        this.h = n2;
        this.i = n3;
        int \u26038 = 25;
        float \u26039 = this.h + Math.min(\u26035, \u26036) * 25;
        if (\u26039 > (\u2603 = (float)(n4 + 50))) {
            this.h = (int)((float)this.h - f2 * (float)((int)((\u26039 - \u2603) / f2)));
        }
        if ((\u2603 = (float)(this.i + \u26037 * 25)) > (\u2603 = (float)(n5 + 50))) {
            this.i = (int)((float)this.i - f2 * (float)ri.f((\u2603 - \u2603) / f2));
        }
        if ((\u2603 = (float)this.i) < (\u2603 = (float)(n5 - 100))) {
            this.i = (int)((float)this.i - f2 * (float)ri.f((\u2603 - \u2603) / f2));
        }
        this.g = true;
        this.f.clear();
        for (int i2 = 0; i2 < \u26035; ++i2) {
            boolean bl3 = i2 < \u26034;
            this.f.add(new a(this.h + 4 + 25 * (i2 % \u26036), this.i + 5 + 25 * (i2 / \u26036), bl3 ? \u26032.get(i2) : (akr)\u26033.get(i2 - \u26034), bl3));
        }
        this.l = null;
    }

    public bnq a() {
        return this.k;
    }

    public akr b() {
        return this.l;
    }

    public boolean a(int n2, int n3, int n4) {
        if (n4 != 0) {
            return false;
        }
        for (a a2 : this.f) {
            if (!a2.b(this.j, n2, n3)) continue;
            this.l = a2.p;
            return true;
        }
        return false;
    }

    public void a(int n2, int n3, float f2) {
        if (!this.g) {
            return;
        }
        this.m += f2;
        bhx.c();
        buq.m();
        buq.c(1.0f, 1.0f, 1.0f, 1.0f);
        this.j.N().a(a);
        buq.G();
        buq.c(0.0f, 0.0f, 170.0f);
        int n4 = this.f.size() <= 16 ? 4 : 5;
        \u2603 = Math.min(this.f.size(), n4);
        \u2603 = ri.f((float)this.f.size() / (float)n4);
        \u2603 = 24;
        \u2603 = 4;
        \u2603 = 82;
        \u2603 = 208;
        this.c(\u2603, \u2603, 24, 4, 82, 208);
        buq.l();
        bhx.a();
        for (a a2 : this.f) {
            a2.a(this.j, n2, n3, f2);
        }
        buq.H();
    }

    private void c(int n2, int n3, int n4, int n5, int n6, int n7) {
        this.b(this.h, this.i, n6, n7, n5, n5);
        this.b(this.h + n5 * 2 + n2 * n4, this.i, n6 + n4 + n5, n7, n5, n5);
        this.b(this.h, this.i + n5 * 2 + n3 * n4, n6, n7 + n4 + n5, n5, n5);
        this.b(this.h + n5 * 2 + n2 * n4, this.i + n5 * 2 + n3 * n4, n6 + n4 + n5, n7 + n4 + n5, n5, n5);
        for (\u2603 = 0; \u2603 < n2; ++\u2603) {
            this.b(this.h + n5 + \u2603 * n4, this.i, n6 + n5, n7, n4, n5);
            this.b(this.h + n5 + (\u2603 + 1) * n4, this.i, n6 + n5, n7, n5, n5);
            for (\u2603 = 0; \u2603 < n3; ++\u2603) {
                if (\u2603 == 0) {
                    this.b(this.h, this.i + n5 + \u2603 * n4, n6, n7 + n5, n5, n4);
                    this.b(this.h, this.i + n5 + (\u2603 + 1) * n4, n6, n7 + n5, n5, n5);
                }
                this.b(this.h + n5 + \u2603 * n4, this.i + n5 + \u2603 * n4, n6 + n5, n7 + n5, n4, n4);
                this.b(this.h + n5 + (\u2603 + 1) * n4, this.i + n5 + \u2603 * n4, n6 + n5, n7 + n5, n5, n4);
                this.b(this.h + n5 + \u2603 * n4, this.i + n5 + (\u2603 + 1) * n4, n6 + n5, n7 + n5, n4, n5);
                this.b(this.h + n5 + (\u2603 + 1) * n4 - 1, this.i + n5 + (\u2603 + 1) * n4 - 1, n6 + n5, n7 + n5, n5 + 1, n5 + 1);
                if (\u2603 != n2 - 1) continue;
                this.b(this.h + n5 * 2 + n2 * n4, this.i + n5 + \u2603 * n4, n6 + n4 + n5, n7 + n5, n5, n4);
                this.b(this.h + n5 * 2 + n2 * n4, this.i + n5 + (\u2603 + 1) * n4, n6 + n4 + n5, n7 + n5, n5, n5);
            }
            this.b(this.h + n5 + \u2603 * n4, this.i + n5 * 2 + n3 * n4, n6 + n5, n7 + n4 + n5, n4, n5);
            this.b(this.h + n5 + (\u2603 + 1) * n4, this.i + n5 * 2 + n3 * n4, n6 + n5, n7 + n4 + n5, n5, n5);
        }
    }

    public void a(boolean bl2) {
        this.g = bl2;
    }

    public boolean c() {
        return this.g;
    }

    class a
    extends biy {
        private final akr p;
        private final boolean q;

        public a(int n2, int n3, akr akr2, boolean bl2) {
            super(0, n2, n3, "");
            this.f = 24;
            this.g = 24;
            this.p = akr2;
            this.q = bl2;
        }

        public void a(bhz bhz2, int n2, int n3, float f2) {
            int \u26033;
            int \u26032;
            bhx.c();
            buq.e();
            bhz2.N().a(a);
            this.n = n2 >= this.h && n3 >= this.i && n2 < this.h + this.f && n3 < this.i + this.g;
            int n4 = 152;
            if (!this.q) {
                n4 += 26;
            }
            \u2603 = 78;
            if (this.n) {
                \u2603 += 26;
            }
            this.b(this.h, this.i, n4, \u2603, this.f, this.g);
            \u26032 = 3;
            \u26033 = 3;
            if (this.p instanceof aku) {
                Object object = (aku)this.p;
                \u26032 = ((aku)object).f();
                \u26033 = ((aku)object).g();
            }
            object = this.p.d().iterator();
            for (int \u26034 = 0; \u26034 < \u26033; ++\u26034) {
                int n5 = 3 + \u26034 * 7;
                for (\u2603 = 0; \u2603 < \u26032; ++\u2603) {
                    if (!object.hasNext() || (\u2603 = ((ako)object.next()).a()).length == 0) continue;
                    \u2603 = 3 + \u2603 * 7;
                    buq.G();
                    float f3 = 0.42f;
                    int \u26035 = (int)((float)(this.h + \u2603) / 0.42f - 3.0f);
                    int \u26036 = (int)((float)(this.i + n5) / 0.42f - 3.0f);
                    buq.b(0.42f, 0.42f, 1.0f);
                    buq.f();
                    bhz2.ad().b(\u2603[ri.d(bnl.this.m / 30.0f) % \u2603.length], \u26035, \u26036);
                    buq.g();
                    buq.H();
                }
            }
            buq.d();
            bhx.a();
        }
    }
}

