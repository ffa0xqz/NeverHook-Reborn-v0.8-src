/*
 * Decompiled with CFR 0.150.
 */
import java.awt.image.BufferedImage;
import java.io.IOException;
import optifine.Config;
import shadersmod.client.ShadersTex;

public class cde
extends cdd {
    private final int[] f;
    private final int g;
    private final int h;
    private boolean shadersInitialized = false;

    public cde(BufferedImage bufferedImage) {
        this(bufferedImage.getWidth(), bufferedImage.getHeight());
        bufferedImage.getRGB(0, 0, bufferedImage.getWidth(), bufferedImage.getHeight(), this.f, 0, bufferedImage.getWidth());
        this.d();
    }

    public cde(int textureWidth, int textureHeight) {
        this.g = textureWidth;
        this.h = textureHeight;
        this.f = new int[textureWidth * textureHeight * 3];
        if (Config.isShaders()) {
            ShadersTex.initDynamicTexture(this.b(), textureWidth, textureHeight, this);
            this.shadersInitialized = true;
        } else {
            cdr.a(this.b(), textureWidth, textureHeight);
        }
    }

    @Override
    public void a(cen resourceManager) throws IOException {
    }

    public void d() {
        if (Config.isShaders()) {
            if (!this.shadersInitialized) {
                ShadersTex.initDynamicTexture(this.b(), this.g, this.h, this);
                this.shadersInitialized = true;
            }
            ShadersTex.updateDynamicTexture(this.b(), this.f, this.g, this.h, this);
        } else {
            cdr.a(this.b(), this.f, this.g, this.h);
        }
    }

    public int[] e() {
        return this.f;
    }
}

