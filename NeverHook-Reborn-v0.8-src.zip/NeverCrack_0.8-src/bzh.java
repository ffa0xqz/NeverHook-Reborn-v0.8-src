/*
 * Decompiled with CFR 0.150.
 */
import optifine.Config;
import optifine.CustomColors;

public class bzh
extends bze<vk> {
    private static final nd a = new nd("textures/entity/experience_orb.png");

    public bzh(bzd renderManagerIn) {
        super(renderManagerIn);
        this.c = 0.15f;
        this.d = 0.75f;
    }

    @Override
    public void a(vk entity, double x2, double y2, double z2, float entityYaw, float partialTicks) {
        if (!this.e) {
            int j2;
            buq.G();
            buq.c((float)x2, (float)y2, (float)z2);
            this.d(entity);
            bhx.b();
            int i2 = entity.k();
            float f2 = (float)(i2 % 4 * 16 + 0) / 64.0f;
            float f1 = (float)(i2 % 4 * 16 + 16) / 64.0f;
            float f22 = (float)(i2 / 4 * 16 + 0) / 64.0f;
            float f3 = (float)(i2 / 4 * 16 + 16) / 64.0f;
            float f4 = 1.0f;
            float f5 = 0.5f;
            float f6 = 0.25f;
            int j3 = entity.av();
            int k2 = j3 % 65536;
            int l2 = j3 / 65536;
            cig.a(cig.r, k2, (float)l2);
            buq.c(1.0f, 1.0f, 1.0f, 1.0f);
            float f7 = 255.0f;
            float f8 = ((float)entity.a + partialTicks) / 2.0f;
            if (Config.isCustomColors()) {
                f8 = CustomColors.getXpOrbTimer(f8);
            }
            l2 = (int)((ri.a(f8 + 0.0f) + 1.0f) * 0.5f * 255.0f);
            int i1 = 255;
            int j1 = (int)((ri.a(f8 + 4.1887903f) + 1.0f) * 0.1f * 255.0f);
            buq.c(0.0f, 0.1f, 0.0f);
            buq.b(180.0f - bzd.e, 0.0f, 1.0f, 0.0f);
            buq.b((float)(this.b.g.aw == 2 ? -1 : 1) * -bzd.f, 1.0f, 0.0f, 0.0f);
            float f9 = 0.3f;
            buq.b(0.3f, 0.3f, 0.3f);
            bvc tessellator = bvc.a();
            bui bufferbuilder = tessellator.c();
            bufferbuilder.a(7, cdw.l);
            int k1 = l2;
            int l1 = 255;
            int i22 = j1;
            if (Config.isCustomColors() && (j2 = CustomColors.getXpOrbColor(f8)) >= 0) {
                k1 = j2 >> 16 & 0xFF;
                l1 = j2 >> 8 & 0xFF;
                i22 = j2 >> 0 & 0xFF;
            }
            bufferbuilder.b(-0.5, -0.25, 0.0).a(f2, f3).b(k1, l1, i22, 128).c(0.0f, 1.0f, 0.0f).d();
            bufferbuilder.b(0.5, -0.25, 0.0).a(f1, f3).b(k1, l1, i22, 128).c(0.0f, 1.0f, 0.0f).d();
            bufferbuilder.b(0.5, 0.75, 0.0).a(f1, f22).b(k1, l1, i22, 128).c(0.0f, 1.0f, 0.0f).d();
            bufferbuilder.b(-0.5, 0.75, 0.0).a(f2, f22).b(k1, l1, i22, 128).c(0.0f, 1.0f, 0.0f).d();
            tessellator.b();
            buq.l();
            buq.E();
            buq.H();
            super.a(entity, x2, y2, z2, entityYaw, partialTicks);
        }
    }

    @Override
    protected nd a(vk entity) {
        return a;
    }
}

