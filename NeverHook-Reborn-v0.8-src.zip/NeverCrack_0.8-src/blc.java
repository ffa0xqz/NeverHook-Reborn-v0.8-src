/*
 * Decompiled with CFR 0.150.
 */
public class blc
extends bli {
    private static final bib.a[] f = new bib.a[]{bib.a.c};
    private final bli g;
    private final bib h;
    private biy i;
    private bjj s;
    protected String a = "Options";

    public blc(bli bli2, bib bib2) {
        this.g = bli2;
        this.h = bib2;
    }

    @Override
    public void b() {
        this.a = cew.a("options.title", new Object[0]);
        int n2 = 0;
        for (bib.a a2 : f) {
            if (a2.a()) {
                this.n.add(new bjq(a2.c(), this.l / 2 - 155 + n2 % 2 * 160, this.m / 6 - 12 + 24 * (n2 >> 1), a2));
            } else {
                bjl bjl2 = new bjl(a2.c(), this.l / 2 - 155 + n2 % 2 * 160, this.m / 6 - 12 + 24 * (n2 >> 1), a2, this.h.c(a2));
                this.n.add(bjl2);
            }
            ++n2;
        }
        if (this.j.f != null) {
            tx tx2 = this.j.f.ag();
            this.i = new biy(108, this.l / 2 - 155 + n2 % 2 * 160, this.m / 6 - 12 + 24 * (n2 >> 1), 150, 20, this.a(tx2));
            this.n.add(this.i);
            if (this.j.E() && !this.j.f.V().s()) {
                this.i.a(this.i.b() - 20);
                this.s = new bjj(109, this.i.h + this.i.b(), this.i.i);
                this.n.add(this.s);
                this.s.b(this.j.f.V().y());
                this.s.l = !this.s.c();
                this.i.l = !this.s.c();
            } else {
                this.i.l = false;
            }
        } else {
            this.n.add(new bjl(bib.a.L.c(), this.l / 2 - 155 + n2 % 2 * 160, this.m / 6 - 12 + 24 * (n2 >> 1), bib.a.L, this.h.c(bib.a.L)));
        }
        this.n.add(new biy(110, this.l / 2 - 155, this.m / 6 + 48 - 6, 150, 20, cew.a("options.skinCustomisation", new Object[0])));
        this.n.add(new biy(106, this.l / 2 + 5, this.m / 6 + 48 - 6, 150, 20, cew.a("options.sounds", new Object[0])));
        this.n.add(new biy(101, this.l / 2 - 155, this.m / 6 + 72 - 6, 150, 20, cew.a("options.video", new Object[0])));
        this.n.add(new biy(100, this.l / 2 + 5, this.m / 6 + 72 - 6, 150, 20, cew.a("options.controls", new Object[0])));
        this.n.add(new biy(102, this.l / 2 - 155, this.m / 6 + 96 - 6, 150, 20, cew.a("options.language", new Object[0])));
        this.n.add(new biy(103, this.l / 2 + 5, this.m / 6 + 96 - 6, 150, 20, cew.a("options.chat.title", new Object[0])));
        this.n.add(new biy(105, this.l / 2 - 155, this.m / 6 + 120 - 6, 150, 20, cew.a("options.resourcepack", new Object[0])));
        this.n.add(new biy(104, this.l / 2 + 5, this.m / 6 + 120 - 6, 150, 20, cew.a("options.snooper.view", new Object[0])));
        this.n.add(new biy(200, this.l / 2 - 100, this.m / 6 + 168, cew.a("gui.done", new Object[0])));
    }

    public String a(tx tx2) {
        ho ho2 = new ho("");
        ho2.a(new hp("options.difficulty", new Object[0]));
        ho2.a(": ");
        ho2.a(new hp(tx2.b(), new Object[0]));
        return ho2.d();
    }

    @Override
    public void a(boolean bl2, int n2) {
        this.j.a(this);
        if (n2 == 109 && bl2 && this.j.f != null) {
            this.j.f.V().e(true);
            this.s.b(true);
            this.s.l = false;
            this.i.l = false;
        }
    }

    @Override
    protected void a(char c2, int n2) {
        if (n2 == 1) {
            this.j.t.b();
        }
        super.a(c2, n2);
    }

    @Override
    protected void a(biy biy22) {
        biy biy22;
        if (!biy22.l) {
            return;
        }
        if (biy22.k < 100 && biy22 instanceof bjl) {
            bib.a a2 = ((bjl)biy22).c();
            this.h.a(a2, 1);
            biy22.j = this.h.c(bib.a.a(biy22.k));
        }
        if (biy22.k == 108) {
            this.j.f.V().a(tx.a(this.j.f.ag().a() + 1));
            this.i.j = this.a(this.j.f.ag());
        }
        if (biy22.k == 109) {
            this.j.a(new bko(this, new hp("difficulty.lock.title", new Object[0]).d(), new hp("difficulty.lock.question", new hp(this.j.f.V().x().b(), new Object[0])).d(), 109));
        }
        if (biy22.k == 110) {
            this.j.t.b();
            this.j.a(new blk(this));
        }
        if (biy22.k == 101) {
            this.j.t.b();
            this.j.a(new blq(this, this.h));
        }
        if (biy22.k == 100) {
            this.j.t.b();
            this.j.a(new bmc(this, this.h));
        }
        if (biy22.k == 102) {
            this.j.t.b();
            this.j.a(new bla(this, this.h, this.j.Q()));
        }
        if (biy22.k == 103) {
            this.j.t.b();
            this.j.a(new bkk(this, this.h));
        }
        if (biy22.k == 104) {
            this.j.t.b();
            this.j.a(new bll(this, this.h));
        }
        if (biy22.k == 200) {
            this.j.t.b();
            this.j.a(this.g);
        }
        if (biy22.k == 105) {
            this.j.t.b();
            this.j.a(new bnu(this));
        }
        if (biy22.k == 106) {
            this.j.t.b();
            this.j.a(new blm(this, this.h));
        }
    }

    @Override
    public void a(int n2, int n3, float f2) {
        this.c();
        this.a(this.q, this.a, this.l / 2, 15, 0xFFFFFF);
        super.a(n2, n3, f2);
    }
}

