/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonDeserializationContext
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonSerializationContext
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import java.util.Random;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class bgc
extends bfx {
    private static final Logger a = LogManager.getLogger();
    private final bfu b;

    public bgc(bgj[] arrbgj, bfu bfu2) {
        super(arrbgj);
        this.b = bfu2;
    }

    @Override
    public ain a(ain ain22, Random random, bfr bfr2) {
        ain ain22;
        if (ain22.f()) {
            float f2 = 1.0f - this.b.b(random);
            ain22.b(ri.d(f2 * (float)ain22.k()));
        } else {
            a.warn("Couldn't set damage of loot item {}", (Object)ain22);
        }
        return ain22;
    }

    public static class a
    extends bfx.a<bgc> {
        protected a() {
            super(new nd("set_damage"), bgc.class);
        }

        @Override
        public void a(JsonObject jsonObject, bgc bgc2, JsonSerializationContext jsonSerializationContext) {
            jsonObject.add("damage", jsonSerializationContext.serialize((Object)bgc2.b));
        }

        public bgc a(JsonObject jsonObject, JsonDeserializationContext jsonDeserializationContext, bgj[] arrbgj) {
            return new bgc(arrbgj, ra.a(jsonObject, "damage", jsonDeserializationContext, bfu.class));
        }

        @Override
        public /* synthetic */ bfx b(JsonObject jsonObject, JsonDeserializationContext jsonDeserializationContext, bgj[] arrbgj) {
            return this.a(jsonObject, jsonDeserializationContext, arrbgj);
        }
    }
}

