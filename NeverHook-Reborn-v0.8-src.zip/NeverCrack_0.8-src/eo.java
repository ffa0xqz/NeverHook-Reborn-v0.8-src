/*
 * Decompiled with CFR 0.150.
 */
public class eo
extends ei {
    public eo() {
        this("commands.generic.notFound", new Object[0]);
    }

    public eo(String string, Object ... arrobject) {
        super(string, arrobject);
    }

    @Override
    public synchronized Throwable fillInStackTrace() {
        return this;
    }
}

