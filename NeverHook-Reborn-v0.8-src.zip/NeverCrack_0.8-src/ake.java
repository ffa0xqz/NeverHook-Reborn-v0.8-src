/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  javax.annotation.Nullable
 */
import com.google.common.collect.ImmutableList;
import java.util.List;
import javax.annotation.Nullable;

public class ake {
    private static final nd b = new nd("empty");
    public static final ey<nd, ake> a = new ey(b);
    private static int c;
    private final String d;
    private final ImmutableList<uy> e;

    @Nullable
    public static ake a(String string) {
        return a.c(new nd(string));
    }

    public ake(uy ... arruy) {
        this((String)null, arruy);
    }

    public ake(@Nullable String string, uy ... arruy) {
        this.d = string;
        this.e = ImmutableList.copyOf((Object[])arruy);
    }

    public String b(String string) {
        return this.d == null ? string + a.b(this).a() : string + this.d;
    }

    public List<uy> a() {
        return this.e;
    }

    public static void b() {
        ake.a("empty", new ake(new uy[0]));
        ake.a("water", new ake(new uy[0]));
        ake.a("mundane", new ake(new uy[0]));
        ake.a("thick", new ake(new uy[0]));
        ake.a("awkward", new ake(new uy[0]));
        ake.a("night_vision", new ake(new uy(uz.p, 3600)));
        ake.a("long_night_vision", new ake("night_vision", new uy(uz.p, 9600)));
        ake.a("invisibility", new ake(new uy(uz.n, 3600)));
        ake.a("long_invisibility", new ake("invisibility", new uy(uz.n, 9600)));
        ake.a("leaping", new ake(new uy(uz.h, 3600)));
        ake.a("long_leaping", new ake("leaping", new uy(uz.h, 9600)));
        ake.a("strong_leaping", new ake("leaping", new uy(uz.h, 1800, 1)));
        ake.a("fire_resistance", new ake(new uy(uz.l, 3600)));
        ake.a("long_fire_resistance", new ake("fire_resistance", new uy(uz.l, 9600)));
        ake.a("swiftness", new ake(new uy(uz.a, 3600)));
        ake.a("long_swiftness", new ake("swiftness", new uy(uz.a, 9600)));
        ake.a("strong_swiftness", new ake("swiftness", new uy(uz.a, 1800, 1)));
        ake.a("slowness", new ake(new uy(uz.b, 1800)));
        ake.a("long_slowness", new ake("slowness", new uy(uz.b, 4800)));
        ake.a("water_breathing", new ake(new uy(uz.m, 3600)));
        ake.a("long_water_breathing", new ake("water_breathing", new uy(uz.m, 9600)));
        ake.a("healing", new ake(new uy(uz.f, 1)));
        ake.a("strong_healing", new ake("healing", new uy(uz.f, 1, 1)));
        ake.a("harming", new ake(new uy(uz.g, 1)));
        ake.a("strong_harming", new ake("harming", new uy(uz.g, 1, 1)));
        ake.a("poison", new ake(new uy(uz.s, 900)));
        ake.a("long_poison", new ake("poison", new uy(uz.s, 1800)));
        ake.a("strong_poison", new ake("poison", new uy(uz.s, 432, 1)));
        ake.a("regeneration", new ake(new uy(uz.j, 900)));
        ake.a("long_regeneration", new ake("regeneration", new uy(uz.j, 1800)));
        ake.a("strong_regeneration", new ake("regeneration", new uy(uz.j, 450, 1)));
        ake.a("strength", new ake(new uy(uz.e, 3600)));
        ake.a("long_strength", new ake("strength", new uy(uz.e, 9600)));
        ake.a("strong_strength", new ake("strength", new uy(uz.e, 1800, 1)));
        ake.a("weakness", new ake(new uy(uz.r, 1800)));
        ake.a("long_weakness", new ake("weakness", new uy(uz.r, 4800)));
        ake.a("luck", new ake("luck", new uy(uz.z, 6000)));
        a.a();
    }

    protected static void a(String string, ake ake2) {
        a.a(c++, new nd(string), ake2);
    }

    public boolean c() {
        if (!this.e.isEmpty()) {
            for (uy uy2 : this.e) {
                if (!uy2.a().b()) continue;
                return true;
            }
        }
        return false;
    }
}

