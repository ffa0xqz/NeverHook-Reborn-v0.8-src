/*
 * Decompiled with CFR 0.150.
 */
public abstract class art
extends atj {
    public static final axf<a> a = axf.a("axis", a.class);

    public art() {
        super(bcx.d);
        this.a(ahn.b);
        this.c(2.0f);
        this.a(atw.a);
    }

    @Override
    public void b(ams ams2, et et2, awr awr2) {
        int n2 = 4;
        \u2603 = 5;
        if (!ams2.a(et2.a(-5, -5, -5), et2.a(5, 5, 5))) {
            return;
        }
        for (et et3 : et.a(et2.a(-4, -4, -4), et2.a(4, 4, 4))) {
            awr awr3 = ams2.o(et3);
            if (awr3.a() != bcx.j || awr3.c(arp.b).booleanValue()) continue;
            ams2.a(et3, awr3.a(arp.b, true), 4);
        }
    }

    @Override
    public awr a(ams ams2, et et2, fa fa2, float f2, float f3, float f4, int n2, vn vn2) {
        return this.a(n2).a(a, art$a.a(fa2.k()));
    }

    @Override
    public awr a(awr awr2, atk atk2) {
        switch (atk2) {
            case d: 
            case b: {
                switch (awr2.c(a)) {
                    case a: {
                        return awr2.a(a, art$a.c);
                    }
                    case c: {
                        return awr2.a(a, art$a.a);
                    }
                }
                return awr2;
            }
        }
        return awr2;
    }

    public static enum a implements rm
    {
        a("x"),
        b("y"),
        c("z"),
        d("none");

        private final String e;

        private a(String string2) {
            this.e = string2;
        }

        public String toString() {
            return this.e;
        }

        public static a a(fa.a a2) {
            switch (a2) {
                case a: {
                    return a;
                }
                case b: {
                    return b;
                }
                case c: {
                    return c;
                }
            }
            return d;
        }

        @Override
        public String m() {
            return this.e;
        }
    }
}

