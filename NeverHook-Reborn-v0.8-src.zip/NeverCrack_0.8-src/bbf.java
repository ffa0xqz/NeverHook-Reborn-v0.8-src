/*
 * Decompiled with CFR 0.150.
 */
import java.util.Random;

public class bbf
extends bbs {
    private final int a = 20;
    private final int b = 11;
    private final azd d;

    public bbf(azd azd2) {
        this.d = azd2;
    }

    @Override
    public String a() {
        return "EndCity";
    }

    @Override
    protected boolean a(int \u260322, int n2) {
        int n3;
        \u2603 = \u260322;
        n3 = n2;
        if (\u260322 < 0) {
            \u260322 -= 19;
        }
        if (n2 < 0) {
            n2 -= 19;
        }
        \u2603 = \u260322 / 20;
        \u2603 = n2 / 20;
        Random random = this.g.a(\u2603, \u2603, 10387313);
        \u2603 *= 20;
        \u2603 *= 20;
        int \u260322 = \u2603;
        n2 = n3;
        if (\u260322 == (\u2603 += (random.nextInt(9) + random.nextInt(9)) / 2) && n2 == (\u2603 += (random.nextInt(9) + random.nextInt(9)) / 2) && this.d.c(\u260322, n2)) {
            \u2603 = bbf.b(\u260322, n2, this.d);
            return \u2603 >= 60;
        }
        return false;
    }

    @Override
    protected bbw b(int n2, int n3) {
        return new a(this.g, this.d, this.f, n2, n3);
    }

    @Override
    public et a(ams ams2, et et2, boolean bl2) {
        this.g = ams2;
        return bbf.a(ams2, this, et2, 20, 11, 10387313, true, 100, bl2);
    }

    private static int b(int n2, int n3, azd azd2) {
        Random random = new Random(n2 + n3 * 10387313);
        atk \u26032 = atk.values()[random.nextInt(atk.values().length)];
        ayu \u26033 = new ayu();
        azd2.a(n2, n3, \u26033);
        int \u26034 = 5;
        int \u26035 = 5;
        if (\u26032 == atk.b) {
            \u26034 = -5;
        } else if (\u26032 == atk.c) {
            \u26034 = -5;
            \u26035 = -5;
        } else if (\u26032 == atk.d) {
            \u26035 = -5;
        }
        int \u26036 = \u26033.a(7, 7);
        int \u26037 = \u26033.a(7, 7 + \u26035);
        int \u26038 = \u26033.a(7 + \u26034, 7);
        int \u26039 = \u26033.a(7 + \u26034, 7 + \u26035);
        int \u260310 = Math.min(Math.min(\u26036, \u26037), Math.min(\u26038, \u26039));
        return \u260310;
    }

    public static class a
    extends bbw {
        private boolean c;

        public a() {
        }

        public a(ams ams2, azd azd2, Random random, int n2, int n3) {
            super(n2, n3);
            this.a(ams2, azd2, random, n2, n3);
        }

        private void a(ams ams2, azd azd2, Random random, int n2, int n3) {
            Random random2 = new Random(n2 + n3 * 10387313);
            atk \u26032 = atk.values()[random2.nextInt(atk.values().length)];
            int \u26033 = bbf.b(n2, n3, azd2);
            if (\u26033 < 60) {
                this.c = false;
                return;
            }
            et \u26034 = new et(n2 * 16 + 8, \u26033, n3 * 16 + 8);
            bbg.a(ams2.U().h(), \u26034, \u26032, this.a, random);
            this.d();
            this.c = true;
        }

        @Override
        public boolean a() {
            return this.c;
        }
    }
}

