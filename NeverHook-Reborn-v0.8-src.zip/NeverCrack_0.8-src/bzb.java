/*
 * Decompiled with CFR 0.150.
 */
import java.util.Random;

public class bzb
extends cad<acs> {
    private static final nd a = new nd("textures/entity/enderman/enderman.png");
    private final Random j = new Random();

    public bzb(bzd bzd2) {
        super(bzd2, new bpo(0.0f), 0.5f);
        this.a(new cbx(this));
        this.a(new cbq(this));
    }

    public bpo c() {
        return (bpo)super.b();
    }

    @Override
    public void a(acs acs22, double d2, double d3, double d4, float f2, float f3) {
        acs acs22;
        awr awr2 = acs22.dn();
        bpo \u26032 = this.c();
        \u26032.a = awr2 != null;
        \u26032.b = acs22.do();
        if (acs22.do()) {
            double d5 = 0.02;
            d2 += this.j.nextGaussian() * 0.02;
            d4 += this.j.nextGaussian() * 0.02;
        }
        super.a(acs22, d2, d3, d4, f2, f3);
    }

    @Override
    protected nd a(acs acs2) {
        return a;
    }

    @Override
    public /* synthetic */ bqd b() {
        return this.c();
    }
}

