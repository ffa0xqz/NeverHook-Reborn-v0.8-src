/*
 * Decompiled with CFR 0.150.
 */
package shadersmod.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import optifine.Config;
import optifine.GuiScreenOF;
import optifine.Lang;
import optifine.StrUtils;
import shadersmod.client.GuiButtonShaderOption;
import shadersmod.client.GuiSliderShaderOption;
import shadersmod.client.ShaderOption;
import shadersmod.client.ShaderOptionProfile;
import shadersmod.client.ShaderOptionScreen;
import shadersmod.client.Shaders;

public class GuiShaderOptions
extends GuiScreenOF {
    private bli prevScreen;
    protected String title = "Shader Options";
    private bib settings;
    private int lastMouseX = 0;
    private int lastMouseY = 0;
    private long mouseStillTime = 0L;
    private String screenName = null;
    private String screenText = null;
    private boolean changed = false;
    public static final String OPTION_PROFILE = "<profile>";
    public static final String OPTION_EMPTY = "<empty>";
    public static final String OPTION_REST = "*";

    public GuiShaderOptions(bli guiscreen, bib gamesettings) {
        this.prevScreen = guiscreen;
        this.settings = gamesettings;
    }

    public GuiShaderOptions(bli guiscreen, bib gamesettings, String screenName) {
        this(guiscreen, gamesettings);
        this.screenName = screenName;
        if (screenName != null) {
            this.screenText = Shaders.translate("screen." + screenName, screenName);
        }
    }

    @Override
    public void b() {
        this.title = cew.a("of.options.shaderOptionsTitle", new Object[0]);
        int i2 = 100;
        int j2 = 0;
        int k2 = 30;
        int l2 = 20;
        int i1 = this.l - 130;
        int j1 = 120;
        int k1 = 20;
        int l1 = Shaders.getShaderPackColumns(this.screenName, 2);
        ShaderOption[] ashaderoption = Shaders.getShaderPackOptions(this.screenName);
        if (ashaderoption != null) {
            int i22 = ri.f((double)ashaderoption.length / 9.0);
            if (l1 < i22) {
                l1 = i22;
            }
            for (int j22 = 0; j22 < ashaderoption.length; ++j22) {
                ShaderOption shaderoption = ashaderoption[j22];
                if (shaderoption == null || !shaderoption.isVisible()) continue;
                int k22 = j22 % l1;
                int l22 = j22 / l1;
                int i3 = Math.min(this.l / l1, 200);
                j2 = (this.l - i3 * l1) / 2;
                int j3 = k22 * i3 + 5 + j2;
                int k3 = k2 + l22 * l2;
                int l3 = i3 - 10;
                String s2 = GuiShaderOptions.getButtonText(shaderoption, l3);
                GuiButtonShaderOption guibuttonshaderoption = Shaders.isShaderPackOptionSlider(shaderoption.getName()) ? new GuiSliderShaderOption(i2 + j22, j3, k3, l3, k1, shaderoption, s2) : new GuiButtonShaderOption(i2 + j22, j3, k3, l3, k1, shaderoption, s2);
                guibuttonshaderoption.l = shaderoption.isEnabled();
                this.n.add(guibuttonshaderoption);
            }
        }
        this.n.add(new biy(201, this.l / 2 - j1 - 20, this.m / 6 + 168 + 11, j1, k1, cew.a("controls.reset", new Object[0])));
        this.n.add(new biy(200, this.l / 2 + 20, this.m / 6 + 168 + 11, j1, k1, cew.a("gui.done", new Object[0])));
    }

    public static String getButtonText(ShaderOption so2, int btnWidth) {
        String s2 = so2.getNameText();
        if (so2 instanceof ShaderOptionScreen) {
            ShaderOptionScreen shaderoptionscreen = (ShaderOptionScreen)so2;
            return s2 + "...";
        }
        Config.getMinecraft();
        bin fontrenderer = bhz.k;
        int i2 = fontrenderer.a(": " + Lang.getOff()) + 5;
        while (fontrenderer.a(s2) + i2 >= btnWidth && s2.length() > 0) {
            s2 = s2.substring(0, s2.length() - 1);
        }
        String s1 = so2.isChanged() ? so2.getValueColor(so2.getValue()) : "";
        String s22 = so2.getValueText(so2.getValue());
        return s2 + ": " + s1 + s22;
    }

    @Override
    protected void a(biy guibutton) {
        if (guibutton.l) {
            if (guibutton.k < 200 && guibutton instanceof GuiButtonShaderOption) {
                GuiButtonShaderOption guibuttonshaderoption = (GuiButtonShaderOption)guibutton;
                ShaderOption shaderoption = guibuttonshaderoption.getShaderOption();
                if (shaderoption instanceof ShaderOptionScreen) {
                    String s2 = shaderoption.getName();
                    GuiShaderOptions guishaderoptions = new GuiShaderOptions(this, this.settings, s2);
                    this.j.a(guishaderoptions);
                    return;
                }
                if (GuiShaderOptions.s()) {
                    shaderoption.resetValue();
                } else {
                    shaderoption.nextValue();
                }
                this.updateAllButtons();
                this.changed = true;
            }
            if (guibutton.k == 201) {
                ShaderOption[] ashaderoption = Shaders.getChangedOptions(Shaders.getShaderPackOptions());
                for (int i2 = 0; i2 < ashaderoption.length; ++i2) {
                    ShaderOption shaderoption1 = ashaderoption[i2];
                    shaderoption1.resetValue();
                    this.changed = true;
                }
                this.updateAllButtons();
            }
            if (guibutton.k == 200) {
                if (this.changed) {
                    Shaders.saveShaderPackOptions();
                    this.changed = false;
                    Shaders.uninit();
                }
                this.j.a(this.prevScreen);
            }
        }
    }

    @Override
    protected void actionPerformedRightClick(biy btn2) {
        if (btn2 instanceof GuiButtonShaderOption) {
            GuiButtonShaderOption guibuttonshaderoption = (GuiButtonShaderOption)btn2;
            ShaderOption shaderoption = guibuttonshaderoption.getShaderOption();
            if (GuiShaderOptions.s()) {
                shaderoption.resetValue();
            } else {
                shaderoption.prevValue();
            }
            this.updateAllButtons();
            this.changed = true;
        }
    }

    @Override
    public void m() {
        super.m();
        if (this.changed) {
            Shaders.saveShaderPackOptions();
            this.changed = false;
            Shaders.uninit();
        }
    }

    private void updateAllButtons() {
        for (biy guibutton : this.n) {
            if (!(guibutton instanceof GuiButtonShaderOption)) continue;
            GuiButtonShaderOption guibuttonshaderoption = (GuiButtonShaderOption)guibutton;
            ShaderOption shaderoption = guibuttonshaderoption.getShaderOption();
            if (shaderoption instanceof ShaderOptionProfile) {
                ShaderOptionProfile shaderoptionprofile = (ShaderOptionProfile)shaderoption;
                shaderoptionprofile.updateProfile();
            }
            guibuttonshaderoption.j = GuiShaderOptions.getButtonText(shaderoption, guibuttonshaderoption.b());
            guibuttonshaderoption.valueChanged();
        }
    }

    @Override
    public void a(int x2, int y2, float f2) {
        this.c();
        if (this.screenText != null) {
            this.a(this.q, this.screenText, this.l / 2, 15, 0xFFFFFF);
        } else {
            this.a(this.q, this.title, this.l / 2, 15, 0xFFFFFF);
        }
        super.a(x2, y2, f2);
        if (Math.abs(x2 - this.lastMouseX) <= 5 && Math.abs(y2 - this.lastMouseY) <= 5) {
            this.drawTooltips(x2, y2, this.n);
        } else {
            this.lastMouseX = x2;
            this.lastMouseY = y2;
            this.mouseStillTime = System.currentTimeMillis();
        }
    }

    private void drawTooltips(int x2, int y2, List buttons) {
        int i2 = 700;
        if (System.currentTimeMillis() >= this.mouseStillTime + (long)i2) {
            int j2 = this.l / 2 - 150;
            int k2 = this.m / 6 - 7;
            if (y2 <= k2 + 98) {
                k2 += 105;
            }
            int l2 = j2 + 150 + 150;
            int i1 = k2 + 84 + 10;
            biy guibutton = GuiShaderOptions.getSelectedButton(buttons, x2, y2);
            if (guibutton instanceof GuiButtonShaderOption) {
                GuiButtonShaderOption guibuttonshaderoption = (GuiButtonShaderOption)guibutton;
                ShaderOption shaderoption = guibuttonshaderoption.getShaderOption();
                String[] astring = this.makeTooltipLines(shaderoption, l2 - j2);
                if (astring == null) {
                    return;
                }
                GuiShaderOptions.drawGradientRect(j2, k2, l2, i1, -536870912, -536870912);
                for (int j1 = 0; j1 < astring.length; ++j1) {
                    String s2 = astring[j1];
                    int k1 = 0xDDDDDD;
                    if (s2.endsWith("!")) {
                        k1 = 0xFF2020;
                    }
                    this.q.a(s2, j2 + 5, k2 + 5 + j1 * 11, k1);
                }
            }
        }
    }

    private String[] makeTooltipLines(ShaderOption so2, int width) {
        if (so2 instanceof ShaderOptionProfile) {
            return null;
        }
        String s2 = so2.getNameText();
        String s1 = Config.normalize(so2.getDescriptionText()).trim();
        String[] astring = this.splitDescription(s1);
        String s22 = null;
        if (!s2.equals(so2.getName()) && this.settings.z) {
            s22 = "\u00a78" + Lang.get("of.general.id") + ": " + so2.getName();
        }
        String s3 = null;
        if (so2.getPaths() != null && this.settings.z) {
            s3 = "\u00a78" + Lang.get("of.general.from") + ": " + Config.arrayToString(so2.getPaths());
        }
        String s4 = null;
        if (so2.getValueDefault() != null && this.settings.z) {
            String s5 = so2.isEnabled() ? so2.getValueText(so2.getValueDefault()) : Lang.get("of.general.ambiguous");
            s4 = "\u00a78" + Lang.getDefault() + ": " + s5;
        }
        ArrayList<String> list = new ArrayList<String>();
        list.add(s2);
        list.addAll(Arrays.asList(astring));
        if (s22 != null) {
            list.add(s22);
        }
        if (s3 != null) {
            list.add(s3);
        }
        if (s4 != null) {
            list.add(s4);
        }
        String[] astring1 = this.makeTooltipLines(width, list);
        return astring1;
    }

    private String[] splitDescription(String desc) {
        if (desc.length() <= 0) {
            return new String[0];
        }
        desc = StrUtils.removePrefix(desc, "//");
        String[] astring = desc.split("\\. ");
        for (int i2 = 0; i2 < astring.length; ++i2) {
            astring[i2] = "- " + astring[i2].trim();
            astring[i2] = StrUtils.removeSuffix(astring[i2], ".");
        }
        return astring;
    }

    private String[] makeTooltipLines(int width, List<String> args) {
        Config.getMinecraft();
        bin fontrenderer = bhz.k;
        ArrayList<String> list = new ArrayList<String>();
        for (int i2 = 0; i2 < args.size(); ++i2) {
            String s2 = args.get(i2);
            if (s2 == null || s2.length() <= 0) continue;
            for (String s1 : fontrenderer.c(s2, width)) {
                list.add(s1);
            }
        }
        String[] astring = list.toArray(new String[list.size()]);
        return astring;
    }
}

