/*
 * Decompiled with CFR 0.150.
 */
package shadersmod.client;

import shadersmod.client.ShadersTex;

public class DefaultTexture
extends cdd {
    public DefaultTexture() {
        this.a(null);
    }

    @Override
    public void a(cen resourcemanager) {
        int[] aint = ShadersTex.createAIntImage(1, -1);
        ShadersTex.setupTexture(this.getMultiTexID(), aint, 1, 1, false, false);
    }
}

