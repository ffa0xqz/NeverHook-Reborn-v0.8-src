/*
 * Decompiled with CFR 0.150.
 */
package shadersmod.client;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import shadersmod.client.IteratorRenderChunks;
import shadersmod.client.Shaders;

public class ShadowUtils {
    public static Iterator<bxp> makeShadowChunkIterator(brz world, double partialTicks, ve viewEntity, int renderDistanceChunks, bvf viewFrustum) {
        float f2 = Shaders.getShadowRenderDistance();
        if (f2 > 0.0f && f2 < (float)((renderDistanceChunks - 1) * 16)) {
            int i2 = ri.f(f2 / 16.0f) + 1;
            float f6 = world.d((float)partialTicks);
            float f1 = Shaders.sunPathRotation * ((float)Math.PI / 180);
            float f22 = f6 > 1.5707964f && f6 < 4.712389f ? f6 + (float)Math.PI : f6;
            float f3 = -ri.a(f22);
            float f4 = ri.b(f22) * ri.b(f1);
            float f5 = -ri.b(f22) * ri.a(f1);
            et blockpos = new et(ri.c(viewEntity.p) >> 4, ri.c(viewEntity.q) >> 4, ri.c(viewEntity.r) >> 4);
            et blockpos1 = blockpos.a(-f3 * (float)i2, -f4 * (float)i2, -f5 * (float)i2);
            et blockpos2 = blockpos.a(f3 * (float)renderDistanceChunks, f4 * (float)renderDistanceChunks, f5 * (float)renderDistanceChunks);
            IteratorRenderChunks iteratorrenderchunks = new IteratorRenderChunks(viewFrustum, blockpos1, blockpos2, i2, i2);
            return iteratorrenderchunks;
        }
        List<bxp> list = Arrays.asList(viewFrustum.f);
        Iterator<bxp> iterator = list.iterator();
        return iterator;
    }
}

