/*
 * Decompiled with CFR 0.150.
 */
package shadersmod.client;

import java.util.Iterator;
import optifine.BlockPosM;
import shadersmod.client.IteratorAxis;

public class Iterator3d
implements Iterator<et> {
    private IteratorAxis iteratorAxis;
    private BlockPosM blockPos = new BlockPosM(0, 0, 0);
    private int axis = 0;
    private int kX;
    private int kY;
    private int kZ;
    private static final int AXIS_X = 0;
    private static final int AXIS_Y = 1;
    private static final int AXIS_Z = 2;

    public Iterator3d(et posStart, et posEnd, int width, int height) {
        boolean flag = posStart.p() > posEnd.p();
        boolean flag1 = posStart.q() > posEnd.q();
        boolean flag2 = posStart.r() > posEnd.r();
        posStart = this.reverseCoord(posStart, flag, flag1, flag2);
        posEnd = this.reverseCoord(posEnd, flag, flag1, flag2);
        this.kX = flag ? -1 : 1;
        this.kY = flag1 ? -1 : 1;
        this.kZ = flag2 ? -1 : 1;
        bhc vec3d = new bhc(posEnd.p() - posStart.p(), posEnd.q() - posStart.q(), posEnd.r() - posStart.r());
        bhc vec3d1 = vec3d.a();
        bhc vec3d2 = new bhc(1.0, 0.0, 0.0);
        double d0 = vec3d1.b(vec3d2);
        double d1 = Math.abs(d0);
        bhc vec3d3 = new bhc(0.0, 1.0, 0.0);
        double d2 = vec3d1.b(vec3d3);
        double d3 = Math.abs(d2);
        bhc vec3d4 = new bhc(0.0, 0.0, 1.0);
        double d4 = vec3d1.b(vec3d4);
        double d5 = Math.abs(d4);
        if (d5 >= d3 && d5 >= d1) {
            this.axis = 2;
            et blockpos3 = new et(posStart.r(), posStart.q() - width, posStart.p() - height);
            et blockpos5 = new et(posEnd.r(), posStart.q() + width + 1, posStart.p() + height + 1);
            int k2 = posEnd.r() - posStart.r();
            double d9 = (double)(posEnd.q() - posStart.q()) / (1.0 * (double)k2);
            double d11 = (double)(posEnd.p() - posStart.p()) / (1.0 * (double)k2);
            this.iteratorAxis = new IteratorAxis(blockpos3, blockpos5, d9, d11);
        } else if (d3 >= d1 && d3 >= d5) {
            this.axis = 1;
            et blockpos2 = new et(posStart.q(), posStart.p() - width, posStart.r() - height);
            et blockpos4 = new et(posEnd.q(), posStart.p() + width + 1, posStart.r() + height + 1);
            int j2 = posEnd.q() - posStart.q();
            double d8 = (double)(posEnd.p() - posStart.p()) / (1.0 * (double)j2);
            double d10 = (double)(posEnd.r() - posStart.r()) / (1.0 * (double)j2);
            this.iteratorAxis = new IteratorAxis(blockpos2, blockpos4, d8, d10);
        } else {
            this.axis = 0;
            et blockpos = new et(posStart.p(), posStart.q() - width, posStart.r() - height);
            et blockpos1 = new et(posEnd.p(), posStart.q() + width + 1, posStart.r() + height + 1);
            int i2 = posEnd.p() - posStart.p();
            double d6 = (double)(posEnd.q() - posStart.q()) / (1.0 * (double)i2);
            double d7 = (double)(posEnd.r() - posStart.r()) / (1.0 * (double)i2);
            this.iteratorAxis = new IteratorAxis(blockpos, blockpos1, d6, d7);
        }
    }

    private et reverseCoord(et pos, boolean revX, boolean revY, boolean revZ) {
        if (revX) {
            pos = new et(-pos.p(), pos.q(), pos.r());
        }
        if (revY) {
            pos = new et(pos.p(), -pos.q(), pos.r());
        }
        if (revZ) {
            pos = new et(pos.p(), pos.q(), -pos.r());
        }
        return pos;
    }

    @Override
    public boolean hasNext() {
        return this.iteratorAxis.hasNext();
    }

    @Override
    public et next() {
        et blockpos = this.iteratorAxis.next();
        switch (this.axis) {
            case 0: {
                this.blockPos.setXyz(blockpos.p() * this.kX, blockpos.q() * this.kY, blockpos.r() * this.kZ);
                return this.blockPos;
            }
            case 1: {
                this.blockPos.setXyz(blockpos.q() * this.kX, blockpos.p() * this.kY, blockpos.r() * this.kZ);
                return this.blockPos;
            }
            case 2: {
                this.blockPos.setXyz(blockpos.r() * this.kX, blockpos.q() * this.kY, blockpos.p() * this.kZ);
                return this.blockPos;
            }
        }
        this.blockPos.setXyz(blockpos.p() * this.kX, blockpos.q() * this.kY, blockpos.r() * this.kZ);
        return this.blockPos;
    }

    @Override
    public void remove() {
        throw new RuntimeException("Not supported");
    }

    public static void main(String[] args) {
        et blockpos = new et(10, 20, 30);
        et blockpos1 = new et(30, 40, 20);
        Iterator3d iterator3d = new Iterator3d(blockpos, blockpos1, 1, 1);
        while (iterator3d.hasNext()) {
            et blockpos2 = iterator3d.next();
            System.out.println("" + blockpos2);
        }
    }
}

