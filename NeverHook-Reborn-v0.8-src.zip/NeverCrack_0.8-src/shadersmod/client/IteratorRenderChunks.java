/*
 * Decompiled with CFR 0.150.
 */
package shadersmod.client;

import java.util.Iterator;
import optifine.BlockPosM;
import shadersmod.client.Iterator3d;

public class IteratorRenderChunks
implements Iterator<bxp> {
    private bvf viewFrustum;
    private Iterator3d Iterator3d;
    private BlockPosM posBlock = new BlockPosM(0, 0, 0);

    public IteratorRenderChunks(bvf viewFrustum, et posStart, et posEnd, int width, int height) {
        this.viewFrustum = viewFrustum;
        this.Iterator3d = new Iterator3d(posStart, posEnd, width, height);
    }

    @Override
    public boolean hasNext() {
        return this.Iterator3d.hasNext();
    }

    @Override
    public bxp next() {
        et blockpos = this.Iterator3d.next();
        this.posBlock.setXyz(blockpos.p() << 4, blockpos.q() << 4, blockpos.r() << 4);
        bxp renderchunk = this.viewFrustum.a(this.posBlock);
        return renderchunk;
    }

    @Override
    public void remove() {
        throw new RuntimeException("Not implemented");
    }
}

