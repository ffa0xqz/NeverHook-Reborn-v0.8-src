/*
 * Decompiled with CFR 0.150.
 */
package shadersmod.client;

public class SVertexAttrib {
    public int index;
    public int count;
    public cdz.a type;
    public int offset;

    public SVertexAttrib(int index, int count, cdz.a type) {
        this.index = index;
        this.count = count;
        this.type = type;
    }
}

