/*
 * Decompiled with CFR 0.150.
 */
package shadersmod.client;

public class SVertexFormat {
    public static final int vertexSizeBlock = 14;
    public static final int offsetMidTexCoord = 8;
    public static final int offsetTangent = 10;
    public static final int offsetEntity = 12;
    public static final cdy defVertexFormatTextured = SVertexFormat.makeDefVertexFormatTextured();

    public static cdy makeDefVertexFormatBlock() {
        cdy vertexformat = new cdy();
        vertexformat.a(new cdz(0, cdz.a.a, cdz.b.a, 3));
        vertexformat.a(new cdz(0, cdz.a.b, cdz.b.c, 4));
        vertexformat.a(new cdz(0, cdz.a.a, cdz.b.d, 2));
        vertexformat.a(new cdz(1, cdz.a.e, cdz.b.d, 2));
        vertexformat.a(new cdz(0, cdz.a.c, cdz.b.b, 3));
        vertexformat.a(new cdz(0, cdz.a.c, cdz.b.g, 1));
        vertexformat.a(new cdz(0, cdz.a.a, cdz.b.g, 2));
        vertexformat.a(new cdz(0, cdz.a.e, cdz.b.g, 4));
        vertexformat.a(new cdz(0, cdz.a.e, cdz.b.g, 4));
        return vertexformat;
    }

    public static cdy makeDefVertexFormatItem() {
        cdy vertexformat = new cdy();
        vertexformat.a(new cdz(0, cdz.a.a, cdz.b.a, 3));
        vertexformat.a(new cdz(0, cdz.a.b, cdz.b.c, 4));
        vertexformat.a(new cdz(0, cdz.a.a, cdz.b.d, 2));
        vertexformat.a(new cdz(0, cdz.a.e, cdz.b.g, 2));
        vertexformat.a(new cdz(0, cdz.a.c, cdz.b.b, 3));
        vertexformat.a(new cdz(0, cdz.a.c, cdz.b.g, 1));
        vertexformat.a(new cdz(0, cdz.a.a, cdz.b.g, 2));
        vertexformat.a(new cdz(0, cdz.a.e, cdz.b.g, 4));
        vertexformat.a(new cdz(0, cdz.a.e, cdz.b.g, 4));
        return vertexformat;
    }

    public static cdy makeDefVertexFormatTextured() {
        cdy vertexformat = new cdy();
        vertexformat.a(new cdz(0, cdz.a.a, cdz.b.a, 3));
        vertexformat.a(new cdz(0, cdz.a.b, cdz.b.g, 4));
        vertexformat.a(new cdz(0, cdz.a.a, cdz.b.d, 2));
        vertexformat.a(new cdz(0, cdz.a.e, cdz.b.g, 2));
        vertexformat.a(new cdz(0, cdz.a.c, cdz.b.b, 3));
        vertexformat.a(new cdz(0, cdz.a.c, cdz.b.g, 1));
        vertexformat.a(new cdz(0, cdz.a.a, cdz.b.g, 2));
        vertexformat.a(new cdz(0, cdz.a.e, cdz.b.g, 4));
        vertexformat.a(new cdz(0, cdz.a.e, cdz.b.g, 4));
        return vertexformat;
    }

    public static void setDefBakedFormat(cdy vf) {
        vf.a();
        vf.a(new cdz(0, cdz.a.a, cdz.b.a, 3));
        vf.a(new cdz(0, cdz.a.b, cdz.b.c, 4));
        vf.a(new cdz(0, cdz.a.a, cdz.b.d, 2));
        vf.a(new cdz(0, cdz.a.e, cdz.b.g, 2));
        vf.a(new cdz(0, cdz.a.c, cdz.b.b, 3));
        vf.a(new cdz(0, cdz.a.c, cdz.b.g, 1));
        vf.a(new cdz(0, cdz.a.a, cdz.b.g, 2));
        vf.a(new cdz(0, cdz.a.e, cdz.b.g, 4));
        vf.a(new cdz(0, cdz.a.e, cdz.b.g, 4));
    }
}

