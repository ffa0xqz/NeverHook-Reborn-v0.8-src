/*
 * Decompiled with CFR 0.150.
 */
package shadersmod.client;

import shadersmod.client.GuiButtonShaderOption;
import shadersmod.client.GuiShaderOptions;
import shadersmod.client.ShaderOption;

public class GuiSliderShaderOption
extends GuiButtonShaderOption {
    private float sliderValue = 1.0f;
    public boolean dragging;
    private ShaderOption shaderOption = null;

    public GuiSliderShaderOption(int buttonId, int x2, int y2, int w2, int h2, ShaderOption shaderOption, String text) {
        super(buttonId, x2, y2, w2, h2, shaderOption, text);
        this.shaderOption = shaderOption;
        this.sliderValue = shaderOption.getIndexNormalized();
        this.j = GuiShaderOptions.getButtonText(shaderOption, this.f);
    }

    @Override
    protected int a(boolean mouseOver) {
        return 0;
    }

    @Override
    protected void a(bhz mc2, int mouseX, int mouseY) {
        if (this.m) {
            if (this.dragging) {
                this.sliderValue = (float)(mouseX - (this.h + 4)) / (float)(this.f - 8);
                this.sliderValue = ri.a(this.sliderValue, 0.0f, 1.0f);
                this.shaderOption.setIndexNormalized(this.sliderValue);
                this.sliderValue = this.shaderOption.getIndexNormalized();
                this.j = GuiShaderOptions.getButtonText(this.shaderOption, this.f);
            }
            mc2.N().a(a);
            buq.c(1.0f, 1.0f, 1.0f, 1.0f);
            this.b(this.h + (int)(this.sliderValue * (float)(this.f - 8)), this.i, 0, 66, 4, 20);
            this.b(this.h + (int)(this.sliderValue * (float)(this.f - 8)) + 4, this.i, 196, 66, 4, 20);
        }
    }

    @Override
    public boolean b(bhz mc2, int mouseX, int mouseY) {
        if (super.b(mc2, mouseX, mouseY)) {
            this.sliderValue = (float)(mouseX - (this.h + 4)) / (float)(this.f - 8);
            this.sliderValue = ri.a(this.sliderValue, 0.0f, 1.0f);
            this.shaderOption.setIndexNormalized(this.sliderValue);
            this.j = GuiShaderOptions.getButtonText(this.shaderOption, this.f);
            this.dragging = true;
            return true;
        }
        return false;
    }

    @Override
    public void a(int mouseX, int mouseY) {
        this.dragging = false;
    }

    @Override
    public void valueChanged() {
        this.sliderValue = this.shaderOption.getIndexNormalized();
    }
}

