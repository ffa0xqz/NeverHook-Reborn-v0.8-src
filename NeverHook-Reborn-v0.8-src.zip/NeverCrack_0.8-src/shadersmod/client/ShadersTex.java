/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.lwjgl.BufferUtils
 *  org.lwjgl.opengl.GL11
 */
package shadersmod.client;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.imageio.ImageIO;
import optifine.Config;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import shadersmod.client.MultiTexID;
import shadersmod.client.Shaders;
import shadersmod.common.SMCLog;

public class ShadersTex {
    public static final int initialBufferSize = 0x100000;
    public static ByteBuffer byteBuffer = BufferUtils.createByteBuffer((int)0x400000);
    public static IntBuffer intBuffer = byteBuffer.asIntBuffer();
    public static int[] intArray = new int[0x100000];
    public static final int defBaseTexColor = 0;
    public static final int defNormTexColor = -8421377;
    public static final int defSpecTexColor = 0;
    public static Map<Integer, MultiTexID> multiTexMap = new HashMap<Integer, MultiTexID>();
    public static cdn updatingTextureMap = null;
    public static cdo updatingSprite = null;
    public static MultiTexID updatingTex = null;
    public static MultiTexID boundTex = null;
    public static int updatingPage = 0;
    public static String iconName = null;
    public static cen resManager = null;
    static nd resLocation = null;
    static int imageSize = 0;

    public static IntBuffer getIntBuffer(int size) {
        if (intBuffer.capacity() < size) {
            int i2 = ShadersTex.roundUpPOT(size);
            byteBuffer = BufferUtils.createByteBuffer((int)(i2 * 4));
            intBuffer = byteBuffer.asIntBuffer();
        }
        return intBuffer;
    }

    public static int[] getIntArray(int size) {
        if (intArray == null) {
            intArray = new int[0x100000];
        }
        if (intArray.length < size) {
            intArray = new int[ShadersTex.roundUpPOT(size)];
        }
        return intArray;
    }

    public static int roundUpPOT(int x2) {
        int i2 = x2 - 1;
        i2 |= i2 >> 1;
        i2 |= i2 >> 2;
        i2 |= i2 >> 4;
        i2 |= i2 >> 8;
        i2 |= i2 >> 16;
        return i2 + 1;
    }

    public static int log2(int x2) {
        int i2 = 0;
        if ((x2 & 0xFFFF0000) != 0) {
            i2 += 16;
            x2 >>= 16;
        }
        if ((x2 & 0xFF00) != 0) {
            i2 += 8;
            x2 >>= 8;
        }
        if ((x2 & 0xF0) != 0) {
            i2 += 4;
            x2 >>= 4;
        }
        if ((x2 & 6) != 0) {
            i2 += 2;
            x2 >>= 2;
        }
        if ((x2 & 2) != 0) {
            ++i2;
        }
        return i2;
    }

    public static IntBuffer fillIntBuffer(int size, int value) {
        int[] aint = ShadersTex.getIntArray(size);
        IntBuffer intbuffer = ShadersTex.getIntBuffer(size);
        Arrays.fill(intArray, 0, size, value);
        intBuffer.put(intArray, 0, size);
        return intBuffer;
    }

    public static int[] createAIntImage(int size) {
        int[] aint = new int[size * 3];
        Arrays.fill(aint, 0, size, 0);
        Arrays.fill(aint, size, size * 2, -8421377);
        Arrays.fill(aint, size * 2, size * 3, 0);
        return aint;
    }

    public static int[] createAIntImage(int size, int color) {
        int[] aint = new int[size * 3];
        Arrays.fill(aint, 0, size, color);
        Arrays.fill(aint, size, size * 2, -8421377);
        Arrays.fill(aint, size * 2, size * 3, 0);
        return aint;
    }

    public static MultiTexID getMultiTexID(cdd tex) {
        MultiTexID multitexid = tex.multiTex;
        if (multitexid == null) {
            int i2 = tex.b();
            multitexid = multiTexMap.get(i2);
            if (multitexid == null) {
                multitexid = new MultiTexID(i2, GL11.glGenTextures(), GL11.glGenTextures());
                multiTexMap.put(i2, multitexid);
            }
            tex.multiTex = multitexid;
        }
        return multitexid;
    }

    public static void deleteTextures(cdd atex, int texid) {
        MultiTexID multitexid = atex.multiTex;
        if (multitexid != null) {
            atex.multiTex = null;
            multiTexMap.remove(multitexid.base);
            buq.h(multitexid.norm);
            buq.h(multitexid.spec);
            if (multitexid.base != texid) {
                SMCLog.warning("Error : MultiTexID.base mismatch: " + multitexid.base + ", texid: " + texid);
                buq.h(multitexid.base);
            }
        }
    }

    public static void bindNSTextures(int normTex, int specTex) {
        if (Shaders.isRenderingWorld && buq.getActiveTextureUnit() == 33984) {
            buq.g(33986);
            buq.i(normTex);
            buq.g(33987);
            buq.i(specTex);
            buq.g(33984);
        }
    }

    public static void bindNSTextures(MultiTexID multiTex) {
        ShadersTex.bindNSTextures(multiTex.norm, multiTex.spec);
    }

    public static void bindTextures(int baseTex, int normTex, int specTex) {
        if (Shaders.isRenderingWorld && buq.getActiveTextureUnit() == 33984) {
            buq.g(33986);
            buq.i(normTex);
            buq.g(33987);
            buq.i(specTex);
            buq.g(33984);
        }
        buq.i(baseTex);
    }

    public static void bindTextures(MultiTexID multiTex) {
        boundTex = multiTex;
        if (Shaders.isRenderingWorld && buq.getActiveTextureUnit() == 33984) {
            if (Shaders.configNormalMap) {
                buq.g(33986);
                buq.i(multiTex.norm);
            }
            if (Shaders.configSpecularMap) {
                buq.g(33987);
                buq.i(multiTex.spec);
            }
            buq.g(33984);
        }
        buq.i(multiTex.base);
    }

    public static void bindTexture(cdq tex) {
        int i2 = tex.b();
        if (tex instanceof cdn) {
            Shaders.atlasSizeX = ((cdn)tex).atlasWidth;
            Shaders.atlasSizeY = ((cdn)tex).atlasHeight;
            ShadersTex.bindTextures(tex.getMultiTexID());
        } else {
            Shaders.atlasSizeX = 0;
            Shaders.atlasSizeY = 0;
            ShadersTex.bindTextures(tex.getMultiTexID());
        }
    }

    public static void bindTextureMapForUpdateAndRender(cdp tm2, nd resLoc) {
        cdn texturemap = (cdn)tm2.b(resLoc);
        Shaders.atlasSizeX = texturemap.atlasWidth;
        Shaders.atlasSizeY = texturemap.atlasHeight;
        updatingTex = texturemap.getMultiTexID();
        ShadersTex.bindTextures(updatingTex);
    }

    public static void bindTextures(int baseTex) {
        MultiTexID multitexid = multiTexMap.get(baseTex);
        ShadersTex.bindTextures(multitexid);
    }

    public static void initDynamicTexture(int texID, int width, int height, cde tex) {
        MultiTexID multitexid = tex.getMultiTexID();
        int[] aint = tex.e();
        int i2 = width * height;
        Arrays.fill(aint, i2, i2 * 2, -8421377);
        Arrays.fill(aint, i2 * 2, i2 * 3, 0);
        cdr.a(multitexid.base, width, height);
        cdr.a(false, false);
        cdr.a(false);
        cdr.a(multitexid.norm, width, height);
        cdr.a(false, false);
        cdr.a(false);
        cdr.a(multitexid.spec, width, height);
        cdr.a(false, false);
        cdr.a(false);
        buq.i(multitexid.base);
    }

    public static void updateDynamicTexture(int texID, int[] src, int width, int height, cde tex) {
        MultiTexID multitexid = tex.getMultiTexID();
        buq.i(multitexid.base);
        ShadersTex.updateDynTexSubImage1(src, width, height, 0, 0, 0);
        buq.i(multitexid.norm);
        ShadersTex.updateDynTexSubImage1(src, width, height, 0, 0, 1);
        buq.i(multitexid.spec);
        ShadersTex.updateDynTexSubImage1(src, width, height, 0, 0, 2);
        buq.i(multitexid.base);
    }

    public static void updateDynTexSubImage1(int[] src, int width, int height, int posX, int posY, int page) {
        int i2 = width * height;
        IntBuffer intbuffer = ShadersTex.getIntBuffer(i2);
        intbuffer.clear();
        int j2 = page * i2;
        if (src.length >= j2 + i2) {
            intbuffer.put(src, j2, i2).position(0).limit(i2);
            GL11.glTexSubImage2D((int)3553, (int)0, (int)posX, (int)posY, (int)width, (int)height, (int)32993, (int)33639, (IntBuffer)intbuffer);
            intbuffer.clear();
        }
    }

    public static cdq createDefaultTexture() {
        cde dynamictexture = new cde(1, 1);
        dynamictexture.e()[0] = -1;
        dynamictexture.d();
        return dynamictexture;
    }

    public static void allocateTextureMap(int texID, int mipmapLevels, int width, int height, cdl stitcher, cdn tex) {
        MultiTexID multitexid;
        SMCLog.info("allocateTextureMap " + mipmapLevels + " " + width + " " + height + " ");
        updatingTextureMap = tex;
        tex.atlasWidth = width;
        tex.atlasHeight = height;
        updatingTex = multitexid = ShadersTex.getMultiTexID(tex);
        cdr.a(multitexid.base, mipmapLevels, width, height);
        if (Shaders.configNormalMap) {
            cdr.a(multitexid.norm, mipmapLevels, width, height);
        }
        if (Shaders.configSpecularMap) {
            cdr.a(multitexid.spec, mipmapLevels, width, height);
        }
        buq.i(texID);
    }

    public static cdo setSprite(cdo tas) {
        updatingSprite = tas;
        return tas;
    }

    public static String setIconName(String name) {
        iconName = name;
        return name;
    }

    public static void uploadTexSubForLoadAtlas(int[][] data, int width, int height, int xoffset, int yoffset, boolean linear, boolean clamp) {
        cdr.a(data, width, height, xoffset, yoffset, linear, clamp);
        boolean flag = false;
        if (Shaders.configNormalMap) {
            int[][] aint = ShadersTex.readImageAndMipmaps(iconName + "_n", width, height, data.length, flag, -8421377);
            buq.i(ShadersTex.updatingTex.norm);
            cdr.a(aint, width, height, xoffset, yoffset, linear, clamp);
        }
        if (Shaders.configSpecularMap) {
            int[][] aint1 = ShadersTex.readImageAndMipmaps(iconName + "_s", width, height, data.length, flag, 0);
            buq.i(ShadersTex.updatingTex.spec);
            cdr.a(aint1, width, height, xoffset, yoffset, linear, clamp);
        }
        buq.i(ShadersTex.updatingTex.base);
    }

    public static int[][] readImageAndMipmaps(String name, int width, int height, int numLevels, boolean border, int defColor) {
        Object aint = new int[numLevels][];
        int[] aint1 = new int[width * height];
        aint[0] = aint1;
        boolean flag = false;
        BufferedImage bufferedimage = ShadersTex.readImage(updatingTextureMap.completeResourceLocation(new nd(name)));
        if (bufferedimage != null) {
            int i2 = bufferedimage.getWidth();
            int j2 = bufferedimage.getHeight();
            if (i2 + (border ? 16 : 0) == width) {
                flag = true;
                bufferedimage.getRGB(0, 0, i2, i2, aint1, 0, i2);
            }
        }
        if (!flag) {
            Arrays.fill(aint1, defColor);
        }
        buq.i(ShadersTex.updatingTex.spec);
        aint = ShadersTex.genMipmapsSimple(((int[][])aint).length - 1, width, aint);
        return aint;
    }

    public static BufferedImage readImage(nd resLoc) {
        try {
            if (!Config.hasResource(resLoc)) {
                return null;
            }
            InputStream inputstream = Config.getResourceStream(resLoc);
            if (inputstream == null) {
                return null;
            }
            BufferedImage bufferedimage = ImageIO.read(inputstream);
            inputstream.close();
            return bufferedimage;
        }
        catch (IOException var3) {
            return null;
        }
    }

    public static int[][] genMipmapsSimple(int maxLevel, int width, int[][] data) {
        for (int i2 = 1; i2 <= maxLevel; ++i2) {
            if (data[i2] != null) continue;
            int j2 = width >> i2;
            int k2 = j2 * 2;
            int[] aint = data[i2 - 1];
            data[i2] = new int[j2 * j2];
            int[] aint1 = data[i2];
            for (int i1 = 0; i1 < j2; ++i1) {
                for (int l2 = 0; l2 < j2; ++l2) {
                    int j1 = i1 * 2 * k2 + l2 * 2;
                    aint1[i1 * j2 + l2] = ShadersTex.blend4Simple(aint[j1], aint[j1 + 1], aint[j1 + k2], aint[j1 + k2 + 1]);
                }
            }
        }
        return data;
    }

    public static void uploadTexSub(int[][] data, int width, int height, int xoffset, int yoffset, boolean linear, boolean clamp) {
        cdr.a(data, width, height, xoffset, yoffset, linear, clamp);
        if (Shaders.configNormalMap || Shaders.configSpecularMap) {
            if (Shaders.configNormalMap) {
                buq.i(ShadersTex.updatingTex.norm);
                ShadersTex.uploadTexSub1(data, width, height, xoffset, yoffset, 1);
            }
            if (Shaders.configSpecularMap) {
                buq.i(ShadersTex.updatingTex.spec);
                ShadersTex.uploadTexSub1(data, width, height, xoffset, yoffset, 2);
            }
            buq.i(ShadersTex.updatingTex.base);
        }
    }

    public static void uploadTexSub1(int[][] src, int width, int height, int posX, int posY, int page) {
        int i2 = width * height;
        IntBuffer intbuffer = ShadersTex.getIntBuffer(i2);
        int j2 = src.length;
        int k2 = 0;
        int l2 = width;
        int i1 = height;
        int j1 = posX;
        int k1 = posY;
        while (l2 > 0 && i1 > 0 && k2 < j2) {
            int l1 = l2 * i1;
            int[] aint = src[k2];
            intbuffer.clear();
            if (aint.length >= l1 * (page + 1)) {
                intbuffer.put(aint, l1 * page, l1).position(0).limit(l1);
                GL11.glTexSubImage2D((int)3553, (int)k2, (int)j1, (int)k1, (int)l2, (int)i1, (int)32993, (int)33639, (IntBuffer)intbuffer);
            }
            l2 >>= 1;
            i1 >>= 1;
            j1 >>= 1;
            k1 >>= 1;
            ++k2;
        }
        intbuffer.clear();
    }

    public static int blend4Alpha(int c0, int c1, int c2, int c3) {
        int k1;
        int i2 = c0 >>> 24 & 0xFF;
        int j2 = c1 >>> 24 & 0xFF;
        int k2 = c2 >>> 24 & 0xFF;
        int l2 = c3 >>> 24 & 0xFF;
        int i1 = i2 + j2 + k2 + l2;
        int j1 = (i1 + 2) / 4;
        if (i1 != 0) {
            k1 = i1;
        } else {
            k1 = 4;
            i2 = 1;
            j2 = 1;
            k2 = 1;
            l2 = 1;
        }
        int l1 = (k1 + 1) / 2;
        int i22 = j1 << 24 | ((c0 >>> 16 & 0xFF) * i2 + (c1 >>> 16 & 0xFF) * j2 + (c2 >>> 16 & 0xFF) * k2 + (c3 >>> 16 & 0xFF) * l2 + l1) / k1 << 16 | ((c0 >>> 8 & 0xFF) * i2 + (c1 >>> 8 & 0xFF) * j2 + (c2 >>> 8 & 0xFF) * k2 + (c3 >>> 8 & 0xFF) * l2 + l1) / k1 << 8 | ((c0 >>> 0 & 0xFF) * i2 + (c1 >>> 0 & 0xFF) * j2 + (c2 >>> 0 & 0xFF) * k2 + (c3 >>> 0 & 0xFF) * l2 + l1) / k1 << 0;
        return i22;
    }

    public static int blend4Simple(int c0, int c1, int c2, int c3) {
        int i2 = ((c0 >>> 24 & 0xFF) + (c1 >>> 24 & 0xFF) + (c2 >>> 24 & 0xFF) + (c3 >>> 24 & 0xFF) + 2) / 4 << 24 | ((c0 >>> 16 & 0xFF) + (c1 >>> 16 & 0xFF) + (c2 >>> 16 & 0xFF) + (c3 >>> 16 & 0xFF) + 2) / 4 << 16 | ((c0 >>> 8 & 0xFF) + (c1 >>> 8 & 0xFF) + (c2 >>> 8 & 0xFF) + (c3 >>> 8 & 0xFF) + 2) / 4 << 8 | ((c0 >>> 0 & 0xFF) + (c1 >>> 0 & 0xFF) + (c2 >>> 0 & 0xFF) + (c3 >>> 0 & 0xFF) + 2) / 4 << 0;
        return i2;
    }

    public static void genMipmapAlpha(int[] aint, int offset, int width, int height) {
        Math.min(width, height);
        int o2 = offset;
        int w2 = width;
        int h2 = height;
        int o1 = 0;
        int w1 = 0;
        int h1 = 0;
        int i2 = 0;
        while (w2 > 1 && h2 > 1) {
            o1 = o2 + w2 * h2;
            w1 = w2 / 2;
            h1 = h2 / 2;
            for (int l1 = 0; l1 < h1; ++l1) {
                int i22 = o1 + l1 * w1;
                int j2 = o2 + l1 * 2 * w2;
                for (int k2 = 0; k2 < w1; ++k2) {
                    aint[i22 + k2] = ShadersTex.blend4Alpha(aint[j2 + k2 * 2], aint[j2 + k2 * 2 + 1], aint[j2 + w2 + k2 * 2], aint[j2 + w2 + k2 * 2 + 1]);
                }
            }
            ++i2;
            w2 = w1;
            h2 = h1;
            o2 = o1;
        }
        while (i2 > 0) {
            w2 = width >> --i2;
            h2 = height >> i2;
            int l2 = o2 = o1 - w2 * h2;
            for (int i3 = 0; i3 < h2; ++i3) {
                for (int j3 = 0; j3 < w2; ++j3) {
                    if (aint[l2] == 0) {
                        aint[l2] = aint[o1 + i3 / 2 * w1 + j3 / 2] & 0xFFFFFF;
                    }
                    ++l2;
                }
            }
            o1 = o2;
            w1 = w2;
        }
    }

    public static void genMipmapSimple(int[] aint, int offset, int width, int height) {
        Math.min(width, height);
        int o2 = offset;
        int w2 = width;
        int h2 = height;
        int o1 = 0;
        int w1 = 0;
        int h1 = 0;
        int i2 = 0;
        while (w2 > 1 && h2 > 1) {
            o1 = o2 + w2 * h2;
            w1 = w2 / 2;
            h1 = h2 / 2;
            for (int l1 = 0; l1 < h1; ++l1) {
                int i22 = o1 + l1 * w1;
                int j2 = o2 + l1 * 2 * w2;
                for (int k2 = 0; k2 < w1; ++k2) {
                    aint[i22 + k2] = ShadersTex.blend4Simple(aint[j2 + k2 * 2], aint[j2 + k2 * 2 + 1], aint[j2 + w2 + k2 * 2], aint[j2 + w2 + k2 * 2 + 1]);
                }
            }
            ++i2;
            w2 = w1;
            h2 = h1;
            o2 = o1;
        }
        while (i2 > 0) {
            w2 = width >> --i2;
            h2 = height >> i2;
            int l2 = o2 = o1 - w2 * h2;
            for (int i3 = 0; i3 < h2; ++i3) {
                for (int j3 = 0; j3 < w2; ++j3) {
                    if (aint[l2] == 0) {
                        aint[l2] = aint[o1 + i3 / 2 * w1 + j3 / 2] & 0xFFFFFF;
                    }
                    ++l2;
                }
            }
            o1 = o2;
            w1 = w2;
        }
    }

    public static boolean isSemiTransparent(int[] aint, int width, int height) {
        int i2 = width * height;
        if (aint[0] >>> 24 == 255 && aint[i2 - 1] == 0) {
            return true;
        }
        for (int j2 = 0; j2 < i2; ++j2) {
            int k2 = aint[j2] >>> 24;
            if (k2 == 0 || k2 == 255) continue;
            return true;
        }
        return false;
    }

    public static void updateSubTex1(int[] src, int width, int height, int posX, int posY) {
        int i2 = 0;
        int j2 = width;
        int k2 = height;
        int l2 = posX;
        int i1 = posY;
        while (j2 > 0 && k2 > 0) {
            GL11.glCopyTexSubImage2D((int)3553, (int)i2, (int)l2, (int)i1, (int)0, (int)0, (int)j2, (int)k2);
            ++i2;
            j2 /= 2;
            k2 /= 2;
            l2 /= 2;
            i1 /= 2;
        }
    }

    public static void setupTexture(MultiTexID multiTex, int[] src, int width, int height, boolean linear, boolean clamp) {
        int i2 = linear ? 9729 : 9728;
        int j2 = clamp ? 10496 : 10497;
        int k2 = width * height;
        IntBuffer intbuffer = ShadersTex.getIntBuffer(k2);
        intbuffer.clear();
        intbuffer.put(src, 0, k2).position(0).limit(k2);
        buq.i(multiTex.base);
        GL11.glTexImage2D((int)3553, (int)0, (int)6408, (int)width, (int)height, (int)0, (int)32993, (int)33639, (IntBuffer)intbuffer);
        GL11.glTexParameteri((int)3553, (int)10241, (int)i2);
        GL11.glTexParameteri((int)3553, (int)10240, (int)i2);
        GL11.glTexParameteri((int)3553, (int)10242, (int)j2);
        GL11.glTexParameteri((int)3553, (int)10243, (int)j2);
        intbuffer.put(src, k2, k2).position(0).limit(k2);
        buq.i(multiTex.norm);
        GL11.glTexImage2D((int)3553, (int)0, (int)6408, (int)width, (int)height, (int)0, (int)32993, (int)33639, (IntBuffer)intbuffer);
        GL11.glTexParameteri((int)3553, (int)10241, (int)i2);
        GL11.glTexParameteri((int)3553, (int)10240, (int)i2);
        GL11.glTexParameteri((int)3553, (int)10242, (int)j2);
        GL11.glTexParameteri((int)3553, (int)10243, (int)j2);
        intbuffer.put(src, k2 * 2, k2).position(0).limit(k2);
        buq.i(multiTex.spec);
        GL11.glTexImage2D((int)3553, (int)0, (int)6408, (int)width, (int)height, (int)0, (int)32993, (int)33639, (IntBuffer)intbuffer);
        GL11.glTexParameteri((int)3553, (int)10241, (int)i2);
        GL11.glTexParameteri((int)3553, (int)10240, (int)i2);
        GL11.glTexParameteri((int)3553, (int)10242, (int)j2);
        GL11.glTexParameteri((int)3553, (int)10243, (int)j2);
        buq.i(multiTex.base);
    }

    public static void updateSubImage(MultiTexID multiTex, int[] src, int width, int height, int posX, int posY, boolean linear, boolean clamp) {
        int i2 = width * height;
        IntBuffer intbuffer = ShadersTex.getIntBuffer(i2);
        intbuffer.clear();
        intbuffer.put(src, 0, i2);
        intbuffer.position(0).limit(i2);
        buq.i(multiTex.base);
        GL11.glTexParameteri((int)3553, (int)10241, (int)9728);
        GL11.glTexParameteri((int)3553, (int)10240, (int)9728);
        GL11.glTexParameteri((int)3553, (int)10242, (int)10497);
        GL11.glTexParameteri((int)3553, (int)10243, (int)10497);
        GL11.glTexSubImage2D((int)3553, (int)0, (int)posX, (int)posY, (int)width, (int)height, (int)32993, (int)33639, (IntBuffer)intbuffer);
        if (src.length == i2 * 3) {
            intbuffer.clear();
            intbuffer.put(src, i2, i2).position(0);
            intbuffer.position(0).limit(i2);
        }
        buq.i(multiTex.norm);
        GL11.glTexParameteri((int)3553, (int)10241, (int)9728);
        GL11.glTexParameteri((int)3553, (int)10240, (int)9728);
        GL11.glTexParameteri((int)3553, (int)10242, (int)10497);
        GL11.glTexParameteri((int)3553, (int)10243, (int)10497);
        GL11.glTexSubImage2D((int)3553, (int)0, (int)posX, (int)posY, (int)width, (int)height, (int)32993, (int)33639, (IntBuffer)intbuffer);
        if (src.length == i2 * 3) {
            intbuffer.clear();
            intbuffer.put(src, i2 * 2, i2);
            intbuffer.position(0).limit(i2);
        }
        buq.i(multiTex.spec);
        GL11.glTexParameteri((int)3553, (int)10241, (int)9728);
        GL11.glTexParameteri((int)3553, (int)10240, (int)9728);
        GL11.glTexParameteri((int)3553, (int)10242, (int)10497);
        GL11.glTexParameteri((int)3553, (int)10243, (int)10497);
        GL11.glTexSubImage2D((int)3553, (int)0, (int)posX, (int)posY, (int)width, (int)height, (int)32993, (int)33639, (IntBuffer)intbuffer);
        buq.g(33984);
    }

    public static nd getNSMapLocation(nd location, String mapName) {
        String s2 = location.a();
        String[] astring = s2.split(".png");
        String s1 = astring[0];
        return new nd(location.b(), s1 + "_" + mapName + ".png");
    }

    public static void loadNSMap(cen manager, nd location, int width, int height, int[] aint) {
        if (Shaders.configNormalMap) {
            ShadersTex.loadNSMap1(manager, ShadersTex.getNSMapLocation(location, "n"), width, height, aint, width * height, -8421377);
        }
        if (Shaders.configSpecularMap) {
            ShadersTex.loadNSMap1(manager, ShadersTex.getNSMapLocation(location, "s"), width, height, aint, width * height * 2, 0);
        }
    }

    public static void loadNSMap1(cen manager, nd location, int width, int height, int[] aint, int offset, int defaultColor) {
        boolean flag = false;
        try {
            cem iresource = manager.a(location);
            BufferedImage bufferedimage = ImageIO.read(iresource.b());
            if (bufferedimage != null && bufferedimage.getWidth() == width && bufferedimage.getHeight() == height) {
                bufferedimage.getRGB(0, 0, width, height, aint, offset, width);
                flag = true;
            }
        }
        catch (IOException iOException) {
            // empty catch block
        }
        if (!flag) {
            Arrays.fill(aint, offset, offset + width * height, defaultColor);
        }
    }

    public static int loadSimpleTexture(int textureID, BufferedImage bufferedimage, boolean linear, boolean clamp, cen resourceManager, nd location, MultiTexID multiTex) {
        int i2 = bufferedimage.getWidth();
        int j2 = bufferedimage.getHeight();
        int k2 = i2 * j2;
        int[] aint = ShadersTex.getIntArray(k2 * 3);
        bufferedimage.getRGB(0, 0, i2, j2, aint, 0, i2);
        ShadersTex.loadNSMap(resourceManager, location, i2, j2, aint);
        ShadersTex.setupTexture(multiTex, aint, i2, j2, linear, clamp);
        return textureID;
    }

    public static void mergeImage(int[] aint, int dstoff, int srcoff, int size) {
    }

    public static int blendColor(int color1, int color2, int factor1) {
        int i2 = 255 - factor1;
        return ((color1 >>> 24 & 0xFF) * factor1 + (color2 >>> 24 & 0xFF) * i2) / 255 << 24 | ((color1 >>> 16 & 0xFF) * factor1 + (color2 >>> 16 & 0xFF) * i2) / 255 << 16 | ((color1 >>> 8 & 0xFF) * factor1 + (color2 >>> 8 & 0xFF) * i2) / 255 << 8 | ((color1 >>> 0 & 0xFF) * factor1 + (color2 >>> 0 & 0xFF) * i2) / 255 << 0;
    }

    public static void loadLayeredTexture(cdi tex, cen manager, List list) {
        int i2 = 0;
        int j2 = 0;
        int k2 = 0;
        int[] aint = null;
        for (Object s2 : list) {
            if (s2 == null) continue;
            try {
                nd resourcelocation = new nd((String)s2);
                InputStream inputstream = manager.a(resourcelocation).b();
                BufferedImage bufferedimage = ImageIO.read(inputstream);
                if (k2 == 0) {
                    i2 = bufferedimage.getWidth();
                    j2 = bufferedimage.getHeight();
                    k2 = i2 * j2;
                    aint = ShadersTex.createAIntImage(k2, 0);
                }
                int[] aint1 = ShadersTex.getIntArray(k2 * 3);
                bufferedimage.getRGB(0, 0, i2, j2, aint1, 0, i2);
                ShadersTex.loadNSMap(manager, resourcelocation, i2, j2, aint1);
                for (int l2 = 0; l2 < k2; ++l2) {
                    int i1 = aint1[l2] >>> 24 & 0xFF;
                    aint[k2 * 0 + l2] = ShadersTex.blendColor(aint1[k2 * 0 + l2], aint[k2 * 0 + l2], i1);
                    aint[k2 * 1 + l2] = ShadersTex.blendColor(aint1[k2 * 1 + l2], aint[k2 * 1 + l2], i1);
                    aint[k2 * 2 + l2] = ShadersTex.blendColor(aint1[k2 * 2 + l2], aint[k2 * 2 + l2], i1);
                }
            }
            catch (IOException ioexception) {
                ioexception.printStackTrace();
            }
        }
        ShadersTex.setupTexture(tex.getMultiTexID(), aint, i2, j2, false, false);
    }

    static void updateTextureMinMagFilter() {
        cdp texturemanager = bhz.z().N();
        cdq itextureobject = texturemanager.b(cdn.g);
        if (itextureobject != null) {
            MultiTexID multitexid = itextureobject.getMultiTexID();
            buq.i(multitexid.base);
            GL11.glTexParameteri((int)3553, (int)10241, (int)Shaders.texMinFilValue[Shaders.configTexMinFilB]);
            GL11.glTexParameteri((int)3553, (int)10240, (int)Shaders.texMagFilValue[Shaders.configTexMagFilB]);
            buq.i(multitexid.norm);
            GL11.glTexParameteri((int)3553, (int)10241, (int)Shaders.texMinFilValue[Shaders.configTexMinFilN]);
            GL11.glTexParameteri((int)3553, (int)10240, (int)Shaders.texMagFilValue[Shaders.configTexMagFilN]);
            buq.i(multitexid.spec);
            GL11.glTexParameteri((int)3553, (int)10241, (int)Shaders.texMinFilValue[Shaders.configTexMinFilS]);
            GL11.glTexParameteri((int)3553, (int)10240, (int)Shaders.texMagFilValue[Shaders.configTexMagFilS]);
            buq.i(0);
        }
    }

    public static cem loadResource(cen manager, nd location) throws IOException {
        resManager = manager;
        resLocation = location;
        return manager.a(location);
    }

    public static int[] loadAtlasSprite(BufferedImage bufferedimage, int startX, int startY, int w2, int h2, int[] aint, int offset, int scansize) {
        imageSize = w2 * h2;
        bufferedimage.getRGB(startX, startY, w2, h2, aint, offset, scansize);
        ShadersTex.loadNSMap(resManager, resLocation, w2, h2, aint);
        return aint;
    }

    public static int[][] getFrameTexData(int[][] src, int width, int height, int frameIndex) {
        int i2 = src.length;
        int[][] aint = new int[i2][];
        for (int j2 = 0; j2 < i2; ++j2) {
            int[] aint1 = src[j2];
            if (aint1 == null) continue;
            int k2 = (width >> j2) * (height >> j2);
            int[] aint2 = new int[k2 * 3];
            aint[j2] = aint2;
            int l2 = aint1.length / 3;
            int i1 = k2 * frameIndex;
            int j1 = 0;
            System.arraycopy(aint1, i1, aint2, j1, k2);
            System.arraycopy(aint1, i1 += l2, aint2, j1 += k2, k2);
            System.arraycopy(aint1, i1 += l2, aint2, j1 += k2, k2);
        }
        return aint;
    }

    public static int[][] prepareAF(cdo tas, int[][] src, int width, int height) {
        boolean flag = true;
        return src;
    }

    public static void fixTransparentColor(cdo tas, int[] aint) {
    }
}

