/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.lwjgl.BufferUtils
 *  org.lwjgl.opengl.GL11
 */
package shadersmod.client;

import java.nio.ByteBuffer;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import shadersmod.client.ICustomTexture;

public class HFNoiseTexture
implements ICustomTexture {
    private int texID = GL11.glGenTextures();
    private int textureUnit = 15;

    public HFNoiseTexture(int width, int height) {
        byte[] abyte = this.genHFNoiseImage(width, height);
        ByteBuffer bytebuffer = BufferUtils.createByteBuffer((int)abyte.length);
        bytebuffer.put(abyte);
        bytebuffer.flip();
        buq.i(this.texID);
        GL11.glTexImage2D((int)3553, (int)0, (int)6407, (int)width, (int)height, (int)0, (int)6407, (int)5121, (ByteBuffer)bytebuffer);
        GL11.glTexParameteri((int)3553, (int)10242, (int)10497);
        GL11.glTexParameteri((int)3553, (int)10243, (int)10497);
        GL11.glTexParameteri((int)3553, (int)10240, (int)9729);
        GL11.glTexParameteri((int)3553, (int)10241, (int)9729);
        buq.i(0);
    }

    public int getID() {
        return this.texID;
    }

    @Override
    public void deleteTexture() {
        buq.h(this.texID);
        this.texID = 0;
    }

    private int random(int seed) {
        seed ^= seed << 13;
        seed ^= seed >> 17;
        seed ^= seed << 5;
        return seed;
    }

    private byte random(int x2, int y2, int z2) {
        int i2 = (this.random(x2) + this.random(y2 * 19)) * this.random(z2 * 23) - z2;
        return (byte)(this.random(i2) % 128);
    }

    private byte[] genHFNoiseImage(int width, int height) {
        byte[] abyte = new byte[width * height * 3];
        int i2 = 0;
        for (int j2 = 0; j2 < height; ++j2) {
            for (int k2 = 0; k2 < width; ++k2) {
                for (int l2 = 1; l2 < 4; ++l2) {
                    abyte[i2++] = this.random(k2, j2, l2);
                }
            }
        }
        return abyte;
    }

    @Override
    public int getTextureId() {
        return this.texID;
    }

    @Override
    public int getTextureUnit() {
        return this.textureUnit;
    }
}

