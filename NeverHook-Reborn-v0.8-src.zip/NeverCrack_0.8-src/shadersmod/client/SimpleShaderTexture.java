/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParser
 *  org.apache.commons.io.IOUtils
 */
package shadersmod.client;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import org.apache.commons.io.IOUtils;
import shadersmod.client.Shaders;
import shadersmod.common.SMCLog;

public class SimpleShaderTexture
extends cdd {
    private String texturePath;
    private static final cfe METADATA_SERIALIZER = SimpleShaderTexture.makeMetadataSerializer();

    public SimpleShaderTexture(String texturePath) {
        this.texturePath = texturePath;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void a(cen resourceManager) throws IOException {
        this.c();
        InputStream inputstream = Shaders.getShaderPackResourceStream(this.texturePath);
        if (inputstream == null) {
            throw new FileNotFoundException("Shader texture not found: " + this.texturePath);
        }
        try {
            BufferedImage bufferedimage = cdr.a(inputstream);
            cft texturemetadatasection = this.loadTextureMetadataSection();
            cdr.a(this.b(), bufferedimage, texturemetadatasection.a(), texturemetadatasection.b());
        }
        finally {
            IOUtils.closeQuietly((InputStream)inputstream);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private cft loadTextureMetadataSection() {
        String s2 = this.texturePath + ".mcmeta";
        String s1 = "texture";
        InputStream inputstream = Shaders.getShaderPackResourceStream(s2);
        if (inputstream != null) {
            cft texturemetadatasection1;
            cfe metadataserializer = METADATA_SERIALIZER;
            BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(inputstream));
            try {
                JsonObject jsonobject = new JsonParser().parse((Reader)bufferedreader).getAsJsonObject();
                cft texturemetadatasection = (cft)metadataserializer.a(s1, jsonobject);
                if (texturemetadatasection == null) {
                    cft cft2 = new cft(false, false);
                    return cft2;
                }
                texturemetadatasection1 = texturemetadatasection;
            }
            catch (RuntimeException runtimeexception) {
                SMCLog.warning("Error reading metadata: " + s2);
                SMCLog.warning("" + runtimeexception.getClass().getName() + ": " + runtimeexception.getMessage());
                cft cft3 = new cft(false, false);
                return cft3;
            }
            finally {
                IOUtils.closeQuietly((Reader)bufferedreader);
                IOUtils.closeQuietly((InputStream)inputstream);
            }
            return texturemetadatasection1;
        }
        return new cft(false, false);
    }

    private static cfe makeMetadataSerializer() {
        cfe metadataserializer = new cfe();
        metadataserializer.a(new cfu(), cft.class);
        metadataserializer.a(new cfk(), cfj.class);
        metadataserializer.a(new cfh(), cfg.class);
        metadataserializer.a(new cfq(), cfp.class);
        metadataserializer.a(new cfn(), cfm.class);
        return metadataserializer;
    }
}

