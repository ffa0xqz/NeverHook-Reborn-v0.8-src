/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.EXTFramebufferObject
 *  org.lwjgl.opengl.GL11
 *  org.lwjgl.opengl.GL20
 *  org.lwjgl.opengl.GL30
 */
package shadersmod.client;

import java.nio.IntBuffer;
import optifine.Config;
import optifine.Reflector;
import org.lwjgl.opengl.EXTFramebufferObject;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import shadersmod.client.ClippingHelperShadow;
import shadersmod.client.Shaders;

public class ShadersRender {
    private static final nd END_PORTAL_TEXTURE = new nd("textures/entity/end_portal.png");

    public static void setFrustrumPosition(bxw frustum, double x2, double y2, double z2) {
        frustum.a(x2, y2, z2);
    }

    public static void setupTerrain(buw renderGlobal, ve viewEntity, double partialTicks, bxw camera, int frameCount, boolean playerSpectator) {
        renderGlobal.a(viewEntity, partialTicks, camera, frameCount, playerSpectator);
    }

    public static void beginTerrainSolid() {
        if (Shaders.isRenderingWorld) {
            Shaders.fogEnabled = true;
            Shaders.useProgram(7);
        }
    }

    public static void beginTerrainCutoutMipped() {
        if (Shaders.isRenderingWorld) {
            Shaders.useProgram(7);
        }
    }

    public static void beginTerrainCutout() {
        if (Shaders.isRenderingWorld) {
            Shaders.useProgram(7);
        }
    }

    public static void endTerrain() {
        if (Shaders.isRenderingWorld) {
            Shaders.useProgram(3);
        }
    }

    public static void beginTranslucent() {
        if (Shaders.isRenderingWorld) {
            if (Shaders.usedDepthBuffers >= 2) {
                buq.g(33995);
                Shaders.checkGLError("pre copy depth");
                GL11.glCopyTexSubImage2D((int)3553, (int)0, (int)0, (int)0, (int)0, (int)0, (int)Shaders.renderWidth, (int)Shaders.renderHeight);
                Shaders.checkGLError("copy depth");
                buq.g(33984);
            }
            Shaders.useProgram(12);
        }
    }

    public static void endTranslucent() {
        if (Shaders.isRenderingWorld) {
            Shaders.useProgram(3);
        }
    }

    public static void renderHand0(buo er, float par1, int par2) {
        if (!Shaders.isShadowPass) {
            boolean flag = Shaders.isItemToRenderMainTranslucent();
            boolean flag1 = Shaders.isItemToRenderOffTranslucent();
            if (!flag || !flag1) {
                Shaders.readCenterDepth();
                Shaders.beginHand();
                GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                Shaders.setSkipRenderHands(flag, flag1);
                er.renderHand(par1, par2, true, false, false);
                Shaders.endHand();
                Shaders.setHandsRendered(!flag, !flag1);
                Shaders.setSkipRenderHands(false, false);
            }
        }
    }

    public static void renderHand1(buo er, float par1, int par2) {
        if (!Shaders.isShadowPass && !Shaders.isBothHandsRendered()) {
            Shaders.readCenterDepth();
            buq.m();
            Shaders.beginHand();
            GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            Shaders.setSkipRenderHands(Shaders.isHandRenderedMain(), Shaders.isHandRenderedOff());
            er.renderHand(par1, par2, true, false, true);
            Shaders.endHand();
            Shaders.setHandsRendered(true, true);
            Shaders.setSkipRenderHands(false, false);
        }
    }

    public static void renderItemFP(bus itemRenderer, float par1, boolean renderTranslucent) {
        Shaders.setRenderingFirstPersonHand(true);
        buq.a(true);
        if (renderTranslucent) {
            buq.c(519);
            GL11.glPushMatrix();
            IntBuffer intbuffer = Shaders.activeDrawBuffers;
            Shaders.setDrawBuffers(Shaders.drawBuffersNone);
            Shaders.renderItemKeepDepthMask = true;
            itemRenderer.a(par1);
            Shaders.renderItemKeepDepthMask = false;
            Shaders.setDrawBuffers(intbuffer);
            GL11.glPopMatrix();
        }
        buq.c(515);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        itemRenderer.a(par1);
        Shaders.setRenderingFirstPersonHand(false);
    }

    public static void renderFPOverlay(buo er, float par1, int par2) {
        if (!Shaders.isShadowPass) {
            Shaders.beginFPOverlay();
            er.renderHand(par1, par2, false, true, false);
            Shaders.endFPOverlay();
        }
    }

    public static void beginBlockDamage() {
        if (Shaders.isRenderingWorld) {
            Shaders.useProgram(11);
            if (Shaders.programsID[11] == Shaders.programsID[7]) {
                Shaders.setDrawBuffers(Shaders.drawBuffersColorAtt0);
                buq.a(false);
            }
        }
    }

    public static void endBlockDamage() {
        if (Shaders.isRenderingWorld) {
            buq.a(true);
            Shaders.useProgram(3);
        }
    }

    public static void renderShadowMap(buo entityRenderer, int pass, float partialTicks, long finishTimeNano) {
        if (Shaders.usedShadowDepthBuffers > 0 && --Shaders.shadowPassCounter <= 0) {
            bhz minecraft = bhz.z();
            minecraft.B.c("shadow pass");
            buw renderglobal = minecraft.g;
            Shaders.isShadowPass = true;
            Shaders.shadowPassCounter = Shaders.shadowPassInterval;
            Shaders.preShadowPassThirdPersonView = minecraft.t.aw;
            minecraft.t.aw = 1;
            Shaders.checkGLError("pre shadow");
            GL11.glMatrixMode((int)5889);
            GL11.glPushMatrix();
            GL11.glMatrixMode((int)5888);
            GL11.glPushMatrix();
            minecraft.B.c("shadow clear");
            EXTFramebufferObject.glBindFramebufferEXT((int)36160, (int)Shaders.sfb);
            Shaders.checkGLError("shadow bind sfb");
            Shaders.useProgram(30);
            minecraft.B.c("shadow camera");
            entityRenderer.a(partialTicks, 2);
            Shaders.setCameraShadow(partialTicks);
            bht.a(minecraft.h, minecraft.t.aw == 2);
            Shaders.checkGLError("shadow camera");
            GL20.glDrawBuffers((IntBuffer)Shaders.sfbDrawBuffers);
            Shaders.checkGLError("shadow drawbuffers");
            GL11.glReadBuffer((int)0);
            Shaders.checkGLError("shadow readbuffer");
            EXTFramebufferObject.glFramebufferTexture2DEXT((int)36160, (int)36096, (int)3553, (int)Shaders.sfbDepthTextures.get(0), (int)0);
            if (Shaders.usedShadowColorBuffers != 0) {
                EXTFramebufferObject.glFramebufferTexture2DEXT((int)36160, (int)36064, (int)3553, (int)Shaders.sfbColorTextures.get(0), (int)0);
            }
            Shaders.checkFramebufferStatus("shadow fb");
            GL11.glClearColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            GL11.glClear((int)(Shaders.usedShadowColorBuffers != 0 ? 16640 : 256));
            Shaders.checkGLError("shadow clear");
            minecraft.B.c("shadow frustum");
            bxz clippinghelper = ClippingHelperShadow.getInstance();
            minecraft.B.c("shadow culling");
            bxy frustum = new bxy(clippinghelper);
            ve entity = minecraft.aa();
            double d0 = entity.M + (entity.p - entity.M) * (double)partialTicks;
            double d1 = entity.N + (entity.q - entity.N) * (double)partialTicks;
            double d2 = entity.O + (entity.r - entity.O) * (double)partialTicks;
            frustum.a(d0, d1, d2);
            buq.j(7425);
            buq.k();
            buq.c(515);
            buq.a(true);
            buq.a(true, true, true, true);
            buq.r();
            minecraft.B.c("shadow prepareterrain");
            minecraft.N().a(cdn.g);
            minecraft.B.c("shadow setupterrain");
            int i2 = 0;
            i2 = entityRenderer.aj;
            entityRenderer.aj = i2 + 1;
            renderglobal.a(entity, partialTicks, frustum, i2, minecraft.h.y());
            minecraft.B.c("shadow updatechunks");
            minecraft.B.c("shadow terrain");
            buq.n(5888);
            buq.G();
            buq.d();
            renderglobal.a(amk.a, (double)partialTicks, 2, entity);
            Shaders.checkGLError("shadow terrain solid");
            buq.e();
            renderglobal.a(amk.b, (double)partialTicks, 2, entity);
            Shaders.checkGLError("shadow terrain cutoutmipped");
            minecraft.N().b(cdn.g).b(false, false);
            renderglobal.a(amk.c, (double)partialTicks, 2, entity);
            Shaders.checkGLError("shadow terrain cutout");
            minecraft.N().b(cdn.g).a();
            buq.j(7424);
            buq.a(516, 0.1f);
            buq.n(5888);
            buq.H();
            buq.G();
            minecraft.B.c("shadow entities");
            if (Reflector.ForgeHooksClient_setRenderPass.exists()) {
                Reflector.callVoid(Reflector.ForgeHooksClient_setRenderPass, 0);
            }
            renderglobal.a(entity, frustum, partialTicks);
            Shaders.checkGLError("shadow entities");
            buq.n(5888);
            buq.H();
            buq.a(true);
            buq.l();
            buq.q();
            buq.a(770, 771, 1, 0);
            buq.a(516, 0.1f);
            if (Shaders.usedShadowDepthBuffers >= 2) {
                buq.g(33989);
                Shaders.checkGLError("pre copy shadow depth");
                GL11.glCopyTexSubImage2D((int)3553, (int)0, (int)0, (int)0, (int)0, (int)0, (int)Shaders.shadowMapWidth, (int)Shaders.shadowMapHeight);
                Shaders.checkGLError("copy shadow depth");
                buq.g(33984);
            }
            buq.l();
            buq.a(true);
            minecraft.N().a(cdn.g);
            buq.j(7425);
            Shaders.checkGLError("shadow pre-translucent");
            GL20.glDrawBuffers((IntBuffer)Shaders.sfbDrawBuffers);
            Shaders.checkGLError("shadow drawbuffers pre-translucent");
            Shaders.checkFramebufferStatus("shadow pre-translucent");
            if (Shaders.isRenderShadowTranslucent()) {
                minecraft.B.c("shadow translucent");
                renderglobal.a(amk.d, (double)partialTicks, 2, entity);
                Shaders.checkGLError("shadow translucent");
            }
            if (Reflector.ForgeHooksClient_setRenderPass.exists()) {
                bhx.b();
                Reflector.call(Reflector.ForgeHooksClient_setRenderPass, 1);
                renderglobal.a(entity, frustum, partialTicks);
                Reflector.call(Reflector.ForgeHooksClient_setRenderPass, -1);
                bhx.a();
                Shaders.checkGLError("shadow entities 1");
            }
            buq.j(7424);
            buq.a(true);
            buq.q();
            buq.l();
            GL11.glFlush();
            Shaders.checkGLError("shadow flush");
            Shaders.isShadowPass = false;
            minecraft.t.aw = Shaders.preShadowPassThirdPersonView;
            minecraft.B.c("shadow postprocess");
            if (Shaders.hasGlGenMipmap) {
                if (Shaders.usedShadowDepthBuffers >= 1) {
                    if (Shaders.shadowMipmapEnabled[0]) {
                        buq.g(33988);
                        buq.i(Shaders.sfbDepthTextures.get(0));
                        GL30.glGenerateMipmap((int)3553);
                        GL11.glTexParameteri((int)3553, (int)10241, (int)(Shaders.shadowFilterNearest[0] ? 9984 : 9987));
                    }
                    if (Shaders.usedShadowDepthBuffers >= 2 && Shaders.shadowMipmapEnabled[1]) {
                        buq.g(33989);
                        buq.i(Shaders.sfbDepthTextures.get(1));
                        GL30.glGenerateMipmap((int)3553);
                        GL11.glTexParameteri((int)3553, (int)10241, (int)(Shaders.shadowFilterNearest[1] ? 9984 : 9987));
                    }
                    buq.g(33984);
                }
                if (Shaders.usedShadowColorBuffers >= 1) {
                    if (Shaders.shadowColorMipmapEnabled[0]) {
                        buq.g(33997);
                        buq.i(Shaders.sfbColorTextures.get(0));
                        GL30.glGenerateMipmap((int)3553);
                        GL11.glTexParameteri((int)3553, (int)10241, (int)(Shaders.shadowColorFilterNearest[0] ? 9984 : 9987));
                    }
                    if (Shaders.usedShadowColorBuffers >= 2 && Shaders.shadowColorMipmapEnabled[1]) {
                        buq.g(33998);
                        buq.i(Shaders.sfbColorTextures.get(1));
                        GL30.glGenerateMipmap((int)3553);
                        GL11.glTexParameteri((int)3553, (int)10241, (int)(Shaders.shadowColorFilterNearest[1] ? 9984 : 9987));
                    }
                    buq.g(33984);
                }
            }
            Shaders.checkGLError("shadow postprocess");
            EXTFramebufferObject.glBindFramebufferEXT((int)36160, (int)Shaders.dfb);
            GL11.glViewport((int)0, (int)0, (int)Shaders.renderWidth, (int)Shaders.renderHeight);
            Shaders.activeDrawBuffers = null;
            minecraft.N().a(cdn.g);
            Shaders.useProgram(7);
            GL11.glMatrixMode((int)5888);
            GL11.glPopMatrix();
            GL11.glMatrixMode((int)5889);
            GL11.glPopMatrix();
            GL11.glMatrixMode((int)5888);
            Shaders.checkGLError("shadow end");
        }
    }

    public static void preRenderChunkLayer(amk blockLayerIn) {
        if (Shaders.isRenderBackFace(blockLayerIn)) {
            buq.r();
        }
        if (cig.f()) {
            GL11.glEnableClientState((int)32885);
            GL20.glEnableVertexAttribArray((int)Shaders.midTexCoordAttrib);
            GL20.glEnableVertexAttribArray((int)Shaders.tangentAttrib);
            GL20.glEnableVertexAttribArray((int)Shaders.entityAttrib);
        }
    }

    public static void postRenderChunkLayer(amk blockLayerIn) {
        if (cig.f()) {
            GL11.glDisableClientState((int)32885);
            GL20.glDisableVertexAttribArray((int)Shaders.midTexCoordAttrib);
            GL20.glDisableVertexAttribArray((int)Shaders.tangentAttrib);
            GL20.glDisableVertexAttribArray((int)Shaders.entityAttrib);
        }
        if (Shaders.isRenderBackFace(blockLayerIn)) {
            buq.q();
        }
    }

    public static void setupArrayPointersVbo() {
        int i2 = 14;
        GL11.glVertexPointer((int)3, (int)5126, (int)56, (long)0L);
        GL11.glColorPointer((int)4, (int)5121, (int)56, (long)12L);
        GL11.glTexCoordPointer((int)2, (int)5126, (int)56, (long)16L);
        cig.l(cig.r);
        GL11.glTexCoordPointer((int)2, (int)5122, (int)56, (long)24L);
        cig.l(cig.q);
        GL11.glNormalPointer((int)5120, (int)56, (long)28L);
        GL20.glVertexAttribPointer((int)Shaders.midTexCoordAttrib, (int)2, (int)5126, (boolean)false, (int)56, (long)32L);
        GL20.glVertexAttribPointer((int)Shaders.tangentAttrib, (int)4, (int)5122, (boolean)false, (int)56, (long)40L);
        GL20.glVertexAttribPointer((int)Shaders.entityAttrib, (int)3, (int)5122, (boolean)false, (int)56, (long)48L);
    }

    public static void beaconBeamBegin() {
        Shaders.useProgram(14);
    }

    public static void beaconBeamStartQuad1() {
    }

    public static void beaconBeamStartQuad2() {
    }

    public static void beaconBeamDraw1() {
    }

    public static void beaconBeamDraw2() {
        buq.l();
    }

    public static void renderEnchantedGlintBegin() {
        Shaders.useProgram(17);
    }

    public static void renderEnchantedGlintEnd() {
        if (Shaders.isRenderingWorld) {
            if (Shaders.isRenderingFirstPersonHand() && Shaders.isRenderBothHands()) {
                Shaders.useProgram(19);
            } else {
                Shaders.useProgram(16);
            }
        } else {
            Shaders.useProgram(0);
        }
    }

    public static boolean renderEndPortal(awe te2, double x2, double y2, double z2, float partialTicks, int destroyStage, float offset) {
        if (!Shaders.isShadowPass && Shaders.programsID[Shaders.activeProgram] == 0) {
            return false;
        }
        buq.g();
        Config.getTextureManager().a(END_PORTAL_TEXTURE);
        bvc tessellator = bvc.a();
        bui bufferbuilder = tessellator.c();
        bufferbuilder.a(7, cdw.a);
        float f2 = 0.5f;
        float f1 = f2 * 0.15f;
        float f22 = f2 * 0.3f;
        float f3 = f2 * 0.4f;
        float f4 = 0.0f;
        float f5 = 0.2f;
        float f6 = (float)(System.currentTimeMillis() % 100000L) / 100000.0f;
        int i2 = 240;
        if (te2.a(fa.d)) {
            bufferbuilder.b(x2, y2, z2 + 1.0).a(f1, f22, f3, 1.0f).a(f4 + f6, f4 + f6).a(i2, i2).d();
            bufferbuilder.b(x2 + 1.0, y2, z2 + 1.0).a(f1, f22, f3, 1.0f).a(f4 + f6, f5 + f6).a(i2, i2).d();
            bufferbuilder.b(x2 + 1.0, y2 + 1.0, z2 + 1.0).a(f1, f22, f3, 1.0f).a(f5 + f6, f5 + f6).a(i2, i2).d();
            bufferbuilder.b(x2, y2 + 1.0, z2 + 1.0).a(f1, f22, f3, 1.0f).a(f5 + f6, f4 + f6).a(i2, i2).d();
        }
        if (te2.a(fa.c)) {
            bufferbuilder.b(x2, y2 + 1.0, z2).a(f1, f22, f3, 1.0f).a(f5 + f6, f5 + f6).a(i2, i2).d();
            bufferbuilder.b(x2 + 1.0, y2 + 1.0, z2).a(f1, f22, f3, 1.0f).a(f5 + f6, f4 + f6).a(i2, i2).d();
            bufferbuilder.b(x2 + 1.0, y2, z2).a(f1, f22, f3, 1.0f).a(f4 + f6, f4 + f6).a(i2, i2).d();
            bufferbuilder.b(x2, y2, z2).a(f1, f22, f3, 1.0f).a(f4 + f6, f5 + f6).a(i2, i2).d();
        }
        if (te2.a(fa.f)) {
            bufferbuilder.b(x2 + 1.0, y2 + 1.0, z2).a(f1, f22, f3, 1.0f).a(f5 + f6, f5 + f6).a(i2, i2).d();
            bufferbuilder.b(x2 + 1.0, y2 + 1.0, z2 + 1.0).a(f1, f22, f3, 1.0f).a(f5 + f6, f4 + f6).a(i2, i2).d();
            bufferbuilder.b(x2 + 1.0, y2, z2 + 1.0).a(f1, f22, f3, 1.0f).a(f4 + f6, f4 + f6).a(i2, i2).d();
            bufferbuilder.b(x2 + 1.0, y2, z2).a(f1, f22, f3, 1.0f).a(f4 + f6, f5 + f6).a(i2, i2).d();
        }
        if (te2.a(fa.e)) {
            bufferbuilder.b(x2, y2, z2).a(f1, f22, f3, 1.0f).a(f4 + f6, f4 + f6).a(i2, i2).d();
            bufferbuilder.b(x2, y2, z2 + 1.0).a(f1, f22, f3, 1.0f).a(f4 + f6, f5 + f6).a(i2, i2).d();
            bufferbuilder.b(x2, y2 + 1.0, z2 + 1.0).a(f1, f22, f3, 1.0f).a(f5 + f6, f5 + f6).a(i2, i2).d();
            bufferbuilder.b(x2, y2 + 1.0, z2).a(f1, f22, f3, 1.0f).a(f5 + f6, f4 + f6).a(i2, i2).d();
        }
        if (te2.a(fa.a)) {
            bufferbuilder.b(x2, y2, z2).a(f1, f22, f3, 1.0f).a(f4 + f6, f4 + f6).a(i2, i2).d();
            bufferbuilder.b(x2 + 1.0, y2, z2).a(f1, f22, f3, 1.0f).a(f4 + f6, f5 + f6).a(i2, i2).d();
            bufferbuilder.b(x2 + 1.0, y2, z2 + 1.0).a(f1, f22, f3, 1.0f).a(f5 + f6, f5 + f6).a(i2, i2).d();
            bufferbuilder.b(x2, y2, z2 + 1.0).a(f1, f22, f3, 1.0f).a(f5 + f6, f4 + f6).a(i2, i2).d();
        }
        if (te2.a(fa.b)) {
            bufferbuilder.b(x2, y2 + (double)offset, z2 + 1.0).a(f1, f22, f3, 1.0f).a(f4 + f6, f4 + f6).a(i2, i2).d();
            bufferbuilder.b(x2 + 1.0, y2 + (double)offset, z2 + 1.0).a(f1, f22, f3, 1.0f).a(f4 + f6, f5 + f6).a(i2, i2).d();
            bufferbuilder.b(x2 + 1.0, y2 + (double)offset, z2).a(f1, f22, f3, 1.0f).a(f5 + f6, f5 + f6).a(i2, i2).d();
            bufferbuilder.b(x2, y2 + (double)offset, z2).a(f1, f22, f3, 1.0f).a(f5 + f6, f4 + f6).a(i2, i2).d();
        }
        tessellator.b();
        buq.f();
        return true;
    }
}

