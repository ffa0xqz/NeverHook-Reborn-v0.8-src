/*
 * Decompiled with CFR 0.150.
 */
package shadersmod.client;

import shadersmod.client.ICustomTexture;

public class CustomTexture
implements ICustomTexture {
    private int textureUnit = -1;
    private String path = null;
    private cdq texture = null;

    public CustomTexture(int textureUnit, String path, cdq texture) {
        this.textureUnit = textureUnit;
        this.path = path;
        this.texture = texture;
    }

    @Override
    public int getTextureUnit() {
        return this.textureUnit;
    }

    public String getPath() {
        return this.path;
    }

    public cdq getTexture() {
        return this.texture;
    }

    @Override
    public int getTextureId() {
        return this.texture.b();
    }

    @Override
    public void deleteTexture() {
        cdr.a(this.texture.b());
    }

    public String toString() {
        return "textureUnit: " + this.textureUnit + ", path: " + this.path + ", glTextureId: " + this.texture.b();
    }
}

