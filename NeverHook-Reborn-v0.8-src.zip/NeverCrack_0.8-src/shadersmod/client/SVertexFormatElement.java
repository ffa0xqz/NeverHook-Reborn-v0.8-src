/*
 * Decompiled with CFR 0.150.
 */
package shadersmod.client;

public class SVertexFormatElement
extends cdz {
    int sUsage;

    public SVertexFormatElement(int sUsage, cdz.a type, int count) {
        super(0, type, cdz.b.g, count);
        this.sUsage = sUsage;
    }
}

