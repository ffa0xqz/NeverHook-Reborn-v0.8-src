/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import io.netty.buffer.Unpooled;
import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

public class dr
extends bi {
    @Override
    public String c() {
        return "stopsound";
    }

    @Override
    public int a() {
        return 2;
    }

    @Override
    public String b(bn bn2) {
        return "commands.stopsound.usage";
    }

    @Override
    public void a(MinecraftServer minecraftServer, bn bn2, String[] arrstring) throws ei {
        if (arrstring.length < 1 || arrstring.length > 3) {
            throw new ep(this.b(bn2), new Object[0]);
        }
        int n2 = 0;
        oo \u26032 = dr.b(minecraftServer, bn2, arrstring[n2++]);
        String \u26033 = "";
        String \u26034 = "";
        if (arrstring.length >= 2) {
            if ((\u2603 = qe.a((String)(\u26035 = arrstring[n2++]))) == null) {
                throw new ei("commands.stopsound.unknownSoundSource", \u26035);
            }
            \u26033 = \u2603.a();
        }
        if (arrstring.length == 3) {
            \u26034 = arrstring[n2++];
        }
        Object \u26035 = new gy(Unpooled.buffer());
        ((gy)\u26035).a(\u26033);
        ((gy)\u26035).a(\u26034);
        \u26032.a.a(new iw("MC|StopSound", (gy)\u26035));
        if (\u26033.isEmpty() && \u26034.isEmpty()) {
            dr.a(bn2, (bk)this, "commands.stopsound.success.all", \u26032.h_());
        } else if (\u26034.isEmpty()) {
            dr.a(bn2, (bk)this, "commands.stopsound.success.soundSource", \u26033, \u26032.h_());
        } else {
            dr.a(bn2, (bk)this, "commands.stopsound.success.individualSound", \u26034, \u26033, \u26032.h_());
        }
    }

    @Override
    public List<String> a(MinecraftServer minecraftServer, bn bn2, String[] arrstring, @Nullable et et2) {
        if (arrstring.length == 1) {
            return dr.a(arrstring, minecraftServer.J());
        }
        if (arrstring.length == 2) {
            return dr.a(arrstring, qe.b());
        }
        if (arrstring.length == 3) {
            return dr.a(arrstring, qc.a.c());
        }
        return Collections.emptyList();
    }

    @Override
    public boolean b(String[] arrstring, int n2) {
        return n2 == 0;
    }
}

