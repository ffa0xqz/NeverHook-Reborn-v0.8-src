/*
 * Decompiled with CFR 0.150.
 */
public abstract class acf
extends ve {
    public acf(ams ams2) {
        super(ams2);
    }
}

