/*
 * Decompiled with CFR 0.150.
 */
public class xk
extends xj {
    private final adw e;

    public xk(adw adw2) {
        super(adw2, aeb.class, 8.0f);
        this.e = adw2;
    }

    @Override
    public boolean a() {
        if (this.e.do()) {
            this.b = this.e.t_();
            return true;
        }
        return false;
    }
}

