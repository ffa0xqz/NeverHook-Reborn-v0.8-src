/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 *  com.google.common.collect.Iterables
 *  com.google.common.collect.Lists
 *  javax.annotation.Nullable
 */
import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import io.netty.buffer.ByteBuf;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

public class awc
extends avh {
    private String a = "";
    private String f = "";
    private String g = "";
    private et h = new et(0, 1, 0);
    private et i = et.a;
    private arw j = arw.a;
    private atk k = atk.a;
    private a l = awc$a.d;
    private boolean m = true;
    private boolean n;
    private boolean o;
    private boolean p = true;
    private float q = 1.0f;
    private long r;

    @Override
    public fy b(fy fy2) {
        super.b(fy2);
        fy2.a("name", this.a);
        fy2.a("author", this.f);
        fy2.a("metadata", this.g);
        fy2.a("posX", this.h.p());
        fy2.a("posY", this.h.q());
        fy2.a("posZ", this.h.r());
        fy2.a("sizeX", this.i.p());
        fy2.a("sizeY", this.i.q());
        fy2.a("sizeZ", this.i.r());
        fy2.a("rotation", this.k.toString());
        fy2.a("mirror", this.j.toString());
        fy2.a("mode", this.l.toString());
        fy2.a("ignoreEntities", this.m);
        fy2.a("powered", this.n);
        fy2.a("showair", this.o);
        fy2.a("showboundingbox", this.p);
        fy2.a("integrity", this.q);
        fy2.a("seed", this.r);
        return fy2;
    }

    @Override
    public void a(fy fy2) {
        super.a(fy2);
        this.a(fy2.l("name"));
        this.f = fy2.l("author");
        this.g = fy2.l("metadata");
        int n2 = ri.a(fy2.h("posX"), -32, 32);
        \u2603 = ri.a(fy2.h("posY"), -32, 32);
        \u2603 = ri.a(fy2.h("posZ"), -32, 32);
        this.h = new et(n2, \u2603, \u2603);
        \u2603 = ri.a(fy2.h("sizeX"), 0, 32);
        \u2603 = ri.a(fy2.h("sizeY"), 0, 32);
        \u2603 = ri.a(fy2.h("sizeZ"), 0, 32);
        this.i = new et(\u2603, \u2603, \u2603);
        try {
            this.k = atk.valueOf(fy2.l("rotation"));
        }
        catch (IllegalArgumentException \u26032) {
            this.k = atk.a;
        }
        try {
            this.j = arw.valueOf(fy2.l("mirror"));
        }
        catch (IllegalArgumentException \u26033) {
            this.j = arw.a;
        }
        try {
            this.l = awc$a.valueOf(fy2.l("mode"));
        }
        catch (IllegalArgumentException \u26034) {
            this.l = awc$a.d;
        }
        this.m = fy2.q("ignoreEntities");
        this.n = fy2.q("powered");
        this.o = fy2.q("showair");
        this.p = fy2.q("showboundingbox");
        this.q = fy2.e("integrity") ? fy2.j("integrity") : 1.0f;
        this.r = fy2.i("seed");
        this.J();
    }

    private void J() {
        if (this.b == null) {
            return;
        }
        et et2 = this.w();
        awr \u26032 = this.b.o(et2);
        if (\u26032.u() == aov.dT) {
            this.b.a(et2, \u26032.a(auj.a, this.l), 2);
        }
    }

    @Override
    @Nullable
    public ih c() {
        return new ih(this.c, 7, this.d());
    }

    @Override
    public fy d() {
        return this.b(new fy());
    }

    public boolean a(aeb aeb2) {
        if (!aeb2.dv()) {
            return false;
        }
        if (aeb2.e().G) {
            aeb2.a(this);
        }
        return true;
    }

    public String a() {
        return this.a;
    }

    public void a(String string) {
        String string2;
        string2 = string;
        for (char c2 : g.b) {
            string2 = string2.replace(c2, '_');
        }
        this.a = string2;
    }

    public void a(vn vn2) {
        if (!rn.b(vn2.h_())) {
            this.f = vn2.h_();
        }
    }

    public et e() {
        return this.h;
    }

    public void b(et et2) {
        this.h = et2;
    }

    public et f() {
        return this.i;
    }

    public void c(et et2) {
        this.i = et2;
    }

    public arw h() {
        return this.j;
    }

    public void b(arw arw2) {
        this.j = arw2;
    }

    public atk i() {
        return this.k;
    }

    public void b(atk atk2) {
        this.k = atk2;
    }

    public String j() {
        return this.g;
    }

    public void b(String string) {
        this.g = string;
    }

    public a k() {
        return this.l;
    }

    public void a(a a2) {
        this.l = a2;
        awr awr2 = this.b.o(this.w());
        if (awr2.u() == aov.dT) {
            this.b.a(this.w(), awr2.a(auj.a, a2), 2);
        }
    }

    public void l() {
        switch (this.k()) {
            case a: {
                this.a(awc$a.b);
                break;
            }
            case b: {
                this.a(awc$a.c);
                break;
            }
            case c: {
                this.a(awc$a.d);
                break;
            }
            case d: {
                this.a(awc$a.a);
            }
        }
    }

    public boolean m() {
        return this.m;
    }

    public void a(boolean bl2) {
        this.m = bl2;
    }

    public float n() {
        return this.q;
    }

    public void a(float f2) {
        this.q = f2;
    }

    public long o() {
        return this.r;
    }

    public void a(long l2) {
        this.r = l2;
    }

    public boolean p() {
        if (this.l != awc$a.a) {
            return false;
        }
        et et2 = this.w();
        int \u26032 = 80;
        \u2603 = new et(et2.p() - 80, 0, et2.r() - 80);
        List<awc> \u26033 = this.a(\u2603, \u2603 = new et(et2.p() + 80, 255, et2.r() + 80));
        List<awc> \u26034 = this.a(\u26033);
        if (\u26034.size() < 1) {
            return false;
        }
        bbe \u26035 = this.a(et2, \u26034);
        if (\u26035.d - \u26035.a > 1 && \u26035.e - \u26035.b > 1 && \u26035.f - \u26035.c > 1) {
            this.h = new et(\u26035.a - et2.p() + 1, \u26035.b - et2.q() + 1, \u26035.c - et2.r() + 1);
            this.i = new et(\u26035.d - \u26035.a - 1, \u26035.e - \u26035.b - 1, \u26035.f - \u26035.c - 1);
            this.y_();
            awr awr2 = this.b.o(et2);
            this.b.a(et2, awr2, awr2, 3);
            return true;
        }
        return false;
    }

    private List<awc> a(List<awc> list) {
        Iterable iterable = Iterables.filter(list, (Predicate)new Predicate<awc>(){

            public boolean a(@Nullable awc awc2) {
                return awc2.l == awc$a.c && awc.this.a.equals(awc2.a);
            }

            public /* synthetic */ boolean apply(@Nullable Object object) {
                return this.a((awc)object);
            }
        });
        return Lists.newArrayList((Iterable)iterable);
    }

    private List<awc> a(et et2, et et3) {
        ArrayList arrayList = Lists.newArrayList();
        for (et.a a2 : et.b(et2, et3)) {
            awr awr2 = this.b.o(a2);
            if (awr2.u() != aov.dT || (\u2603 = this.b.r(a2)) == null || !(\u2603 instanceof awc)) continue;
            arrayList.add((awc)\u2603);
        }
        return arrayList;
    }

    private bbe a(et et2, List<awc> list) {
        bbe \u26032;
        if (list.size() > 1) {
            et et3 = list.get(0).w();
            \u26032 = new bbe(et3, et3);
        } else {
            \u26032 = new bbe(et2, et2);
        }
        for (awc \u26033 : list) {
            \u2603 = \u26033.w();
            if (\u2603.p() < \u26032.a) {
                \u26032.a = \u2603.p();
            } else if (\u2603.p() > \u26032.d) {
                \u26032.d = \u2603.p();
            }
            if (\u2603.q() < \u26032.b) {
                \u26032.b = \u2603.q();
            } else if (\u2603.q() > \u26032.e) {
                \u26032.e = \u2603.q();
            }
            if (\u2603.r() < \u26032.c) {
                \u26032.c = \u2603.r();
                continue;
            }
            if (\u2603.r() <= \u26032.f) continue;
            \u26032.f = \u2603.r();
        }
        return \u26032;
    }

    public void a(ByteBuf byteBuf) {
        byteBuf.writeInt(this.c.p());
        byteBuf.writeInt(this.c.q());
        byteBuf.writeInt(this.c.r());
    }

    public boolean q() {
        return this.b(true);
    }

    public boolean b(boolean bl2) {
        if (this.l != awc$a.a || this.b.G || rn.b(this.a)) {
            return false;
        }
        et et2 = this.w().a(this.h);
        om \u26032 = (om)this.b;
        MinecraftServer \u26033 = this.b.u();
        bce \u26034 = \u26032.y();
        bch \u26035 = \u26034.a(\u26033, new nd(this.a));
        \u26035.a(this.b, et2, this.i, !this.m, aov.dj);
        \u26035.a(this.f);
        return !bl2 || \u26034.c(\u26033, new nd(this.a));
    }

    public boolean r() {
        return this.c(true);
    }

    public boolean c(boolean bl22) {
        boolean bl22;
        Object object;
        if (this.l != awc$a.b || this.b.G || rn.b(this.a)) {
            return false;
        }
        et et2 = this.w();
        \u2603 = et2.a(this.h);
        om \u26032 = (om)this.b;
        MinecraftServer \u26033 = this.b.u();
        bce \u26034 = \u26032.y();
        bch \u26035 = \u26034.b(\u26033, new nd(this.a));
        if (\u26035 == null) {
            return false;
        }
        if (!rn.b(\u26035.b())) {
            this.f = \u26035.b();
        }
        if (!(\u2603 = this.i.equals(\u2603 = \u26035.a()))) {
            this.i = \u2603;
            this.y_();
            object = this.b.o(et2);
            this.b.a(et2, (awr)object, (awr)object, 3);
        }
        if (!bl22 || \u2603) {
            object = new bcf().a(this.j).a(this.k).a(this.m).a((aml)null).a((aou)null).b(false);
            if (this.q < 1.0f) {
                ((bcf)object).a(ri.a(this.q, 0.0f, 1.0f)).a((Long)this.r);
            }
            \u26035.a(this.b, \u2603, (bcf)object);
            return true;
        }
        return false;
    }

    public void s() {
        om om2 = (om)this.b;
        bce \u26032 = om2.y();
        \u26032.b(new nd(this.a));
    }

    public boolean E() {
        if (this.l != awc$a.b || this.b.G) {
            return false;
        }
        om om2 = (om)this.b;
        MinecraftServer \u26032 = this.b.u();
        bce \u26033 = om2.y();
        return \u26033.b(\u26032, new nd(this.a)) != null;
    }

    public boolean F() {
        return this.n;
    }

    public void d(boolean bl2) {
        this.n = bl2;
    }

    public boolean G() {
        return this.o;
    }

    public void e(boolean bl2) {
        this.o = bl2;
    }

    public boolean I() {
        return this.p;
    }

    public void f(boolean bl2) {
        this.p = bl2;
    }

    @Override
    @Nullable
    public hh i_() {
        return new hp("structure_block.hover." + this.l.f, this.l == awc$a.d ? this.g : this.a);
    }

    public static enum a implements rm
    {
        a("save", 0),
        b("load", 1),
        c("corner", 2),
        d("data", 3);

        private static final a[] e;
        private final String f;
        private final int g;

        private a(String string2, int n3) {
            this.f = string2;
            this.g = n3;
        }

        @Override
        public String m() {
            return this.f;
        }

        public int a() {
            return this.g;
        }

        public static a a(int n2) {
            if (n2 < 0 || n2 >= e.length) {
                return e[0];
            }
            return e[n2];
        }

        static {
            e = new a[awc$a.values().length];
            a[] arra = awc$a.values();
            int n2 = arra.length;
            for (int i2 = 0; i2 < n2; ++i2) {
                a a2;
                awc$a.e[a2.a()] = a2 = arra[i2];
            }
        }
    }
}

