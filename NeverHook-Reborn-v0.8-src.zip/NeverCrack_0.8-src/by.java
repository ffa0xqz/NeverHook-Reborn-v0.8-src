/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  javax.annotation.Nullable
 */
import com.mojang.authlib.GameProfile;
import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

public class by
extends bi {
    @Override
    public String c() {
        return "deop";
    }

    @Override
    public int a() {
        return 3;
    }

    @Override
    public String b(bn bn2) {
        return "commands.deop.usage";
    }

    @Override
    public void a(MinecraftServer minecraftServer, bn bn2, String[] arrstring) throws ei {
        if (arrstring.length != 1 || arrstring[0].length() <= 0) {
            throw new ep("commands.deop.usage", new Object[0]);
        }
        GameProfile gameProfile = minecraftServer.am().m().a(arrstring[0]);
        if (gameProfile == null) {
            throw new ei("commands.deop.failed", arrstring[0]);
        }
        minecraftServer.am().b(gameProfile);
        by.a(bn2, (bk)this, "commands.deop.success", arrstring[0]);
    }

    @Override
    public List<String> a(MinecraftServer minecraftServer, bn bn2, String[] arrstring, @Nullable et et2) {
        if (arrstring.length == 1) {
            return by.a(arrstring, minecraftServer.am().n());
        }
        return Collections.emptyList();
    }
}

