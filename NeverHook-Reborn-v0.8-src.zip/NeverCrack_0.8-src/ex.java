/*
 * Decompiled with CFR 0.150.
 */
public class ex
implements fb {
    @Override
    public final ain a(eu eu2, ain ain2) {
        \u2603 = this.b(eu2, ain2);
        this.a(eu2);
        this.a(eu2, eu2.e().c(apx.a));
        return \u2603;
    }

    protected ain b(eu eu2, ain ain2) {
        fa fa2 = eu2.e().c(apx.a);
        fk \u26032 = apx.a(eu2);
        ain \u26033 = ain2.a(1);
        ex.a(eu2.h(), \u26033, 6, fa2, \u26032);
        return ain2;
    }

    public static void a(ams ams2, ain ain2, int n2, fa fa2, fk fk2) {
        double d2 = fk2.a();
        \u2603 = fk2.b();
        \u2603 = fk2.c();
        \u2603 = fa2.k() == fa.a.b ? (\u2603 -= 0.125) : (\u2603 -= 0.15625);
        acj \u26032 = new acj(ams2, d2, \u2603, \u2603, ain2);
        \u2603 = ams2.r.nextDouble() * 0.1 + 0.2;
        \u26032.s = (double)fa2.g() * \u2603;
        \u26032.t = 0.2f;
        \u26032.u = (double)fa2.i() * \u2603;
        \u26032.s += ams2.r.nextGaussian() * (double)0.0075f * (double)n2;
        \u26032.t += ams2.r.nextGaussian() * (double)0.0075f * (double)n2;
        \u26032.u += ams2.r.nextGaussian() * (double)0.0075f * (double)n2;
        ams2.a(\u26032);
    }

    protected void a(eu eu2) {
        eu2.h().b(1000, eu2.d(), 0);
    }

    protected void a(eu eu2, fa fa2) {
        eu2.h().b(2000, eu2.d(), this.a(fa2));
    }

    private int a(fa fa2) {
        return fa2.g() + 1 + (fa2.i() + 1) * 3;
    }
}

