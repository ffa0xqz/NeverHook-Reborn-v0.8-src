/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Sets
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonDeserializationContext
 *  com.google.gson.JsonDeserializer
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonParseException
 */
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class bwg {
    private final List<bwi> a;
    private aws b;

    public bwg(List<bwi> list) {
        this.a = list;
    }

    public List<bwi> a() {
        return this.a;
    }

    public Set<bwb> b() {
        HashSet hashSet = Sets.newHashSet();
        for (bwi bwi2 : this.a) {
            hashSet.add(bwi2.a());
        }
        return hashSet;
    }

    public void a(aws aws2) {
        this.b = aws2;
    }

    public aws c() {
        return this.b;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object instanceof bwg) {
            bwg bwg2 = (bwg)object;
            if (this.a.equals(bwg2.a)) {
                if (this.b == null) {
                    return bwg2.b == null;
                }
                return this.b.equals(bwg2.b);
            }
        }
        return false;
    }

    public int hashCode() {
        return 31 * this.a.hashCode() + (this.b == null ? 0 : this.b.hashCode());
    }

    public static class a
    implements JsonDeserializer<bwg> {
        public bwg a(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            return new bwg(this.a(jsonDeserializationContext, jsonElement.getAsJsonArray()));
        }

        private List<bwi> a(JsonDeserializationContext jsonDeserializationContext, JsonArray jsonArray) {
            ArrayList arrayList = Lists.newArrayList();
            for (JsonElement jsonElement : jsonArray) {
                arrayList.add((bwi)jsonDeserializationContext.deserialize(jsonElement, bwi.class));
            }
            return arrayList;
        }

        public /* synthetic */ Object deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            return this.a(jsonElement, type, jsonDeserializationContext);
        }
    }
}

