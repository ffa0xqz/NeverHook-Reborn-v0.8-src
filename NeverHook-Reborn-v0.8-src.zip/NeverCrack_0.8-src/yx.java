/*
 * Decompiled with CFR 0.150.
 */
public class yx
extends yy {
    vz a;
    vn b;
    private int c;

    public yx(vz vz2) {
        super(vz2, false);
        this.a = vz2;
        this.a(1);
    }

    @Override
    public boolean a() {
        if (!this.a.dl()) {
            return false;
        }
        vn vn2 = this.a.do();
        if (vn2 == null) {
            return false;
        }
        this.b = vn2.bU();
        int \u26032 = vn2.bV();
        return \u26032 != this.c && this.a(this.b, false) && this.a.a(this.b, vn2);
    }

    @Override
    public void c() {
        this.e.d(this.b);
        vn vn2 = this.a.do();
        if (vn2 != null) {
            this.c = vn2.bV();
        }
        super.c();
    }
}

