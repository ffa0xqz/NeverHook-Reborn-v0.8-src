/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 *  com.google.common.collect.Iterators
 *  com.google.common.collect.Lists
 *  com.mojang.authlib.Agent
 *  com.mojang.authlib.GameProfile
 *  com.mojang.authlib.ProfileLookupCallback
 *  javax.annotation.Nullable
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.common.base.Predicate;
import com.google.common.collect.Iterators;
import com.google.common.collect.Lists;
import com.mojang.authlib.Agent;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.ProfileLookupCallback;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class pi {
    private static final Logger e = LogManager.getLogger();
    public static final File a = new File("banned-ips.txt");
    public static final File b = new File("banned-players.txt");
    public static final File c = new File("ops.txt");
    public static final File d = new File("white-list.txt");

    private static void a(MinecraftServer minecraftServer, Collection<String> collection, ProfileLookupCallback profileLookupCallback) {
        String[] arrstring = (String[])Iterators.toArray((Iterator)Iterators.filter(collection.iterator(), (Predicate)new Predicate<String>(){

            public boolean a(@Nullable String string) {
                return !rn.b(string);
            }

            public /* synthetic */ boolean apply(@Nullable Object object) {
                return this.a((String)object);
            }
        }), String.class);
        if (minecraftServer.ab()) {
            minecraftServer.aA().findProfilesByNames(arrstring, Agent.MINECRAFT, profileLookupCallback);
        } else {
            for (String string : arrstring) {
                UUID uUID = aeb.a(new GameProfile(null, string));
                GameProfile \u26032 = new GameProfile(uUID, string);
                profileLookupCallback.onProfileLookupSucceeded(\u26032);
            }
        }
    }

    public static String a(final MinecraftServer minecraftServer, String string) {
        if (rn.b(string) || string.length() > 16) {
            return string;
        }
        GameProfile gameProfile = minecraftServer.aB().a(string);
        if (gameProfile != null && gameProfile.getId() != null) {
            return gameProfile.getId().toString();
        }
        if (minecraftServer.R() || !minecraftServer.ab()) {
            return aeb.a(new GameProfile(null, string)).toString();
        }
        final ArrayList \u26032 = Lists.newArrayList();
        ProfileLookupCallback \u26033 = new ProfileLookupCallback(){

            public void onProfileLookupSucceeded(GameProfile gameProfile) {
                minecraftServer.aB().a(gameProfile);
                \u26032.add(gameProfile);
            }

            public void onProfileLookupFailed(GameProfile gameProfile, Exception exception) {
                e.warn("Could not lookup user whitelist entry for {}", (Object)gameProfile.getName(), (Object)exception);
            }
        };
        pi.a(minecraftServer, Lists.newArrayList((Object[])new String[]{string}), \u26033);
        if (!\u26032.isEmpty() && ((GameProfile)\u26032.get(0)).getId() != null) {
            return ((GameProfile)\u26032.get(0)).getId().toString();
        }
        return "";
    }
}

