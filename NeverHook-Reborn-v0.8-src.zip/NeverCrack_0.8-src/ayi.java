/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 */
import com.google.common.collect.Maps;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Map;

public class ayi {
    private static final Map<File, ayh> a = Maps.newHashMap();

    public static synchronized ayh a(File file, int n2, int n3) {
        File file2 = new File(file, "region");
        \u2603 = new File(file2, "r." + (n2 >> 5) + "." + (n3 >> 5) + ".mca");
        ayh \u26032 = a.get(\u2603);
        if (\u26032 != null) {
            return \u26032;
        }
        if (!file2.exists()) {
            file2.mkdirs();
        }
        if (a.size() >= 256) {
            ayi.a();
        }
        ayh \u26033 = new ayh(\u2603);
        a.put(\u2603, \u26033);
        return \u26033;
    }

    public static synchronized ayh b(File file, int n2, int n3) {
        File file2 = new File(file, "region");
        \u2603 = new File(file2, "r." + (n2 >> 5) + "." + (n3 >> 5) + ".mca");
        ayh \u26032 = a.get(\u2603);
        if (\u26032 != null) {
            return \u26032;
        }
        if (!file2.exists() || !\u2603.exists()) {
            return null;
        }
        if (a.size() >= 256) {
            ayi.a();
        }
        ayh \u26033 = new ayh(\u2603);
        a.put(\u2603, \u26033);
        return \u26033;
    }

    public static synchronized void a() {
        for (ayh ayh2 : a.values()) {
            try {
                if (ayh2 == null) continue;
                ayh2.c();
            }
            catch (IOException iOException) {
                iOException.printStackTrace();
            }
        }
        a.clear();
    }

    public static DataInputStream d(File file, int n2, int n3) {
        ayh ayh2 = ayi.a(file, n2, n3);
        return ayh2.a(n2 & 0x1F, n3 & 0x1F);
    }

    public static DataOutputStream e(File file, int n2, int n3) {
        ayh ayh2 = ayi.a(file, n2, n3);
        return ayh2.b(n2 & 0x1F, n3 & 0x1F);
    }

    public static boolean f(File file, int n2, int n3) {
        ayh ayh2 = ayi.b(file, n2, n3);
        if (ayh2 != null) {
            return ayh2.c(n2 & 0x1F, n3 & 0x1F);
        }
        return false;
    }
}

