/*
 * Decompiled with CFR 0.150.
 */
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;

public class qm {
    public final String a;
    private final hh g;
    public boolean b;
    private final qn h;
    private final bho i;
    private Class<? extends qp> j;
    private static final NumberFormat k = NumberFormat.getIntegerInstance(Locale.US);
    public static qn c = new qn(){

        @Override
        public String a(int n2) {
            return k.format(n2);
        }
    };
    private static final DecimalFormat l = new DecimalFormat("########0.00");
    public static qn d = new qn(){

        @Override
        public String a(int n2) {
            double d2 = (double)n2 / 20.0;
            \u2603 = d2 / 60.0;
            \u2603 = \u2603 / 60.0;
            \u2603 = \u2603 / 24.0;
            \u2603 = \u2603 / 365.0;
            if (\u2603 > 0.5) {
                return l.format(\u2603) + " y";
            }
            if (\u2603 > 0.5) {
                return l.format(\u2603) + " d";
            }
            if (\u2603 > 0.5) {
                return l.format(\u2603) + " h";
            }
            if (\u2603 > 0.5) {
                return l.format(\u2603) + " m";
            }
            return d2 + " s";
        }
    };
    public static qn e = new qn(){

        @Override
        public String a(int n2) {
            double d2 = (double)n2 / 100.0;
            \u2603 = d2 / 1000.0;
            if (\u2603 > 0.5) {
                return l.format(\u2603) + " km";
            }
            if (d2 > 0.5) {
                return l.format(d2) + " m";
            }
            return n2 + " cm";
        }
    };
    public static qn f = new qn(){

        @Override
        public String a(int n2) {
            return l.format((double)n2 * 0.1);
        }
    };

    public qm(String string, hh hh2, qn qn2) {
        this.a = string;
        this.g = hh2;
        this.h = qn2;
        this.i = new bhq(this);
        bho.a.put(this.i.a(), this.i);
    }

    public qm(String string, hh hh2) {
        this(string, hh2, c);
    }

    public qm c() {
        this.b = true;
        return this;
    }

    public qm a() {
        if (qq.a.containsKey(this.a)) {
            throw new RuntimeException("Duplicate stat id: \"" + qq.a.get((Object)this.a).g + "\" and \"" + this.g + "\" at id " + this.a);
        }
        qq.b.add(this);
        qq.a.put(this.a, this);
        return this;
    }

    public String a(int n2) {
        return this.h.a(n2);
    }

    public hh d() {
        hh hh2 = this.g.f();
        hh2.b().a(a.h);
        return hh2;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null || this.getClass() != object.getClass()) {
            return false;
        }
        qm qm2 = (qm)object;
        return this.a.equals(qm2.a);
    }

    public int hashCode() {
        return this.a.hashCode();
    }

    public String toString() {
        return "Stat{id=" + this.a + ", nameId=" + this.g + ", awardLocallyOnly=" + this.b + ", formatter=" + this.h + ", objectiveCriteria=" + this.i + '}';
    }

    public bho f() {
        return this.i;
    }

    public Class<? extends qp> g() {
        return this.j;
    }
}

