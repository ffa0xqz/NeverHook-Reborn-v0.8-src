/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.GsonBuilder
 *  com.google.gson.TypeAdapterFactory
 */
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.TypeAdapterFactory;
import java.io.IOException;

public class mr
implements ht<mp> {
    private static final Gson a = new GsonBuilder().registerTypeAdapter(ms.c.class, (Object)new ms.c.a()).registerTypeAdapter(ms.a.class, (Object)new ms.a.a()).registerTypeAdapter(ms.class, (Object)new ms.b()).registerTypeHierarchyAdapter(hh.class, (Object)new hh.a()).registerTypeHierarchyAdapter(hn.class, (Object)new hn.a()).registerTypeAdapterFactory((TypeAdapterFactory)new rh()).create();
    private ms b;

    public mr() {
    }

    public mr(ms ms2) {
        this.b = ms2;
    }

    @Override
    public void a(gy gy2) throws IOException {
        this.b = ra.a(a, gy2.e(32767), ms.class);
    }

    @Override
    public void b(gy gy2) throws IOException {
        gy2.a(a.toJson((Object)this.b));
    }

    @Override
    public void a(mp mp2) {
        mp2.a(this);
    }

    public ms a() {
        return this.b;
    }
}

