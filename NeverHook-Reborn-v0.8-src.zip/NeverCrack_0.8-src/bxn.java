/*
 * Decompiled with CFR 0.150.
 */
public class bxn
implements bxq {
    @Override
    public bxp a(ams ams2, buw buw2, int n2) {
        return new bxo(ams2, buw2, n2);
    }
}

