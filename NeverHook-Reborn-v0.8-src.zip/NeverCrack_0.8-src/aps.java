/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import java.util.Random;
import javax.annotation.Nullable;

public class aps
extends apa {
    protected static final bgz a = new bgz(0.09999999403953552, 0.0, 0.09999999403953552, 0.9f, 0.8f, 0.9f);

    protected aps() {
        super(bcx.l);
    }

    @Override
    public bgz b(awr awr2, amw amw2, et et2) {
        return a;
    }

    @Override
    public bcy c(awr awr2, amw amw2, et et2) {
        return bcy.p;
    }

    @Override
    protected boolean x(awr awr2) {
        return awr2.u() == aov.m || awr2.u() == aov.cz || awr2.u() == aov.cu || awr2.u() == aov.d;
    }

    @Override
    public boolean a(amw amw2, et et2) {
        return true;
    }

    @Override
    public int a(Random random) {
        return random.nextInt(3);
    }

    @Override
    public ail a(awr awr2, Random random, int n2) {
        return aip.B;
    }

    @Override
    public void a(ams ams2, aeb aeb2, et et2, awr awr2, @Nullable avh avh2, ain ain2) {
        if (ams2.G || ain2.c() != aip.bm) {
            super.a(ams2, aeb2, et2, awr2, avh2, ain2);
        } else {
            aeb2.b(qq.a(this));
            aps.a(ams2, et2, new ain(aov.I, 1, 0));
        }
    }
}

