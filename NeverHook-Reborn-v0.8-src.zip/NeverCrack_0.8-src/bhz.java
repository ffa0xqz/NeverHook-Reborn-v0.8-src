/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Multimap
 *  com.google.common.collect.Queues
 *  com.google.common.collect.Sets
 *  com.google.common.hash.Hashing
 *  com.google.common.util.concurrent.Futures
 *  com.google.common.util.concurrent.ListenableFuture
 *  com.google.common.util.concurrent.ListenableFutureTask
 *  com.mojang.authlib.GameProfile
 *  com.mojang.authlib.GameProfileRepository
 *  com.mojang.authlib.minecraft.MinecraftSessionService
 *  com.mojang.authlib.properties.PropertyMap
 *  com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService
 *  javax.annotation.Nullable
 *  org.apache.commons.io.Charsets
 *  org.apache.commons.io.IOUtils
 *  org.apache.commons.lang3.Validate
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 *  org.lwjgl.LWJGLException
 *  org.lwjgl.Sys
 *  org.lwjgl.input.Keyboard
 *  org.lwjgl.input.Mouse
 *  org.lwjgl.opengl.ContextCapabilities
 *  org.lwjgl.opengl.Display
 *  org.lwjgl.opengl.DisplayMode
 *  org.lwjgl.opengl.GLContext
 *  org.lwjgl.opengl.OpenGLException
 *  org.lwjgl.opengl.PixelFormat
 */
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import com.google.common.collect.Queues;
import com.google.common.collect.Sets;
import com.google.common.hash.Hashing;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.ListenableFutureTask;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.GameProfileRepository;
import com.mojang.authlib.minecraft.MinecraftSessionService;
import com.mojang.authlib.properties.PropertyMap;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.Proxy;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Queue;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
import java.util.stream.Collectors;
import javax.annotation.Nullable;
import javax.imageio.ImageIO;
import net.minecraft.client.ClientBrandRetriever;
import net.minecraft.server.MinecraftServer;
import org.apache.commons.io.Charsets;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.Validate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.LWJGLException;
import org.lwjgl.Sys;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.ContextCapabilities;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.opengl.GLContext;
import org.lwjgl.opengl.OpenGLException;
import org.lwjgl.opengl.PixelFormat;
import org.lwjgl.util.glu.GLU;
import top.nhprem.Main;
import top.nhprem.api.event.event.EventAttackClient;
import top.nhprem.api.event.event.EventKey;
import top.nhprem.api.event.event.EventMouseKey;
import top.nhprem.api.event.event.TickEvent;
import top.nhprem.api.utils.font.FontUtil;
import top.nhprem.api.utils.font.MCFontRenderer;
import top.nhprem.api.utils.other.DiscordHelper;
import top.nhprem.client.features.impl.misc.FastWorldLoad;
import top.nhprem.client.features.impl.misc.Optimization;
import top.nhprem.client.features.impl.player.MultiAction;

public class bhz
implements tp,
uk {
    private static final Logger J = LogManager.getLogger();
    private static final nd K = new nd("textures/gui/title/mojang.png");
    public static final boolean a = h.a() == h.a.d;
    public static byte[] b = new byte[0xA00000];
    private static final List<DisplayMode> L = Lists.newArrayList((Object[])new DisplayMode[]{new DisplayMode(2560, 1600), new DisplayMode(2880, 1800)});
    private final File M;
    private final PropertyMap N;
    public static double frameTime;
    private final PropertyMap O;
    private bsc P;
    public cdp Q;
    private static bhz R;
    private final rw S;
    public bry c;
    private boolean T;
    private final boolean U = true;
    private boolean V;
    private b W;
    public int d;
    public int e;
    private boolean X;
    public final bif Y = new bif(20.0f);
    private final uj Z = new uj("client", this, MinecraftServer.aw());
    public brz f;
    public buw g;
    public bzd aa;
    private bzu ab;
    private bus ac;
    public bub h;
    @Nullable
    public ve ad;
    public ve i;
    public bte j;
    private cgv ae = new cgv();
    public big af;
    private boolean ag;
    private float ah;
    public static bin k;
    public MCFontRenderer sfui16;
    public MCFontRenderer sfui18;
    public MCFontRenderer neverlose500_13;
    public MCFontRenderer neverlose500_14;
    public MCFontRenderer neverlose500_15;
    public MCFontRenderer neverlose900_20;
    public MCFontRenderer neverlose900_19;
    public MCFontRenderer neverlose900_18;
    public MCFontRenderer neverlose900_17;
    public MCFontRenderer neverlose900_16;
    public MCFontRenderer neverlose900_15;
    public MCFontRenderer neverlose900_14;
    public MCFontRenderer neverlose900_13;
    public MCFontRenderer neverlose500_16;
    public MCFontRenderer stylesicons_14;
    public MCFontRenderer neverlose500_17;
    public MCFontRenderer neverlose500_19;
    public MCFontRenderer neverlose500_20;
    public MCFontRenderer neverlose500_22;
    public MCFontRenderer rubik_regular_16;
    public MCFontRenderer elegant_20;
    public MCFontRenderer makslol;
    public MCFontRenderer elegant_30;
    public MCFontRenderer elegant_18;
    public MCFontRenderer icons_20;
    public MCFontRenderer neverlose500_18;
    public MCFontRenderer robotoRegular;
    public MCFontRenderer robotoRegular18;
    public MCFontRenderer feturo;
    public MCFontRenderer icons_30;
    public MCFontRenderer urwgeometric;
    public MCFontRenderer bebasbook;
    public MCFontRenderer lato;
    public MCFontRenderer lato15;
    public MCFontRenderer poppins16;
    public MCFontRenderer poppins20;
    public MCFontRenderer poppinsBold20;
    public MCFontRenderer icons_font_35;
    public MCFontRenderer iconsnot;
    public MCFontRenderer wexsideicons_30;
    public MCFontRenderer wexsideicons_17;
    public bin l;
    @Nullable
    public bli m;
    public bic n;
    public buo o;
    public bye p;
    private int ai;
    private final int aj;
    private final int ak;
    @Nullable
    private chb al;
    public bio q;
    public boolean r;
    public bha s;
    public bib t;
    public bhu u;
    public bia v;
    public final File w;
    private final File am;
    private final String an;
    private final String ao;
    private final Proxy ap;
    private bfe aq;
    boolean bl2;
    private static int ar;
    public int as;
    private String at;
    private int au;
    public boolean x;
    long y = bhz.I();
    private int av;
    public final qz z = new qz();
    long A = System.nanoTime();
    private final boolean aw;
    private final boolean ax;
    @Nullable
    private gw ay;
    private boolean az;
    public final rj B = new rj();
    public static float globalOffset;
    private long aA = -1L;
    public cel aB;
    private final cfe aC = new cfe();
    private final List<cep> aD = Lists.newArrayList();
    private final cee aE;
    private ces aF;
    public cey aG;
    private bii aH;
    private bil aI;
    private bvb aJ;
    private cdn aK;
    private chm aL;
    private chj aM;
    private nd aN;
    private final MinecraftSessionService aO;
    private cev aP;
    private final Queue<FutureTask<?>> aQ = Queues.newArrayDeque();
    private final Thread aR = Thread.currentThread();
    private cga aS;
    private bvk aT;
    private final bka aU;
    volatile boolean C = true;
    public String D = "";
    public boolean H = true;
    private long aV = bhz.I();
    private int aW;
    private boolean aX;
    private final chx aY;
    long I = -1L;
    private String aZ = "root";

    public bhz(box gameConfig) {
        R = this;
        this.w = gameConfig.c.a;
        this.am = gameConfig.c.c;
        this.M = gameConfig.c.b;
        this.an = gameConfig.d.b;
        this.ao = gameConfig.d.c;
        this.N = gameConfig.a.b;
        this.O = gameConfig.a.c;
        this.aE = new cee(gameConfig.c.a());
        this.ap = gameConfig.a.d == null ? Proxy.NO_PROXY : gameConfig.a.d;
        this.aO = new YggdrasilAuthenticationService(this.ap, UUID.randomUUID().toString()).createMinecraftSessionService();
        this.af = gameConfig.a.a;
        J.info("Setting user: {}", (Object)this.af.c());
        J.debug("(Session ID is {})", (Object)this.af.a());
        this.ax = gameConfig.d.a;
        this.d = gameConfig.b.a > 0 ? gameConfig.b.a : 1;
        this.e = gameConfig.b.b > 0 ? gameConfig.b.b : 1;
        this.aj = gameConfig.b.a;
        this.ak = gameConfig.b.b;
        this.T = gameConfig.b.c;
        this.aw = bhz.aw();
        this.al = null;
        if (gameConfig.e.a != null) {
            this.at = gameConfig.e.a;
            this.au = gameConfig.e.b;
        }
        ImageIO.setUseCache(false);
        Locale.setDefault(Locale.ROOT);
        ng.c();
        hk.b = bhw::b;
        this.S = rx.a();
        this.aU = new bka(this);
        this.aY = new chx(this);
    }

    public void a() {
        block15: {
            this.C = true;
            try {
                this.aq();
            }
            catch (Throwable throwable) {
                b crashreport = b.a(throwable, "Initializing game");
                crashreport.a("Initialization");
                this.c(this.b(crashreport));
                return;
            }
            try {
                while (this.C) {
                    if (!this.V || this.W == null) {
                        try {
                            this.az();
                        }
                        catch (OutOfMemoryError var10) {
                            this.m();
                            this.a(new bld());
                            System.gc();
                        }
                        continue;
                    }
                    this.c(this.W);
                }
            }
            catch (bie var12) {
                break block15;
            }
            catch (f reportedexception) {
                this.b(reportedexception.a());
                this.m();
                J.fatal("Reported exception thrown!", (Throwable)reportedexception);
                this.c(reportedexception.a());
                break block15;
            }
            catch (Throwable throwable1) {
                b crashreport1 = this.b(new b("Unexpected error", throwable1));
                this.m();
                J.fatal("Unreported exception thrown!", throwable1);
                this.c(crashreport1);
                break block15;
            }
            finally {
                this.h();
            }
            return;
        }
    }

    public void setSession(big session) {
        this.af = session;
    }

    private void aq() throws LWJGLException, IOException {
        this.t = new bib(this, this.w);
        this.u = new bhu(this, this.w);
        this.aD.add(this.aE);
        this.ax();
        if (this.t.E > 0 && this.t.D > 0) {
            this.d = this.t.D;
            this.e = this.t.E;
        }
        J.info("LWJGL Version: {}", (Object)Sys.getVersion());
        this.av();
        this.au();
        this.at();
        cig.a();
        this.aJ = new bvb(this.d, this.e, true);
        this.aJ.a(0.0f, 0.0f, 0.0f, 0.0f);
        this.as();
        this.aF = new ces(this.M, new File(this.w, "server-resource-packs"), this.aE, this.aC, this.t);
        this.aB = new cet(this.aC);
        this.aG = new cey(this.aC, this.t.aJ);
        this.aB.a(this.aG);
        this.f();
        this.Q = new cdp(this.aB);
        this.aB.a(this.Q);
        this.aP = new cev(this.Q, new File(this.am, "skins"), this.aO);
        this.aq = new bex(new File(this.w, "saves"), this.S);
        this.aL = new chm(this.aB, this.t);
        this.aB.a(this.aL);
        this.aM = new chj(this);
        k = new bin(this.t, new nd("textures/font/ascii.png"), this.Q, false);
        this.sfui18 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/sf-ui.ttf"), 18.0f, 0), true, true);
        this.sfui16 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/sf-ui.ttf"), 16.0f, 0), true, true);
        this.neverlose500_13 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/neverlose500.ttf"), 13.0f, 0), true, true);
        this.neverlose500_14 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/neverlose500.ttf"), 14.0f, 0), true, true);
        this.neverlose500_15 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/neverlose500.ttf"), 15.0f, 0), true, true);
        this.neverlose500_16 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/neverlose500.ttf"), 16.0f, 0), true, true);
        this.neverlose500_17 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/neverlose500.ttf"), 17.0f, 0), true, true);
        this.neverlose500_18 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/neverlose500.ttf"), 18.0f, 0), true, true);
        this.neverlose500_19 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/neverlose500.ttf"), 19.0f, 0), true, true);
        this.neverlose500_20 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/neverlose500.ttf"), 20.0f, 0), true, true);
        this.neverlose500_22 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/neverlose500.ttf"), 22.0f, 0), true, true);
        this.rubik_regular_16 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/rubik_regular.ttf"), 16.0f, 0), true, true);
        this.stylesicons_14 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/stylesicons.ttf"), 14.0f, 0), true, true);
        this.robotoRegular = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/robotoregular.ttf"), 20.0f, 0), true, true);
        this.robotoRegular18 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/robotoregular.ttf"), 18.0f, 0), true, true);
        this.lato = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/lato.ttf"), 18.0f, 0), true, true);
        this.lato15 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/lato.ttf"), 15.0f, 0), true, true);
        this.makslol = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/makslol.ttf"), 40.0f, 0), true, true);
        this.icons_20 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/icons.ttf"), 20.0f, 0), true, true);
        this.icons_30 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/icons.ttf"), 30.0f, 0), true, true);
        this.elegant_20 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/elegent.ttf"), 20.0f, 0), true, true);
        this.elegant_18 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/elegent.ttf"), 18.0f, 0), true, true);
        this.elegant_30 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/elegent.ttf"), 30.0f, 0), true, true);
        this.neverlose900_13 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/neverlose900.ttf"), 13.0f, 0), true, true);
        this.neverlose900_14 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/neverlose900.ttf"), 14.0f, 0), true, true);
        this.neverlose900_15 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/neverlose900.ttf"), 15.0f, 0), true, true);
        this.neverlose900_16 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/neverlose900.ttf"), 16.0f, 0), true, true);
        this.neverlose900_17 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/neverlose900.ttf"), 17.0f, 0), true, true);
        this.neverlose900_18 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/neverlose900.ttf"), 18.0f, 0), true, true);
        this.neverlose900_19 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/neverlose900.ttf"), 19.0f, 0), true, true);
        this.neverlose900_20 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/neverlose900.ttf"), 20.0f, 0), true, true);
        this.icons_font_35 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/icons_font.ttf"), 35.0f, 0), true, true);
        this.iconsnot = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/icons1233.ttf"), 60.0f, 0), true, true);
        this.poppinsBold20 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/poppins_bold.ttf"), 20.0f, 0), true, true);
        this.poppins16 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/poppins.ttf"), 16.0f, 0), true, true);
        this.poppins20 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/poppins.ttf"), 20.0f, 0), true, true);
        this.urwgeometric = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/urwgeometric.ttf"), 18.0f, 0), true, true);
        this.bebasbook = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/bebasbook.ttf"), 24.0f, 0), true, true);
        this.wexsideicons_17 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/wexsideicons.ttf"), 17.0f, 0), true, true);
        this.wexsideicons_30 = new MCFontRenderer(FontUtil.getFontFromTTF(new nd("font/wexsideicons.ttf"), 30.0f, 0), true, true);
        if (this.t.aJ != null) {
            k.a(this.e());
            k.b(this.aG.b());
        }
        this.l = new bin(this.t, new nd("textures/font/ascii_sga.png"), this.Q, false);
        this.aB.a(k);
        this.aB.a(this.l);
        this.aB.a(new cek());
        this.aB.a(new cej());
        this.v = new bia();
        this.a("Pre startup");
        buq.y();
        buq.j(7425);
        buq.a(1.0);
        buq.k();
        buq.c(515);
        buq.e();
        buq.a(516, 0.1f);
        buq.a(buq.i.b);
        buq.n(5889);
        buq.F();
        buq.n(5888);
        this.a("Startup");
        this.aK = new cdn("textures");
        this.aK.a(this.t.K);
        this.Q.a(cdn.g, this.aK);
        this.Q.a(cdn.g);
        this.aK.a(false, this.t.K > 0);
        this.aS = new cga(this.aK);
        this.aB.a(this.aS);
        this.aH = bii.a();
        this.aI = bil.a(this.aH);
        this.ab = new bzu(this.Q, this.aS, this.aI);
        this.aa = new bzd(this.Q, this.ab);
        this.ac = new bus(this);
        this.aB.a(this.ab);
        this.o = new buo(this, this.aB);
        this.aB.a(this.o);
        this.aT = new bvk(this.aS.c(), this.aH);
        this.aB.a(this.aT);
        this.g = new buw(this);
        this.aB.a(this.g);
        this.ar();
        this.aB.a(this.ae);
        buq.b(0, 0, this.d, this.e);
        this.j = new bte(this.f, this.Q);
        this.a("Post startup");
        this.q = new bio(this);
        blp blp2 = new blp();
        this.n = new bic(this);
        this.p = new bye(this);
        if (this.t.u && !this.T) {
            this.r();
        }
        try {
            Display.setVSyncEnabled((boolean)this.t.v);
        }
        catch (OpenGLException var2) {
            this.t.v = false;
            this.t.b();
        }
        this.g.b();
    }

    private void ar() {
        cgu<ain> searchtree = new cgu<ain>(p_193988_0_ -> p_193988_0_.a((aeb)null, ajz.a.a).stream().map(a::a).map(String::trim).filter(p_193984_0_ -> !p_193984_0_.isEmpty()).collect(Collectors.toList()), p_193985_0_ -> Collections.singleton(ail.g.b(p_193985_0_.c())));
        fi<ain> nonnulllist = fi.a();
        for (ail item : ail.g) {
            item.a(ahn.g, nonnulllist);
        }
        nonnulllist.forEach(searchtree::a);
        cgu<bnq> searchtree1 = new cgu<bnq>(p_193990_0_ -> p_193990_0_.d().stream().flatMap(p_193993_0_ -> p_193993_0_.b().a((aeb)null, ajz.a.a).stream()).map(a::a).map(String::trim).filter(p_193994_0_ -> !p_193994_0_.isEmpty()).collect(Collectors.toList()), p_193991_0_ -> p_193991_0_.d().stream().map(p_193992_0_ -> ail.g.b(p_193992_0_.b().c())).collect(Collectors.toList()));
        cif.f.forEach(searchtree1::a);
        this.ae.a(cgv.a, searchtree);
        this.ae.a(cgv.b, searchtree1);
    }

    private void as() {
        this.aC.a(new cfu(), cft.class);
        this.aC.a(new cfk(), cfj.class);
        this.aC.a(new cfh(), cfg.class);
        this.aC.a(new cfq(), cfp.class);
        this.aC.a(new cfn(), cfm.class);
    }

    private void at() throws LWJGLException {
        Display.setResizable((boolean)true);
        Display.setTitle((String)("Loading " + Main.instance.name + "" + Main.version));
        try {
            Display.create((PixelFormat)new PixelFormat().withDepthBits(24));
        }
        catch (LWJGLException lwjglexception) {
            J.error("Couldn't set pixel format", (Throwable)lwjglexception);
            try {
                Thread.sleep(1000L);
            }
            catch (InterruptedException interruptedException) {
                // empty catch block
            }
            if (this.T) {
                this.ay();
            }
            Display.create();
        }
    }

    private void au() throws LWJGLException {
        if (this.T) {
            Display.setFullscreen((boolean)true);
            DisplayMode displaymode = Display.getDisplayMode();
            this.d = Math.max(1, displaymode.getWidth());
            this.e = Math.max(1, displaymode.getHeight());
        } else {
            Display.setDisplayMode((DisplayMode)new DisplayMode(this.d, this.e));
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void av() {
        h.a util$enumos = h.a();
        if (util$enumos != h.a.d) {
            InputStream inputstream1;
            InputStream inputstream;
            block5: {
                inputstream = null;
                inputstream1 = null;
                try {
                    inputstream = this.aE.c(new nd("icons/icon_16x16.png"));
                    inputstream1 = this.aE.c(new nd("icons/icon_32x32.png"));
                    if (inputstream == null || inputstream1 == null) break block5;
                    Display.setIcon((ByteBuffer[])new ByteBuffer[]{this.a(inputstream), this.a(inputstream1)});
                }
                catch (IOException ioexception) {
                    try {
                        J.error("Couldn't set icon", (Throwable)ioexception);
                    }
                    catch (Throwable throwable) {
                        IOUtils.closeQuietly(inputstream);
                        IOUtils.closeQuietly(inputstream1);
                        throw throwable;
                    }
                    IOUtils.closeQuietly((InputStream)inputstream);
                    IOUtils.closeQuietly(inputstream1);
                }
            }
            IOUtils.closeQuietly((InputStream)inputstream);
            IOUtils.closeQuietly((InputStream)inputstream1);
        }
    }

    private static boolean aw() {
        String[] astring;
        for (String s2 : astring = new String[]{"sun.arch.data.model", "com.ibm.vm.bitmode", "os.arch"}) {
            String s1 = System.getProperty(s2);
            if (s1 == null || !s1.contains("64")) continue;
            return true;
        }
        return false;
    }

    public bvb b() {
        return this.aJ;
    }

    public String c() {
        return this.an;
    }

    public String d() {
        return this.ao;
    }

    private void ax() {
        Thread thread = new Thread("Timer hack thread"){

            @Override
            public void run() {
                while (bhz.this.C) {
                    try {
                        Thread.sleep(Integer.MAX_VALUE);
                    }
                    catch (InterruptedException interruptedException) {}
                }
            }
        };
        thread.setDaemon(true);
        thread.start();
    }

    public void a(b crash) {
        this.V = true;
        this.W = crash;
    }

    public void c(b crashReportIn) {
        File file1 = new File(bhz.z().w, "crash-reports");
        File file2 = new File(file1, "crash-" + new SimpleDateFormat("yyyy-MM-dd_HH.mm.ss").format(new Date()) + "-client.txt");
        ng.a(crashReportIn.e());
        if (crashReportIn.f() != null) {
            ng.a("#@!@# Game crashed! Crash report saved to: #@!@# " + crashReportIn.f());
            System.exit(-1);
        } else if (crashReportIn.a(file2)) {
            ng.a("#@!@# Game crashed! Crash report saved to: #@!@# " + file2.getAbsolutePath());
            System.exit(-1);
        } else {
            ng.a("#@?@# Game crashed! Crash report could not be saved. #@?@#");
            System.exit(-2);
        }
    }

    public boolean e() {
        return this.aG.a() || this.t.aK;
    }

    public void f() {
        ArrayList list = Lists.newArrayList(this.aD);
        if (this.al != null) {
            this.al.aM();
        }
        for (ces.a resourcepackrepository$entry : this.aF.e()) {
            list.add(resourcepackrepository$entry.c());
        }
        if (this.aF.g() != null) {
            list.add(this.aF.g());
        }
        try {
            this.aB.a(list);
        }
        catch (RuntimeException runtimeexception) {
            J.info("Caught error stitching, removing all assigned resourcepacks", (Throwable)runtimeexception);
            list.clear();
            list.addAll(this.aD);
            this.aF.a(Collections.emptyList());
            this.aB.a(list);
            this.t.m.clear();
            this.t.n.clear();
            this.t.b();
        }
        this.aG.a(list);
        if (this.g != null) {
            this.g.a();
        }
    }

    private ByteBuffer a(InputStream imageStream) throws IOException {
        BufferedImage bufferedimage = ImageIO.read(imageStream);
        int[] aint = bufferedimage.getRGB(0, 0, bufferedimage.getWidth(), bufferedimage.getHeight(), null, 0, bufferedimage.getWidth());
        ByteBuffer bytebuffer = ByteBuffer.allocate(4 * aint.length);
        for (int i2 : aint) {
            bytebuffer.putInt(i2 << 8 | i2 >> 24 & 0xFF);
        }
        bytebuffer.flip();
        return bytebuffer;
    }

    private void ay() throws LWJGLException {
        HashSet set = Sets.newHashSet();
        Collections.addAll(set, Display.getAvailableDisplayModes());
        DisplayMode displaymode = Display.getDesktopDisplayMode();
        if (!set.contains((Object)displaymode) && h.a() == h.a.d) {
            block0: for (DisplayMode displaymode1 : L) {
                boolean flag = true;
                for (DisplayMode displaymode2 : set) {
                    if (displaymode2.getBitsPerPixel() != 32 || displaymode2.getWidth() != displaymode1.getWidth() || displaymode2.getHeight() != displaymode1.getHeight()) continue;
                    flag = false;
                    break;
                }
                if (flag) continue;
                for (DisplayMode displaymode3 : set) {
                    if (displaymode3.getBitsPerPixel() != 32 || displaymode3.getWidth() != displaymode1.getWidth() / 2 || displaymode3.getHeight() != displaymode1.getHeight() / 2) continue;
                    displaymode = displaymode3;
                    continue block0;
                }
            }
        }
        Display.setDisplayMode((DisplayMode)displaymode);
        this.d = displaymode.getWidth();
        this.e = displaymode.getHeight();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void a(cdp textureManagerInstance) throws LWJGLException {
        bir scaledresolution = new bir(this);
        int i2 = bir.e();
        bvb framebuffer = new bvb(scaledresolution.a() * i2, scaledresolution.b() * i2, true);
        framebuffer.a(false);
        buq.n(5889);
        buq.F();
        buq.a(0.0, scaledresolution.a(), scaledresolution.b(), 0.0, 1000.0, 3000.0);
        buq.n(5888);
        buq.F();
        buq.c(0.0f, 0.0f, -2000.0f);
        buq.g();
        buq.p();
        buq.j();
        buq.y();
        InputStream inputstream = null;
        try {
            inputstream = this.aE.a(K);
            this.aN = textureManagerInstance.a("logo", new cde(ImageIO.read(inputstream)));
            textureManagerInstance.a(this.aN);
        }
        catch (IOException ioexception) {
            try {
                J.error("Unable to load logo: {}", (Object)K, (Object)ioexception);
            }
            catch (Throwable throwable) {
                IOUtils.closeQuietly(inputstream);
                throw throwable;
            }
            IOUtils.closeQuietly((InputStream)inputstream);
        }
        IOUtils.closeQuietly((InputStream)inputstream);
        bvc tessellator = bvc.a();
        bui bufferbuilder = tessellator.c();
        bufferbuilder.a(7, cdw.i);
        bufferbuilder.b(0.0, (double)this.e, 0.0).a(0.0, 0.0).b(255, 255, 255, 255).d();
        bufferbuilder.b((double)this.d, (double)this.e, 0.0).a(0.0, 0.0).b(255, 255, 255, 255).d();
        bufferbuilder.b((double)this.d, 0.0, 0.0).a(0.0, 0.0).b(255, 255, 255, 255).d();
        bufferbuilder.b(0.0, 0.0, 0.0).a(0.0, 0.0).b(255, 255, 255, 255).d();
        tessellator.b();
        buq.c(1.0f, 1.0f, 1.0f, 1.0f);
        int j2 = 256;
        int k2 = 256;
        this.a((scaledresolution.a() - 256) / 2, (scaledresolution.b() - 256) / 2, 0, 0, 256, 256, 255, 255, 255, 255);
        buq.g();
        buq.p();
        framebuffer.e();
        framebuffer.c(scaledresolution.a() * i2, scaledresolution.b() * i2);
        buq.e();
        buq.a(516, 0.1f);
        this.i();
    }

    public void a(int posX, int posY, int texU, int texV, int width, int height, int red, int green, int blue, int alpha) {
        bui bufferbuilder = bvc.a().c();
        bufferbuilder.a(7, cdw.i);
        float f2 = 0.00390625f;
        float f1 = 0.00390625f;
        bufferbuilder.b((double)posX, (double)(posY + height), 0.0).a((float)texU * 0.00390625f, (float)(texV + height) * 0.00390625f).b(red, green, blue, alpha).d();
        bufferbuilder.b((double)(posX + width), (double)(posY + height), 0.0).a((float)(texU + width) * 0.00390625f, (float)(texV + height) * 0.00390625f).b(red, green, blue, alpha).d();
        bufferbuilder.b((double)(posX + width), (double)posY, 0.0).a((float)(texU + width) * 0.00390625f, (float)texV * 0.00390625f).b(red, green, blue, alpha).d();
        bufferbuilder.b((double)posX, (double)posY, 0.0).a((float)texU * 0.00390625f, (float)texV * 0.00390625f).b(red, green, blue, alpha).d();
        bvc.a().b();
    }

    public bfe g() {
        return this.aq;
    }

    public void a(@Nullable bli guiScreenIn) {
        if (this.m != null) {
            this.m.m();
        }
        if (guiScreenIn == null && this.f == null) {
            guiScreenIn = new blp();
        } else if (guiScreenIn == null && this.h.cd() <= 0.0f) {
            guiScreenIn = new bkt(null);
        }
        if (guiScreenIn instanceof blp || guiScreenIn instanceof bnd) {
            this.t.ax = false;
            this.q.d().a(true);
        }
        this.m = guiScreenIn;
        if (guiScreenIn != null) {
            this.p();
            bhw.b();
            while (Mouse.next()) {
            }
            while (Keyboard.next()) {
            }
            bir scaledresolution = new bir(this);
            int i2 = scaledresolution.a();
            int j2 = scaledresolution.b();
            guiScreenIn.a(this, i2, j2);
            this.r = false;
        } else {
            this.aL.d();
            this.o();
        }
    }

    private void a(String message) {
        int i2 = buq.L();
        if (i2 != 0) {
            String s2 = GLU.gluErrorString(i2);
            J.error("########## GL ERROR ##########");
            J.error("@ {}", (Object)message);
            J.error("{}: {}", (Object)i2, (Object)s2);
        }
    }

    public void h() {
        try {
            Main.instance.stopClient();
            J.info("Stopping!");
            try {
                this.a((brz)null);
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            this.aL.c();
        }
        finally {
            Display.destroy();
            if (!this.V) {
                System.exit(0);
            }
        }
        System.gc();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void az() throws IOException {
        boolean flag;
        long i2 = System.nanoTime();
        this.B.a("root");
        if (Display.isCreated() && Display.isCloseRequested()) {
            this.n();
        }
        this.Y.a();
        this.B.a("scheduledExecutables");
        Queue<FutureTask<?>> queue = this.aQ;
        synchronized (queue) {
            while (!this.aQ.isEmpty()) {
                h.a(this.aQ.poll(), J);
            }
        }
        this.B.b();
        long l2 = System.nanoTime();
        this.B.a("tick");
        for (int j2 = 0; j2 < Math.min(10, this.Y.a); ++j2) {
            this.t();
        }
        this.B.c("preRenderErrors");
        long i1 = System.nanoTime() - l2;
        this.a("Pre render");
        this.B.c("sound");
        this.aL.a(this.h, this.Y.elapsedPartialTicks);
        this.B.b();
        this.B.a("render");
        buq.G();
        buq.m(16640);
        this.aJ.a(true);
        this.B.a("display");
        buq.y();
        this.B.b();
        if (!this.r) {
            this.B.c("gameRenderer");
            this.o.a(this.ag ? this.ah : this.Y.elapsedPartialTicks, i2);
            this.B.c("toasts");
            this.aU.a(new bir(this));
            this.B.b();
        }
        this.B.b();
        if (this.t.ax && this.t.ay && !this.t.av) {
            if (!this.B.a) {
                this.B.a();
            }
            this.B.a = true;
            this.a(i1);
        } else {
            this.B.a = false;
            this.I = System.nanoTime();
        }
        this.aJ.e();
        buq.H();
        buq.G();
        this.aJ.c(this.d, this.e);
        buq.H();
        buq.G();
        this.o.b(this.Y.elapsedPartialTicks);
        buq.H();
        this.B.a("root");
        this.i();
        Thread.yield();
        this.a("Post render");
        ++this.aW;
        boolean bl2 = flag = this.E() && this.m != null && this.m.d() && !this.al.a();
        if (this.ag != flag) {
            if (this.ag) {
                this.ah = this.Y.elapsedPartialTicks;
            } else {
                this.Y.elapsedPartialTicks = this.ah;
            }
            this.ag = flag;
        }
        long k2 = System.nanoTime();
        this.z.a(k2 - this.A);
        this.A = k2;
        while (bhz.I() >= this.aV + 1000L) {
            ar = this.aW;
            Object[] arrobject = new Object[8];
            arrobject[0] = ar;
            arrobject[1] = bxp.a;
            arrobject[2] = bxp.a == 1 ? "" : "s";
            arrobject[3] = (float)this.t.i == bib.a.i.f() ? "inf" : Integer.valueOf(this.t.i);
            arrobject[4] = this.t.v ? " vsync" : "";
            Object object = arrobject[5] = this.t.k ? "" : " fast";
            arrobject[6] = this.t.j == 0 ? "" : (this.t.j == 1 ? " fast-clouds" : " fancy-clouds");
            arrobject[7] = cig.f() ? " vbo" : "";
            this.D = String.format("%d fps (%d chunk update%s) T: %s%s%s%s%s", arrobject);
            bxp.a = 0;
            this.aV += 1000L;
            this.aW = 0;
            this.Z.b();
            if (this.Z.d()) continue;
            this.Z.a();
        }
        if (this.l()) {
            this.B.a("fpslimit_wait");
            Display.sync((int)this.k());
            this.B.b();
        }
        this.B.b();
        frameTime = (double)(System.nanoTime() - i2) / 1000000.0;
    }

    public void i() {
        this.B.a("display_update");
        Display.update();
        this.B.b();
        this.j();
    }

    protected void j() {
        if (!this.T && Display.wasResized()) {
            int i2 = this.d;
            int j2 = this.e;
            this.d = Display.getWidth();
            this.e = Display.getHeight();
            if (this.d != i2 || this.e != j2) {
                if (this.d <= 0) {
                    this.d = 1;
                }
                if (this.e <= 0) {
                    this.e = 1;
                }
                this.a(this.d, this.e);
            }
        }
    }

    public int k() {
        if (Main.instance.featureDirector.getFeatureByClass(Optimization.class).isToggled() && Optimization.cpu.getBoolValue() && !Display.isActive()) {
            return 1;
        }
        return this.f == null && this.m != null ? 30 : this.t.i;
    }

    public boolean l() {
        return (float)this.k() < bib.a.i.f();
    }

    public void m() {
        try {
            b = new byte[0];
            this.g.l();
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        try {
            if (!Main.instance.featureDirector.getFeatureByClass(FastWorldLoad.class).isToggled()) {
                System.gc();
                this.a((brz)null);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        System.gc();
    }

    private void b(int keyCount) {
        List<rj.a> list = this.B.b(this.aZ);
        if (!list.isEmpty()) {
            rj.a profiler$result = list.remove(0);
            if (keyCount == 0) {
                int i2;
                if (!profiler$result.c.isEmpty() && (i2 = this.aZ.lastIndexOf(46)) >= 0) {
                    this.aZ = this.aZ.substring(0, i2);
                }
            } else if (--keyCount < list.size() && !"unspecified".equals(list.get((int)keyCount).c)) {
                if (!this.aZ.isEmpty()) {
                    this.aZ = this.aZ + ".";
                }
                this.aZ = this.aZ + list.get((int)keyCount).c;
            }
        }
    }

    private void a(long elapsedTicksTime) {
        if (this.B.a) {
            List<rj.a> list = this.B.b(this.aZ);
            rj.a profiler$result = list.remove(0);
            buq.m(256);
            buq.n(5889);
            buq.h();
            buq.F();
            buq.a(0.0, this.d, this.e, 0.0, 1000.0, 3000.0);
            buq.n(5888);
            buq.F();
            buq.c(0.0f, 0.0f, -2000.0f);
            buq.d(1.0f);
            buq.z();
            bvc tessellator = bvc.a();
            bui bufferbuilder = tessellator.c();
            int i2 = 160;
            int j2 = this.d - 160 - 10;
            int k2 = this.e - 320;
            buq.m();
            bufferbuilder.a(7, cdw.f);
            bufferbuilder.b((double)((float)j2 - 176.0f), (double)((float)k2 - 96.0f - 16.0f), 0.0).b(200, 0, 0, 0).d();
            bufferbuilder.b((double)((float)j2 - 176.0f), (double)(k2 + 320), 0.0).b(200, 0, 0, 0).d();
            bufferbuilder.b((double)((float)j2 + 176.0f), (double)(k2 + 320), 0.0).b(200, 0, 0, 0).d();
            bufferbuilder.b((double)((float)j2 + 176.0f), (double)((float)k2 - 96.0f - 16.0f), 0.0).b(200, 0, 0, 0).d();
            tessellator.b();
            buq.l();
            double d0 = 0.0;
            for (int l2 = 0; l2 < list.size(); ++l2) {
                rj.a profiler$result1 = list.get(l2);
                int i1 = ri.c(profiler$result1.a / 4.0) + 1;
                bufferbuilder.a(6, cdw.f);
                int j1 = profiler$result1.a();
                int k1 = j1 >> 16 & 0xFF;
                int l1 = j1 >> 8 & 0xFF;
                int i22 = j1 & 0xFF;
                bufferbuilder.b((double)j2, (double)k2, 0.0).b(k1, l1, i22, 255).d();
                for (int j22 = i1; j22 >= 0; --j22) {
                    float f2 = (float)((d0 + profiler$result1.a * (double)j22 / (double)i1) * (Math.PI * 2) / 100.0);
                    float f1 = ri.a(f2) * 160.0f;
                    float f22 = ri.b(f2) * 160.0f * 0.5f;
                    bufferbuilder.b((double)((float)j2 + f1), (double)((float)k2 - f22), 0.0).b(k1, l1, i22, 255).d();
                }
                tessellator.b();
                bufferbuilder.a(5, cdw.f);
                for (int i3 = i1; i3 >= 0; --i3) {
                    float f3 = (float)((d0 + profiler$result1.a * (double)i3 / (double)i1) * (Math.PI * 2) / 100.0);
                    float f4 = ri.a(f3) * 160.0f;
                    float f5 = ri.b(f3) * 160.0f * 0.5f;
                    bufferbuilder.b((double)((float)j2 + f4), (double)((float)k2 - f5), 0.0).b(k1 >> 1, l1 >> 1, i22 >> 1, 255).d();
                    bufferbuilder.b((double)((float)j2 + f4), (double)((float)k2 - f5 + 10.0f), 0.0).b(k1 >> 1, l1 >> 1, i22 >> 1, 255).d();
                }
                tessellator.b();
                d0 += profiler$result1.a;
            }
            DecimalFormat decimalformat = new DecimalFormat("##0.00");
            buq.y();
            String s2 = "";
            if (!"unspecified".equals(profiler$result.c)) {
                s2 = s2 + "[0] ";
            }
            s2 = profiler$result.c.isEmpty() ? s2 + "ROOT " : s2 + profiler$result.c + ' ';
            int l2 = 0xFFFFFF;
            k.a(s2, j2 - 160, k2 - 80 - 16, 0xFFFFFF);
            s2 = decimalformat.format(profiler$result.b) + "%";
            k.a(s2, j2 + 160 - k.a(s2), k2 - 80 - 16, 0xFFFFFF);
            for (int k22 = 0; k22 < list.size(); ++k22) {
                rj.a profiler$result2 = list.get(k22);
                StringBuilder stringbuilder = new StringBuilder();
                if ("unspecified".equals(profiler$result2.c)) {
                    stringbuilder.append("[?] ");
                } else {
                    stringbuilder.append("[").append(k22 + 1).append("] ");
                }
                String s1 = stringbuilder.append(profiler$result2.c).toString();
                k.a(s1, j2 - 160, k2 + 80 + k22 * 8 + 20, profiler$result2.a());
                s1 = decimalformat.format(profiler$result2.a) + "%";
                k.a(s1, j2 + 160 - 50 - k.a(s1), k2 + 80 + k22 * 8 + 20, profiler$result2.a());
                s1 = decimalformat.format(profiler$result2.b) + "%";
                k.a(s1, j2 + 160 - k.a(s1), k2 + 80 + k22 * 8 + 20, profiler$result2.a());
            }
        }
    }

    public void n() {
        System.exit(0);
    }

    public void o() {
        if (Display.isActive() && !this.x) {
            if (!a) {
                bhw.a();
            }
            this.x = true;
            this.v.a();
            this.a((bli)null);
            this.ai = 10000;
        }
    }

    public void p() {
        if (this.x) {
            this.x = false;
            this.v.b();
        }
    }

    public void q() {
        if (this.m == null) {
            this.a(new ble());
            if (this.E() && !this.al.a()) {
                this.aL.a();
            }
        }
    }

    private void b(boolean bl2) {
        boolean bl3;
        if (!bl2) {
            this.ai = 0;
        }
        boolean bl4 = Main.instance.featureDirector.getFeatureByClass(MultiAction.class).isToggled() ? true : (bl3 = (this.bl2 = !this.h.cG()));
        if (this.ai <= 0 && this.bl2) {
            if (bl2 && this.s != null && this.s.a == bha.a.b) {
                et blockPos = this.s.a();
                if (this.f.o(blockPos).a() != bcx.a && this.c.b(blockPos, this.s.b)) {
                    this.j.a(blockPos, this.s.b);
                    this.h.a(tz.a);
                }
            } else {
                this.c.c();
            }
        }
    }

    public void aA() {
        if (this.ai <= 0) {
            EventAttackClient mouseAttackEvent = new EventAttackClient(this.s.d);
            if (this.s != null) {
                mouseAttackEvent.call();
            }
            if (this.s == null) {
                J.error("Null returned as 'hitResult', this shouldn't happen!");
                if (this.c.g()) {
                    this.ai = 10;
                }
            } else if (!this.h.L()) {
                switch (this.s.a) {
                    case c: {
                        this.c.a(this.h, this.s.d);
                        break;
                    }
                    case b: {
                        et blockpos = this.s.a();
                        if (this.f.o(blockpos).a() != bcx.a) {
                            this.c.a(blockpos, this.s.b);
                            break;
                        }
                    }
                    case a: {
                        if (this.c.g()) {
                            this.ai = 10;
                        }
                        this.h.ds();
                    }
                }
                this.h.a(tz.a);
            }
        }
    }

    public void aB() {
        if (!this.c.m()) {
            this.as = 4;
            if (!this.h.L()) {
                if (this.s == null) {
                    J.warn("Null returned as 'hitResult', this shouldn't happen!");
                }
                for (tz enumhand : tz.values()) {
                    ain itemstack = this.h.b(enumhand);
                    if (this.s != null) {
                        switch (this.s.a) {
                            case c: {
                                if (this.c.a(this.h, this.s.d, this.s, enumhand) == ub.a) {
                                    return;
                                }
                                if (this.c.a((aeb)this.h, this.s.d, enumhand) != ub.a) break;
                                return;
                            }
                            case b: {
                                et blockpos = this.s.a();
                                if (this.f.o(blockpos).a() == bcx.a) break;
                                int i2 = itemstack.E();
                                ub enumactionresult = this.c.a(this.h, this.f, blockpos, this.s.b, this.s.c, enumhand);
                                if (enumactionresult != ub.a) break;
                                this.h.a(enumhand);
                                if (!itemstack.b() && (itemstack.E() != i2 || this.c.h())) {
                                    this.o.c.a(enumhand);
                                }
                                return;
                            }
                        }
                    }
                    if (itemstack.b() || this.c.a((aeb)this.h, this.f, enumhand) != ub.a) continue;
                    this.o.c.a(enumhand);
                    return;
                }
            }
        }
    }

    public void r() {
        try {
            this.t.u = this.T = !this.T;
            if (this.T) {
                this.ay();
                this.d = Display.getDisplayMode().getWidth();
                this.e = Display.getDisplayMode().getHeight();
                if (this.d <= 0) {
                    this.d = 1;
                }
                if (this.e <= 0) {
                    this.e = 1;
                }
            } else {
                Display.setDisplayMode((DisplayMode)new DisplayMode(this.aj, this.ak));
                this.d = this.aj;
                this.e = this.ak;
                if (this.d <= 0) {
                    this.d = 1;
                }
                if (this.e <= 0) {
                    this.e = 1;
                }
            }
            if (this.m != null) {
                this.a(this.d, this.e);
            } else {
                this.aC();
            }
            Display.setFullscreen((boolean)this.T);
            Display.setVSyncEnabled((boolean)this.t.v);
            this.i();
        }
        catch (Exception exception) {
            J.error("Couldn't toggle fullscreen", (Throwable)exception);
        }
    }

    private void a(int width, int height) {
        this.d = Math.max(1, width);
        this.e = Math.max(1, height);
        if (this.m != null) {
            bir scaledresolution = new bir(this);
            this.m.b(this, scaledresolution.a(), scaledresolution.b());
        }
        this.n = new bic(this);
        this.aC();
    }

    private void aC() {
        this.aJ.a(this.d, this.e);
        if (this.o != null) {
            this.o.a(this.d, this.e);
        }
    }

    public chj s() {
        return this.aM;
    }

    public void t() throws IOException {
        TickEvent event = new TickEvent();
        event.call();
        DiscordHelper.update();
        if (this.as > 0) {
            --this.as;
        }
        this.B.a("gui");
        if (!this.ag) {
            this.q.c();
        }
        this.B.b();
        this.o.a(1.0f);
        this.aY.a(this.f, this.s);
        this.B.a("gameMode");
        if (!this.ag && this.f != null) {
            this.c.e();
        }
        this.B.c("textures");
        if (this.f != null) {
            this.Q.e();
        }
        if (this.m == null && this.h != null) {
            if (this.h.cd() <= 0.0f && !(this.m instanceof bkt)) {
                this.a((bli)null);
            } else if (this.h.cz() && this.f != null) {
                this.a(new bkz());
            }
        } else if (this.m != null && this.m instanceof bkz && !this.h.cz()) {
            this.a((bli)null);
        }
        if (this.m != null) {
            this.ai = 10000;
        }
        if (this.m != null) {
            try {
                this.m.q();
            }
            catch (Throwable throwable1) {
                b crashreport = b.a(throwable1, "Updating screen events");
                c crashreportcategory = crashreport.a("Affected screen");
                crashreportcategory.a("Screen name", new d<String>(){

                    public String a() throws Exception {
                        return bhz.this.m.getClass().getCanonicalName();
                    }
                });
                throw new f(crashreport);
            }
            if (this.m != null) {
                try {
                    this.m.e();
                }
                catch (Throwable throwable) {
                    b crashreport1 = b.a(throwable, "Ticking screen");
                    c crashreportcategory1 = crashreport1.a("Affected screen");
                    crashreportcategory1.a("Screen name", new d<String>(){

                        public String a() throws Exception {
                            return bhz.this.m.getClass().getCanonicalName();
                        }
                    });
                    throw new f(crashreport1);
                }
            }
        }
        if (this.m == null || this.m.p) {
            this.B.c("mouse");
            this.aG();
            if (this.ai > 0) {
                --this.ai;
            }
            this.B.c("keyboard");
            this.aD();
        }
        if (this.f != null) {
            if (this.h != null) {
                ++this.av;
                if (this.av == 30) {
                    this.av = 0;
                    this.f.i(this.h);
                }
            }
            this.B.c("gameRenderer");
            if (!this.ag) {
                this.o.e();
            }
            this.B.c("levelRenderer");
            if (!this.ag) {
                this.g.k();
            }
            this.B.c("level");
            if (!this.ag) {
                if (this.f.ai() > 0) {
                    this.f.d(this.f.ai() - 1);
                }
                this.f.k();
            }
        } else if (this.o.a()) {
            this.o.b();
        }
        if (!this.ag) {
            this.aM.e();
            this.aL.e();
        }
        if (this.f != null) {
            if (!this.ag) {
                this.f.a(this.f.ag() != tx.a, true);
                this.aY.d();
                try {
                    this.f.d();
                }
                catch (Throwable throwable2) {
                    b crashreport2 = b.a(throwable2, "Exception in world tick");
                    if (this.f == null) {
                        c crashreportcategory2 = crashreport2.a("Affected level");
                        crashreportcategory2.a("Problem", "Level is null!");
                    } else {
                        this.f.a(crashreport2);
                    }
                    throw new f(crashreport2);
                }
            }
            this.B.c("animateTick");
            if (!this.ag && this.f != null) {
                this.f.b(ri.c(this.h.p), ri.c(this.h.q), ri.c(this.h.r));
            }
            this.B.c("particles");
            if (!this.ag) {
                this.j.a();
            }
        } else if (this.ay != null) {
            this.B.c("pendingConnection");
            this.ay.a();
        }
        this.B.b();
        this.y = bhz.I();
    }

    private void aD() throws IOException {
        while (Keyboard.next()) {
            boolean flag;
            int i2;
            int n2 = i2 = Keyboard.getEventKey() == 0 ? Keyboard.getEventCharacter() + 256 : Keyboard.getEventKey();
            if (this.aA > 0L) {
                if (bhz.I() - this.aA >= 6000L) {
                    throw new f(new b("Manually triggered debug crash", new Throwable()));
                }
                if (!Keyboard.isKeyDown((int)46) || !Keyboard.isKeyDown((int)61)) {
                    this.aA = -1L;
                }
            } else if (Keyboard.isKeyDown((int)46) && Keyboard.isKeyDown((int)61)) {
                this.aX = true;
                this.aA = bhz.I();
            }
            this.W();
            if (this.m != null) {
                this.m.l();
            }
            if (flag = Keyboard.getEventKeyState()) {
                if (i2 == 62 && this.o != null) {
                    this.o.c();
                }
                boolean flag1 = false;
                EventKey eventKey = new EventKey(i2);
                eventKey.call();
                if (this.m == null) {
                    if (i2 == 1) {
                        this.q();
                    }
                    flag1 = Keyboard.isKeyDown((int)61) && this.c(i2);
                    this.aX |= flag1;
                    if (i2 == 59) {
                        boolean bl2 = this.t.av = !this.t.av;
                    }
                }
                if (flag1) {
                    bhw.a(i2, false);
                } else {
                    bhw.a(i2, true);
                    bhw.a(i2);
                }
                if (!this.t.ay) continue;
                if (i2 == 11) {
                    this.b(0);
                }
                for (int j2 = 0; j2 < 9; ++j2) {
                    if (i2 != 2 + j2) continue;
                    this.b(j2 + 1);
                }
                continue;
            }
            bhw.a(i2, false);
            if (i2 != 61) continue;
            if (this.aX) {
                this.aX = false;
                continue;
            }
            this.t.ax = !this.t.ax;
            this.t.ay = this.t.ax && bli.s();
            this.t.az = this.t.ax && bli.t();
        }
        this.aE();
    }

    private boolean c(int p_184122_1_) {
        if (p_184122_1_ == 30) {
            this.g.a();
            this.a("debug.reload_chunks.message", new Object[0]);
            return true;
        }
        if (p_184122_1_ == 48) {
            boolean flag1 = !this.aa.b();
            this.aa.b(flag1);
            this.a(flag1 ? "debug.show_hitboxes.on" : "debug.show_hitboxes.off", new Object[0]);
            return true;
        }
        if (p_184122_1_ == 32) {
            if (this.q != null) {
                this.q.d().a(false);
            }
            return true;
        }
        if (p_184122_1_ == 33) {
            this.t.a(bib.a.f, bli.s() ? -1 : 1);
            this.a("debug.cycle_renderdistance.message", this.t.e);
            return true;
        }
        if (p_184122_1_ == 34) {
            boolean flag = this.p.b();
            this.a(flag ? "debug.chunk_boundaries.on" : "debug.chunk_boundaries.off", new Object[0]);
            return true;
        }
        if (p_184122_1_ == 35) {
            this.t.z = !this.t.z;
            this.a(this.t.z ? "debug.advanced_tooltips.on" : "debug.advanced_tooltips.off", new Object[0]);
            this.t.b();
            return true;
        }
        if (p_184122_1_ == 49) {
            if (!this.h.a(2, "")) {
                this.a("debug.creative_spectator.error", new Object[0]);
            } else if (this.h.z()) {
                this.h.g("/gamemode spectator");
            } else if (this.h.y()) {
                this.h.g("/gamemode creative");
            }
            return true;
        }
        if (p_184122_1_ == 25) {
            this.t.A = !this.t.A;
            this.t.b();
            this.a(this.t.A ? "debug.pause_focus.on" : "debug.pause_focus.off", new Object[0]);
            return true;
        }
        if (p_184122_1_ == 16) {
            this.a("debug.help.message", new Object[0]);
            biz guinewchat = this.q.d();
            guinewchat.a(new hp("debug.reload_chunks.help", new Object[0]));
            guinewchat.a(new hp("debug.show_hitboxes.help", new Object[0]));
            guinewchat.a(new hp("debug.clear_chat.help", new Object[0]));
            guinewchat.a(new hp("debug.cycle_renderdistance.help", new Object[0]));
            guinewchat.a(new hp("debug.chunk_boundaries.help", new Object[0]));
            guinewchat.a(new hp("debug.advanced_tooltips.help", new Object[0]));
            guinewchat.a(new hp("debug.creative_spectator.help", new Object[0]));
            guinewchat.a(new hp("debug.pause_focus.help", new Object[0]));
            guinewchat.a(new hp("debug.help.help", new Object[0]));
            guinewchat.a(new hp("debug.reload_resourcepacks.help", new Object[0]));
            return true;
        }
        if (p_184122_1_ == 20) {
            this.a("debug.reload_resourcepacks.message", new Object[0]);
            this.f();
            return true;
        }
        return false;
    }

    private void aE() {
        boolean flag2;
        while (this.t.ak.g()) {
            ++this.t.aw;
            if (this.t.aw > 2) {
                this.t.aw = 0;
            }
            if (this.t.aw == 0) {
                this.o.a(this.aa());
            } else if (this.t.aw == 1) {
                this.o.a((ve)null);
            }
            this.g.o();
        }
        while (this.t.al.g()) {
            this.t.aB = !this.t.aB;
        }
        for (int i2 = 0; i2 < 9; ++i2) {
            boolean flag = this.t.aq.e();
            boolean flag1 = this.t.ar.e();
            if (!this.t.ap[i2].g()) continue;
            if (this.h.y()) {
                this.q.g().a(i2);
                continue;
            }
            if (!this.h.z() || this.m != null || !flag1 && !flag) {
                this.h.bv.d = i2;
                continue;
            }
            bmn.a(this, i2, flag1, flag);
        }
        while (this.t.aa.g()) {
            if (this.c.j()) {
                this.h.B();
                continue;
            }
            this.aY.a();
            this.a(new bmv(this.h));
        }
        while (this.t.ao.g()) {
            this.a(new blz(this.h.d.f()));
        }
        while (this.t.ab.g()) {
            if (this.h.y()) continue;
            this.v().a(new lo(lo.a.g, et.a, fa.a));
        }
        while (this.t.ac.g()) {
            if (this.h.y()) continue;
            this.h.a(bli.r());
        }
        boolean bl2 = flag2 = this.t.o != aeb.b.c;
        if (flag2) {
            while (this.t.ag.g()) {
                this.a(new bkl());
            }
            if (this.m == null && this.t.ai.g()) {
                this.a(new bkl("/"));
            }
        }
        if (this.h.cG()) {
            if (!this.t.ad.e()) {
                this.c.c(this.h);
            }
            while (this.t.ae.g()) {
            }
            while (this.t.ad.g()) {
            }
            while (this.t.af.g()) {
            }
        } else {
            while (this.t.ae.g()) {
                this.aA();
            }
            while (this.t.ad.g()) {
                this.aB();
            }
            while (this.t.af.g()) {
                this.aH();
            }
        }
        if (this.t.ad.e() && this.as == 0 && !this.h.cG()) {
            this.aB();
        }
        this.b(this.m == null && this.t.ae.e() && this.x);
    }

    private void aG() throws IOException {
        while (Mouse.next()) {
            long j2;
            int i2 = Mouse.getEventButton();
            bhw.a(i2 - 100, Mouse.getEventButtonState());
            if (Mouse.getEventButtonState()) {
                EventMouseKey eventMouse = new EventMouseKey(i2);
                eventMouse.call();
                if (this.h.y() && i2 == 2) {
                    this.q.g().b();
                } else {
                    bhw.a(i2 - 100);
                }
            }
            if ((j2 = bhz.I() - this.y) > 200L) continue;
            int k2 = Mouse.getEventDWheel();
            if (k2 != 0) {
                if (this.h.y()) {
                    int n2 = k2 = k2 < 0 ? -1 : 1;
                    if (this.q.g().a()) {
                        this.q.g().b(-k2);
                    } else {
                        float f2 = ri.a(this.h.bO.a() + (float)k2 * 0.005f, 0.0f, 0.2f);
                        this.h.bO.a(f2);
                    }
                } else {
                    this.h.bv.f(k2);
                }
            }
            if (this.m == null) {
                if (this.x || !Mouse.getEventButtonState()) continue;
                this.o();
                continue;
            }
            if (this.m == null) continue;
            this.m.k();
        }
    }

    private void a(String p_190521_1_, Object ... p_190521_2_) {
        this.q.d().a(new ho("").a(new hp("debug.prefix", new Object[0]).a(new hn().a(a.o).a(true))).a(" ").a(new hp(p_190521_1_, p_190521_2_)));
    }

    public void a(String folderName, String worldName, @Nullable amv worldSettingsIn) {
        bfc isavehandler;
        bfb worldinfo;
        if (!Main.instance.featureDirector.getFeatureByClass(FastWorldLoad.class).isToggled()) {
            this.a((brz)null);
            System.gc();
        }
        if ((worldinfo = (isavehandler = this.aq.a(folderName, false)).d()) == null && worldSettingsIn != null) {
            worldinfo = new bfb(worldSettingsIn, folderName);
            isavehandler.a(worldinfo);
        }
        if (worldSettingsIn == null) {
            worldSettingsIn = new amv(worldinfo);
        }
        try {
            YggdrasilAuthenticationService yggdrasilauthenticationservice = new YggdrasilAuthenticationService(this.ap, UUID.randomUUID().toString());
            MinecraftSessionService minecraftsessionservice = yggdrasilauthenticationservice.createMinecraftSessionService();
            GameProfileRepository gameprofilerepository = yggdrasilauthenticationservice.createProfileRepository();
            pf playerprofilecache = new pf(gameprofilerepository, new File(this.w, MinecraftServer.a.getName()));
            awb.a(playerprofilecache);
            awb.a(minecraftsessionservice);
            pf.a(false);
            this.al = new chb(this, folderName, worldName, worldSettingsIn, yggdrasilauthenticationservice, minecraftsessionservice, gameprofilerepository, playerprofilecache);
            this.al.F();
            this.az = true;
        }
        catch (Throwable throwable) {
            b crashreport = b.a(throwable, "Starting integrated server");
            c crashreportcategory = crashreport.a("Starting integrated server");
            crashreportcategory.a("Level ID", folderName);
            crashreportcategory.a("Level Name", worldName);
            throw new f(crashreport);
        }
        this.n.a(cew.a("menu.loadingLevel", new Object[0]));
        while (!this.al.ao()) {
            String s2 = this.al.k();
            if (s2 != null) {
                this.n.c(cew.a(s2, new Object[0]));
            } else {
                this.n.c("");
            }
            try {
                Thread.sleep(200L);
            }
            catch (InterruptedException crashreport) {}
        }
        this.a(new blg());
        SocketAddress socketaddress = this.al.an().a();
        gw networkmanager = gw.a(socketaddress);
        networkmanager.a(new brw(networkmanager, this, null));
        networkmanager.a(new mc(socketaddress.toString(), 0, gx.d));
        networkmanager.a(new ml(this.K().e()));
        this.ay = networkmanager;
    }

    public void a(@Nullable brz worldClientIn) {
        this.a(worldClientIn, "");
    }

    public void a(@Nullable brz worldClientIn, String loadingMessage) {
        if (worldClientIn == null) {
            brx nethandlerplayclient = this.v();
            if (nethandlerplayclient != null) {
                nethandlerplayclient.b();
            }
            if (this.al != null && this.al.M()) {
                this.al.x();
            }
            this.al = null;
            this.o.k();
            this.c = null;
            bit.a.b();
        }
        this.ad = null;
        this.ay = null;
        if (this.n != null) {
            this.n.b(loadingMessage);
            if (!Main.instance.featureDirector.getFeatureByClass(FastWorldLoad.class).isToggled()) {
                this.n.c("");
            }
        }
        if (worldClientIn == null && this.f != null) {
            this.aF.h();
            this.q.i();
            this.a((bsc)null);
            this.az = false;
        }
        this.aL.b();
        this.f = worldClientIn;
        if (this.g != null) {
            this.g.a(worldClientIn);
        }
        if (this.j != null) {
            this.j.a(worldClientIn);
        }
        bwv.a.a(worldClientIn);
        if (worldClientIn != null) {
            if (!Main.instance.featureDirector.getFeatureByClass(FastWorldLoad.class).isToggled() && !this.az) {
                YggdrasilAuthenticationService authenticationservice = new YggdrasilAuthenticationService(this.ap, UUID.randomUUID().toString());
                MinecraftSessionService minecraftsessionservice = authenticationservice.createMinecraftSessionService();
                GameProfileRepository gameprofilerepository = authenticationservice.createProfileRepository();
                pf playerprofilecache = new pf(gameprofilerepository, new File(this.w, MinecraftServer.a.getName()));
                awb.a(playerprofilecache);
                awb.a(minecraftsessionservice);
                pf.a(false);
            }
            if (this.h == null) {
                this.h = this.c.a(worldClientIn, new qr(), new cif());
                this.c.b(this.h);
            }
            this.h.W();
            worldClientIn.a(this.h);
            this.h.e = new bua(this.t);
            this.c.a(this.h);
            this.ad = this.h;
        } else {
            this.aq.d();
            this.h = null;
        }
        if (!Main.instance.featureDirector.getFeatureByClass(FastWorldLoad.class).isToggled()) {
            System.gc();
        }
        this.y = 0L;
    }

    public void a(int dimension) {
        this.f.h();
        this.f.c();
        int i2 = 0;
        String s2 = null;
        if (this.h != null) {
            i2 = this.h.S();
            this.f.e(this.h);
            s2 = this.h.C();
        }
        this.ad = null;
        bub entityplayersp = this.h;
        this.h = this.c.a(this.f, this.h == null ? new qr() : this.h.D(), this.h == null ? new qj() : this.h.E());
        this.h.V().a(entityplayersp.V().c());
        this.h.am = dimension;
        this.ad = this.h;
        this.h.W();
        this.h.h(s2);
        this.f.a(this.h);
        this.c.b(this.h);
        this.h.e = new bua(this.t);
        this.h.h(i2);
        this.c.a(this.h);
        this.h.o(entityplayersp.do());
        if (this.m instanceof bkt) {
            this.a((bli)null);
        }
    }

    public final boolean u() {
        return this.ax;
    }

    @Nullable
    public brx v() {
        return this.h == null ? null : this.h.d;
    }

    public static boolean w() {
        return R == null || !bhz.R.t.av;
    }

    public static boolean x() {
        return R != null && bhz.R.t.k;
    }

    public static boolean y() {
        return R != null && bhz.R.t.l != 0;
    }

    private void aH() {
        if (this.s != null && this.s.a != bha.a.a) {
            ain itemstack;
            boolean flag = this.h.bO.d;
            avh tileentity = null;
            if (this.s.a == bha.a.b) {
                et blockpos = this.s.a();
                awr iblockstate = this.f.o(blockpos);
                aou block = iblockstate.u();
                if (iblockstate.a() == bcx.a) {
                    return;
                }
                itemstack = block.a((ams)this.f, blockpos, iblockstate);
                if (itemstack.b()) {
                    return;
                }
                if (flag && bli.r() && block.l()) {
                    tileentity = this.f.r(blockpos);
                }
            } else {
                if (this.s.a != bha.a.c || this.s.d == null || !flag) {
                    return;
                }
                if (this.s.d instanceof acb) {
                    itemstack = new ain(aip.aq);
                } else if (this.s.d instanceof aca) {
                    itemstack = new ain(aip.cy);
                } else if (this.s.d instanceof abz) {
                    abz entityitemframe = (abz)this.s.d;
                    ain itemstack1 = entityitemframe.r();
                    itemstack = itemstack1.b() ? new ain(aip.ca) : itemstack1.l();
                } else if (this.s.d instanceof afc) {
                    ail item1;
                    afc entityminecart = (afc)this.s.d;
                    switch (entityminecart.v()) {
                        case c: {
                            item1 = aip.aW;
                            break;
                        }
                        case b: {
                            item1 = aip.aV;
                            break;
                        }
                        case d: {
                            item1 = aip.cs;
                            break;
                        }
                        case f: {
                            item1 = aip.ct;
                            break;
                        }
                        case g: {
                            item1 = aip.cA;
                            break;
                        }
                        default: {
                            item1 = aip.aC;
                        }
                    }
                    itemstack = new ain(item1);
                } else if (this.s.d instanceof afb) {
                    itemstack = new ain(((afb)this.s.d).j());
                } else if (this.s.d instanceof abx) {
                    itemstack = new ain(aip.cu);
                } else if (this.s.d instanceof aba) {
                    itemstack = new ain(aip.cQ);
                } else {
                    nd resourcelocation = vg.a(this.s.d);
                    if (resourcelocation == null || !vg.c.containsKey(resourcelocation)) {
                        return;
                    }
                    itemstack = new ain(aip.bU);
                    ajt.a(itemstack, resourcelocation);
                }
            }
            if (itemstack.b()) {
                String s2 = "";
                if (this.s.a == bha.a.b) {
                    s2 = aou.h.b(this.f.o(this.s.a()).u()).toString();
                } else if (this.s.a == bha.a.c) {
                    s2 = vg.a(this.s.d).toString();
                }
                J.warn("Picking on: [{}] {} gave null item", (Object)this.s.a, (Object)s2);
            } else {
                aea inventoryplayer = this.h.bv;
                if (tileentity != null) {
                    this.a(itemstack, tileentity);
                }
                int i2 = inventoryplayer.b(itemstack);
                if (flag) {
                    inventoryplayer.a(itemstack);
                    this.c.a(this.h.b(tz.a), 36 + inventoryplayer.d);
                } else if (i2 != -1) {
                    if (aea.e(i2)) {
                        inventoryplayer.d = i2;
                    } else {
                        this.c.a(i2);
                    }
                }
            }
        }
    }

    private ain a(ain stack, avh te2) {
        fy nbttagcompound = te2.b(new fy());
        if (stack.c() == aip.ci && nbttagcompound.e("Owner")) {
            fy nbttagcompound2 = nbttagcompound.p("Owner");
            fy nbttagcompound3 = new fy();
            nbttagcompound3.a("SkullOwner", nbttagcompound2);
            stack.b(nbttagcompound3);
            return stack;
        }
        stack.a("BlockEntityTag", nbttagcompound);
        fy nbttagcompound1 = new fy();
        ge nbttaglist = new ge();
        nbttaglist.a(new gm("(+NBT)"));
        nbttagcompound1.a("Lore", nbttaglist);
        stack.a("display", nbttagcompound1);
        return stack;
    }

    public b b(b theCrash) {
        theCrash.g().a("Launched Version", new d<String>(){

            public String a() throws Exception {
                return bhz.this.an;
            }
        });
        theCrash.g().a("LWJGL", new d<String>(){

            public String a() throws Exception {
                return Sys.getVersion();
            }
        });
        theCrash.g().a("OpenGL", new d<String>(){

            public String a() {
                return buq.u(7937) + " GL version " + buq.u(7938) + ", " + buq.u(7936);
            }
        });
        theCrash.g().a("GL Caps", new d<String>(){

            public String a() {
                return cig.c();
            }
        });
        theCrash.g().a("Using VBOs", new d<String>(){

            public String a() {
                return bhz.this.t.w ? "Yes" : "No";
            }
        });
        theCrash.g().a("Is Modded", new d<String>(){

            public String a() throws Exception {
                String s2 = ClientBrandRetriever.getClientModName();
                if (!"vanilla".equals(s2)) {
                    return "Definitely; Client brand changed to '" + s2 + "'";
                }
                return bhz.class.getSigners() == null ? "Very likely; Jar signature invalidated" : "Probably not. Jar signature remains and client brand is untouched.";
            }
        });
        theCrash.g().a("Type", new d<String>(){

            public String a() throws Exception {
                return "Client (map_client.txt)";
            }
        });
        theCrash.g().a("Resource Packs", new d<String>(){

            public String a() throws Exception {
                StringBuilder stringbuilder = new StringBuilder();
                for (String s2 : bhz.this.t.m) {
                    if (stringbuilder.length() > 0) {
                        stringbuilder.append(", ");
                    }
                    stringbuilder.append(s2);
                    if (!bhz.this.t.n.contains(s2)) continue;
                    stringbuilder.append(" (incompatible)");
                }
                return stringbuilder.toString();
            }
        });
        theCrash.g().a("Current Language", new d<String>(){

            public String a() throws Exception {
                return bhz.this.aG.c().toString();
            }
        });
        theCrash.g().a("Profiler Position", new d<String>(){

            public String a() throws Exception {
                return bhz.this.B.a ? bhz.this.B.c() : "N/A (disabled)";
            }
        });
        theCrash.g().a("CPU", new d<String>(){

            public String a() throws Exception {
                return cig.k();
            }
        });
        if (this.f != null) {
            this.f.a(theCrash);
        }
        return theCrash;
    }

    public static bhz z() {
        return R;
    }

    public ListenableFuture<Object> A() {
        return this.a(new Runnable(){

            @Override
            public void run() {
                bhz.this.f();
            }
        });
    }

    @Override
    public void a(uj playerSnooper) {
        playerSnooper.a("fps", ar);
        playerSnooper.a("vsync_enabled", this.t.v);
        playerSnooper.a("display_frequency", Display.getDisplayMode().getFrequency());
        playerSnooper.a("display_type", this.T ? "fullscreen" : "windowed");
        playerSnooper.a("run_time", (MinecraftServer.aw() - playerSnooper.g()) / 60L * 1000L);
        playerSnooper.a("current_action", this.aI());
        playerSnooper.a("language", this.t.aJ == null ? "en_us" : this.t.aJ);
        String s2 = ByteOrder.nativeOrder() == ByteOrder.LITTLE_ENDIAN ? "little" : "big";
        playerSnooper.a("endianness", s2);
        playerSnooper.a("subtitles", this.t.P);
        playerSnooper.a("touch", this.t.B ? "touch" : "mouse");
        playerSnooper.a("resource_packs", this.aF.e().size());
        int i2 = 0;
        for (ces.a resourcepackrepository$entry : this.aF.e()) {
            playerSnooper.a("resource_pack[" + i2++ + "]", resourcepackrepository$entry.d());
        }
        if (this.al != null && this.al.as() != null) {
            playerSnooper.a("snooper_partner", this.al.as().f());
        }
    }

    private String aI() {
        if (this.al != null) {
            return this.al.a() ? "hosting_lan" : "singleplayer";
        }
        if (this.P != null) {
            return this.P.d() ? "playing_lan" : "multiplayer";
        }
        return "out_of_game";
    }

    @Override
    public void b(uj playerSnooper) {
        playerSnooper.b("opengl_version", buq.u(7938));
        playerSnooper.b("opengl_vendor", buq.u(7936));
        playerSnooper.b("client_brand", ClientBrandRetriever.getClientModName());
        playerSnooper.b("launched_version", this.an);
        ContextCapabilities contextcapabilities = GLContext.getCapabilities();
        playerSnooper.b("gl_caps[ARB_arrays_of_arrays]", contextcapabilities.GL_ARB_arrays_of_arrays);
        playerSnooper.b("gl_caps[ARB_base_instance]", contextcapabilities.GL_ARB_base_instance);
        playerSnooper.b("gl_caps[ARB_blend_func_extended]", contextcapabilities.GL_ARB_blend_func_extended);
        playerSnooper.b("gl_caps[ARB_clear_buffer_object]", contextcapabilities.GL_ARB_clear_buffer_object);
        playerSnooper.b("gl_caps[ARB_color_buffer_float]", contextcapabilities.GL_ARB_color_buffer_float);
        playerSnooper.b("gl_caps[ARB_compatibility]", contextcapabilities.GL_ARB_compatibility);
        playerSnooper.b("gl_caps[ARB_compressed_texture_pixel_storage]", contextcapabilities.GL_ARB_compressed_texture_pixel_storage);
        playerSnooper.b("gl_caps[ARB_compute_shader]", contextcapabilities.GL_ARB_compute_shader);
        playerSnooper.b("gl_caps[ARB_copy_buffer]", contextcapabilities.GL_ARB_copy_buffer);
        playerSnooper.b("gl_caps[ARB_copy_image]", contextcapabilities.GL_ARB_copy_image);
        playerSnooper.b("gl_caps[ARB_depth_buffer_float]", contextcapabilities.GL_ARB_depth_buffer_float);
        playerSnooper.b("gl_caps[ARB_compute_shader]", contextcapabilities.GL_ARB_compute_shader);
        playerSnooper.b("gl_caps[ARB_copy_buffer]", contextcapabilities.GL_ARB_copy_buffer);
        playerSnooper.b("gl_caps[ARB_copy_image]", contextcapabilities.GL_ARB_copy_image);
        playerSnooper.b("gl_caps[ARB_depth_buffer_float]", contextcapabilities.GL_ARB_depth_buffer_float);
        playerSnooper.b("gl_caps[ARB_depth_clamp]", contextcapabilities.GL_ARB_depth_clamp);
        playerSnooper.b("gl_caps[ARB_depth_texture]", contextcapabilities.GL_ARB_depth_texture);
        playerSnooper.b("gl_caps[ARB_draw_buffers]", contextcapabilities.GL_ARB_draw_buffers);
        playerSnooper.b("gl_caps[ARB_draw_buffers_blend]", contextcapabilities.GL_ARB_draw_buffers_blend);
        playerSnooper.b("gl_caps[ARB_draw_elements_base_vertex]", contextcapabilities.GL_ARB_draw_elements_base_vertex);
        playerSnooper.b("gl_caps[ARB_draw_indirect]", contextcapabilities.GL_ARB_draw_indirect);
        playerSnooper.b("gl_caps[ARB_draw_instanced]", contextcapabilities.GL_ARB_draw_instanced);
        playerSnooper.b("gl_caps[ARB_explicit_attrib_location]", contextcapabilities.GL_ARB_explicit_attrib_location);
        playerSnooper.b("gl_caps[ARB_explicit_uniform_location]", contextcapabilities.GL_ARB_explicit_uniform_location);
        playerSnooper.b("gl_caps[ARB_fragment_layer_viewport]", contextcapabilities.GL_ARB_fragment_layer_viewport);
        playerSnooper.b("gl_caps[ARB_fragment_program]", contextcapabilities.GL_ARB_fragment_program);
        playerSnooper.b("gl_caps[ARB_fragment_shader]", contextcapabilities.GL_ARB_fragment_shader);
        playerSnooper.b("gl_caps[ARB_fragment_program_shadow]", contextcapabilities.GL_ARB_fragment_program_shadow);
        playerSnooper.b("gl_caps[ARB_framebuffer_object]", contextcapabilities.GL_ARB_framebuffer_object);
        playerSnooper.b("gl_caps[ARB_framebuffer_sRGB]", contextcapabilities.GL_ARB_framebuffer_sRGB);
        playerSnooper.b("gl_caps[ARB_geometry_shader4]", contextcapabilities.GL_ARB_geometry_shader4);
        playerSnooper.b("gl_caps[ARB_gpu_shader5]", contextcapabilities.GL_ARB_gpu_shader5);
        playerSnooper.b("gl_caps[ARB_half_float_pixel]", contextcapabilities.GL_ARB_half_float_pixel);
        playerSnooper.b("gl_caps[ARB_half_float_vertex]", contextcapabilities.GL_ARB_half_float_vertex);
        playerSnooper.b("gl_caps[ARB_instanced_arrays]", contextcapabilities.GL_ARB_instanced_arrays);
        playerSnooper.b("gl_caps[ARB_map_buffer_alignment]", contextcapabilities.GL_ARB_map_buffer_alignment);
        playerSnooper.b("gl_caps[ARB_map_buffer_range]", contextcapabilities.GL_ARB_map_buffer_range);
        playerSnooper.b("gl_caps[ARB_multisample]", contextcapabilities.GL_ARB_multisample);
        playerSnooper.b("gl_caps[ARB_multitexture]", contextcapabilities.GL_ARB_multitexture);
        playerSnooper.b("gl_caps[ARB_occlusion_query2]", contextcapabilities.GL_ARB_occlusion_query2);
        playerSnooper.b("gl_caps[ARB_pixel_buffer_object]", contextcapabilities.GL_ARB_pixel_buffer_object);
        playerSnooper.b("gl_caps[ARB_seamless_cube_map]", contextcapabilities.GL_ARB_seamless_cube_map);
        playerSnooper.b("gl_caps[ARB_shader_objects]", contextcapabilities.GL_ARB_shader_objects);
        playerSnooper.b("gl_caps[ARB_shader_stencil_export]", contextcapabilities.GL_ARB_shader_stencil_export);
        playerSnooper.b("gl_caps[ARB_shader_texture_lod]", contextcapabilities.GL_ARB_shader_texture_lod);
        playerSnooper.b("gl_caps[ARB_shadow]", contextcapabilities.GL_ARB_shadow);
        playerSnooper.b("gl_caps[ARB_shadow_ambient]", contextcapabilities.GL_ARB_shadow_ambient);
        playerSnooper.b("gl_caps[ARB_stencil_texturing]", contextcapabilities.GL_ARB_stencil_texturing);
        playerSnooper.b("gl_caps[ARB_sync]", contextcapabilities.GL_ARB_sync);
        playerSnooper.b("gl_caps[ARB_tessellation_shader]", contextcapabilities.GL_ARB_tessellation_shader);
        playerSnooper.b("gl_caps[ARB_texture_border_clamp]", contextcapabilities.GL_ARB_texture_border_clamp);
        playerSnooper.b("gl_caps[ARB_texture_buffer_object]", contextcapabilities.GL_ARB_texture_buffer_object);
        playerSnooper.b("gl_caps[ARB_texture_cube_map]", contextcapabilities.GL_ARB_texture_cube_map);
        playerSnooper.b("gl_caps[ARB_texture_cube_map_array]", contextcapabilities.GL_ARB_texture_cube_map_array);
        playerSnooper.b("gl_caps[ARB_texture_non_power_of_two]", contextcapabilities.GL_ARB_texture_non_power_of_two);
        playerSnooper.b("gl_caps[ARB_uniform_buffer_object]", contextcapabilities.GL_ARB_uniform_buffer_object);
        playerSnooper.b("gl_caps[ARB_vertex_blend]", contextcapabilities.GL_ARB_vertex_blend);
        playerSnooper.b("gl_caps[ARB_vertex_buffer_object]", contextcapabilities.GL_ARB_vertex_buffer_object);
        playerSnooper.b("gl_caps[ARB_vertex_program]", contextcapabilities.GL_ARB_vertex_program);
        playerSnooper.b("gl_caps[ARB_vertex_shader]", contextcapabilities.GL_ARB_vertex_shader);
        playerSnooper.b("gl_caps[EXT_bindable_uniform]", contextcapabilities.GL_EXT_bindable_uniform);
        playerSnooper.b("gl_caps[EXT_blend_equation_separate]", contextcapabilities.GL_EXT_blend_equation_separate);
        playerSnooper.b("gl_caps[EXT_blend_func_separate]", contextcapabilities.GL_EXT_blend_func_separate);
        playerSnooper.b("gl_caps[EXT_blend_minmax]", contextcapabilities.GL_EXT_blend_minmax);
        playerSnooper.b("gl_caps[EXT_blend_subtract]", contextcapabilities.GL_EXT_blend_subtract);
        playerSnooper.b("gl_caps[EXT_draw_instanced]", contextcapabilities.GL_EXT_draw_instanced);
        playerSnooper.b("gl_caps[EXT_framebuffer_multisample]", contextcapabilities.GL_EXT_framebuffer_multisample);
        playerSnooper.b("gl_caps[EXT_framebuffer_object]", contextcapabilities.GL_EXT_framebuffer_object);
        playerSnooper.b("gl_caps[EXT_framebuffer_sRGB]", contextcapabilities.GL_EXT_framebuffer_sRGB);
        playerSnooper.b("gl_caps[EXT_geometry_shader4]", contextcapabilities.GL_EXT_geometry_shader4);
        playerSnooper.b("gl_caps[EXT_gpu_program_parameters]", contextcapabilities.GL_EXT_gpu_program_parameters);
        playerSnooper.b("gl_caps[EXT_gpu_shader4]", contextcapabilities.GL_EXT_gpu_shader4);
        playerSnooper.b("gl_caps[EXT_multi_draw_arrays]", contextcapabilities.GL_EXT_multi_draw_arrays);
        playerSnooper.b("gl_caps[EXT_packed_depth_stencil]", contextcapabilities.GL_EXT_packed_depth_stencil);
        playerSnooper.b("gl_caps[EXT_paletted_texture]", contextcapabilities.GL_EXT_paletted_texture);
        playerSnooper.b("gl_caps[EXT_rescale_normal]", contextcapabilities.GL_EXT_rescale_normal);
        playerSnooper.b("gl_caps[EXT_separate_shader_objects]", contextcapabilities.GL_EXT_separate_shader_objects);
        playerSnooper.b("gl_caps[EXT_shader_image_load_store]", contextcapabilities.GL_EXT_shader_image_load_store);
        playerSnooper.b("gl_caps[EXT_shadow_funcs]", contextcapabilities.GL_EXT_shadow_funcs);
        playerSnooper.b("gl_caps[EXT_shared_texture_palette]", contextcapabilities.GL_EXT_shared_texture_palette);
        playerSnooper.b("gl_caps[EXT_stencil_clear_tag]", contextcapabilities.GL_EXT_stencil_clear_tag);
        playerSnooper.b("gl_caps[EXT_stencil_two_side]", contextcapabilities.GL_EXT_stencil_two_side);
        playerSnooper.b("gl_caps[EXT_stencil_wrap]", contextcapabilities.GL_EXT_stencil_wrap);
        playerSnooper.b("gl_caps[EXT_texture_3d]", contextcapabilities.GL_EXT_texture_3d);
        playerSnooper.b("gl_caps[EXT_texture_array]", contextcapabilities.GL_EXT_texture_array);
        playerSnooper.b("gl_caps[EXT_texture_buffer_object]", contextcapabilities.GL_EXT_texture_buffer_object);
        playerSnooper.b("gl_caps[EXT_texture_integer]", contextcapabilities.GL_EXT_texture_integer);
        playerSnooper.b("gl_caps[EXT_texture_lod_bias]", contextcapabilities.GL_EXT_texture_lod_bias);
        playerSnooper.b("gl_caps[EXT_texture_sRGB]", contextcapabilities.GL_EXT_texture_sRGB);
        playerSnooper.b("gl_caps[EXT_vertex_shader]", contextcapabilities.GL_EXT_vertex_shader);
        playerSnooper.b("gl_caps[EXT_vertex_weighting]", contextcapabilities.GL_EXT_vertex_weighting);
        playerSnooper.b("gl_caps[gl_max_vertex_uniforms]", buq.v(35658));
        buq.L();
        playerSnooper.b("gl_caps[gl_max_fragment_uniforms]", buq.v(35657));
        buq.L();
        playerSnooper.b("gl_caps[gl_max_vertex_attribs]", buq.v(34921));
        buq.L();
        playerSnooper.b("gl_caps[gl_max_vertex_texture_image_units]", buq.v(35660));
        buq.L();
        playerSnooper.b("gl_caps[gl_max_texture_image_units]", buq.v(34930));
        buq.L();
        playerSnooper.b("gl_caps[gl_max_array_texture_layers]", buq.v(35071));
        buq.L();
        playerSnooper.b("gl_max_texture_size", bhz.B());
        GameProfile gameprofile = this.af.e();
        if (gameprofile != null && gameprofile.getId() != null) {
            playerSnooper.b("uuid", Hashing.sha1().hashBytes(gameprofile.getId().toString().getBytes(Charsets.ISO_8859_1)).toString());
        }
    }

    public static int B() {
        for (int i2 = 16384; i2 > 0; i2 >>= 1) {
            buq.a(32868, 0, 6408, i2, i2, 0, 6408, 5121, null);
            int j2 = buq.c(32868, 0, 4096);
            if (j2 == 0) continue;
            return i2;
        }
        return -1;
    }

    @Override
    public boolean Z() {
        return this.t.t;
    }

    public void a(bsc serverDataIn) {
        this.P = serverDataIn;
    }

    @Nullable
    public bsc C() {
        return this.P;
    }

    public boolean D() {
        return this.az;
    }

    public boolean E() {
        return this.az && this.al != null;
    }

    @Nullable
    public chb F() {
        return this.al;
    }

    public static void G() {
        chb integratedserver;
        if (R != null && (integratedserver = R.F()) != null) {
            integratedserver.u();
        }
    }

    public uj H() {
        return this.Z;
    }

    public static long I() {
        return Sys.getTime() * 1000L / Sys.getTimerResolution();
    }

    public boolean J() {
        return this.T;
    }

    public big K() {
        return this.af;
    }

    public PropertyMap L() {
        if (this.O.isEmpty()) {
            GameProfile gameprofile = this.X().fillProfileProperties(this.af.e(), false);
            this.O.putAll((Multimap)gameprofile.getProperties());
        }
        return this.O;
    }

    public Proxy M() {
        return this.ap;
    }

    public cdp N() {
        return this.Q;
    }

    public cen O() {
        return this.aB;
    }

    public ces P() {
        return this.aF;
    }

    public cey Q() {
        return this.aG;
    }

    public cdn R() {
        return this.aK;
    }

    public boolean S() {
        return this.aw;
    }

    public boolean T() {
        return this.ag;
    }

    public chm U() {
        return this.aL;
    }

    public chj.a V() {
        if (this.m instanceof blr) {
            return chj.a.d;
        }
        if (this.h != null) {
            if (this.h.l.s instanceof aym) {
                return chj.a.e;
            }
            if (this.h.l.s instanceof ayq) {
                return this.q.j().d() ? chj.a.f : chj.a.g;
            }
            return this.h.bO.d && this.h.bO.c ? chj.a.c : chj.a.b;
        }
        return chj.a.a;
    }

    public void W() {
        int i2;
        int n2 = i2 = Keyboard.getEventKey() == 0 ? Keyboard.getEventCharacter() + 256 : Keyboard.getEventKey();
        if (!(i2 == 0 || Keyboard.isRepeatEvent() || this.m instanceof bmc && ((bmc)this.m).g > bhz.I() - 20L || !Keyboard.getEventKeyState())) {
            if (i2 == this.t.am.j()) {
                this.r();
            } else if (i2 == this.t.aj.j()) {
                this.q.d().a(bid.a(this.w, this.d, this.e, this.aJ));
            } else if (i2 == 48 && bli.r() && (this.m == null || this.m != null && !this.m.p())) {
                this.t.a(bib.a.N, 1);
                if (this.m instanceof bkk) {
                    ((bkk)this.m).a();
                }
            }
        }
    }

    public MinecraftSessionService X() {
        return this.aO;
    }

    public cev Y() {
        return this.aP;
    }

    @Nullable
    public ve aa() {
        return this.ad;
    }

    public void a(ve viewingEntity) {
        this.ad = viewingEntity;
        this.o.a(viewingEntity);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public <V> ListenableFuture<V> a(Callable<V> callableToSchedule) {
        Validate.notNull(callableToSchedule);
        if (this.aF()) {
            try {
                return Futures.immediateFuture(callableToSchedule.call());
            }
            catch (Exception exception) {
                return Futures.immediateFailedCheckedFuture((Exception)exception);
            }
        }
        ListenableFutureTask listenablefuturetask = ListenableFutureTask.create(callableToSchedule);
        Queue<FutureTask<?>> queue = this.aQ;
        synchronized (queue) {
            this.aQ.add((FutureTask<?>)listenablefuturetask);
            return listenablefuturetask;
        }
    }

    @Override
    public ListenableFuture<Object> a(Runnable runnableToSchedule) {
        Validate.notNull((Object)runnableToSchedule);
        return this.a(Executors.callable(runnableToSchedule));
    }

    @Override
    public boolean aF() {
        return Thread.currentThread() == this.aR;
    }

    public bvk ab() {
        return this.aT;
    }

    public bzd ac() {
        return this.aa;
    }

    public bzu ad() {
        return this.ab;
    }

    public bus ae() {
        return this.ac;
    }

    public <T> cgw<T> a(cgv.a<T> p_193987_1_) {
        return this.ae.a(p_193987_1_);
    }

    public static int af() {
        return ar;
    }

    public qz ag() {
        return this.z;
    }

    public boolean ah() {
        return this.X;
    }

    public void a(boolean isConnected) {
        this.X = isConnected;
    }

    public rw ai() {
        return this.S;
    }

    public float aj() {
        return this.Y.elapsedPartialTicks;
    }

    public float ak() {
        return this.Y.a;
    }

    public bii al() {
        return this.aH;
    }

    public boolean an() {
        return this.h != null && this.h.do() || this.t.x;
    }

    public bka ao() {
        return this.aU;
    }

    public chx ap() {
        return this.aY;
    }
}

