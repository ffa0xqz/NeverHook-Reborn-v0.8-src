/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.GsonBuilder
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonDeserializationContext
 *  com.google.gson.JsonDeserializer
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParseException
 *  com.google.gson.JsonPrimitive
 *  com.google.gson.JsonSerializationContext
 *  com.google.gson.JsonSerializer
 *  com.google.gson.TypeAdapterFactory
 *  javax.annotation.Nullable
 */
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.google.gson.TypeAdapterFactory;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;

public interface hh
extends Iterable<hh> {
    public hh a(hn var1);

    public hn b();

    public hh a(String var1);

    public hh a(hh var1);

    public String e();

    public String c();

    public String d();

    public List<hh> a();

    public hh f();

    public static class a
    implements JsonDeserializer<hh>,
    JsonSerializer<hh> {
        private static final Gson a;

        /*
         * WARNING - void declaration
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        public hh a(JsonElement jsonElement2, Type type, JsonDeserializationContext jsonDeserializationContext2) throws JsonParseException {
            void var5_15;
            JsonElement jsonElement2;
            if (jsonElement2.isJsonPrimitive()) {
                return new ho(jsonElement2.getAsString());
            }
            if (jsonElement2.isJsonObject()) {
                JsonDeserializationContext jsonDeserializationContext2;
                void var5_13;
                String string;
                JsonObject jsonObject = jsonElement2.getAsJsonObject();
                if (jsonObject.has("text")) {
                    ho ho2 = new ho(jsonObject.get("text").getAsString());
                } else if (jsonObject.has("translate")) {
                    string = jsonObject.get("translate").getAsString();
                    if (jsonObject.has("with")) {
                        JsonArray jsonArray = jsonObject.getAsJsonArray("with");
                        Object[] \u26032 = new Object[jsonArray.size()];
                        for (int i2 = 0; i2 < \u26032.length; ++i2) {
                            \u26032[i2] = this.a(jsonArray.get(i2), type, jsonDeserializationContext2);
                            if (!(\u26032[i2] instanceof ho) || !(\u2603 = (ho)\u26032[i2]).b().g() || !\u2603.a().isEmpty()) continue;
                            \u26032[i2] = \u2603.g();
                        }
                        hp hp2 = new hp(string, \u26032);
                    } else {
                        hp hp3 = new hp(string, new Object[0]);
                    }
                } else if (jsonObject.has("score")) {
                    string = jsonObject.getAsJsonObject("score");
                    if (!string.has("name") || !string.has("objective")) throw new JsonParseException("A score component needs a least a name and an objective");
                    hl hl2 = new hl(ra.h((JsonObject)string, "name"), ra.h((JsonObject)string, "objective"));
                    if (string.has("value")) {
                        hl2.b(ra.h((JsonObject)string, "value"));
                    }
                } else if (jsonObject.has("selector")) {
                    hm hm2 = new hm(ra.h(jsonObject, "selector"));
                } else {
                    if (!jsonObject.has("keybind")) throw new JsonParseException("Don't know how to turn " + (Object)jsonElement2 + " into a Component");
                    hk hk2 = new hk(ra.h(jsonObject, "keybind"));
                }
                if (jsonObject.has("extra")) {
                    string = jsonObject.getAsJsonArray("extra");
                    if (string.size() <= 0) throw new JsonParseException("Unexpected empty array of components");
                    for (int i3 = 0; i3 < string.size(); ++i3) {
                        var5_13.a(this.a(string.get(i3), type, jsonDeserializationContext2));
                    }
                }
                var5_13.a((hn)jsonDeserializationContext2.deserialize(jsonElement2, hn.class));
                return var5_13;
            }
            if (!jsonElement2.isJsonArray()) throw new JsonParseException("Don't know how to turn " + (Object)jsonElement2 + " into a Component");
            JsonArray \u26033 = jsonElement2.getAsJsonArray();
            Object var5_14 = null;
            for (JsonElement jsonElement3 : \u26033) {
                hh hh2 = this.a(jsonElement3, jsonElement3.getClass(), jsonDeserializationContext2);
                if (var5_15 == null) {
                    hh hh3 = hh2;
                    continue;
                }
                var5_15.a(hh2);
            }
            return var5_15;
        }

        private void a(hn hn2, JsonObject jsonObject, JsonSerializationContext jsonSerializationContext) {
            JsonElement jsonElement = jsonSerializationContext.serialize((Object)hn2);
            if (jsonElement.isJsonObject()) {
                JsonObject jsonObject2 = (JsonObject)jsonElement;
                for (Map.Entry entry : jsonObject2.entrySet()) {
                    jsonObject.add((String)entry.getKey(), (JsonElement)entry.getValue());
                }
            }
        }

        public JsonElement a(hh hh22, Type type, JsonSerializationContext jsonSerializationContext) {
            JsonObject \u26032;
            hh hh22;
            Object object;
            JsonObject jsonObject = new JsonObject();
            if (!hh22.b().g()) {
                this.a(hh22.b(), jsonObject, jsonSerializationContext);
            }
            if (!hh22.a().isEmpty()) {
                object = new JsonArray();
                for (hh hh3 : hh22.a()) {
                    object.add(this.a(hh3, hh3.getClass(), jsonSerializationContext));
                }
                jsonObject.add("extra", (JsonElement)object);
            }
            if (hh22 instanceof ho) {
                jsonObject.addProperty("text", ((ho)hh22).g());
            } else if (hh22 instanceof hp) {
                object = (hp)hh22;
                jsonObject.addProperty("translate", ((hp)object).i());
                if (((hp)object).j() != null && ((hp)object).j().length > 0) {
                    \u26032 = new JsonArray();
                    for (Object object2 : ((hp)object).j()) {
                        if (object2 instanceof hh) {
                            \u26032.add(this.a((hh)object2, object2.getClass(), jsonSerializationContext));
                            continue;
                        }
                        \u26032.add((JsonElement)new JsonPrimitive(String.valueOf(object2)));
                    }
                    jsonObject.add("with", (JsonElement)\u26032);
                }
            } else if (hh22 instanceof hl) {
                object = (hl)hh22;
                \u26032 = new JsonObject();
                \u26032.addProperty("name", ((hl)object).g());
                \u26032.addProperty("objective", ((hl)object).h());
                \u26032.addProperty("value", ((hl)object).e());
                jsonObject.add("score", (JsonElement)\u26032);
            } else if (hh22 instanceof hm) {
                object = (hm)hh22;
                jsonObject.addProperty("selector", ((hm)object).g());
            } else if (hh22 instanceof hk) {
                object = (hk)hh22;
                jsonObject.addProperty("keybind", ((hk)object).h());
            } else {
                throw new IllegalArgumentException("Don't know how to serialize " + hh22 + " as a Component");
            }
            return jsonObject;
        }

        public static String a(hh hh2) {
            return a.toJson((Object)hh2);
        }

        @Nullable
        public static hh a(String string) {
            return ra.a(a, string, hh.class, false);
        }

        @Nullable
        public static hh b(String string) {
            return ra.a(a, string, hh.class, true);
        }

        public /* synthetic */ JsonElement serialize(Object object, Type type, JsonSerializationContext jsonSerializationContext) {
            return this.a((hh)object, type, jsonSerializationContext);
        }

        public /* synthetic */ Object deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            return this.a(jsonElement, type, jsonDeserializationContext);
        }

        static {
            GsonBuilder gsonBuilder = new GsonBuilder();
            gsonBuilder.registerTypeHierarchyAdapter(hh.class, (Object)new a());
            gsonBuilder.registerTypeHierarchyAdapter(hn.class, (Object)new hn.a());
            gsonBuilder.registerTypeAdapterFactory((TypeAdapterFactory)new rh());
            a = gsonBuilder.create();
        }
    }
}

