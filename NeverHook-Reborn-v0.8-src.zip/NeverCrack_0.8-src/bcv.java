/*
 * Decompiled with CFR 0.150.
 */
public class bcv
extends bcx {
    public bcv(bcy bcy2) {
        super(bcy2);
        this.i();
    }

    @Override
    public boolean a() {
        return false;
    }

    @Override
    public boolean b() {
        return false;
    }

    @Override
    public boolean c() {
        return false;
    }
}

