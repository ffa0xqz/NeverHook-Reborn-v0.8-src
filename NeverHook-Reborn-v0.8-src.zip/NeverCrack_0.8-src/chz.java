/*
 * Decompiled with CFR 0.150.
 */
import java.util.function.Function;

public enum chz {
    a("movement", chu::new),
    b("find_tree", cht::new),
    c("punch_tree", chw::new),
    d("open_inventory", chv::new),
    e("craft_planks", chs::new),
    f("none", chr::new);

    private final String g;
    private final Function<chx, ? extends chy> h;

    private <T extends chy> chz(String string2, Function<chx, T> function) {
        this.g = string2;
        this.h = function;
    }

    public chy a(chx chx2) {
        return this.h.apply(chx2);
    }

    public String a() {
        return this.g;
    }

    public static chz a(String string) {
        for (chz chz2 : chz.values()) {
            if (!chz2.g.equals(string)) continue;
            return chz2;
        }
        return f;
    }
}

