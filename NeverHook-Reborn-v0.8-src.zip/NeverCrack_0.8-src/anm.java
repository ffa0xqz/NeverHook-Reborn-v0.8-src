/*
 * Decompiled with CFR 0.150.
 */
import java.util.Iterator;
import java.util.Random;

public class anm
extends anf {
    public anm(anf.a a2) {
        super(a2);
        this.u.clear();
        this.q = aov.m.t();
        this.r = aov.m.t();
        this.s.z = -999;
        this.s.D = 2;
        this.s.F = 50;
        this.s.G = 10;
        this.u.clear();
        this.u.add(new anf.c(aad.class, 4, 2, 3));
        Iterator iterator = this.t.iterator();
        while (iterator.hasNext()) {
            anf.c c2 = (anf.c)iterator.next();
            if (c2.b != adr.class && c2.b != ads.class) continue;
            iterator.remove();
        }
        this.t.add(new anf.c(adr.class, 19, 4, 4));
        this.t.add(new anf.c(ads.class, 1, 1, 1));
        this.t.add(new anf.c(acz.class, 80, 4, 4));
    }

    @Override
    public void a(ams ams2, Random random, et et2) {
        super.a(ams2, random, et2);
        if (random.nextInt(1000) == 0) {
            int n2 = random.nextInt(16) + 8;
            \u2603 = random.nextInt(16) + 8;
            et \u26032 = ams2.l(et2.a(n2, 0, \u2603)).a();
            new azn().b(ams2, random, \u26032);
        }
        if (random.nextInt(64) == 0) {
            new azu().b(ams2, random, et2);
        }
    }
}

