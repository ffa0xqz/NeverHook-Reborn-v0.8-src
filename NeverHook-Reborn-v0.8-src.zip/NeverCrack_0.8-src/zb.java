/*
 * Decompiled with CFR 0.150.
 */
public class zb
extends zc {
    private boolean i;

    public zb(vo vo2, ams ams2) {
        super(vo2, ams2);
    }

    @Override
    protected bek a() {
        this.h = new bem();
        this.h.a(true);
        return new bek(this.h);
    }

    @Override
    protected boolean b() {
        return this.a.z || this.h() && this.q() || this.a.aS();
    }

    @Override
    protected bhc c() {
        return new bhc(this.a.p, this.s(), this.a.r);
    }

    @Override
    public bej b(et et2) {
        if (this.b.o(et2).a() == bcx.a) {
            \u2603 = et2.b();
            while (\u2603.q() > 0 && this.b.o(\u2603).a() == bcx.a) {
                \u2603 = \u2603.b();
            }
            if (\u2603.q() > 0) {
                return super.b(\u2603.a());
            }
            while (\u2603.q() < this.b.aa() && this.b.o(\u2603).a() == bcx.a) {
                \u2603 = \u2603.a();
            }
            et2 = \u2603;
        }
        if (this.b.o(et2).a().a()) {
            \u2603 = et2.a();
            while (\u2603.q() < this.b.aa() && this.b.o(\u2603).a().a()) {
                \u2603 = \u2603.a();
            }
            return super.b(\u2603);
        }
        return super.b(et2);
    }

    @Override
    public bej a(ve ve2) {
        return this.b(new et(ve2));
    }

    private int s() {
        if (!this.a.ao() || !this.h()) {
            return (int)(this.a.bw().b + 0.5);
        }
        int n2 = (int)this.a.bw().b;
        aou \u26032 = this.b.o(new et(ri.c(this.a.p), n2, ri.c(this.a.r))).u();
        \u2603 = 0;
        while (\u26032 == aov.i || \u26032 == aov.j) {
            \u26032 = this.b.o(new et(ri.c(this.a.p), ++n2, ri.c(this.a.r))).u();
            if (++\u2603 <= 16) continue;
            return (int)this.a.bw().b;
        }
        return n2;
    }

    @Override
    protected void q_() {
        super.q_();
        if (this.i) {
            if (this.b.h(new et(ri.c(this.a.p), (int)(this.a.bw().b + 0.5), ri.c(this.a.r)))) {
                return;
            }
            for (int i2 = 0; i2 < this.c.d(); ++i2) {
                beh beh2 = this.c.a(i2);
                if (!this.b.h(new et(beh2.a, beh2.b, beh2.c))) continue;
                this.c.b(i2 - 1);
                return;
            }
        }
    }

    @Override
    protected boolean a(bhc bhc2, bhc bhc3, int n2, int n3, int n4) {
        \u2603 = ri.c(bhc2.b);
        \u2603 = ri.c(bhc2.d);
        double d2 = bhc3.b - bhc2.b;
        \u2603 = bhc3.d - bhc2.d;
        \u2603 = d2 * d2 + \u2603 * \u2603;
        if (\u2603 < 1.0E-8) {
            return false;
        }
        \u2603 = 1.0 / Math.sqrt(\u2603);
        if (!this.a(\u2603, (int)bhc2.c, \u2603, n2 += 2, n3, n4 += 2, bhc2, d2 *= \u2603, \u2603 *= \u2603)) {
            return false;
        }
        n2 -= 2;
        n4 -= 2;
        \u2603 = 1.0 / Math.abs(d2);
        \u2603 = 1.0 / Math.abs(\u2603);
        \u2603 = (double)\u2603 - bhc2.b;
        \u2603 = (double)\u2603 - bhc2.d;
        if (d2 >= 0.0) {
            \u2603 += 1.0;
        }
        if (\u2603 >= 0.0) {
            \u2603 += 1.0;
        }
        \u2603 /= d2;
        \u2603 /= \u2603;
        int \u26032 = d2 < 0.0 ? -1 : 1;
        int \u26033 = \u2603 < 0.0 ? -1 : 1;
        int \u26034 = ri.c(bhc3.b);
        int \u26035 = ri.c(bhc3.d);
        int \u26036 = \u26034 - \u2603;
        int \u26037 = \u26035 - \u2603;
        while (\u26036 * \u26032 > 0 || \u26037 * \u26033 > 0) {
            if (\u2603 < \u2603) {
                \u2603 += \u2603;
                \u26036 = \u26034 - (\u2603 += \u26032);
            } else {
                \u2603 += \u2603;
                \u26037 = \u26035 - (\u2603 += \u26033);
            }
            if (this.a(\u2603, (int)bhc2.c, \u2603, n2, n3, n4, bhc2, d2, \u2603)) continue;
            return false;
        }
        return true;
    }

    private boolean a(int n2, int n3, int n4, int n5, int n6, int n7, bhc bhc2, double d2, double d3) {
        int n8 = n2 - n5 / 2;
        \u2603 = n4 - n7 / 2;
        if (!this.b(n8, n3, \u2603, n5, n6, n7, bhc2, d2, d3)) {
            return false;
        }
        for (\u2603 = n8; \u2603 < n8 + n5; ++\u2603) {
            for (\u2603 = \u2603; \u2603 < \u2603 + n7; ++\u2603) {
                double d4 = (double)\u2603 + 0.5 - bhc2.b;
                \u2603 = (double)\u2603 + 0.5 - bhc2.d;
                if (d4 * d2 + \u2603 * d3 < 0.0) continue;
                bef \u26032 = this.h.a(this.b, \u2603, n3 - 1, \u2603, this.a, n5, n6, n7, true, true);
                if (\u26032 == bef.g) {
                    return false;
                }
                if (\u26032 == bef.f) {
                    return false;
                }
                if (\u26032 == bef.b) {
                    return false;
                }
                \u26032 = this.h.a(this.b, \u2603, n3, \u2603, this.a, n5, n6, n7, true, true);
                float \u26033 = this.a.a(\u26032);
                if (\u26033 < 0.0f || \u26033 >= 8.0f) {
                    return false;
                }
                if (\u26032 != bef.j && \u26032 != bef.i && \u26032 != bef.n) continue;
                return false;
            }
        }
        return true;
    }

    private boolean b(int n2, int n3, int n4, int n5, int n6, int n7, bhc bhc2, double d2, double d3) {
        for (et et2 : et.a(new et(n2, n3, n4), new et(n2 + n5 - 1, n3 + n6 - 1, n4 + n7 - 1))) {
            double d4 = (double)et2.p() + 0.5 - bhc2.b;
            if (d4 * d2 + (\u2603 = (double)et2.r() + 0.5 - bhc2.d) * d3 < 0.0 || (\u2603 = this.b.o(et2).u()).b(this.b, et2)) continue;
            return false;
        }
        return true;
    }

    public void a(boolean bl2) {
        this.h.b(bl2);
    }

    public void b(boolean bl2) {
        this.h.a(bl2);
    }

    public boolean g() {
        return this.h.c();
    }

    public void c(boolean bl2) {
        this.h.c(bl2);
    }

    public boolean h() {
        return this.h.e();
    }

    public void d(boolean bl2) {
        this.i = bl2;
    }
}

