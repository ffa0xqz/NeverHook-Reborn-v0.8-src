/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.annotations.VisibleForTesting
 *  com.google.common.collect.Iterators
 *  com.google.common.collect.Lists
 */
import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.Iterators;
import com.google.common.collect.Lists;
import java.util.Arrays;
import java.util.IllegalFormatException;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class hp
extends he {
    private final String d;
    private final Object[] e;
    private final Object f = new Object();
    private long g = -1L;
    @VisibleForTesting
    List<hh> b = Lists.newArrayList();
    public static final Pattern c = Pattern.compile("%(?:(\\d+)\\$)?([A-Za-z%]|$)");

    public hp(String string, Object ... arrobject) {
        this.d = string;
        this.e = arrobject;
        for (Object object : arrobject) {
            if (!(object instanceof hh)) continue;
            ((hh)object).b().a(this.b());
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @VisibleForTesting
    synchronized void g() {
        Object object = this.f;
        synchronized (object) {
            long l2 = ft.a();
            if (l2 == this.g) {
                return;
            }
            this.g = l2;
            this.b.clear();
        }
        try {
            this.b(ft.a(this.d));
        }
        catch (hq hq2) {
            this.b.clear();
            try {
                this.b(ft.b(this.d));
            }
            catch (hq hq3) {
                throw hq2;
            }
        }
    }

    protected void b(String string) {
        boolean bl2 = false;
        Matcher \u26032 = c.matcher(string);
        int \u26033 = 0;
        int \u26034 = 0;
        try {
            while (\u26032.find(\u26034)) {
                Object object;
                int n2 = \u26032.start();
                \u2603 = \u26032.end();
                if (n2 > \u26034) {
                    object = new ho(String.format(string.substring(\u26034, n2), new Object[0]));
                    ((he)object).b().a(this.b());
                    this.b.add((hh)object);
                }
                object = \u26032.group(2);
                String \u26035 = string.substring(n2, \u2603);
                if ("%".equals(object) && "%%".equals(\u26035)) {
                    \u2603 = new ho("%");
                    ((he)\u2603).b().a(this.b());
                    this.b.add((hh)\u2603);
                } else if ("s".equals(object)) {
                    \u2603 = \u26032.group(1);
                    int n3 = \u2603 = \u2603 != null ? Integer.parseInt((String)\u2603) - 1 : \u26033++;
                    if (\u2603 < this.e.length) {
                        this.b.add(this.a(\u2603));
                    }
                } else {
                    throw new hq(this, "Unsupported format: '" + \u26035 + "'");
                }
                \u26034 = \u2603;
            }
            if (\u26034 < string.length()) {
                ho \u26036 = new ho(String.format(string.substring(\u26034), new Object[0]));
                \u26036.b().a(this.b());
                this.b.add(\u26036);
            }
        }
        catch (IllegalFormatException illegalFormatException) {
            throw new hq(this, (Throwable)illegalFormatException);
        }
    }

    private hh a(int n2) {
        hh \u26032;
        if (n2 >= this.e.length) {
            throw new hq(this, n2);
        }
        Object object = this.e[n2];
        if (object instanceof hh) {
            \u26032 = (hh)object;
        } else {
            \u26032 = new ho(object == null ? "null" : object.toString());
            \u26032.b().a(this.b());
        }
        return \u26032;
    }

    @Override
    public hh a(hn hn2) {
        super.a(hn2);
        for (Object object : this.e) {
            if (!(object instanceof hh)) continue;
            ((hh)object).b().a(this.b());
        }
        if (this.g > -1L) {
            for (hh hh2 : this.b) {
                hh2.b().a(hn2);
            }
        }
        return this;
    }

    @Override
    public Iterator<hh> iterator() {
        this.g();
        return Iterators.concat(hp.a(this.b), hp.a(this.a));
    }

    @Override
    public String e() {
        this.g();
        StringBuilder stringBuilder = new StringBuilder();
        for (hh hh2 : this.b) {
            stringBuilder.append(hh2.e());
        }
        return stringBuilder.toString();
    }

    public hp h() {
        Object[] arrobject = new Object[this.e.length];
        for (int i2 = 0; i2 < this.e.length; ++i2) {
            arrobject[i2] = this.e[i2] instanceof hh ? ((hh)this.e[i2]).f() : this.e[i2];
        }
        hp \u26032 = new hp(this.d, arrobject);
        \u26032.a(this.b().m());
        for (hh hh2 : this.a()) {
            \u26032.a(hh2.f());
        }
        return \u26032;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object instanceof hp) {
            hp hp2 = (hp)object;
            return Arrays.equals(this.e, hp2.e) && this.d.equals(hp2.d) && super.equals(object);
        }
        return false;
    }

    @Override
    public int hashCode() {
        int n2 = super.hashCode();
        n2 = 31 * n2 + this.d.hashCode();
        n2 = 31 * n2 + Arrays.hashCode(this.e);
        return n2;
    }

    @Override
    public String toString() {
        return "TranslatableComponent{key='" + this.d + '\'' + ", args=" + Arrays.toString(this.e) + ", siblings=" + this.a + ", style=" + this.b() + '}';
    }

    public String i() {
        return this.d;
    }

    public Object[] j() {
        return this.e;
    }

    @Override
    public /* synthetic */ hh f() {
        return this.h();
    }
}

