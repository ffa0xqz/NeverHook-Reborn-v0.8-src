/*
 * Decompiled with CFR 0.150.
 */
public class aih
extends ail {
    public final int a = 32;
    private final int b;
    private final float c;
    private final boolean d;
    private boolean e;
    private uy f;
    private float n;

    public aih(int n2, float f2, boolean bl2) {
        this.b = n2;
        this.d = bl2;
        this.c = f2;
        this.b(ahn.h);
    }

    public aih(int n2, boolean bl2) {
        this(n2, 0.6f, bl2);
    }

    @Override
    public ain a(ain ain22, ams ams2, vn vn2) {
        ain ain22;
        if (vn2 instanceof aeb) {
            aeb aeb2 = (aeb)vn2;
            aeb2.di().a(this, ain22);
            ams2.a(null, aeb2.p, aeb2.q, aeb2.r, qd.fD, qe.h, 0.5f, ams2.r.nextFloat() * 0.1f + 0.9f);
            this.a(ain22, ams2, aeb2);
            aeb2.b(qq.b(this));
            if (aeb2 instanceof oo) {
                m.y.a((oo)aeb2, ain22);
            }
        }
        ain22.g(1);
        return ain22;
    }

    protected void a(ain ain2, ams ams2, aeb aeb2) {
        if (!ams2.G && this.f != null && ams2.r.nextFloat() < this.n) {
            aeb2.c(new uy(this.f));
        }
    }

    @Override
    public int e(ain ain2) {
        return 32;
    }

    @Override
    public aka f(ain ain2) {
        return aka.b;
    }

    @Override
    public uc<ain> a(ams ams2, aeb aeb2, tz tz2) {
        ain ain2 = aeb2.b(tz2);
        if (aeb2.n(this.e)) {
            aeb2.c(tz2);
            return new uc<ain>(ub.a, ain2);
        }
        return new uc<ain>(ub.c, ain2);
    }

    public int h(ain ain2) {
        return this.b;
    }

    public float i(ain ain2) {
        return this.c;
    }

    public boolean g() {
        return this.d;
    }

    public aih a(uy uy2, float f2) {
        this.f = uy2;
        this.n = f2;
        return this;
    }

    public aih h() {
        this.e = true;
        return this;
    }
}

