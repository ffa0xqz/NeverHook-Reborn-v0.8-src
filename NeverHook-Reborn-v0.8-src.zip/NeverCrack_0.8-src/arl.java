/*
 * Decompiled with CFR 0.150.
 */
import java.util.Random;

public class arl
extends aou {
    public static final axf<a> a = axf.a("variant", a.class);
    private final aou b;

    public arl(bcx bcx2, bcy bcy2, aou aou2) {
        super(bcx2, bcy2);
        this.w(this.A.b().a(a, arl$a.l));
        this.b = aou2;
    }

    @Override
    public int a(Random random) {
        return Math.max(0, random.nextInt(10) - 7);
    }

    @Override
    public bcy c(awr awr2, amw amw2, et et2) {
        switch (awr2.c(a)) {
            case m: {
                return bcy.f;
            }
            case k: {
                return bcy.e;
            }
            case j: {
                return bcy.e;
            }
        }
        return super.c(awr2, amw2, et2);
    }

    @Override
    public ail a(awr awr2, Random random, int n2) {
        return ail.a(this.b);
    }

    @Override
    public ain a(ams ams2, et et2, awr awr2) {
        return new ain(this.b);
    }

    @Override
    public awr a(ams ams2, et et2, fa fa2, float f2, float f3, float f4, int n2, vn vn2) {
        return this.t();
    }

    @Override
    public awr a(int n2) {
        return this.t().a(a, arl$a.a(n2));
    }

    @Override
    public int e(awr awr2) {
        return awr2.c(a).a();
    }

    @Override
    public awr a(awr awr2, atk atk2) {
        block0 : switch (atk2) {
            case c: {
                switch (awr2.c(a)) {
                    case a: {
                        return awr2.a(a, arl$a.i);
                    }
                    case b: {
                        return awr2.a(a, arl$a.h);
                    }
                    case c: {
                        return awr2.a(a, arl$a.g);
                    }
                    case d: {
                        return awr2.a(a, arl$a.f);
                    }
                    case f: {
                        return awr2.a(a, arl$a.d);
                    }
                    case g: {
                        return awr2.a(a, arl$a.c);
                    }
                    case h: {
                        return awr2.a(a, arl$a.b);
                    }
                    case i: {
                        return awr2.a(a, arl$a.a);
                    }
                    case j: {
                        break;
                    }
                    default: {
                        return awr2;
                    }
                }
            }
            case d: {
                switch (awr2.c(a)) {
                    case a: {
                        return awr2.a(a, arl$a.g);
                    }
                    case b: {
                        return awr2.a(a, arl$a.d);
                    }
                    case c: {
                        return awr2.a(a, arl$a.a);
                    }
                    case d: {
                        return awr2.a(a, arl$a.h);
                    }
                    case f: {
                        return awr2.a(a, arl$a.b);
                    }
                    case g: {
                        return awr2.a(a, arl$a.i);
                    }
                    case h: {
                        return awr2.a(a, arl$a.f);
                    }
                    case i: {
                        return awr2.a(a, arl$a.c);
                    }
                    case j: {
                        break;
                    }
                    default: {
                        return awr2;
                    }
                }
            }
            case b: {
                switch (awr2.c(a)) {
                    case a: {
                        return awr2.a(a, arl$a.c);
                    }
                    case b: {
                        return awr2.a(a, arl$a.f);
                    }
                    case c: {
                        return awr2.a(a, arl$a.i);
                    }
                    case d: {
                        return awr2.a(a, arl$a.b);
                    }
                    case f: {
                        return awr2.a(a, arl$a.h);
                    }
                    case g: {
                        return awr2.a(a, arl$a.a);
                    }
                    case h: {
                        return awr2.a(a, arl$a.d);
                    }
                    case i: {
                        return awr2.a(a, arl$a.g);
                    }
                    case j: {
                        break block0;
                    }
                }
                return awr2;
            }
        }
        return awr2;
    }

    @Override
    public awr a(awr awr2, arw arw2) {
        a a2 = awr2.c(a);
        switch (arw2) {
            case b: {
                switch (a2) {
                    case a: {
                        return awr2.a(a, arl$a.g);
                    }
                    case b: {
                        return awr2.a(a, arl$a.h);
                    }
                    case c: {
                        return awr2.a(a, arl$a.i);
                    }
                    case g: {
                        return awr2.a(a, arl$a.a);
                    }
                    case h: {
                        return awr2.a(a, arl$a.b);
                    }
                    case i: {
                        return awr2.a(a, arl$a.c);
                    }
                }
                break;
            }
            case c: {
                switch (a2) {
                    case a: {
                        return awr2.a(a, arl$a.c);
                    }
                    case c: {
                        return awr2.a(a, arl$a.a);
                    }
                    case d: {
                        return awr2.a(a, arl$a.f);
                    }
                    case f: {
                        return awr2.a(a, arl$a.d);
                    }
                    case g: {
                        return awr2.a(a, arl$a.i);
                    }
                    case i: {
                        return awr2.a(a, arl$a.g);
                    }
                }
                break;
            }
        }
        return super.a(awr2, arw2);
    }

    @Override
    protected aws b() {
        return new aws((aou)this, a);
    }

    public static enum a implements rm
    {
        a(1, "north_west"),
        b(2, "north"),
        c(3, "north_east"),
        d(4, "west"),
        e(5, "center"),
        f(6, "east"),
        g(7, "south_west"),
        h(8, "south"),
        i(9, "south_east"),
        j(10, "stem"),
        k(0, "all_inside"),
        l(14, "all_outside"),
        m(15, "all_stem");

        private static final a[] n;
        private final int o;
        private final String p;

        private a(int n3, String string2) {
            this.o = n3;
            this.p = string2;
        }

        public int a() {
            return this.o;
        }

        public String toString() {
            return this.p;
        }

        public static a a(int n2) {
            if (n2 < 0 || n2 >= n.length) {
                n2 = 0;
            }
            return (\u2603 = n[n2]) == null ? n[0] : \u2603;
        }

        @Override
        public String m() {
            return this.p;
        }

        static {
            n = new a[16];
            a[] arra = arl$a.values();
            int n2 = arra.length;
            for (int i2 = 0; i2 < n2; ++i2) {
                a a2;
                arl$a.n[a2.a()] = a2 = arra[i2];
            }
        }
    }
}

