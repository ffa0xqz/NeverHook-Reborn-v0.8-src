/*
 * Decompiled with CFR 0.150.
 */
public class aer
extends aet {
    public aer(ams ams2) {
        super(ams2);
    }

    public aer(ams ams2, vn vn2) {
        super(ams2, vn2);
    }

    public aer(ams ams2, double d2, double d3, double d4) {
        super(ams2, d2, d3, d4);
    }

    public static void a(rw rw2) {
        aet.a(rw2, "Snowball");
    }

    @Override
    public void a(byte by2) {
        if (by2 == 3) {
            for (int i2 = 0; i2 < 8; ++i2) {
                this.l.a(fj.F, this.p, this.q, this.r, 0.0, 0.0, 0.0, new int[0]);
            }
        }
    }

    @Override
    protected void a(bha bha2) {
        if (bha2.d != null) {
            int n2 = 0;
            if (bha2.d instanceof aco) {
                n2 = 3;
            }
            bha2.d.a(up.a((ve)this, (ve)this.k()), (float)n2);
        }
        if (!this.l.G) {
            this.l.a((ve)this, (byte)3);
            this.X();
        }
    }
}

