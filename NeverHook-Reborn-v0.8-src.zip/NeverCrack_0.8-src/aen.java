/*
 * Decompiled with CFR 0.150.
 */
public interface aen {
    public void c(double var1, double var3, double var5, float var7, float var8);
}

