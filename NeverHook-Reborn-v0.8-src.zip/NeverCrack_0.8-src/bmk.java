/*
 * Decompiled with CFR 0.150.
 */
public class bmk
extends bme {
    private static final nd v = new nd("textures/gui/container/generic_54.png");
    private final tt w;
    private final tt x;
    private final int y;

    public bmk(tt upperInv, tt lowerInv) {
        super(new aft(upperInv, lowerInv, bhz.z().h));
        this.w = upperInv;
        this.x = lowerInv;
        this.p = false;
        int i2 = 222;
        int j2 = 114;
        this.y = lowerInv.w_() / 9;
        this.g = 114 + this.y * 18;
    }

    @Override
    public void a(int mouseX, int mouseY, float partialTicks) {
        this.c();
        super.a(mouseX, mouseY, partialTicks);
        this.b(mouseX, mouseY);
    }

    public int getInventoryRows() {
        return this.y;
    }

    @Override
    protected void c(int mouseX, int mouseY) {
        this.q.drawString(this.x.i_().c(), 8.0f, 6.0f, 0x404040);
        this.q.drawString(this.w.i_().c(), 8.0f, this.g - 96 + 2, 0x404040);
    }

    @Override
    protected void a(float partialTicks, int mouseX, int mouseY) {
        buq.c(1.0f, 1.0f, 1.0f, 1.0f);
        this.j.N().a(v);
        int i2 = (this.l - this.f) / 2;
        int j2 = (this.m - this.g) / 2;
        this.b(i2, j2, 0, 0, this.f, this.y * 18 + 17);
        this.b(i2, j2 + this.y * 18 + 17, 0, 126, this.f, 96);
    }
}

