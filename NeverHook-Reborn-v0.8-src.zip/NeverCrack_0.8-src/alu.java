/*
 * Decompiled with CFR 0.150.
 */
public class alu
extends ali {
    public final a a;

    public alu(ali.a a2, a a3, vj ... arrvj) {
        super(a2, alj.b, arrvj);
        this.a = a3;
        if (a3 == alu$a.c) {
            this.c = alj.c;
        }
    }

    @Override
    public int a(int n2) {
        return this.a.b() + (n2 - 1) * this.a.c();
    }

    @Override
    public int b(int n2) {
        return this.a(n2) + this.a.c();
    }

    @Override
    public int b() {
        return 4;
    }

    @Override
    public int a(int n2, up up2) {
        if (up2.g()) {
            return 0;
        }
        if (this.a == alu$a.a) {
            return n2;
        }
        if (this.a == alu$a.b && up2.o()) {
            return n2 * 2;
        }
        if (this.a == alu$a.c && up2 == up.k) {
            return n2 * 3;
        }
        if (this.a == alu$a.d && up2.c()) {
            return n2 * 2;
        }
        if (this.a == alu$a.e && up2.a()) {
            return n2 * 2;
        }
        return 0;
    }

    @Override
    public String a() {
        return "enchantment.protect." + this.a.a();
    }

    @Override
    public boolean a(ali ali22) {
        ali ali22;
        if (ali22 instanceof alu) {
            alu alu2 = (alu)ali22;
            if (this.a == alu2.a) {
                return false;
            }
            return this.a == alu$a.c || alu2.a == alu$a.c;
        }
        return super.a(ali22);
    }

    public static int a(vn vn2, int n2) {
        \u2603 = alk.a(alm.b, vn2);
        if (\u2603 > 0) {
            n2 -= ri.d((float)n2 * ((float)\u2603 * 0.15f));
        }
        return n2;
    }

    public static double a(vn vn2, double d2) {
        int n2 = alk.a(alm.d, vn2);
        if (n2 > 0) {
            d2 -= (double)ri.c(d2 * (double)((float)n2 * 0.15f));
        }
        return d2;
    }

    public static enum a {
        a("all", 1, 11, 20),
        b("fire", 10, 8, 12),
        c("fall", 5, 6, 10),
        d("explosion", 5, 8, 12),
        e("projectile", 3, 6, 15);

        private final String f;
        private final int g;
        private final int h;
        private final int i;

        private a(String string2, int n3, int n4, int n5) {
            this.f = string2;
            this.g = n3;
            this.h = n4;
            this.i = n5;
        }

        public String a() {
            return this.f;
        }

        public int b() {
            return this.g;
        }

        public int c() {
            return this.h;
        }
    }
}

