/*
 * Decompiled with CFR 0.150.
 */
public class ael
extends aej {
    public int e = 1;

    public ael(ams ams2) {
        super(ams2);
    }

    public ael(ams ams2, double d2, double d3, double d4, double d5, double d6, double d7) {
        super(ams2, d2, d3, d4, d5, d6, d7);
    }

    public ael(ams ams2, vn vn2, double d2, double d3, double d4) {
        super(ams2, vn2, d2, d3, d4);
    }

    @Override
    protected void a(bha bha2) {
        if (!this.l.G) {
            if (bha2.d != null) {
                bha2.d.a(up.a(this, (ve)this.a), 6.0f);
                this.a(this.a, bha2.d);
            }
            boolean bl2 = this.l.W().b("mobGriefing");
            this.l.a(null, this.p, this.q, this.r, (float)this.e, bl2, bl2);
            this.X();
        }
    }

    public static void a(rw rw2) {
        aej.a(rw2, "Fireball");
    }

    @Override
    public void b(fy fy2) {
        super.b(fy2);
        fy2.a("ExplosionPower", this.e);
    }

    @Override
    public void a(fy fy2) {
        super.a(fy2);
        if (fy2.b("ExplosionPower", 99)) {
            this.e = fy2.h("ExplosionPower");
        }
    }
}

