/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 */
import com.google.common.collect.Maps;
import java.util.Map;

public class cgv
implements ceo {
    public static final a<ain> a = new a();
    public static final a<bnq> b = new a();
    private final Map<a<?>, cgu<?>> c = Maps.newHashMap();

    @Override
    public void a(cen cen2) {
        for (cgu<?> cgu2 : this.c.values()) {
            cgu2.a();
        }
    }

    public <T> void a(a<T> a2, cgu<T> cgu2) {
        this.c.put(a2, cgu2);
    }

    public <T> cgw<T> a(a<T> a2) {
        return this.c.get(a2);
    }

    public static class a<T> {
    }
}

