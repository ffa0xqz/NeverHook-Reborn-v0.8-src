/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.lwjgl.input.Keyboard
 */
import io.netty.buffer.Unpooled;
import javax.annotation.Nullable;
import org.lwjgl.input.Keyboard;

public class bmx
extends bli
implements bln {
    private bjc a;
    private bjc f;
    private final amh g;
    private biy h;
    private biy i;
    private biy s;
    private boolean t;
    private blo u;

    public bmx(amh amh2) {
        this.g = amh2;
    }

    @Override
    public void e() {
        this.a.a();
    }

    @Override
    public void b() {
        Keyboard.enableRepeatEvents((boolean)true);
        this.n.clear();
        this.h = this.b(new biy(0, this.l / 2 - 4 - 150, this.m / 4 + 120 + 12, 150, 20, cew.a("gui.done", new Object[0])));
        this.i = this.b(new biy(1, this.l / 2 + 4, this.m / 4 + 120 + 12, 150, 20, cew.a("gui.cancel", new Object[0])));
        this.s = this.b(new biy(4, this.l / 2 + 150 - 20, 150, 20, 20, "O"));
        this.a = new bjc(2, this.q, this.l / 2 - 150, 50, 300, 20);
        this.a.f(32500);
        this.a.b(true);
        this.a.a(this.g.m());
        this.f = new bjc(3, this.q, this.l / 2 - 150, 150, 276, 20);
        this.f.f(32500);
        this.f.c(false);
        this.f.a("-");
        this.t = this.g.n();
        this.a();
        this.h.l = !this.a.b().trim().isEmpty();
        this.u = new blo(this.a, true){

            @Override
            @Nullable
            public et b() {
                return bmx.this.g.c();
            }
        };
    }

    @Override
    public void m() {
        Keyboard.enableRepeatEvents((boolean)false);
    }

    @Override
    protected void a(biy biy22) {
        biy biy22;
        if (!biy22.l) {
            return;
        }
        if (biy22.k == 1) {
            this.g.a(this.t);
            this.j.a((bli)null);
        } else if (biy22.k == 0) {
            gy gy2 = new gy(Unpooled.buffer());
            gy2.writeByte(this.g.j());
            this.g.a(gy2);
            gy2.a(this.a.b());
            gy2.writeBoolean(this.g.n());
            this.j.v().a(new lh("MC|AdvCmd", gy2));
            if (!this.g.n()) {
                this.g.b((hh)null);
            }
            this.j.a((bli)null);
        } else if (biy22.k == 4) {
            this.g.a(!this.g.n());
            this.a();
        }
    }

    @Override
    protected void a(char c2, int n2) {
        this.u.d();
        if (n2 == 15) {
            this.u.a();
        } else {
            this.u.c();
        }
        this.a.a(c2, n2);
        this.f.a(c2, n2);
        boolean bl2 = this.h.l = !this.a.b().trim().isEmpty();
        if (n2 == 28 || n2 == 156) {
            this.a(this.h);
        } else if (n2 == 1) {
            this.a(this.i);
        }
    }

    @Override
    protected void a(int n2, int n3, int n4) {
        super.a(n2, n3, n4);
        this.a.a(n2, n3, n4);
        this.f.a(n2, n3, n4);
    }

    @Override
    public void a(int n2, int n3, float f2) {
        this.c();
        this.a(this.q, cew.a("advMode.setCommand", new Object[0]), this.l / 2, 20, 0xFFFFFF);
        this.c(this.q, cew.a("advMode.command", new Object[0]), this.l / 2 - 150, 40, 0xA0A0A0);
        this.a.g();
        int n4 = 75;
        \u2603 = 0;
        this.c(this.q, cew.a("advMode.nearestPlayer", new Object[0]), this.l / 2 - 140, n4 + \u2603++ * this.q.a, 0xA0A0A0);
        this.c(this.q, cew.a("advMode.randomPlayer", new Object[0]), this.l / 2 - 140, n4 + \u2603++ * this.q.a, 0xA0A0A0);
        this.c(this.q, cew.a("advMode.allPlayers", new Object[0]), this.l / 2 - 140, n4 + \u2603++ * this.q.a, 0xA0A0A0);
        this.c(this.q, cew.a("advMode.allEntities", new Object[0]), this.l / 2 - 140, n4 + \u2603++ * this.q.a, 0xA0A0A0);
        this.c(this.q, cew.a("advMode.self", new Object[0]), this.l / 2 - 140, n4 + \u2603++ * this.q.a, 0xA0A0A0);
        if (!this.f.b().isEmpty()) {
            this.c(this.q, cew.a("advMode.previousOutput", new Object[0]), this.l / 2 - 150, n4 += \u2603 * this.q.a + 20, 0xA0A0A0);
            this.f.g();
        }
        super.a(n2, n3, f2);
    }

    private void a() {
        if (this.g.n()) {
            this.s.j = "O";
            if (this.g.l() != null) {
                this.f.a(this.g.l().c());
            }
        } else {
            this.s.j = "X";
            this.f.a("-");
        }
    }

    @Override
    public void a(String ... arrstring) {
        this.u.a(arrstring);
    }
}

