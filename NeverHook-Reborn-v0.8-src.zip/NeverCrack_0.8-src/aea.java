/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import java.util.Arrays;
import java.util.List;
import javax.annotation.Nullable;

public class aea
implements tt {
    public final fi<ain> a = fi.a(36, ain.a);
    public final fi<ain> b = fi.a(4, ain.a);
    public final fi<ain> c = fi.a(1, ain.a);
    private final List<fi<ain>> f = Arrays.asList(this.a, this.b, this.c);
    public int d;
    public aeb e;
    private ain g = ain.a;
    private int h;

    public aea(aeb aeb2) {
        this.e = aeb2;
    }

    public ain i() {
        if (aea.e(this.d)) {
            return this.a.get(this.d);
        }
        return ain.a;
    }

    public static int j() {
        return 9;
    }

    private boolean a(ain ain2, ain ain3) {
        return !ain2.b() && this.b(ain2, ain3) && ain2.e() && ain2.E() < ain2.d() && ain2.E() < this.z_();
    }

    private boolean b(ain ain2, ain ain3) {
        return ain2.c() == ain3.c() && (!ain2.g() || ain2.j() == ain3.j()) && ain.a(ain2, ain3);
    }

    public int k() {
        for (int i2 = 0; i2 < this.a.size(); ++i2) {
            if (!this.a.get(i2).b()) continue;
            return i2;
        }
        return -1;
    }

    public void a(ain ain2) {
        int n2 = this.b(ain2);
        if (aea.e(n2)) {
            this.d = n2;
            return;
        }
        if (n2 == -1) {
            this.d = this.l();
            if (!this.a.get(this.d).b() && (\u2603 = this.k()) != -1) {
                this.a.set(\u2603, this.a.get(this.d));
            }
            this.a.set(this.d, ain2);
        } else {
            this.d(n2);
        }
    }

    public void d(int n2) {
        this.d = this.l();
        ain ain2 = this.a.get(this.d);
        this.a.set(this.d, this.a.get(n2));
        this.a.set(n2, ain2);
    }

    public static boolean e(int n2) {
        return n2 >= 0 && n2 < 9;
    }

    public int b(ain ain2) {
        for (int i2 = 0; i2 < this.a.size(); ++i2) {
            if (this.a.get(i2).b() || !this.b(ain2, this.a.get(i2))) continue;
            return i2;
        }
        return -1;
    }

    public int c(ain ain2) {
        for (int i2 = 0; i2 < this.a.size(); ++i2) {
            ain ain3 = this.a.get(i2);
            if (this.a.get(i2).b() || !this.b(ain2, this.a.get(i2)) || this.a.get(i2).h() || ain3.x() || ain3.t()) continue;
            return i2;
        }
        return -1;
    }

    public int l() {
        int n2;
        for (n2 = 0; n2 < 9; ++n2) {
            \u2603 = (this.d + n2) % 9;
            if (!this.a.get(\u2603).b()) continue;
            return \u2603;
        }
        for (n2 = 0; n2 < 9; ++n2) {
            \u2603 = (this.d + n2) % 9;
            if (this.a.get(\u2603).x()) continue;
            return \u2603;
        }
        return this.d;
    }

    public void f(int n2) {
        if (n2 > 0) {
            n2 = 1;
        }
        if (n2 < 0) {
            n2 = -1;
        }
        this.d -= n2;
        while (this.d < 0) {
            this.d += 9;
        }
        while (this.d >= 9) {
            this.d -= 9;
        }
    }

    public int a(@Nullable ail ail2, int n2, int n3, @Nullable fy fy2) {
        int n4 = 0;
        for (n5 = 0; n5 < this.w_(); ++n5) {
            ain ain2 = this.a(n5);
            if (ain2.b() || ail2 != null && ain2.c() != ail2 || n2 > -1 && ain2.j() != n2 || fy2 != null && !gj.a(fy2, ain2.p(), true)) continue;
            int \u26032 = n3 <= 0 ? ain2.E() : Math.min(n3 - n4, ain2.E());
            n4 += \u26032;
            if (n3 == 0) continue;
            ain2.g(\u26032);
            if (ain2.b()) {
                this.a(n5, ain.a);
            }
            if (n3 <= 0 || n4 < n3) continue;
            return n4;
        }
        if (!this.g.b()) {
            if (ail2 != null && this.g.c() != ail2) {
                return n4;
            }
            if (n2 > -1 && this.g.j() != n2) {
                return n4;
            }
            if (fy2 != null && !gj.a(fy2, this.g.p(), true)) {
                return n4;
            }
            int n5 = n3 <= 0 ? this.g.E() : Math.min(n3 - n4, this.g.E());
            n4 += n5;
            if (n3 != 0) {
                this.g.g(n5);
                if (this.g.b()) {
                    this.g = ain.a;
                }
                if (n3 > 0 && n4 >= n3) {
                    return n4;
                }
            }
        }
        return n4;
    }

    private int i(ain ain2) {
        int n2 = this.d(ain2);
        if (n2 == -1) {
            n2 = this.k();
        }
        if (n2 == -1) {
            return ain2.E();
        }
        return this.d(n2, ain2);
    }

    private int d(int n2, ain ain2) {
        int n3;
        ail ail2 = ain2.c();
        int \u26032 = ain2.E();
        ain \u26033 = this.a(n2);
        if (\u26033.b()) {
            \u26033 = new ain(ail2, 0, ain2.j());
            if (ain2.o()) {
                \u26033.b(ain2.p().g());
            }
            this.a(n2, \u26033);
        }
        if ((n3 = \u26032) > \u26033.d() - \u26033.E()) {
            n3 = \u26033.d() - \u26033.E();
        }
        if (n3 > this.z_() - \u26033.E()) {
            n3 = this.z_() - \u26033.E();
        }
        if (n3 == 0) {
            return \u26032;
        }
        \u26033.f(n3);
        \u26033.d(5);
        return \u26032 -= n3;
    }

    public int d(ain ain2) {
        if (this.a(this.a(this.d), ain2)) {
            return this.d;
        }
        if (this.a(this.a(40), ain2)) {
            return 40;
        }
        for (int i2 = 0; i2 < this.a.size(); ++i2) {
            if (!this.a(this.a.get(i2), ain2)) continue;
            return i2;
        }
        return -1;
    }

    public void n() {
        for (fi<ain> fi2 : this.f) {
            for (int i2 = 0; i2 < fi2.size(); ++i2) {
                if (fi2.get(i2).b()) continue;
                fi2.get(i2).a(this.e.l, this.e, i2, this.d == i2);
            }
        }
    }

    public boolean e(ain ain2) {
        return this.c(-1, ain2);
    }

    public boolean c(int n22, final ain ain22) {
        if (ain22.b()) {
            return false;
        }
        try {
            int n22;
            if (!ain22.h()) {
                ain ain22;
                do {
                    int n3 = ain22.E();
                    if (n22 == -1) {
                        ain22.e(this.i(ain22));
                        continue;
                    }
                    ain22.e(this.d(n22, ain22));
                } while (!ain22.b() && ain22.E() < n3);
                if (ain22.E() == n3 && this.e.bO.d) {
                    ain22.e(0);
                    return true;
                }
                return ain22.E() < n3;
            }
            if (n22 == -1) {
                n22 = this.k();
            }
            if (n22 >= 0) {
                this.a.set(n22, ain22.l());
                this.a.get(n22).d(5);
                ain22.e(0);
                return true;
            }
            if (this.e.bO.d) {
                ain22.e(0);
                return true;
            }
            return false;
        }
        catch (Throwable throwable) {
            b b2 = b.a(throwable, "Adding item to inventory");
            c \u26032 = b2.a("Item being added");
            \u26032.a("Item ID", ail.a(ain22.c()));
            \u26032.a("Item data", ain22.j());
            \u26032.a("Item name", new d<String>(){

                public String a() throws Exception {
                    return ain22.r();
                }

                @Override
                public /* synthetic */ Object call() throws Exception {
                    return this.a();
                }
            });
            throw new f(b2);
        }
    }

    public void a(ams ams2, ain ain2) {
        if (ams2.G) {
            return;
        }
        while (!ain2.b()) {
            int n2 = this.d(ain2);
            if (n2 == -1) {
                n2 = this.k();
            }
            if (n2 == -1) {
                this.e.a(ain2, false);
                break;
            }
            \u2603 = ain2.d() - this.a(n2).E();
            if (!this.c(n2, ain2.a(\u2603))) continue;
            ((oo)this.e).a.a(new iu(-2, n2, this.a(n2)));
        }
    }

    @Override
    public ain a(int n2, int n3) {
        fi<ain> fi2 = null;
        for (fi<ain> fi3 : this.f) {
            if (n2 < fi3.size()) {
                fi2 = fi3;
                break;
            }
            n2 -= fi3.size();
        }
        if (fi2 != null && !((ain)fi2.get(n2)).b()) {
            return tu.a(fi2, n2, n3);
        }
        return ain.a;
    }

    public void f(ain ain2) {
        block0: for (fi<ain> fi2 : this.f) {
            for (int i2 = 0; i2 < fi2.size(); ++i2) {
                if (fi2.get(i2) != ain2) continue;
                fi2.set(i2, ain.a);
                continue block0;
            }
        }
    }

    @Override
    public ain c_(int n2) {
        fi<ain> fi2 = null;
        for (fi<ain> fi3 : this.f) {
            if (n2 < fi3.size()) {
                fi2 = fi3;
                break;
            }
            n2 -= fi3.size();
        }
        if (fi2 != null && !((ain)fi2.get(n2)).b()) {
            ain ain2 = fi2.get(n2);
            fi2.set(n2, ain.a);
            return ain2;
        }
        return ain.a;
    }

    @Override
    public void a(int n2, ain ain2) {
        fi<ain> fi2 = null;
        for (fi<ain> fi3 : this.f) {
            if (n2 < fi3.size()) {
                fi2 = fi3;
                break;
            }
            n2 -= fi3.size();
        }
        if (fi2 != null) {
            fi2.set(n2, ain2);
        }
    }

    public float a(awr awr2) {
        float f2 = 1.0f;
        if (!this.a.get(this.d).b()) {
            f2 *= this.a.get(this.d).a(awr2);
        }
        return f2;
    }

    public ge a(ge ge22) {
        ge ge22;
        fy fy2;
        int n2;
        for (n2 = 0; n2 < this.a.size(); ++n2) {
            if (this.a.get(n2).b()) continue;
            fy2 = new fy();
            fy2.a("Slot", (byte)n2);
            this.a.get(n2).a(fy2);
            ge22.a(fy2);
        }
        for (n2 = 0; n2 < this.b.size(); ++n2) {
            if (this.b.get(n2).b()) continue;
            fy2 = new fy();
            fy2.a("Slot", (byte)(n2 + 100));
            this.b.get(n2).a(fy2);
            ge22.a(fy2);
        }
        for (n2 = 0; n2 < this.c.size(); ++n2) {
            if (this.c.get(n2).b()) continue;
            fy2 = new fy();
            fy2.a("Slot", (byte)(n2 + 150));
            this.c.get(n2).a(fy2);
            ge22.a(fy2);
        }
        return ge22;
    }

    public void b(ge ge2) {
        this.a.clear();
        this.b.clear();
        this.c.clear();
        for (int i2 = 0; i2 < ge2.c(); ++i2) {
            fy fy2 = ge2.b(i2);
            int \u26032 = fy2.f("Slot") & 0xFF;
            ain \u26033 = new ain(fy2);
            if (\u26033.b()) continue;
            if (\u26032 >= 0 && \u26032 < this.a.size()) {
                this.a.set(\u26032, \u26033);
                continue;
            }
            if (\u26032 >= 100 && \u26032 < this.b.size() + 100) {
                this.b.set(\u26032 - 100, \u26033);
                continue;
            }
            if (\u26032 < 150 || \u26032 >= this.c.size() + 150) continue;
            this.c.set(\u26032 - 150, \u26033);
        }
    }

    @Override
    public int w_() {
        return this.a.size() + this.b.size() + this.c.size();
    }

    @Override
    public boolean x_() {
        for (ain ain2 : this.a) {
            if (ain2.b()) continue;
            return false;
        }
        for (ain ain2 : this.b) {
            if (ain2.b()) continue;
            return false;
        }
        for (ain ain2 : this.c) {
            if (ain2.b()) continue;
            return false;
        }
        return true;
    }

    @Override
    public ain a(int n2) {
        fi<ain> fi2 = null;
        for (fi<ain> fi3 : this.f) {
            if (n2 < fi3.size()) {
                fi2 = fi3;
                break;
            }
            n2 -= fi3.size();
        }
        return fi2 == null ? ain.a : (ain)fi2.get(n2);
    }

    @Override
    public String h_() {
        return "container.inventory";
    }

    @Override
    public boolean n_() {
        return false;
    }

    @Override
    public hh i_() {
        if (this.n_()) {
            return new ho(this.h_());
        }
        return new hp(this.h_(), new Object[0]);
    }

    @Override
    public int z_() {
        return 64;
    }

    public boolean b(awr awr2) {
        if (awr2.a().l()) {
            return true;
        }
        ain ain2 = this.a(this.d);
        if (!ain2.b()) {
            return ain2.b(awr2);
        }
        return false;
    }

    public ain g(int n2) {
        return this.b.get(n2);
    }

    public void a(float f2) {
        if ((f2 /= 4.0f) < 1.0f) {
            f2 = 1.0f;
        }
        for (int i2 = 0; i2 < this.b.size(); ++i2) {
            ain ain2 = this.b.get(i2);
            if (!(ain2.c() instanceof agt)) continue;
            ain2.a((int)f2, (vn)this.e);
        }
    }

    public void o() {
        for (List list : this.f) {
            for (int i2 = 0; i2 < list.size(); ++i2) {
                ain ain2 = (ain)list.get(i2);
                if (ain2.b()) continue;
                this.e.a(ain2, true, false);
                list.set(i2, ain.a);
            }
        }
    }

    @Override
    public void y_() {
        ++this.h;
    }

    public int p() {
        return this.h;
    }

    public void g(ain ain2) {
        this.g = ain2;
    }

    public ain q() {
        return this.g;
    }

    @Override
    public boolean a(aeb aeb2) {
        if (this.e.F) {
            return false;
        }
        return !(aeb2.h(this.e) > 64.0);
    }

    public boolean h(ain ain2) {
        for (List list : this.f) {
            for (ain ain3 : list) {
                if (ain3.b() || !ain3.a(ain2)) continue;
                return true;
            }
        }
        return false;
    }

    @Override
    public void b(aeb aeb2) {
    }

    @Override
    public void c(aeb aeb2) {
    }

    @Override
    public boolean b(int n2, ain ain2) {
        return true;
    }

    public void a(aea aea22) {
        aea aea22;
        for (int i2 = 0; i2 < this.w_(); ++i2) {
            this.a(i2, aea22.a(i2));
        }
        this.d = aea22.d;
    }

    @Override
    public int c(int n2) {
        return 0;
    }

    @Override
    public void b(int n2, int n3) {
    }

    @Override
    public int h() {
        return 0;
    }

    @Override
    public void m() {
        for (List list : this.f) {
            list.clear();
        }
    }

    public void a(aed aed2, boolean bl22) {
        boolean bl22;
        for (ain ain2 : this.a) {
            aed2.a(ain2);
        }
        if (bl22) {
            aed2.a(this.c.get(0));
        }
    }
}

