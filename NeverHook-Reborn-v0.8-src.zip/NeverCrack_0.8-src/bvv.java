/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import javax.annotation.Nullable;
import net.minecraftforge.common.model.ITransformation;
import optifine.BlockModelUtils;
import optifine.Config;
import optifine.Reflector;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector3f;
import org.lwjgl.util.vector.Vector4f;
import shadersmod.client.Shaders;

public class bvv {
    private static final float a = 1.0f / (float)Math.cos(0.3926991f) - 1.0f;
    private static final float b = 1.0f / (float)Math.cos(0.7853981633974483) - 1.0f;
    private static final a[] c = new a[cfx.values().length * fa.values().length];
    private static final a d = new a(){

        @Override
        bvr a(float p_188007_1_, float p_188007_2_, float p_188007_3_, float p_188007_4_) {
            return new bvr(new float[]{p_188007_1_, p_188007_2_, p_188007_3_, p_188007_4_}, 0);
        }
    };
    private static final a e = new a(){

        @Override
        bvr a(float p_188007_1_, float p_188007_2_, float p_188007_3_, float p_188007_4_) {
            return new bvr(new float[]{p_188007_4_, 16.0f - p_188007_1_, p_188007_2_, 16.0f - p_188007_3_}, 270);
        }
    };
    private static final a f = new a(){

        @Override
        bvr a(float p_188007_1_, float p_188007_2_, float p_188007_3_, float p_188007_4_) {
            return new bvr(new float[]{16.0f - p_188007_1_, 16.0f - p_188007_2_, 16.0f - p_188007_3_, 16.0f - p_188007_4_}, 0);
        }
    };
    private static final a g = new a(){

        @Override
        bvr a(float p_188007_1_, float p_188007_2_, float p_188007_3_, float p_188007_4_) {
            return new bvr(new float[]{16.0f - p_188007_2_, p_188007_3_, 16.0f - p_188007_4_, p_188007_1_}, 90);
        }
    };

    public bvn a(Vector3f posFrom, Vector3f posTo, bvp face, cdo sprite, fa facing, cfx modelRotationIn, @Nullable bvq partRotation, boolean uvLocked, boolean shade) {
        bvr blockfaceuv = face.e;
        if (uvLocked) {
            blockfaceuv = this.a(face.e, facing, modelRotationIn);
        }
        int[] aint = this.makeQuadVertexData(blockfaceuv, sprite, facing, this.a(posFrom, posTo), modelRotationIn, partRotation, shade);
        fa enumfacing = bvv.a(aint);
        if (partRotation == null) {
            this.a(aint, enumfacing);
        }
        return new bvn(aint, face.c, enumfacing, sprite);
    }

    public bvn makeBakedQuad(Vector3f p_makeBakedQuad_1_, Vector3f p_makeBakedQuad_2_, bvp p_makeBakedQuad_3_, cdo p_makeBakedQuad_4_, fa p_makeBakedQuad_5_, ITransformation p_makeBakedQuad_6_, bvq p_makeBakedQuad_7_, boolean p_makeBakedQuad_8_, boolean p_makeBakedQuad_9_) {
        bvr blockfaceuv = p_makeBakedQuad_3_.e;
        if (p_makeBakedQuad_8_) {
            blockfaceuv = Reflector.ForgeHooksClient_applyUVLock.exists() ? (bvr)Reflector.call(Reflector.ForgeHooksClient_applyUVLock, p_makeBakedQuad_3_.e, p_makeBakedQuad_5_, p_makeBakedQuad_6_) : this.a(p_makeBakedQuad_3_.e, p_makeBakedQuad_5_, (cfx)p_makeBakedQuad_6_);
        }
        boolean flag = p_makeBakedQuad_9_ && !Reflector.ForgeHooksClient_fillNormal.exists();
        int[] aint = this.makeQuadVertexData(blockfaceuv, p_makeBakedQuad_4_, p_makeBakedQuad_5_, this.a(p_makeBakedQuad_1_, p_makeBakedQuad_2_), p_makeBakedQuad_6_, p_makeBakedQuad_7_, flag);
        fa enumfacing = bvv.a(aint);
        if (p_makeBakedQuad_7_ == null) {
            this.a(aint, enumfacing);
        }
        if (Reflector.ForgeHooksClient_fillNormal.exists()) {
            Reflector.call(Reflector.ForgeHooksClient_fillNormal, aint, enumfacing);
            return new bvn(aint, p_makeBakedQuad_3_.c, enumfacing, p_makeBakedQuad_4_, p_makeBakedQuad_9_, cdw.b);
        }
        return new bvn(aint, p_makeBakedQuad_3_.c, enumfacing, p_makeBakedQuad_4_);
    }

    private bvr a(bvr p_188010_1_, fa p_188010_2_, cfx p_188010_3_) {
        return c[bvv.a(p_188010_3_, p_188010_2_)].a(p_188010_1_);
    }

    private int[] makeQuadVertexData(bvr p_makeQuadVertexData_1_, cdo p_makeQuadVertexData_2_, fa p_makeQuadVertexData_3_, float[] p_makeQuadVertexData_4_, ITransformation p_makeQuadVertexData_5_, @Nullable bvq p_makeQuadVertexData_6_, boolean p_makeQuadVertexData_7_) {
        int i2 = 28;
        if (Config.isShaders()) {
            i2 = 56;
        }
        int[] aint = new int[i2];
        for (int j2 = 0; j2 < 4; ++j2) {
            this.fillVertexData(aint, j2, p_makeQuadVertexData_3_, p_makeQuadVertexData_1_, p_makeQuadVertexData_4_, p_makeQuadVertexData_2_, p_makeQuadVertexData_5_, p_makeQuadVertexData_6_, p_makeQuadVertexData_7_);
        }
        return aint;
    }

    private int a(fa facing) {
        float f2 = bvv.b(facing);
        int i2 = ri.a((int)(f2 * 255.0f), 0, 255);
        return 0xFF000000 | i2 << 16 | i2 << 8 | i2;
    }

    public static float b(fa p_178412_0_) {
        switch (p_178412_0_) {
            case a: {
                if (Config.isShaders()) {
                    return Shaders.blockLightLevel05;
                }
                return 0.5f;
            }
            case b: {
                return 1.0f;
            }
            case c: 
            case d: {
                if (Config.isShaders()) {
                    return Shaders.blockLightLevel08;
                }
                return 0.8f;
            }
            case e: 
            case f: {
                if (Config.isShaders()) {
                    return Shaders.blockLightLevel06;
                }
                return 0.6f;
            }
        }
        return 1.0f;
    }

    private float[] a(Vector3f pos1, Vector3f pos2) {
        float[] afloat = new float[fa.values().length];
        afloat[bun.a.f] = pos1.x / 16.0f;
        afloat[bun.a.e] = pos1.y / 16.0f;
        afloat[bun.a.d] = pos1.z / 16.0f;
        afloat[bun.a.c] = pos2.x / 16.0f;
        afloat[bun.a.b] = pos2.y / 16.0f;
        afloat[bun.a.a] = pos2.z / 16.0f;
        return afloat;
    }

    private void fillVertexData(int[] p_fillVertexData_1_, int p_fillVertexData_2_, fa p_fillVertexData_3_, bvr p_fillVertexData_4_, float[] p_fillVertexData_5_, cdo p_fillVertexData_6_, ITransformation p_fillVertexData_7_, @Nullable bvq p_fillVertexData_8_, boolean p_fillVertexData_9_) {
        fa enumfacing = p_fillVertexData_7_.rotate(p_fillVertexData_3_);
        int i2 = p_fillVertexData_9_ ? this.a(enumfacing) : -1;
        bun.b enumfacedirection$vertexinformation = bun.a(p_fillVertexData_3_).a(p_fillVertexData_2_);
        Vector3f vector3f = new Vector3f(p_fillVertexData_5_[enumfacedirection$vertexinformation.a], p_fillVertexData_5_[enumfacedirection$vertexinformation.b], p_fillVertexData_5_[enumfacedirection$vertexinformation.c]);
        this.a(vector3f, p_fillVertexData_8_);
        int j2 = this.rotateVertex(vector3f, p_fillVertexData_3_, p_fillVertexData_2_, p_fillVertexData_7_);
        BlockModelUtils.snapVertexPosition(vector3f);
        this.a(p_fillVertexData_1_, j2, p_fillVertexData_2_, vector3f, i2, p_fillVertexData_6_, p_fillVertexData_4_);
    }

    private void a(int[] faceData, int storeIndex, int vertexIndex, Vector3f position, int shadeColor, cdo sprite, bvr faceUV) {
        int i2 = faceData.length / 4;
        int j2 = storeIndex * i2;
        faceData[j2] = Float.floatToRawIntBits(position.x);
        faceData[j2 + 1] = Float.floatToRawIntBits(position.y);
        faceData[j2 + 2] = Float.floatToRawIntBits(position.z);
        faceData[j2 + 3] = shadeColor;
        faceData[j2 + 4] = Float.floatToRawIntBits(sprite.a((double)faceUV.a(vertexIndex) * 0.999 + (double)faceUV.a((vertexIndex + 2) % 4) * 0.001));
        faceData[j2 + 4 + 1] = Float.floatToRawIntBits(sprite.b((double)faceUV.b(vertexIndex) * 0.999 + (double)faceUV.b((vertexIndex + 2) % 4) * 0.001));
    }

    private void a(Vector3f p_178407_1_, @Nullable bvq partRotation) {
        if (partRotation != null) {
            Matrix4f matrix4f = this.a();
            Vector3f vector3f = new Vector3f(0.0f, 0.0f, 0.0f);
            switch (partRotation.b) {
                case a: {
                    Matrix4f.rotate(partRotation.c * ((float)Math.PI / 180), new Vector3f(1.0f, 0.0f, 0.0f), matrix4f, matrix4f);
                    vector3f.set(0.0f, 1.0f, 1.0f);
                    break;
                }
                case b: {
                    Matrix4f.rotate(partRotation.c * ((float)Math.PI / 180), new Vector3f(0.0f, 1.0f, 0.0f), matrix4f, matrix4f);
                    vector3f.set(1.0f, 0.0f, 1.0f);
                    break;
                }
                case c: {
                    Matrix4f.rotate(partRotation.c * ((float)Math.PI / 180), new Vector3f(0.0f, 0.0f, 1.0f), matrix4f, matrix4f);
                    vector3f.set(1.0f, 1.0f, 0.0f);
                }
            }
            if (partRotation.d) {
                if (Math.abs(partRotation.c) == 22.5f) {
                    vector3f.scale(a);
                } else {
                    vector3f.scale(b);
                }
                Vector3f.add(vector3f, new Vector3f(1.0f, 1.0f, 1.0f), vector3f);
            } else {
                vector3f.set(1.0f, 1.0f, 1.0f);
            }
            this.a(p_178407_1_, new Vector3f(partRotation.a), matrix4f, vector3f);
        }
    }

    public int a(Vector3f p_188011_1_, fa p_188011_2_, int p_188011_3_, cfx p_188011_4_) {
        return this.a(p_188011_1_, p_188011_2_, p_188011_3_, p_188011_4_);
    }

    public int rotateVertex(Vector3f p_rotateVertex_1_, fa p_rotateVertex_2_, int p_rotateVertex_3_, ITransformation p_rotateVertex_4_) {
        if (p_rotateVertex_4_ == cfx.a) {
            return p_rotateVertex_3_;
        }
        if (Reflector.ForgeHooksClient_transform.exists()) {
            Reflector.call(Reflector.ForgeHooksClient_transform, p_rotateVertex_1_, p_rotateVertex_4_.getMatrix());
        } else {
            this.a(p_rotateVertex_1_, new Vector3f(0.5f, 0.5f, 0.5f), ((cfx)p_rotateVertex_4_).a(), new Vector3f(1.0f, 1.0f, 1.0f));
        }
        return p_rotateVertex_4_.rotate(p_rotateVertex_2_, p_rotateVertex_3_);
    }

    private void a(Vector3f position, Vector3f rotationOrigin, Matrix4f rotationMatrix, Vector3f scale) {
        Vector4f vector4f = new Vector4f(position.x - rotationOrigin.x, position.y - rotationOrigin.y, position.z - rotationOrigin.z, 1.0f);
        Matrix4f.transform(rotationMatrix, vector4f, vector4f);
        vector4f.x *= scale.x;
        vector4f.y *= scale.y;
        vector4f.z *= scale.z;
        position.set(vector4f.x + rotationOrigin.x, vector4f.y + rotationOrigin.y, vector4f.z + rotationOrigin.z);
    }

    private Matrix4f a() {
        Matrix4f matrix4f = new Matrix4f();
        matrix4f.setIdentity();
        return matrix4f;
    }

    public static fa a(int[] faceData) {
        int i2 = faceData.length / 4;
        int j2 = i2 * 2;
        Vector3f vector3f = new Vector3f(Float.intBitsToFloat(faceData[0]), Float.intBitsToFloat(faceData[1]), Float.intBitsToFloat(faceData[2]));
        Vector3f vector3f1 = new Vector3f(Float.intBitsToFloat(faceData[i2]), Float.intBitsToFloat(faceData[i2 + 1]), Float.intBitsToFloat(faceData[i2 + 2]));
        Vector3f vector3f2 = new Vector3f(Float.intBitsToFloat(faceData[j2]), Float.intBitsToFloat(faceData[j2 + 1]), Float.intBitsToFloat(faceData[j2 + 2]));
        Vector3f vector3f3 = new Vector3f();
        Vector3f vector3f4 = new Vector3f();
        Vector3f vector3f5 = new Vector3f();
        Vector3f.sub(vector3f, vector3f1, vector3f3);
        Vector3f.sub(vector3f2, vector3f1, vector3f4);
        Vector3f.cross(vector3f4, vector3f3, vector3f5);
        float f2 = (float)Math.sqrt(vector3f5.x * vector3f5.x + vector3f5.y * vector3f5.y + vector3f5.z * vector3f5.z);
        vector3f5.x /= f2;
        vector3f5.y /= f2;
        vector3f5.z /= f2;
        fa enumfacing = null;
        float f1 = 0.0f;
        for (fa enumfacing1 : fa.values()) {
            fq vec3i = enumfacing1.n();
            Vector3f vector3f6 = new Vector3f(vec3i.p(), vec3i.q(), vec3i.r());
            float f22 = Vector3f.dot(vector3f5, vector3f6);
            if (!(f22 >= 0.0f) || !(f22 > f1)) continue;
            f1 = f22;
            enumfacing = enumfacing1;
        }
        if (enumfacing == null) {
            return fa.b;
        }
        return enumfacing;
    }

    private void a(int[] p_178408_1_, fa p_178408_2_) {
        int[] aint = new int[p_178408_1_.length];
        System.arraycopy(p_178408_1_, 0, aint, 0, p_178408_1_.length);
        float[] afloat = new float[fa.values().length];
        afloat[bun.a.f] = 999.0f;
        afloat[bun.a.e] = 999.0f;
        afloat[bun.a.d] = 999.0f;
        afloat[bun.a.c] = -999.0f;
        afloat[bun.a.b] = -999.0f;
        afloat[bun.a.a] = -999.0f;
        int i2 = p_178408_1_.length / 4;
        for (int j2 = 0; j2 < 4; ++j2) {
            int k2 = i2 * j2;
            float f2 = Float.intBitsToFloat(aint[k2]);
            float f1 = Float.intBitsToFloat(aint[k2 + 1]);
            float f22 = Float.intBitsToFloat(aint[k2 + 2]);
            if (f2 < afloat[bun.a.f]) {
                afloat[bun.a.f] = f2;
            }
            if (f1 < afloat[bun.a.e]) {
                afloat[bun.a.e] = f1;
            }
            if (f22 < afloat[bun.a.d]) {
                afloat[bun.a.d] = f22;
            }
            if (f2 > afloat[bun.a.c]) {
                afloat[bun.a.c] = f2;
            }
            if (f1 > afloat[bun.a.b]) {
                afloat[bun.a.b] = f1;
            }
            if (!(f22 > afloat[bun.a.a])) continue;
            afloat[bun.a.a] = f22;
        }
        bun enumfacedirection = bun.a(p_178408_2_);
        for (int j1 = 0; j1 < 4; ++j1) {
            int k1 = i2 * j1;
            bun.b enumfacedirection$vertexinformation = enumfacedirection.a(j1);
            float f8 = afloat[enumfacedirection$vertexinformation.a];
            float f3 = afloat[enumfacedirection$vertexinformation.b];
            float f4 = afloat[enumfacedirection$vertexinformation.c];
            p_178408_1_[k1] = Float.floatToRawIntBits(f8);
            p_178408_1_[k1 + 1] = Float.floatToRawIntBits(f3);
            p_178408_1_[k1 + 2] = Float.floatToRawIntBits(f4);
            for (int l2 = 0; l2 < 4; ++l2) {
                int i1 = i2 * l2;
                float f5 = Float.intBitsToFloat(aint[i1]);
                float f6 = Float.intBitsToFloat(aint[i1 + 1]);
                float f7 = Float.intBitsToFloat(aint[i1 + 2]);
                if (!ri.a(f8, f5) || !ri.a(f3, f6) || !ri.a(f4, f7)) continue;
                p_178408_1_[k1 + 4] = aint[i1 + 4];
                p_178408_1_[k1 + 4 + 1] = aint[i1 + 4 + 1];
            }
        }
    }

    private static void a(cfx p_188013_0_, fa p_188013_1_, a p_188013_2_) {
        bvv.c[bvv.a((cfx)p_188013_0_, (fa)p_188013_1_)] = p_188013_2_;
    }

    private static int a(cfx p_188014_0_, fa p_188014_1_) {
        return cfx.values().length * p_188014_1_.ordinal() + p_188014_0_.ordinal();
    }

    static {
        bvv.a(cfx.a, fa.a, d);
        bvv.a(cfx.a, fa.f, d);
        bvv.a(cfx.a, fa.c, d);
        bvv.a(cfx.a, fa.d, d);
        bvv.a(cfx.a, fa.b, d);
        bvv.a(cfx.a, fa.e, d);
        bvv.a(cfx.b, fa.f, d);
        bvv.a(cfx.b, fa.c, d);
        bvv.a(cfx.b, fa.d, d);
        bvv.a(cfx.b, fa.e, d);
        bvv.a(cfx.c, fa.f, d);
        bvv.a(cfx.c, fa.c, d);
        bvv.a(cfx.c, fa.d, d);
        bvv.a(cfx.c, fa.e, d);
        bvv.a(cfx.d, fa.f, d);
        bvv.a(cfx.d, fa.c, d);
        bvv.a(cfx.d, fa.d, d);
        bvv.a(cfx.d, fa.e, d);
        bvv.a(cfx.e, fa.a, d);
        bvv.a(cfx.e, fa.d, d);
        bvv.a(cfx.f, fa.a, d);
        bvv.a(cfx.g, fa.a, d);
        bvv.a(cfx.g, fa.c, d);
        bvv.a(cfx.h, fa.a, d);
        bvv.a(cfx.i, fa.a, d);
        bvv.a(cfx.i, fa.b, d);
        bvv.a(cfx.m, fa.d, d);
        bvv.a(cfx.m, fa.b, d);
        bvv.a(cfx.n, fa.b, d);
        bvv.a(cfx.o, fa.c, d);
        bvv.a(cfx.o, fa.b, d);
        bvv.a(cfx.p, fa.b, d);
        bvv.a(cfx.d, fa.b, e);
        bvv.a(cfx.b, fa.a, e);
        bvv.a(cfx.e, fa.e, e);
        bvv.a(cfx.f, fa.e, e);
        bvv.a(cfx.g, fa.e, e);
        bvv.a(cfx.h, fa.c, e);
        bvv.a(cfx.h, fa.d, e);
        bvv.a(cfx.h, fa.e, e);
        bvv.a(cfx.j, fa.b, e);
        bvv.a(cfx.l, fa.a, e);
        bvv.a(cfx.m, fa.f, e);
        bvv.a(cfx.n, fa.f, e);
        bvv.a(cfx.n, fa.c, e);
        bvv.a(cfx.n, fa.d, e);
        bvv.a(cfx.o, fa.f, e);
        bvv.a(cfx.p, fa.f, e);
        bvv.a(cfx.c, fa.a, f);
        bvv.a(cfx.c, fa.b, f);
        bvv.a(cfx.e, fa.c, f);
        bvv.a(cfx.e, fa.b, f);
        bvv.a(cfx.f, fa.b, f);
        bvv.a(cfx.g, fa.d, f);
        bvv.a(cfx.g, fa.b, f);
        bvv.a(cfx.h, fa.b, f);
        bvv.a(cfx.i, fa.f, f);
        bvv.a(cfx.i, fa.c, f);
        bvv.a(cfx.i, fa.d, f);
        bvv.a(cfx.i, fa.e, f);
        bvv.a(cfx.j, fa.f, f);
        bvv.a(cfx.j, fa.c, f);
        bvv.a(cfx.j, fa.d, f);
        bvv.a(cfx.j, fa.e, f);
        bvv.a(cfx.k, fa.a, f);
        bvv.a(cfx.k, fa.f, f);
        bvv.a(cfx.k, fa.c, f);
        bvv.a(cfx.k, fa.d, f);
        bvv.a(cfx.k, fa.b, f);
        bvv.a(cfx.k, fa.e, f);
        bvv.a(cfx.l, fa.f, f);
        bvv.a(cfx.l, fa.c, f);
        bvv.a(cfx.l, fa.d, f);
        bvv.a(cfx.l, fa.e, f);
        bvv.a(cfx.m, fa.a, f);
        bvv.a(cfx.m, fa.c, f);
        bvv.a(cfx.n, fa.a, f);
        bvv.a(cfx.o, fa.a, f);
        bvv.a(cfx.o, fa.d, f);
        bvv.a(cfx.p, fa.a, f);
        bvv.a(cfx.b, fa.b, g);
        bvv.a(cfx.d, fa.a, g);
        bvv.a(cfx.e, fa.f, g);
        bvv.a(cfx.f, fa.f, g);
        bvv.a(cfx.f, fa.c, g);
        bvv.a(cfx.f, fa.d, g);
        bvv.a(cfx.g, fa.f, g);
        bvv.a(cfx.h, fa.f, g);
        bvv.a(cfx.m, fa.e, g);
        bvv.a(cfx.j, fa.a, g);
        bvv.a(cfx.l, fa.b, g);
        bvv.a(cfx.n, fa.e, g);
        bvv.a(cfx.o, fa.e, g);
        bvv.a(cfx.p, fa.c, g);
        bvv.a(cfx.p, fa.d, g);
        bvv.a(cfx.p, fa.e, g);
    }

    static abstract class a {
        private a() {
        }

        public bvr a(bvr p_188006_1_) {
            float f2 = p_188006_1_.a(p_188006_1_.c(0));
            float f1 = p_188006_1_.b(p_188006_1_.c(0));
            float f22 = p_188006_1_.a(p_188006_1_.c(2));
            float f3 = p_188006_1_.b(p_188006_1_.c(2));
            return this.a(f2, f1, f22, f3);
        }

        abstract bvr a(float var1, float var2, float var3, float var4);
    }
}

