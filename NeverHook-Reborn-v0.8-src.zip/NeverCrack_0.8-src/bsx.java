/*
 * Decompiled with CFR 0.150.
 */
public class bsx
extends btd {
    private int a;
    private final int b;

    protected bsx(ams ams2, double d2, double d3, double d4, double d5, double d6, double d7) {
        super(ams2, d2, d3, d4, 0.0, 0.0, 0.0);
        this.b = 8;
    }

    @Override
    public void a(bui bui2, ve ve2, float f2, float f3, float f4, float f5, float f6, float f7) {
    }

    @Override
    public void a() {
        for (int i2 = 0; i2 < 6; ++i2) {
            double d2 = this.g + (this.r.nextDouble() - this.r.nextDouble()) * 4.0;
            \u2603 = this.h + (this.r.nextDouble() - this.r.nextDouble()) * 4.0;
            \u2603 = this.i + (this.r.nextDouble() - this.r.nextDouble()) * 4.0;
            this.c.a(fj.b, d2, \u2603, \u2603, (double)((float)this.a / (float)this.b), 0.0, 0.0, new int[0]);
        }
        ++this.a;
        if (this.a == this.b) {
            this.i();
        }
    }

    @Override
    public int b() {
        return 1;
    }

    public static class a
    implements btf {
        @Override
        public btd a(int n2, ams ams2, double d2, double d3, double d4, double d5, double d6, double d7, int ... arrn) {
            return new bsx(ams2, d2, d3, d4, d5, d6, d7);
        }
    }
}

