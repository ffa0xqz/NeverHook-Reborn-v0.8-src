/*
 * Decompiled with CFR 0.150.
 */
public class xe
extends xp {
    private final adw c;
    private boolean d;
    private boolean e;
    private int f;

    public xe(adw adw2, double d2) {
        super(adw2, d2, 16);
        this.c = adw2;
    }

    @Override
    public boolean a() {
        if (this.a <= 0) {
            if (!this.c.l.W().b("mobGriefing")) {
                return false;
            }
            this.f = -1;
            this.d = this.c.du();
            this.e = this.c.dt();
        }
        return super.a();
    }

    @Override
    public boolean b() {
        return this.f >= 0 && super.b();
    }

    @Override
    public void e() {
        super.e();
        this.c.t().a((double)this.b.p() + 0.5, this.b.q() + 1, (double)this.b.r() + 0.5, 10.0f, this.c.N());
        if (this.f()) {
            ams ams2 = this.c.l;
            et \u26032 = this.b.a();
            awr \u26033 = ams2.o(\u26032);
            aou \u26034 = \u26033.u();
            if (this.f == 0 && \u26034 instanceof apq && ((apq)\u26034).z(\u26033)) {
                ams2.b(\u26032, true);
            } else if (this.f == 1 && \u26033.a() == bcx.a) {
                ui ui2 = this.c.dq();
                for (int i2 = 0; i2 < ui2.w_(); ++i2) {
                    ain ain2 = ui2.a(i2);
                    boolean \u26035 = false;
                    if (!ain2.b()) {
                        if (ain2.c() == aip.Q) {
                            ams2.a(\u26032, aov.aj.t(), 3);
                            \u26035 = true;
                        } else if (ain2.c() == aip.cd) {
                            ams2.a(\u26032, aov.cc.t(), 3);
                            \u26035 = true;
                        } else if (ain2.c() == aip.cc) {
                            ams2.a(\u26032, aov.cb.t(), 3);
                            \u26035 = true;
                        } else if (ain2.c() == aip.cV) {
                            ams2.a(\u26032, aov.cZ.t(), 3);
                            \u26035 = true;
                        }
                    }
                    if (!\u26035) continue;
                    ain2.g(1);
                    if (!ain2.b()) break;
                    ui2.a(i2, ain.a);
                    break;
                }
            }
            this.f = -1;
            this.a = 10;
        }
    }

    @Override
    protected boolean a(ams ams2, et et2) {
        aou \u26032 = ams2.o(et2).u();
        if (\u26032 == aov.ak) {
            awr awr2 = ams2.o(et2 = et2.a());
            \u26032 = awr2.u();
            if (\u26032 instanceof apq && ((apq)\u26032).z(awr2) && this.e && (this.f == 0 || this.f < 0)) {
                this.f = 0;
                return true;
            }
            if (awr2.a() == bcx.a && this.d && (this.f == 1 || this.f < 0)) {
                this.f = 1;
                return true;
            }
        }
        return false;
    }
}

