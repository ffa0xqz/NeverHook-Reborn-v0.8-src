/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 */
import com.google.common.collect.Maps;
import java.util.Map;

public class hg {
    private final a a;
    private final String b;

    public hg(a a2, String string) {
        this.a = a2;
        this.b = string;
    }

    public a a() {
        return this.a;
    }

    public String b() {
        return this.b;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null || this.getClass() != object.getClass()) {
            return false;
        }
        hg hg2 = (hg)object;
        if (this.a != hg2.a) {
            return false;
        }
        return !(this.b != null ? !this.b.equals(hg2.b) : hg2.b != null);
    }

    public String toString() {
        return "ClickEvent{action=" + (Object)((Object)this.a) + ", value='" + this.b + '\'' + '}';
    }

    public int hashCode() {
        int n2 = this.a.hashCode();
        n2 = 31 * n2 + (this.b != null ? this.b.hashCode() : 0);
        return n2;
    }

    public static enum a {
        a("open_url", true),
        b("open_file", false),
        c("run_command", true),
        d("suggest_command", true),
        e("change_page", true);

        private static final Map<String, a> f;
        private final boolean g;
        private final String h;

        private a(String string2, boolean bl2) {
            this.h = string2;
            this.g = bl2;
        }

        public boolean a() {
            return this.g;
        }

        public String b() {
            return this.h;
        }

        public static a a(String string) {
            return f.get(string);
        }

        static {
            f = Maps.newHashMap();
            for (a a2 : hg$a.values()) {
                f.put(a2.b(), a2);
            }
        }
    }
}

