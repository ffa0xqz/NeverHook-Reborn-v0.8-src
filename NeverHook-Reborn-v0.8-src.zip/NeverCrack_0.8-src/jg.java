/*
 * Decompiled with CFR 0.150.
 */
import java.io.IOException;

public class jg
implements ht<hw> {
    private fj a;
    private float b;
    private float c;
    private float d;
    private float e;
    private float f;
    private float g;
    private float h;
    private int i;
    private boolean j;
    private int[] k;

    public jg() {
    }

    public jg(fj fj2, boolean bl2, float f2, float f3, float f4, float f5, float f6, float f7, float f8, int n2, int ... arrn) {
        this.a = fj2;
        this.j = bl2;
        this.b = f2;
        this.c = f3;
        this.d = f4;
        this.e = f5;
        this.f = f6;
        this.g = f7;
        this.h = f8;
        this.i = n2;
        this.k = arrn;
    }

    @Override
    public void a(gy gy2) throws IOException {
        this.a = fj.a(gy2.readInt());
        if (this.a == null) {
            this.a = fj.J;
        }
        this.j = gy2.readBoolean();
        this.b = gy2.readFloat();
        this.c = gy2.readFloat();
        this.d = gy2.readFloat();
        this.e = gy2.readFloat();
        this.f = gy2.readFloat();
        this.g = gy2.readFloat();
        this.h = gy2.readFloat();
        this.i = gy2.readInt();
        int n2 = this.a.d();
        this.k = new int[n2];
        for (\u2603 = 0; \u2603 < n2; ++\u2603) {
            this.k[\u2603] = gy2.g();
        }
    }

    @Override
    public void b(gy gy2) throws IOException {
        gy2.writeInt(this.a.c());
        gy2.writeBoolean(this.j);
        gy2.writeFloat(this.b);
        gy2.writeFloat(this.c);
        gy2.writeFloat(this.d);
        gy2.writeFloat(this.e);
        gy2.writeFloat(this.f);
        gy2.writeFloat(this.g);
        gy2.writeFloat(this.h);
        gy2.writeInt(this.i);
        int n2 = this.a.d();
        for (\u2603 = 0; \u2603 < n2; ++\u2603) {
            gy2.d(this.k[\u2603]);
        }
    }

    public fj a() {
        return this.a;
    }

    public boolean b() {
        return this.j;
    }

    public double c() {
        return this.b;
    }

    public double d() {
        return this.c;
    }

    public double e() {
        return this.d;
    }

    public float f() {
        return this.e;
    }

    public float g() {
        return this.f;
    }

    public float h() {
        return this.g;
    }

    public float i() {
        return this.h;
    }

    public int j() {
        return this.i;
    }

    public int[] k() {
        return this.k;
    }

    @Override
    public void a(hw hw2) {
        hw2.a(this);
    }
}

