/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonDeserializationContext
 *  com.google.gson.JsonDeserializer
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonParseException
 *  com.google.gson.JsonPrimitive
 *  com.google.gson.JsonSerializationContext
 *  com.google.gson.JsonSerializer
 *  org.apache.commons.lang3.StringUtils
 *  org.apache.commons.lang3.Validate
 */
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import java.lang.reflect.Type;
import java.util.Locale;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;

public class nd
implements Comparable<nd> {
    protected final String a;
    protected final String b;

    protected nd(int n2, String ... arrstring) {
        this.a = StringUtils.isEmpty((CharSequence)arrstring[0]) ? "minecraft" : arrstring[0].toLowerCase(Locale.ROOT);
        this.b = arrstring[1].toLowerCase(Locale.ROOT);
        Validate.notNull((Object)this.b);
    }

    public nd(String string) {
        this(0, nd.a(string));
    }

    public nd(String string, String string2) {
        this(0, string, string2);
    }

    protected static String[] a(String string) {
        String[] arrstring = new String[]{"minecraft", string};
        int \u26032 = string.indexOf(58);
        if (\u26032 >= 0) {
            arrstring[1] = string.substring(\u26032 + 1, string.length());
            if (\u26032 > 1) {
                arrstring[0] = string.substring(0, \u26032);
            }
        }
        return arrstring;
    }

    public String a() {
        return this.b;
    }

    public String b() {
        return this.a;
    }

    public String toString() {
        return this.a + ':' + this.b;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object instanceof nd) {
            nd nd2 = (nd)object;
            return this.a.equals(nd2.a) && this.b.equals(nd2.b);
        }
        return false;
    }

    public int hashCode() {
        return 31 * this.a.hashCode() + this.b.hashCode();
    }

    public int a(nd nd2) {
        int n2 = this.a.compareTo(nd2.a);
        if (n2 == 0) {
            n2 = this.b.compareTo(nd2.b);
        }
        return n2;
    }

    @Override
    public /* synthetic */ int compareTo(Object object) {
        return this.a((nd)object);
    }

    public static class a
    implements JsonDeserializer<nd>,
    JsonSerializer<nd> {
        public nd a(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            return new nd(ra.a(jsonElement, "location"));
        }

        public JsonElement a(nd nd2, Type type, JsonSerializationContext jsonSerializationContext) {
            return new JsonPrimitive(nd2.toString());
        }

        public /* synthetic */ JsonElement serialize(Object object, Type type, JsonSerializationContext jsonSerializationContext) {
            return this.a((nd)object, type, jsonSerializationContext);
        }

        public /* synthetic */ Object deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            return this.a(jsonElement, type, jsonDeserializationContext);
        }
    }
}

