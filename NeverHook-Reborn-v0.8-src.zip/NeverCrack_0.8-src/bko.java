/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 */
import com.google.common.collect.Lists;
import java.util.List;

public class bko
extends bli {
    protected bkn a;
    protected String f;
    private final String s;
    private final List<String> t = Lists.newArrayList();
    protected String g;
    protected String h;
    protected int i;
    private int u;

    public bko(bkn bkn2, String string, String string2, int n2) {
        this.a = bkn2;
        this.f = string;
        this.s = string2;
        this.i = n2;
        this.g = cew.a("gui.yes", new Object[0]);
        this.h = cew.a("gui.no", new Object[0]);
    }

    public bko(bkn bkn2, String string, String string2, String string3, String string4, int n2) {
        this.a = bkn2;
        this.f = string;
        this.s = string2;
        this.g = string3;
        this.h = string4;
        this.i = n2;
    }

    @Override
    public void b() {
        this.n.add(new bjl(0, this.l / 2 - 155, this.m / 6 + 96, this.g));
        this.n.add(new bjl(1, this.l / 2 - 155 + 160, this.m / 6 + 96, this.h));
        this.t.clear();
        this.t.addAll(this.q.c(this.s, this.l - 50));
    }

    @Override
    protected void a(biy biy2) {
        this.a.a(biy2.k == 0, this.i);
    }

    @Override
    public void a(int n22, int n3, float f2) {
        int n22;
        this.c();
        this.a(this.q, this.f, this.l / 2, 70, 0xFFFFFF);
        int n4 = 90;
        for (String string : this.t) {
            this.a(this.q, string, this.l / 2, n4, 0xFFFFFF);
            n4 += this.q.a;
        }
        super.a(n22, n3, f2);
    }

    public void b(int n2) {
        this.u = n2;
        for (biy biy2 : this.n) {
            biy2.l = false;
        }
    }

    @Override
    public void e() {
        super.e();
        if (--this.u == 0) {
            for (biy biy2 : this.n) {
                biy2.l = true;
            }
        }
    }
}

