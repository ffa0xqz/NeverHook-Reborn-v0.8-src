/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import java.util.Random;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class bai
extends azs {
    private static final Logger a = LogManager.getLogger();
    private static final nd[] b = new nd[]{vg.a(adi.class), vg.a(adr.class), vg.a(adr.class), vg.a(adl.class)};

    @Override
    public boolean b(ams ams22, Random random, et et2) {
        int n2;
        et et3;
        int n3 = 3;
        \u2603 = random.nextInt(2) + 2;
        \u2603 = -\u2603 - 1;
        \u2603 = \u2603 + 1;
        \u2603 = -1;
        \u2603 = 4;
        \u2603 = random.nextInt(2) + 2;
        \u2603 = -\u2603 - 1;
        \u2603 = \u2603 + 1;
        \u2603 = 0;
        for (n2 = \u2603; n2 <= \u2603; ++n2) {
            for (\u2603 = -1; \u2603 <= 4; ++\u2603) {
                for (\u2603 = \u2603; \u2603 <= \u2603; ++\u2603) {
                    et3 = et2.a(n2, \u2603, \u2603);
                    bcx \u26032 = ams22.o(et3).a();
                    boolean \u26033 = \u26032.a();
                    if (\u2603 == -1 && !\u26033) {
                        return false;
                    }
                    if (\u2603 == 4 && !\u26033) {
                        return false;
                    }
                    if (n2 != \u2603 && n2 != \u2603 && \u2603 != \u2603 && \u2603 != \u2603 || \u2603 != 0 || !ams22.d(et3) || !ams22.d(et3.a())) continue;
                    ++\u2603;
                }
            }
        }
        if (\u2603 < 1 || \u2603 > 5) {
            return false;
        }
        for (n2 = \u2603; n2 <= \u2603; ++n2) {
            for (\u2603 = 3; \u2603 >= -1; --\u2603) {
                for (\u2603 = \u2603; \u2603 <= \u2603; ++\u2603) {
                    et3 = et2.a(n2, \u2603, \u2603);
                    if (n2 == \u2603 || \u2603 == -1 || \u2603 == \u2603 || n2 == \u2603 || \u2603 == 4 || \u2603 == \u2603) {
                        if (et3.q() >= 0 && !ams22.o(et3.b()).a().a()) {
                            ams22.g(et3);
                            continue;
                        }
                        if (!ams22.o(et3).a().a() || ams22.o(et3).u() == aov.ae) continue;
                        if (\u2603 == -1 && random.nextInt(4) != 0) {
                            ams22.a(et3, aov.Y.t(), 2);
                            continue;
                        }
                        ams22.a(et3, aov.e.t(), 2);
                        continue;
                    }
                    if (ams22.o(et3).u() == aov.ae) continue;
                    ams22.g(et3);
                }
            }
        }
        block6: for (n2 = 0; n2 < 2; ++n2) {
            for (\u2603 = 0; \u2603 < 3; ++\u2603) {
                ams ams22;
                \u2603 = et2.p() + random.nextInt(\u2603 * 2 + 1) - \u2603;
                et et4 = new et(\u2603, \u2603 = et2.q(), \u2603 = et2.r() + random.nextInt(\u2603 * 2 + 1) - \u2603);
                if (!ams22.d(et4)) continue;
                int \u26034 = 0;
                for (fa fa2 : fa.c.a) {
                    if (!ams22.o(et4.a(fa2)).a().a()) continue;
                    ++\u26034;
                }
                if (\u26034 != 1) continue;
                ams22.a(et4, aov.ae.f(ams22, et4, aov.ae.t()), 2);
                avh \u26035 = ams22.r(et4);
                if (!(\u26035 instanceof avj)) continue block6;
                ((avj)\u26035).a(bfl.d, random.nextLong());
                continue block6;
            }
        }
        ams22.a(et2, aov.ac.t(), 2);
        avh avh2 = ams22.r(et2);
        if (avh2 instanceof avw) {
            ((avw)avh2).a().a(this.a(random));
        } else {
            a.error("Failed to fetch mob spawner entity at ({}, {}, {})", (Object)et2.p(), (Object)et2.q(), (Object)et2.r());
        }
        return true;
    }

    private nd a(Random random) {
        return b[random.nextInt(b.length)];
    }
}

