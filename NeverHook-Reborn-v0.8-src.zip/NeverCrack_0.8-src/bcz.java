/*
 * Decompiled with CFR 0.150.
 */
public class bcz
extends bcx {
    public bcz(bcy bcy2) {
        super(bcy2);
    }

    @Override
    public boolean a() {
        return false;
    }

    @Override
    public boolean b() {
        return false;
    }

    @Override
    public boolean c() {
        return false;
    }
}

