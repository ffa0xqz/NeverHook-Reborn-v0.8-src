/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 */
import com.google.common.collect.Lists;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class bbo
extends bbs {
    private static final List<anf> a = Arrays.asList(ank.d, ank.s, ank.w, ank.x, ank.h, ank.n, ank.F);
    private final List<anf.c> b = Lists.newArrayList();
    private int d = 32;
    private final int h = 8;

    public bbo() {
        this.b.add(new anf.c(adp.class, 1, 1, 1));
    }

    public bbo(Map<String, String> map) {
        this();
        for (Map.Entry<String, String> entry : map.entrySet()) {
            if (!entry.getKey().equals("distance")) continue;
            this.d = ri.a(entry.getValue(), this.d, 9);
        }
    }

    @Override
    public String a() {
        return "Temple";
    }

    @Override
    protected boolean a(int \u260322, int n2) {
        int n3;
        \u2603 = \u260322;
        n3 = n2;
        if (\u260322 < 0) {
            \u260322 -= this.d - 1;
        }
        if (n2 < 0) {
            n2 -= this.d - 1;
        }
        \u2603 = \u260322 / this.d;
        \u2603 = n2 / this.d;
        Random random = this.g.a(\u2603, \u2603, 14357617);
        \u2603 *= this.d;
        \u2603 *= this.d;
        int \u260322 = \u2603;
        n2 = n3;
        if (\u260322 == (\u2603 += random.nextInt(this.d - 8)) && n2 == (\u2603 += random.nextInt(this.d - 8))) {
            anf anf2 = this.g.C().a(new et(\u260322 * 16 + 8, 0, n2 * 16 + 8));
            if (anf2 == null) {
                return false;
            }
            for (anf anf3 : a) {
                if (anf2 != anf3) continue;
                return true;
            }
        }
        return false;
    }

    @Override
    public et a(ams ams2, et et2, boolean bl2) {
        this.g = ams2;
        return bbo.a(ams2, this, et2, this.d, 8, 14357617, false, 100, bl2);
    }

    @Override
    protected bbw b(int n2, int n3) {
        return new a(this.g, this.f, n2, n3);
    }

    public boolean a(et et2) {
        bbw bbw2 = this.c(et2);
        if (bbw2 == null || !(bbw2 instanceof a) || bbw2.a.isEmpty()) {
            return false;
        }
        bbv \u26032 = bbw2.a.get(0);
        return \u26032 instanceof bbp.e;
    }

    public List<anf.c> b() {
        return this.b;
    }

    public static class a
    extends bbw {
        public a() {
        }

        public a(ams ams2, Random random, int n2, int n3) {
            this(ams2, random, n2, n3, ams2.b(new et(n2 * 16 + 8, 0, n3 * 16 + 8)));
        }

        public a(ams ams2, Random random, int n2, int n3, anf anf22) {
            super(n2, n3);
            anf anf22;
            if (anf22 == ank.w || anf22 == ank.x) {
                bbp.c c2 = new bbp.c(random, n2 * 16, n3 * 16);
                this.a.add(c2);
            } else if (anf22 == ank.h) {
                bbp.e e2 = new bbp.e(random, n2 * 16, n3 * 16);
                this.a.add(e2);
            } else if (anf22 == ank.d || anf22 == ank.s) {
                bbp.a a2 = new bbp.a(random, n2 * 16, n3 * 16);
                this.a.add(a2);
            } else if (anf22 == ank.n || anf22 == ank.F) {
                bbp.b b2 = new bbp.b(random, n2 * 16, n3 * 16);
                this.a.add(b2);
            }
            this.d();
        }
    }
}

