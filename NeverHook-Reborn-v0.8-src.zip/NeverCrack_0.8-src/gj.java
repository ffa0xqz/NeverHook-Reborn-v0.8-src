/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.annotations.VisibleForTesting
 *  com.google.common.base.Optional
 *  com.mojang.authlib.GameProfile
 *  com.mojang.authlib.properties.Property
 *  javax.annotation.Nullable
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Optional;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import java.util.Map;
import java.util.UUID;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public final class gj {
    private static final Logger a = LogManager.getLogger();

    @Nullable
    public static GameProfile a(fy fy2) {
        String string = null;
        \u2603 = null;
        if (fy2.b("Name", 8)) {
            string = fy2.l("Name");
        }
        if (fy2.b("Id", 8)) {
            \u2603 = fy2.l("Id");
        }
        try {
            UUID uUID;
            try {
                uUID = UUID.fromString(\u2603);
            }
            catch (Throwable throwable) {
                uUID = null;
            }
            GameProfile \u26032 = new GameProfile(uUID, string);
            if (fy2.b("Properties", 10)) {
                fy fy3 = fy2.p("Properties");
                for (String string2 : fy3.c()) {
                    ge ge2 = fy3.c(string2, 10);
                    for (int i2 = 0; i2 < ge2.c(); ++i2) {
                        fy fy4 = ge2.b(i2);
                        String \u26033 = fy4.l("Value");
                        if (fy4.b("Signature", 8)) {
                            \u26032.getProperties().put((Object)string2, (Object)new Property(string2, \u26033, fy4.l("Signature")));
                            continue;
                        }
                        \u26032.getProperties().put((Object)string2, (Object)new Property(string2, \u26033));
                    }
                }
            }
            return \u26032;
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    public static fy a(fy fy22, GameProfile gameProfile) {
        fy fy22;
        if (!rn.b(gameProfile.getName())) {
            fy22.a("Name", gameProfile.getName());
        }
        if (gameProfile.getId() != null) {
            fy22.a("Id", gameProfile.getId().toString());
        }
        if (!gameProfile.getProperties().isEmpty()) {
            fy fy3 = new fy();
            for (String string : gameProfile.getProperties().keySet()) {
                ge ge2 = new ge();
                for (Property property : gameProfile.getProperties().get((Object)string)) {
                    fy fy4 = new fy();
                    fy4.a("Value", property.getValue());
                    if (property.hasSignature()) {
                        fy4.a("Signature", property.getSignature());
                    }
                    ge2.a(fy4);
                }
                fy3.a(string, ge2);
            }
            fy22.a("Properties", fy3);
        }
        return fy22;
    }

    @VisibleForTesting
    public static boolean a(gn gn22, gn gn3, boolean bl2) {
        gn gn22;
        if (gn22 == gn3) {
            return true;
        }
        if (gn22 == null) {
            return true;
        }
        if (gn3 == null) {
            return false;
        }
        if (!gn22.getClass().equals(gn3.getClass())) {
            return false;
        }
        if (gn22 instanceof fy) {
            fy fy2 = (fy)gn22;
            \u2603 = (fy)gn3;
            for (String string : fy2.c()) {
                gn gn4 = fy2.c(string);
                if (gj.a(gn4, \u2603.c(string), bl2)) continue;
                return false;
            }
            return true;
        }
        if (gn22 instanceof ge && bl2) {
            ge ge2 = (ge)gn22;
            \u2603 = (ge)gn3;
            if (ge2.b_()) {
                return \u2603.b_();
            }
            for (int i2 = 0; i2 < ge2.c(); ++i2) {
                gn gn5 = ge2.i(i2);
                boolean \u26032 = false;
                for (int i3 = 0; i3 < \u2603.c(); ++i3) {
                    if (!gj.a(gn5, \u2603.i(i3), bl2)) continue;
                    \u26032 = true;
                    break;
                }
                if (\u26032) continue;
                return false;
            }
            return true;
        }
        return gn22.equals(gn3);
    }

    public static fy a(UUID uUID) {
        fy fy2 = new fy();
        fy2.a("M", uUID.getMostSignificantBits());
        fy2.a("L", uUID.getLeastSignificantBits());
        return fy2;
    }

    public static UUID b(fy fy2) {
        return new UUID(fy2.i("M"), fy2.i("L"));
    }

    public static et c(fy fy2) {
        return new et(fy2.h("X"), fy2.h("Y"), fy2.h("Z"));
    }

    public static fy a(et et2) {
        fy fy2 = new fy();
        fy2.a("X", et2.p());
        fy2.a("Y", et2.q());
        fy2.a("Z", et2.r());
        return fy2;
    }

    public static awr d(fy fy2) {
        if (!fy2.b("Name", 8)) {
            return aov.a.t();
        }
        aou aou2 = aou.h.c(new nd(fy2.l("Name")));
        awr \u26032 = aou2.t();
        if (fy2.b("Properties", 10)) {
            fy fy3 = fy2.p("Properties");
            aws \u26033 = aou2.s();
            for (String string : fy3.c()) {
                axh<?> axh2 = \u26033.a(string);
                if (axh2 == null) continue;
                \u26032 = gj.a(\u26032, axh2, string, fy3, fy2);
            }
        }
        return \u26032;
    }

    private static <T extends Comparable<T>> awr a(awr awr2, axh<T> axh2, String string, fy fy2, fy fy3) {
        Optional<T> optional = axh2.b(fy2.l(string));
        if (optional.isPresent()) {
            return awr2.a(axh2, (Comparable)optional.get());
        }
        a.warn("Unable to read property: {} with value: {} for blockstate: {}", (Object)string, (Object)fy2.l(string), (Object)fy3.toString());
        return awr2;
    }

    public static fy a(fy fy22, awr awr2) {
        fy fy22;
        fy22.a("Name", aou.h.b(awr2.u()).toString());
        if (!awr2.t().isEmpty()) {
            fy fy3 = new fy();
            for (Map.Entry entry : awr2.t().entrySet()) {
                axh axh2 = (axh)entry.getKey();
                fy3.a(axh2.a(), gj.a(axh2, (Comparable)entry.getValue()));
            }
            fy22.a("Properties", fy3);
        }
        return fy22;
    }

    private static <T extends Comparable<T>> String a(axh<T> axh2, Comparable<?> comparable) {
        return axh2.a(comparable);
    }
}

