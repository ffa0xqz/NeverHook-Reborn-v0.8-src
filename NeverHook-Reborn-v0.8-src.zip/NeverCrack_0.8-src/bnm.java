/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  it.unimi.dsi.fastutil.objects.ObjectLinkedOpenHashSet
 *  it.unimi.dsi.fastutil.objects.ObjectSet
 *  javax.annotation.Nullable
 *  org.lwjgl.input.Keyboard
 */
import com.google.common.collect.Lists;
import it.unimi.dsi.fastutil.objects.ObjectLinkedOpenHashSet;
import it.unimi.dsi.fastutil.objects.ObjectSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import javax.annotation.Nullable;
import org.lwjgl.input.Keyboard;

public class bnm
extends bip
implements bnr {
    protected static final nd a = new nd("textures/gui/recipe_book.png");
    private int f;
    private int g;
    private int h;
    private final bnk j = new bnk();
    private final List<bno> k = Lists.newArrayList((Object[])new bno[]{new bno(0, ahn.g), new bno(0, ahn.i), new bno(0, ahn.b), new bno(0, ahn.f), new bno(0, ahn.d)});
    private bno l;
    private bjr m;
    private afw o;
    private bhz p;
    private bjc q;
    private String r = "";
    private qj s;
    private final bnn t = new bnn();
    private aed u = new aed();
    private int v;

    public void func_194303_a(int p_194303_1_, int p_194303_2_, bhz p_194303_3_, boolean p_194303_4_, afw p_194303_5_) {
        this.p = p_194303_3_;
        this.g = p_194303_1_;
        this.h = p_194303_2_;
        this.o = p_194303_5_;
        this.s = p_194303_3_.h.E();
        this.v = p_194303_3_.h.bv.p();
        this.l = this.k.get(0);
        this.l.b(true);
        if (this.c()) {
            this.a(p_194303_4_, p_194303_5_);
        }
        Keyboard.enableRepeatEvents((boolean)true);
    }

    public void a(boolean p_193014_1_, afw p_193014_2_) {
        this.f = p_193014_1_ ? 0 : 86;
        int i2 = (this.g - 147) / 2 - this.f;
        int j2 = (this.h - 166) / 2;
        this.u.a();
        this.p.h.bv.a(this.u, false);
        p_193014_2_.a(this.u);
        this.q = new bjc(0, bhz.k, i2 + 25, j2 + 14, 80, bhz.k.a + 5);
        this.q.f(50);
        this.q.a(false);
        this.q.e(true);
        this.q.g(0xFFFFFF);
        this.t.a(this.p, i2, j2);
        this.t.a(this);
        this.m = new bjr(0, i2 + 110, j2 + 12, 26, 16, this.s.b());
        this.m.a(152, 41, 28, 18, a);
        this.b(false);
        this.f();
    }

    public void a() {
        Keyboard.enableRepeatEvents((boolean)false);
    }

    public int a(boolean p_193011_1_, int p_193011_2_, int p_193011_3_) {
        int i2 = this.c() && !p_193011_1_ ? 177 + (p_193011_2_ - p_193011_3_ - 200) / 2 : (p_193011_2_ - p_193011_3_) / 2;
        return i2;
    }

    public void b() {
        this.a(!this.c());
    }

    public boolean c() {
        return this.s.a();
    }

    private void a(boolean p_193006_1_) {
        this.s.a(p_193006_1_);
        if (!p_193006_1_) {
            this.t.c();
        }
        this.j();
    }

    public void a(@Nullable agp p_191874_1_) {
        if (p_191874_1_ != null && p_191874_1_.e <= 9) {
            this.j.a();
            if (this.c()) {
                this.g();
            }
        }
    }

    private void b(boolean p_193003_1_) {
        List<bnq> list = cif.e.get(this.l.d());
        list.forEach(p_193944_1_ -> p_193944_1_.a(this.u, this.o.j(), this.o.i(), this.s));
        ArrayList list1 = Lists.newArrayList(list);
        list1.removeIf(p_193952_0_ -> !p_193952_0_.a());
        list1.removeIf(p_193953_0_ -> !p_193953_0_.c());
        String s2 = this.q.b();
        if (!s2.isEmpty()) {
            ObjectLinkedOpenHashSet objectset = new ObjectLinkedOpenHashSet(this.p.a(cgv.b).a(s2.toLowerCase(Locale.ROOT)));
            list1.removeIf(arg_0 -> bnm.lambda$func_193003_g$3((ObjectSet)objectset, arg_0));
        }
        if (this.s.b()) {
            list1.removeIf(p_193958_0_ -> !p_193958_0_.b());
        }
        this.t.a(list1, p_193003_1_);
    }

    private void f() {
        int i2 = (this.g - 147) / 2 - this.f - 30;
        int j2 = (this.h - 166) / 2 + 3;
        int k2 = 27;
        int l2 = 0;
        for (bno guibuttonrecipetab : this.k) {
            ahn creativetabs = guibuttonrecipetab.d();
            if (creativetabs == ahn.g) {
                guibuttonrecipetab.m = true;
                guibuttonrecipetab.c(i2, j2 + 27 * l2++);
                continue;
            }
            if (!guibuttonrecipetab.e()) continue;
            guibuttonrecipetab.c(i2, j2 + 27 * l2++);
            guibuttonrecipetab.a(this.p);
        }
    }

    public void d() {
        if (this.c() && this.v != this.p.h.bv.p()) {
            this.g();
            this.v = this.p.h.bv.p();
        }
    }

    private void g() {
        this.u.a();
        this.p.h.bv.a(this.u, false);
        this.o.a(this.u);
        this.b(false);
    }

    public void a(int p_191861_1_, int p_191861_2_, float p_191861_3_) {
        if (this.c()) {
            bhx.c();
            buq.g();
            buq.G();
            buq.c(0.0f, 0.0f, 100.0f);
            this.p.N().a(a);
            buq.c(1.0f, 1.0f, 1.0f, 1.0f);
            int i2 = (this.g - 147) / 2 - this.f;
            int j2 = (this.h - 166) / 2;
            this.b(i2, j2, 1, 1, 147, 166);
            this.q.g();
            bhx.a();
            for (bno guibuttonrecipetab : this.k) {
                guibuttonrecipetab.a(this.p, p_191861_1_, p_191861_2_, p_191861_3_);
            }
            this.m.a(this.p, p_191861_1_, p_191861_2_, p_191861_3_);
            this.t.a(i2, j2, p_191861_1_, p_191861_2_, p_191861_3_);
            buq.H();
        }
    }

    public void c(int p_191876_1_, int p_191876_2_, int p_191876_3_, int p_191876_4_) {
        if (this.c()) {
            this.t.a(p_191876_3_, p_191876_4_);
            if (this.m.a()) {
                String s1 = cew.a(this.m.c() ? "gui.recipebook.toggleRecipes.craftable" : "gui.recipebook.toggleRecipes.all", new Object[0]);
                if (this.p.m != null) {
                    this.p.m.a(s1, p_191876_3_, p_191876_4_);
                }
            }
            this.d(p_191876_1_, p_191876_2_, p_191876_3_, p_191876_4_);
        }
    }

    private void d(int p_193015_1_, int p_193015_2_, int p_193015_3_, int p_193015_4_) {
        ain itemstack = null;
        for (int i2 = 0; i2 < this.j.b(); ++i2) {
            bnk.a ghostrecipe$ghostingredient = this.j.a(i2);
            int j2 = ghostrecipe$ghostingredient.a() + p_193015_1_;
            int k2 = ghostrecipe$ghostingredient.b() + p_193015_2_;
            if (p_193015_3_ < j2 || p_193015_4_ < k2 || p_193015_3_ >= j2 + 16 || p_193015_4_ >= k2 + 16) continue;
            itemstack = ghostrecipe$ghostingredient.c();
        }
        if (itemstack != null && this.p.m != null) {
            this.p.m.a(this.p.m.a(itemstack), p_193015_3_, p_193015_4_);
        }
    }

    public void a(int p_191864_1_, int p_191864_2_, boolean p_191864_3_, float p_191864_4_) {
        this.j.a(this.p, p_191864_1_, p_191864_2_, p_191864_3_, p_191864_4_);
    }

    public boolean a(int p_191862_1_, int p_191862_2_, int p_191862_3_) {
        if (this.c() && !this.p.h.y()) {
            if (this.t.a(p_191862_1_, p_191862_2_, p_191862_3_, (this.g - 147) / 2 - this.f, (this.h - 166) / 2, 147, 166)) {
                akr irecipe = this.t.a();
                bnq recipelist = this.t.b();
                if (irecipe != null && recipelist != null) {
                    if (!recipelist.a(irecipe) && this.j.c() == irecipe) {
                        return false;
                    }
                    this.j.a();
                    this.p.c.func_194338_a(this.p.h.by.d, irecipe, bli.s(), this.p.h);
                    if (!this.h() && p_191862_3_ == 0) {
                        this.a(false);
                    }
                }
                return true;
            }
            if (p_191862_3_ != 0) {
                return false;
            }
            if (this.q.a(p_191862_1_, p_191862_2_, p_191862_3_)) {
                return true;
            }
            if (this.m.b(this.p, p_191862_1_, p_191862_2_)) {
                boolean flag = !this.s.b();
                this.s.b(flag);
                this.m.b(flag);
                this.m.a(this.p.U());
                this.j();
                this.b(false);
                return true;
            }
            for (bno guibuttonrecipetab : this.k) {
                if (!guibuttonrecipetab.b(this.p, p_191862_1_, p_191862_2_)) continue;
                if (this.l != guibuttonrecipetab) {
                    guibuttonrecipetab.a(this.p.U());
                    this.l.b(false);
                    this.l = guibuttonrecipetab;
                    this.l.b(true);
                    this.b(true);
                }
                return true;
            }
            return false;
        }
        return false;
    }

    public boolean c(int p_193955_1_, int p_193955_2_, int p_193955_3_, int p_193955_4_, int p_193955_5_, int p_193955_6_) {
        if (!this.c()) {
            return true;
        }
        boolean flag = p_193955_1_ < p_193955_3_ || p_193955_2_ < p_193955_4_ || p_193955_1_ >= p_193955_3_ + p_193955_5_ || p_193955_2_ >= p_193955_4_ + p_193955_6_;
        boolean flag1 = p_193955_3_ - 147 < p_193955_1_ && p_193955_1_ < p_193955_3_ && p_193955_4_ < p_193955_2_ && p_193955_2_ < p_193955_4_ + p_193955_6_;
        return flag && !flag1 && !this.l.b(this.p, p_193955_1_, p_193955_2_);
    }

    public boolean a(char p_191859_1_, int p_191859_2_) {
        if (this.c() && !this.p.h.y()) {
            if (p_191859_2_ == 1 && !this.h()) {
                this.a(false);
                return true;
            }
            if (bib.a(this.p.t.ag) && !this.q.m()) {
                this.q.b(true);
            } else if (this.q.a(p_191859_1_, p_191859_2_)) {
                String s1 = this.q.b().toLowerCase(Locale.ROOT);
                this.a(s1);
                if (!s1.equals(this.r)) {
                    this.b(false);
                    this.r = s1;
                }
                return true;
            }
            return false;
        }
        return false;
    }

    private void a(String p_193716_1_) {
        if ("excitedze".equals(p_193716_1_)) {
            cey languagemanager = this.p.Q();
            cex language = languagemanager.a("en_pt");
            if (languagemanager.c().a(language) == 0) {
                return;
            }
            languagemanager.a(language);
            this.p.t.aJ = language.a();
            this.p.f();
            bhz.k.a(this.p.Q().a() || this.p.t.aK);
            bhz.k.b(languagemanager.b());
            this.p.t.b();
        }
    }

    private boolean h() {
        return this.f == 86;
    }

    public void e() {
        this.f();
        if (this.c()) {
            this.b(false);
        }
    }

    @Override
    public void a(List<akr> p_193001_1_) {
        for (akr irecipe : p_193001_1_) {
            this.p.h.a(irecipe);
        }
    }

    public void a(akr p_193951_1_, List<agp> p_193951_2_) {
        ain itemstack = p_193951_1_.b();
        this.j.a(p_193951_1_);
        this.j.a(ako.a(itemstack), p_193951_2_.get((int)0).f, p_193951_2_.get((int)0).g);
        int i2 = this.o.j();
        int j2 = this.o.i();
        int k2 = p_193951_1_ instanceof aku ? ((aku)p_193951_1_).f() : i2;
        int l2 = 1;
        Iterator iterator = p_193951_1_.d().iterator();
        for (int i1 = 0; i1 < j2; ++i1) {
            for (int j1 = 0; j1 < k2; ++j1) {
                if (!iterator.hasNext()) {
                    return;
                }
                ako ingredient = (ako)iterator.next();
                if (ingredient != ako.a) {
                    agp slot = p_193951_2_.get(l2);
                    this.j.a(ingredient, slot.f, slot.g);
                }
                ++l2;
            }
            if (k2 >= i2) continue;
            l2 += i2 - k2;
        }
    }

    private void j() {
        if (this.p.v() != null) {
            this.p.v().a(new lr(this.c(), this.s.b()));
        }
    }

    private static /* synthetic */ boolean lambda$func_193003_g$3(ObjectSet objectset, bnq p_193947_1_) {
        return !objectset.contains((Object)p_193947_1_);
    }
}

