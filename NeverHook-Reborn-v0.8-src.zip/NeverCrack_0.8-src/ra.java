/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonDeserializationContext
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParseException
 *  com.google.gson.JsonPrimitive
 *  com.google.gson.JsonSyntaxException
 *  com.google.gson.reflect.TypeToken
 *  com.google.gson.stream.JsonReader
 *  javax.annotation.Nullable
 *  org.apache.commons.lang3.StringUtils
 */
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.lang.reflect.Type;
import javax.annotation.Nullable;
import org.apache.commons.lang3.StringUtils;

public class ra {
    public static boolean a(JsonObject jsonObject, String string) {
        if (!ra.f(jsonObject, string)) {
            return false;
        }
        return jsonObject.getAsJsonPrimitive(string).isString();
    }

    public static boolean a(JsonElement jsonElement) {
        if (!jsonElement.isJsonPrimitive()) {
            return false;
        }
        return jsonElement.getAsJsonPrimitive().isString();
    }

    public static boolean b(JsonElement jsonElement) {
        if (!jsonElement.isJsonPrimitive()) {
            return false;
        }
        return jsonElement.getAsJsonPrimitive().isNumber();
    }

    public static boolean c(JsonObject jsonObject, String string) {
        if (!ra.f(jsonObject, string)) {
            return false;
        }
        return jsonObject.getAsJsonPrimitive(string).isBoolean();
    }

    public static boolean d(JsonObject jsonObject, String string) {
        if (!ra.g(jsonObject, string)) {
            return false;
        }
        return jsonObject.get(string).isJsonArray();
    }

    public static boolean f(JsonObject jsonObject, String string) {
        if (!ra.g(jsonObject, string)) {
            return false;
        }
        return jsonObject.get(string).isJsonPrimitive();
    }

    public static boolean g(JsonObject jsonObject, String string) {
        if (jsonObject == null) {
            return false;
        }
        return jsonObject.get(string) != null;
    }

    public static String a(JsonElement jsonElement, String string) {
        if (jsonElement.isJsonPrimitive()) {
            return jsonElement.getAsString();
        }
        throw new JsonSyntaxException("Expected " + string + " to be a string, was " + ra.d(jsonElement));
    }

    public static String h(JsonObject jsonObject, String string) {
        if (jsonObject.has(string)) {
            return ra.a(jsonObject.get(string), string);
        }
        throw new JsonSyntaxException("Missing " + string + ", expected to find a string");
    }

    public static String a(JsonObject jsonObject, String string, String string2) {
        if (jsonObject.has(string)) {
            return ra.a(jsonObject.get(string), string);
        }
        return string2;
    }

    public static ail b(JsonElement jsonElement, String string2) {
        String string2;
        if (jsonElement.isJsonPrimitive()) {
            \u2603 = jsonElement.getAsString();
            ail ail2 = ail.b(\u2603);
            if (ail2 == null) {
                throw new JsonSyntaxException("Expected " + string2 + " to be an item, was unknown string '" + \u2603 + "'");
            }
            return ail2;
        }
        throw new JsonSyntaxException("Expected " + string2 + " to be an item, was " + ra.d(jsonElement));
    }

    public static ail i(JsonObject jsonObject, String string) {
        if (jsonObject.has(string)) {
            return ra.b(jsonObject.get(string), string);
        }
        throw new JsonSyntaxException("Missing " + string + ", expected to find an item");
    }

    public static boolean c(JsonElement jsonElement, String string) {
        if (jsonElement.isJsonPrimitive()) {
            return jsonElement.getAsBoolean();
        }
        throw new JsonSyntaxException("Expected " + string + " to be a Boolean, was " + ra.d(jsonElement));
    }

    public static boolean j(JsonObject jsonObject, String string) {
        if (jsonObject.has(string)) {
            return ra.c(jsonObject.get(string), string);
        }
        throw new JsonSyntaxException("Missing " + string + ", expected to find a Boolean");
    }

    public static boolean a(JsonObject jsonObject, String string, boolean bl2) {
        if (jsonObject.has(string)) {
            return ra.c(jsonObject.get(string), string);
        }
        return bl2;
    }

    public static float e(JsonElement jsonElement, String string) {
        if (jsonElement.isJsonPrimitive() && jsonElement.getAsJsonPrimitive().isNumber()) {
            return jsonElement.getAsFloat();
        }
        throw new JsonSyntaxException("Expected " + string + " to be a Float, was " + ra.d(jsonElement));
    }

    public static float l(JsonObject jsonObject, String string) {
        if (jsonObject.has(string)) {
            return ra.e(jsonObject.get(string), string);
        }
        throw new JsonSyntaxException("Missing " + string + ", expected to find a Float");
    }

    public static float a(JsonObject jsonObject, String string, float f2) {
        if (jsonObject.has(string)) {
            return ra.e(jsonObject.get(string), string);
        }
        return f2;
    }

    public static int g(JsonElement jsonElement, String string) {
        if (jsonElement.isJsonPrimitive() && jsonElement.getAsJsonPrimitive().isNumber()) {
            return jsonElement.getAsInt();
        }
        throw new JsonSyntaxException("Expected " + string + " to be a Int, was " + ra.d(jsonElement));
    }

    public static int n(JsonObject jsonObject, String string) {
        if (jsonObject.has(string)) {
            return ra.g(jsonObject.get(string), string);
        }
        throw new JsonSyntaxException("Missing " + string + ", expected to find a Int");
    }

    public static int a(JsonObject jsonObject, String string, int n2) {
        if (jsonObject.has(string)) {
            return ra.g(jsonObject.get(string), string);
        }
        return n2;
    }

    public static JsonObject m(JsonElement jsonElement, String string) {
        if (jsonElement.isJsonObject()) {
            return jsonElement.getAsJsonObject();
        }
        throw new JsonSyntaxException("Expected " + string + " to be a JsonObject, was " + ra.d(jsonElement));
    }

    public static JsonObject t(JsonObject jsonObject, String string) {
        if (jsonObject.has(string)) {
            return ra.m(jsonObject.get(string), string);
        }
        throw new JsonSyntaxException("Missing " + string + ", expected to find a JsonObject");
    }

    public static JsonObject a(JsonObject jsonObject, String string, JsonObject jsonObject2) {
        if (jsonObject.has(string)) {
            return ra.m(jsonObject.get(string), string);
        }
        return jsonObject2;
    }

    public static JsonArray n(JsonElement jsonElement, String string) {
        if (jsonElement.isJsonArray()) {
            return jsonElement.getAsJsonArray();
        }
        throw new JsonSyntaxException("Expected " + string + " to be a JsonArray, was " + ra.d(jsonElement));
    }

    public static JsonArray u(JsonObject jsonObject, String string) {
        if (jsonObject.has(string)) {
            return ra.n(jsonObject.get(string), string);
        }
        throw new JsonSyntaxException("Missing " + string + ", expected to find a JsonArray");
    }

    public static JsonArray a(JsonObject jsonObject, String string, @Nullable JsonArray jsonArray) {
        if (jsonObject.has(string)) {
            return ra.n(jsonObject.get(string), string);
        }
        return jsonArray;
    }

    public static <T> T a(@Nullable JsonElement jsonElement, String string, JsonDeserializationContext jsonDeserializationContext, Class<? extends T> class_) {
        if (jsonElement != null) {
            return (T)jsonDeserializationContext.deserialize(jsonElement, class_);
        }
        throw new JsonSyntaxException("Missing " + string);
    }

    public static <T> T a(JsonObject jsonObject, String string, JsonDeserializationContext jsonDeserializationContext, Class<? extends T> class_) {
        if (jsonObject.has(string)) {
            return ra.a(jsonObject.get(string), string, jsonDeserializationContext, class_);
        }
        throw new JsonSyntaxException("Missing " + string);
    }

    public static <T> T a(JsonObject jsonObject, String string, T t2, JsonDeserializationContext jsonDeserializationContext, Class<? extends T> class_) {
        if (jsonObject.has(string)) {
            return ra.a(jsonObject.get(string), string, jsonDeserializationContext, class_);
        }
        return t2;
    }

    public static String d(JsonElement jsonElement) {
        String string = StringUtils.abbreviateMiddle((String)String.valueOf((Object)jsonElement), (String)"...", (int)10);
        if (jsonElement == null) {
            return "null (missing)";
        }
        if (jsonElement.isJsonNull()) {
            return "null (json)";
        }
        if (jsonElement.isJsonArray()) {
            return "an array (" + string + ")";
        }
        if (jsonElement.isJsonObject()) {
            return "an object (" + string + ")";
        }
        if (jsonElement.isJsonPrimitive()) {
            JsonPrimitive jsonPrimitive = jsonElement.getAsJsonPrimitive();
            if (jsonPrimitive.isNumber()) {
                return "a number (" + string + ")";
            }
            if (jsonPrimitive.isBoolean()) {
                return "a boolean (" + string + ")";
            }
        }
        return string;
    }

    @Nullable
    public static <T> T a(Gson gson, Reader reader, Class<T> class_, boolean bl2) {
        try {
            JsonReader jsonReader = new JsonReader(reader);
            jsonReader.setLenient(bl2);
            return (T)gson.getAdapter(class_).read(jsonReader);
        }
        catch (IOException iOException) {
            throw new JsonParseException((Throwable)iOException);
        }
    }

    @Nullable
    public static <T> T a(Gson gson, Reader reader, Type type, boolean bl2) {
        try {
            JsonReader jsonReader = new JsonReader(reader);
            jsonReader.setLenient(bl2);
            return (T)gson.getAdapter(TypeToken.get((Type)type)).read(jsonReader);
        }
        catch (IOException iOException) {
            throw new JsonParseException((Throwable)iOException);
        }
    }

    @Nullable
    public static <T> T a(Gson gson, String string, Type type, boolean bl2) {
        return ra.a(gson, (Reader)new StringReader(string), type, bl2);
    }

    @Nullable
    public static <T> T a(Gson gson, String string, Class<T> class_, boolean bl2) {
        return ra.a(gson, (Reader)new StringReader(string), class_, bl2);
    }

    @Nullable
    public static <T> T a(Gson gson, Reader reader, Type type) {
        return ra.a(gson, reader, type, false);
    }

    @Nullable
    public static <T> T a(Gson gson, String string, Type type) {
        return ra.a(gson, string, type, false);
    }

    @Nullable
    public static <T> T a(Gson gson, Reader reader, Class<T> class_) {
        return ra.a(gson, reader, class_, false);
    }

    @Nullable
    public static <T> T a(Gson gson, String string, Class<T> class_) {
        return ra.a(gson, string, class_, false);
    }
}

