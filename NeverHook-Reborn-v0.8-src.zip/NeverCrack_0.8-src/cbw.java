/*
 * Decompiled with CFR 0.150.
 */
import optifine.Config;
import shadersmod.client.Shaders;

public class cbw
implements cce<abb> {
    private static final nd a = new nd("textures/entity/enderdragon/dragon_eyes.png");
    private final bza b;

    public cbw(bza dragonRendererIn) {
        this.b = dragonRendererIn;
    }

    @Override
    public void a(abb entitylivingbaseIn, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
        this.b.a(a);
        buq.m();
        buq.d();
        buq.a(buq.r.e, buq.l.e);
        buq.g();
        buq.c(514);
        int i2 = 61680;
        int j2 = 61680;
        boolean k2 = false;
        cig.a(cig.r, 61680.0f, 0.0f);
        buq.f();
        buq.c(1.0f, 1.0f, 1.0f, 1.0f);
        bhz.z().o.d(true);
        if (Config.isShaders()) {
            Shaders.beginSpiderEyes();
        }
        Config.getRenderGlobal().renderOverlayEyes = true;
        this.b.b().a(entitylivingbaseIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
        Config.getRenderGlobal().renderOverlayEyes = false;
        if (Config.isShaders()) {
            Shaders.endSpiderEyes();
        }
        bhz.z().o.d(false);
        this.b.c(entitylivingbaseIn);
        buq.l();
        buq.e();
        buq.c(515);
    }

    @Override
    public boolean a() {
        return false;
    }
}

