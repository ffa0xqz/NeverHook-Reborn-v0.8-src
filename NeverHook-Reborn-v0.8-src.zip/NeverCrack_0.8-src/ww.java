/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import java.util.Random;
import javax.annotation.Nullable;

public class ww
extends xc {
    private final vv a;
    private double b;
    private double c;
    private double d;
    private final double e;
    private final ams f;

    public ww(vv vv2, double d2) {
        this.a = vv2;
        this.e = d2;
        this.f = vv2.l;
        this.a(1);
    }

    @Override
    public boolean a() {
        if (!this.f.D()) {
            return false;
        }
        if (!this.a.aR()) {
            return false;
        }
        if (!this.f.h(new et(this.a.p, this.a.bw().b, this.a.r))) {
            return false;
        }
        if (!this.a.b(vj.f).b()) {
            return false;
        }
        bhc bhc2 = this.f();
        if (bhc2 == null) {
            return false;
        }
        this.b = bhc2.b;
        this.c = bhc2.c;
        this.d = bhc2.d;
        return true;
    }

    @Override
    public boolean b() {
        return !this.a.x().o();
    }

    @Override
    public void c() {
        this.a.x().a(this.b, this.c, this.d, this.e);
    }

    @Nullable
    private bhc f() {
        Random random = this.a.bR();
        et \u26032 = new et(this.a.p, this.a.bw().b, this.a.r);
        for (int i2 = 0; i2 < 10; ++i2) {
            et et2 = \u26032.a(random.nextInt(20) - 10, random.nextInt(6) - 3, random.nextInt(20) - 10);
            if (this.f.h(et2) || !(this.a.a(et2) < 0.0f)) continue;
            return new bhc(et2.p(), et2.q(), et2.r());
        }
        return null;
    }
}

