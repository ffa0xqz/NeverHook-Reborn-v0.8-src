/*
 * Decompiled with CFR 0.150.
 */
import java.io.IOException;

public class kx
implements ht<kw> {
    private int a;

    public kx() {
    }

    public kx(int n2) {
        this.a = n2;
    }

    @Override
    public void a(gy gy2) throws IOException {
        this.a = gy2.g();
    }

    @Override
    public void b(gy gy2) throws IOException {
        gy2.d(this.a);
    }

    @Override
    public void a(kw kw2) {
        kw2.a(this);
    }

    public int a() {
        return this.a;
    }
}

