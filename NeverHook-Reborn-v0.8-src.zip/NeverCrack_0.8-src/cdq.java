/*
 * Decompiled with CFR 0.150.
 */
import java.io.IOException;
import shadersmod.client.MultiTexID;

public interface cdq {
    public void b(boolean var1, boolean var2);

    public void a();

    public void a(cen var1) throws IOException;

    public int b();

    public MultiTexID getMultiTexID();
}

