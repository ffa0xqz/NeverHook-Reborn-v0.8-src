/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Maps
 *  com.google.common.collect.Sets
 *  javax.annotation.Nullable
 */
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;

public class qq {
    protected static final Map<String, qm> a = Maps.newHashMap();
    public static final List<qm> b = Lists.newArrayList();
    public static final List<qm> c = Lists.newArrayList();
    public static final List<qi> d = Lists.newArrayList();
    public static final List<qi> e = Lists.newArrayList();
    public static final qm f = new qh("stat.leaveGame", new hp("stat.leaveGame", new Object[0])).c().a();
    public static final qm g = new qh("stat.playOneMinute", new hp("stat.playOneMinute", new Object[0]), qm.d).c().a();
    public static final qm h = new qh("stat.timeSinceDeath", new hp("stat.timeSinceDeath", new Object[0]), qm.d).c().a();
    public static final qm i = new qh("stat.sneakTime", new hp("stat.sneakTime", new Object[0]), qm.d).c().a();
    public static final qm j = new qh("stat.walkOneCm", new hp("stat.walkOneCm", new Object[0]), qm.e).c().a();
    public static final qm k = new qh("stat.crouchOneCm", new hp("stat.crouchOneCm", new Object[0]), qm.e).c().a();
    public static final qm l = new qh("stat.sprintOneCm", new hp("stat.sprintOneCm", new Object[0]), qm.e).c().a();
    public static final qm m = new qh("stat.swimOneCm", new hp("stat.swimOneCm", new Object[0]), qm.e).c().a();
    public static final qm n = new qh("stat.fallOneCm", new hp("stat.fallOneCm", new Object[0]), qm.e).c().a();
    public static final qm o = new qh("stat.climbOneCm", new hp("stat.climbOneCm", new Object[0]), qm.e).c().a();
    public static final qm p = new qh("stat.flyOneCm", new hp("stat.flyOneCm", new Object[0]), qm.e).c().a();
    public static final qm q = new qh("stat.diveOneCm", new hp("stat.diveOneCm", new Object[0]), qm.e).c().a();
    public static final qm r = new qh("stat.minecartOneCm", new hp("stat.minecartOneCm", new Object[0]), qm.e).c().a();
    public static final qm s = new qh("stat.boatOneCm", new hp("stat.boatOneCm", new Object[0]), qm.e).c().a();
    public static final qm t = new qh("stat.pigOneCm", new hp("stat.pigOneCm", new Object[0]), qm.e).c().a();
    public static final qm u = new qh("stat.horseOneCm", new hp("stat.horseOneCm", new Object[0]), qm.e).c().a();
    public static final qm v = new qh("stat.aviateOneCm", new hp("stat.aviateOneCm", new Object[0]), qm.e).c().a();
    public static final qm w = new qh("stat.jump", new hp("stat.jump", new Object[0])).c().a();
    public static final qm x = new qh("stat.drop", new hp("stat.drop", new Object[0])).c().a();
    public static final qm y = new qh("stat.damageDealt", new hp("stat.damageDealt", new Object[0]), qm.f).a();
    public static final qm z = new qh("stat.damageTaken", new hp("stat.damageTaken", new Object[0]), qm.f).a();
    public static final qm A = new qh("stat.deaths", new hp("stat.deaths", new Object[0])).a();
    public static final qm B = new qh("stat.mobKills", new hp("stat.mobKills", new Object[0])).a();
    public static final qm C = new qh("stat.animalsBred", new hp("stat.animalsBred", new Object[0])).a();
    public static final qm D = new qh("stat.playerKills", new hp("stat.playerKills", new Object[0])).a();
    public static final qm E = new qh("stat.fishCaught", new hp("stat.fishCaught", new Object[0])).a();
    public static final qm F = new qh("stat.talkedToVillager", new hp("stat.talkedToVillager", new Object[0])).a();
    public static final qm G = new qh("stat.tradedWithVillager", new hp("stat.tradedWithVillager", new Object[0])).a();
    public static final qm H = new qh("stat.cakeSlicesEaten", new hp("stat.cakeSlicesEaten", new Object[0])).a();
    public static final qm I = new qh("stat.cauldronFilled", new hp("stat.cauldronFilled", new Object[0])).a();
    public static final qm J = new qh("stat.cauldronUsed", new hp("stat.cauldronUsed", new Object[0])).a();
    public static final qm K = new qh("stat.armorCleaned", new hp("stat.armorCleaned", new Object[0])).a();
    public static final qm L = new qh("stat.bannerCleaned", new hp("stat.bannerCleaned", new Object[0])).a();
    public static final qm M = new qh("stat.brewingstandInteraction", new hp("stat.brewingstandInteraction", new Object[0])).a();
    public static final qm N = new qh("stat.beaconInteraction", new hp("stat.beaconInteraction", new Object[0])).a();
    public static final qm O = new qh("stat.dropperInspected", new hp("stat.dropperInspected", new Object[0])).a();
    public static final qm P = new qh("stat.hopperInspected", new hp("stat.hopperInspected", new Object[0])).a();
    public static final qm Q = new qh("stat.dispenserInspected", new hp("stat.dispenserInspected", new Object[0])).a();
    public static final qm R = new qh("stat.noteblockPlayed", new hp("stat.noteblockPlayed", new Object[0])).a();
    public static final qm S = new qh("stat.noteblockTuned", new hp("stat.noteblockTuned", new Object[0])).a();
    public static final qm T = new qh("stat.flowerPotted", new hp("stat.flowerPotted", new Object[0])).a();
    public static final qm U = new qh("stat.trappedChestTriggered", new hp("stat.trappedChestTriggered", new Object[0])).a();
    public static final qm V = new qh("stat.enderchestOpened", new hp("stat.enderchestOpened", new Object[0])).a();
    public static final qm W = new qh("stat.itemEnchanted", new hp("stat.itemEnchanted", new Object[0])).a();
    public static final qm X = new qh("stat.recordPlayed", new hp("stat.recordPlayed", new Object[0])).a();
    public static final qm Y = new qh("stat.furnaceInteraction", new hp("stat.furnaceInteraction", new Object[0])).a();
    public static final qm Z = new qh("stat.craftingTableInteraction", new hp("stat.workbenchInteraction", new Object[0])).a();
    public static final qm aa = new qh("stat.chestOpened", new hp("stat.chestOpened", new Object[0])).a();
    public static final qm ab = new qh("stat.sleepInBed", new hp("stat.sleepInBed", new Object[0])).a();
    public static final qm ac = new qh("stat.shulkerBoxOpened", new hp("stat.shulkerBoxOpened", new Object[0])).a();
    private static final qm[] ad = new qm[4096];
    private static final qm[] ae = new qm[32000];
    private static final qm[] af = new qm[32000];
    private static final qm[] ag = new qm[32000];
    private static final qm[] ah = new qm[32000];
    private static final qm[] ai = new qm[32000];

    @Nullable
    public static qm a(aou aou2) {
        return ad[aou.a(aou2)];
    }

    @Nullable
    public static qm a(ail ail2) {
        return ae[ail.a(ail2)];
    }

    @Nullable
    public static qm b(ail ail2) {
        return af[ail.a(ail2)];
    }

    @Nullable
    public static qm c(ail ail2) {
        return ag[ail.a(ail2)];
    }

    @Nullable
    public static qm d(ail ail2) {
        return ah[ail.a(ail2)];
    }

    @Nullable
    public static qm e(ail ail2) {
        return ai[ail.a(ail2)];
    }

    public static void a() {
        qq.c();
        qq.d();
        qq.e();
        qq.b();
        qq.f();
    }

    private static void b() {
        HashSet hashSet = Sets.newHashSet();
        for (Object \u26032 : aks.a) {
            ain ain2 = \u26032.b();
            if (ain2.b()) continue;
            hashSet.add(\u26032.b().c());
        }
        for (Object \u26032 : akn.a().b().values()) {
            hashSet.add(((ain)\u26032).c());
        }
        for (Object \u26032 : hashSet) {
            if (\u26032 == null) continue;
            int n2 = ail.a((ail)\u26032);
            String \u26033 = qq.f((ail)\u26032);
            if (\u26033 == null) continue;
            qq.ae[n2] = new qi("stat.craftItem.", \u26033, new hp("stat.craftItem", new ain((ail)\u26032).C()), (ail)\u26032).a();
        }
        qq.a(ae);
    }

    private static void c() {
        for (aou aou2 : aou.h) {
            ail ail2 = ail.a(aou2);
            if (ail2 == aip.a) continue;
            int \u26032 = aou.a(aou2);
            String \u26033 = qq.f(ail2);
            if (\u26033 == null || !aou2.o()) continue;
            qq.ad[\u26032] = new qi("stat.mineBlock.", \u26033, new hp("stat.mineBlock", new ain(aou2).C()), ail2).a();
            e.add((qi)ad[\u26032]);
        }
        qq.a(ad);
    }

    private static void d() {
        for (ail ail2 : ail.g) {
            if (ail2 == null) continue;
            int n2 = ail.a(ail2);
            String \u26032 = qq.f(ail2);
            if (\u26032 == null) continue;
            qq.af[n2] = new qi("stat.useItem.", \u26032, new hp("stat.useItem", new ain(ail2).C()), ail2).a();
            if (ail2 instanceof agz) continue;
            d.add((qi)af[n2]);
        }
        qq.a(af);
    }

    private static void e() {
        for (ail ail2 : ail.g) {
            if (ail2 == null) continue;
            int n2 = ail.a(ail2);
            String \u26032 = qq.f(ail2);
            if (\u26032 == null || !ail2.m()) continue;
            qq.ag[n2] = new qi("stat.breakItem.", \u26032, new hp("stat.breakItem", new ain(ail2).C()), ail2).a();
        }
        qq.a(ag);
    }

    private static void f() {
        for (ail ail2 : ail.g) {
            if (ail2 == null) continue;
            int n2 = ail.a(ail2);
            String \u26032 = qq.f(ail2);
            if (\u26032 == null) continue;
            qq.ah[n2] = new qi("stat.pickup.", \u26032, new hp("stat.pickup", new ain(ail2).C()), ail2).a();
            qq.ai[n2] = new qi("stat.drop.", \u26032, new hp("stat.drop", new ain(ail2).C()), ail2).a();
        }
        qq.a(ag);
    }

    private static String f(ail ail2) {
        nd nd2 = ail.g.b(ail2);
        if (nd2 != null) {
            return nd2.toString().replace(':', '.');
        }
        return null;
    }

    private static void a(qm[] arrqm) {
        qq.a(arrqm, aov.j, aov.i);
        qq.a(arrqm, aov.l, aov.k);
        qq.a(arrqm, aov.aZ, aov.aU);
        qq.a(arrqm, aov.am, aov.al);
        qq.a(arrqm, aov.aD, aov.aC);
        qq.a(arrqm, aov.bc, aov.bb);
        qq.a(arrqm, aov.ck, aov.cj);
        qq.a(arrqm, aov.aF, aov.aE);
        qq.a(arrqm, aov.bK, aov.bJ);
        qq.a(arrqm, aov.T, aov.U);
        qq.a(arrqm, aov.bL, aov.bM);
        qq.a(arrqm, aov.cO, aov.cP);
        qq.a(arrqm, aov.c, aov.d);
        qq.a(arrqm, aov.ak, aov.d);
    }

    private static void a(qm[] arrqm, aou aou2, aou aou3) {
        int n2 = aou.a(aou2);
        \u2603 = aou.a(aou3);
        if (arrqm[n2] != null && arrqm[\u2603] == null) {
            arrqm[\u2603] = arrqm[n2];
            return;
        }
        b.remove(arrqm[n2]);
        e.remove(arrqm[n2]);
        c.remove(arrqm[n2]);
        arrqm[n2] = arrqm[\u2603];
    }

    public static qm a(vg.a a2) {
        String string = vg.a(a2.a);
        if (string == null) {
            return null;
        }
        return new qm("stat.killEntity." + string, new hp("stat.entityKill", new hp("entity." + string + ".name", new Object[0]))).a();
    }

    public static qm b(vg.a a2) {
        String string = vg.a(a2.a);
        if (string == null) {
            return null;
        }
        return new qm("stat.entityKilledBy." + string, new hp("stat.entityKilledBy", new hp("entity." + string + ".name", new Object[0]))).a();
    }

    @Nullable
    public static qm a(String string) {
        return a.get(string);
    }
}

