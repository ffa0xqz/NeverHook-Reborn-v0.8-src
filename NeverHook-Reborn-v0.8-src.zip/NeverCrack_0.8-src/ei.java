/*
 * Decompiled with CFR 0.150.
 */
public class ei
extends Exception {
    private final Object[] a;

    public ei(String string, Object ... arrobject) {
        super(string);
        this.a = arrobject;
    }

    public Object[] a() {
        return this.a;
    }

    @Override
    public synchronized Throwable fillInStackTrace() {
        return this;
    }
}

