/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Sets
 */
import com.google.common.collect.Sets;
import java.util.Set;

public class agw
extends aho {
    private static final Set<aou> e = Sets.newHashSet((Object[])new aou[]{aov.f, aov.X, aov.r, aov.s, aov.ae, aov.aU, aov.aZ, aov.bk, aov.au, aov.cd, aov.aB});
    private static final float[] f = new float[]{6.0f, 8.0f, 8.0f, 8.0f, 6.0f};
    private static final float[] n = new float[]{-3.2f, -3.2f, -3.1f, -3.0f, -3.0f};

    protected agw(ail.a a2) {
        super(a2, e);
        this.b = f[a2.ordinal()];
        this.c = n[a2.ordinal()];
    }

    @Override
    public float a(ain ain2, awr awr2) {
        bcx bcx2 = awr2.a();
        if (bcx2 == bcx.d || bcx2 == bcx.k || bcx2 == bcx.l) {
            return this.a;
        }
        return super.a(ain2, awr2);
    }
}

