/*
 * Decompiled with CFR 0.150.
 */
public class bcy {
    public static final bcy[] a = new bcy[64];
    public static final bcy[] b = new bcy[16];
    public static final bcy c = new bcy(0, 0);
    public static final bcy d = new bcy(1, 8368696);
    public static final bcy e = new bcy(2, 16247203);
    public static final bcy f = new bcy(3, 0xC7C7C7);
    public static final bcy g = new bcy(4, 0xFF0000);
    public static final bcy h = new bcy(5, 0xA0A0FF);
    public static final bcy i = new bcy(6, 0xA7A7A7);
    public static final bcy j = new bcy(7, 31744);
    public static final bcy k = new bcy(8, 0xFFFFFF);
    public static final bcy l = new bcy(9, 10791096);
    public static final bcy m = new bcy(10, 9923917);
    public static final bcy n = new bcy(11, 0x707070);
    public static final bcy o = new bcy(12, 0x4040FF);
    public static final bcy p = new bcy(13, 9402184);
    public static final bcy q = new bcy(14, 0xFFFCF5);
    public static final bcy r = new bcy(15, 14188339);
    public static final bcy s = new bcy(16, 11685080);
    public static final bcy t = new bcy(17, 6724056);
    public static final bcy u = new bcy(18, 0xE5E533);
    public static final bcy v = new bcy(19, 8375321);
    public static final bcy w = new bcy(20, 15892389);
    public static final bcy x = new bcy(21, 0x4C4C4C);
    public static final bcy y = new bcy(22, 0x999999);
    public static final bcy z = new bcy(23, 5013401);
    public static final bcy A = new bcy(24, 8339378);
    public static final bcy B = new bcy(25, 3361970);
    public static final bcy C = new bcy(26, 6704179);
    public static final bcy D = new bcy(27, 6717235);
    public static final bcy E = new bcy(28, 0x993333);
    public static final bcy F = new bcy(29, 0x191919);
    public static final bcy G = new bcy(30, 16445005);
    public static final bcy H = new bcy(31, 6085589);
    public static final bcy I = new bcy(32, 4882687);
    public static final bcy J = new bcy(33, 55610);
    public static final bcy K = new bcy(34, 8476209);
    public static final bcy L = new bcy(35, 0x700200);
    public static final bcy M = new bcy(36, 13742497);
    public static final bcy N = new bcy(37, 10441252);
    public static final bcy O = new bcy(38, 9787244);
    public static final bcy P = new bcy(39, 7367818);
    public static final bcy Q = new bcy(40, 12223780);
    public static final bcy R = new bcy(41, 6780213);
    public static final bcy S = new bcy(42, 10505550);
    public static final bcy T = new bcy(43, 0x392923);
    public static final bcy U = new bcy(44, 8874850);
    public static final bcy V = new bcy(45, 0x575C5C);
    public static final bcy W = new bcy(46, 8014168);
    public static final bcy X = new bcy(47, 4996700);
    public static final bcy Y = new bcy(48, 4993571);
    public static final bcy Z = new bcy(49, 5001770);
    public static final bcy aa = new bcy(50, 9321518);
    public static final bcy ab = new bcy(51, 2430480);
    public int ac;
    public final int ad;

    private bcy(int index, int color) {
        if (index < 0 || index > 63) {
            throw new IndexOutOfBoundsException("Map colour ID must be between 0 and 63 (inclusive)");
        }
        this.ad = index;
        this.ac = color;
        bcy.a[index] = this;
    }

    public int a(int p_151643_1_) {
        int i2 = 220;
        if (p_151643_1_ == 3) {
            i2 = 135;
        }
        if (p_151643_1_ == 2) {
            i2 = 255;
        }
        if (p_151643_1_ == 1) {
            i2 = 220;
        }
        if (p_151643_1_ == 0) {
            i2 = 180;
        }
        int j2 = (this.ac >> 16 & 0xFF) * i2 / 255;
        int k2 = (this.ac >> 8 & 0xFF) * i2 / 255;
        int l2 = (this.ac & 0xFF) * i2 / 255;
        return 0xFF000000 | j2 << 16 | k2 << 8 | l2;
    }

    public static bcy a(ahq p_193558_0_) {
        return b[p_193558_0_.a()];
    }

    static {
        bcy.b[ahq.a.a()] = k;
        bcy.b[ahq.b.a()] = r;
        bcy.b[ahq.c.a()] = s;
        bcy.b[ahq.d.a()] = t;
        bcy.b[ahq.e.a()] = u;
        bcy.b[ahq.f.a()] = v;
        bcy.b[ahq.g.a()] = w;
        bcy.b[ahq.h.a()] = x;
        bcy.b[ahq.i.a()] = y;
        bcy.b[ahq.j.a()] = z;
        bcy.b[ahq.k.a()] = A;
        bcy.b[ahq.l.a()] = B;
        bcy.b[ahq.m.a()] = C;
        bcy.b[ahq.n.a()] = D;
        bcy.b[ahq.o.a()] = E;
        bcy.b[ahq.p.a()] = F;
    }
}

