/*
 * Decompiled with CFR 0.150.
 */
import java.io.IOException;

public class bmv
extends bmp
implements bns {
    private float w;
    private float x;
    private bje y;
    private final bnm z = new bnm();
    private boolean A;
    private boolean B;

    public bmv(aeb player) {
        super(player.bx);
        this.p = true;
    }

    @Override
    public void e() {
        if (this.j.c.h()) {
            this.j.a(new bmn(this.j.h));
        }
        this.z.d();
    }

    @Override
    public void b() {
        this.n.clear();
        if (this.j.c.h()) {
            this.j.a(new bmn(this.j.h));
        } else {
            super.b();
        }
        this.A = this.l < 379;
        this.z.func_194303_a(this.l, this.m, this.j, this.A, ((agg)this.h).a);
        this.i = this.z.a(this.A, this.l, this.f);
        this.y = new bje(10, this.i + 104, this.m / 2 - 22, 20, 18, 178, 0, 19, a);
        this.n.add(this.y);
    }

    @Override
    protected void c(int mouseX, int mouseY) {
        this.q.drawString(cew.a("container.crafting", new Object[0]), 97.0f, 8.0f, 0x404040);
    }

    @Override
    public void a(int mouseX, int mouseY, float partialTicks) {
        this.c();
        boolean bl2 = this.v = !this.z.c();
        if (this.z.c() && this.A) {
            this.a(partialTicks, mouseX, mouseY);
            this.z.a(mouseX, mouseY, partialTicks);
        } else {
            this.z.a(mouseX, mouseY, partialTicks);
            super.a(mouseX, mouseY, partialTicks);
            this.z.a(this.i, this.s, false, partialTicks);
        }
        this.b(mouseX, mouseY);
        this.z.c(this.i, this.s, mouseX, mouseY);
        this.w = mouseX;
        this.x = mouseY;
    }

    @Override
    protected void a(float partialTicks, int mouseX, int mouseY) {
        buq.c(1.0f, 1.0f, 1.0f, 1.0f);
        this.j.N().a(a);
        int i2 = this.i;
        int j2 = this.s;
        this.b(i2, j2, 0, 0, this.f, this.g);
        bmv.a(i2 + 51, j2 + 75, 30, (float)(i2 + 51) - this.w, (float)(j2 + 75 - 50) - this.x, this.j.h);
    }

    public static void a(int posX, int posY, int scale, float mouseX, float mouseY, vn ent) {
        buq.h();
        buq.G();
        buq.c((float)posX, (float)posY, 50.0f);
        buq.b((float)(-scale), (float)scale, (float)scale);
        buq.b(180.0f, 0.0f, 0.0f, 1.0f);
        float f2 = ent.aN;
        float f1 = ent.v;
        float f22 = ent.w;
        float f3 = ent.aQ;
        float f4 = ent.aP;
        buq.b(135.0f, 0.0f, 1.0f, 0.0f);
        bhx.b();
        buq.b(-135.0f, 0.0f, 1.0f, 0.0f);
        buq.b(-((float)Math.atan(mouseY / 40.0f)) * 20.0f, 1.0f, 0.0f, 0.0f);
        ent.aN = (float)Math.atan(mouseX / 40.0f) * 20.0f;
        ent.v = (float)Math.atan(mouseX / 40.0f) * 70.0f;
        ent.rotationPitchHead = -((float)Math.atan(mouseY / 40.0f)) * 20.0f;
        ent.aP = ent.v;
        ent.aQ = ent.v;
        buq.c(0.0f, 0.0f, 0.0f);
        bzd rendermanager = bhz.z().ac();
        rendermanager.a(180.0f);
        rendermanager.a(false);
        rendermanager.a(ent, 0.0, 0.0, 0.0, 0.0f, 1.0f, false);
        rendermanager.a(true);
        ent.aN = f2;
        ent.v = f1;
        ent.rotationPitchHead = f22;
        ent.aQ = f3;
        ent.aP = f4;
        buq.H();
        bhx.a();
        buq.E();
        buq.g(cig.r);
        buq.z();
        buq.g(cig.q);
    }

    @Override
    protected boolean c(int rectX, int rectY, int rectWidth, int rectHeight, int pointX, int pointY) {
        return (!this.A || !this.z.c()) && super.c(rectX, rectY, rectWidth, rectHeight, pointX, pointY);
    }

    @Override
    protected void a(int mouseX, int mouseY, int mouseButton) throws IOException {
        if (!(this.z.a(mouseX, mouseY, mouseButton) || this.A && this.z.c())) {
            super.a(mouseX, mouseY, mouseButton);
        }
    }

    @Override
    protected void b(int mouseX, int mouseY, int state) {
        if (this.B) {
            this.B = false;
        } else {
            super.b(mouseX, mouseY, state);
        }
    }

    @Override
    protected boolean c(int p_193983_1_, int p_193983_2_, int p_193983_3_, int p_193983_4_) {
        boolean flag = p_193983_1_ < p_193983_3_ || p_193983_2_ < p_193983_4_ || p_193983_1_ >= p_193983_3_ + this.f || p_193983_2_ >= p_193983_4_ + this.g;
        return this.z.c(p_193983_1_, p_193983_2_, this.i, this.s, this.f, this.g) && flag;
    }

    @Override
    protected void a(biy button) throws IOException {
        if (button.k == 10) {
            this.z.a(this.A, ((agg)this.h).a);
            this.z.b();
            this.i = this.z.a(this.A, this.l, this.f);
            this.y.c(this.i + 104, this.m / 2 - 22);
            this.B = true;
        }
    }

    @Override
    protected void a(char typedChar, int keyCode) throws IOException {
        if (!this.z.a(typedChar, keyCode)) {
            super.a(typedChar, keyCode);
        }
    }

    @Override
    public void a(agp slotIn, int slotId, int mouseButton, afu type) {
        super.a(slotIn, slotId, mouseButton, type);
        this.z.a(slotIn);
    }

    @Override
    public void I_() {
        this.z.e();
    }

    @Override
    public void m() {
        this.z.a();
        super.m();
    }

    @Override
    public bnm func_194310_f() {
        return this.z;
    }
}

