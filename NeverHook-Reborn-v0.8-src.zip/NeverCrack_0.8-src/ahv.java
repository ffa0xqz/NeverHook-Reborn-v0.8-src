/*
 * Decompiled with CFR 0.150.
 */
public class ahv
extends ahm {
    protected ahv() {
        this.b(ahn.f);
    }

    @Override
    public uc<ain> a(ams ams2, aeb aeb2, tz tz2) {
        ain ain2 = aiu.a(ams2, aeb2.p, aeb2.r, (byte)0, true, false);
        \u2603 = aeb2.b(tz2);
        \u2603.g(1);
        if (\u2603.b()) {
            return new uc<ain>(ub.a, ain2);
        }
        if (!aeb2.bv.e(ain2.l())) {
            aeb2.a(ain2, false);
        }
        aeb2.b(qq.b(this));
        return new uc<ain>(ub.a, \u2603);
    }
}

