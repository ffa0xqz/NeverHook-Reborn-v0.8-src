/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  javax.annotation.Nullable
 */
import com.google.common.collect.Lists;
import java.util.List;
import javax.annotation.Nullable;

public abstract class aoq
extends aou {
    protected static final bgz a = new bgz(0.0, 0.0, 0.0, 1.0, 0.125, 1.0);
    protected static final bgz b = new bgz(0.0, 0.0, 0.0, 1.0, 0.5, 1.0);
    protected final boolean c;

    public static boolean b(ams ams2, et et2) {
        return aoq.i(ams2.o(et2));
    }

    public static boolean i(awr awr2) {
        aou aou2 = awr2.u();
        return aou2 == aov.av || aou2 == aov.D || aou2 == aov.E || aou2 == aov.cs;
    }

    protected aoq(boolean bl2) {
        super(bcx.q);
        this.c = bl2;
        this.a(ahn.e);
    }

    @Override
    @Nullable
    public bgz a(awr awr2, amw amw2, et et2) {
        return k;
    }

    @Override
    public boolean b(awr awr2) {
        return false;
    }

    @Override
    public bgz b(awr awr2, amw amw2, et et2) {
        b b2 = \u2603 = awr2.u() == this ? awr2.c(this.g()) : null;
        if (\u2603 != null && \u2603.c()) {
            return b;
        }
        return a;
    }

    @Override
    public awp a(amw amw2, awr awr2, et et2, fa fa2) {
        return awp.i;
    }

    @Override
    public boolean c(awr awr2) {
        return false;
    }

    @Override
    public boolean a(ams ams2, et et2) {
        return ams2.o(et2.b()).q();
    }

    @Override
    public void c(ams ams2, et et2, awr awr2) {
        if (!ams2.G) {
            awr2 = this.a(ams2, et2, awr2, true);
            if (this.c) {
                awr2.a(ams2, et2, this, et2);
            }
        }
    }

    @Override
    public void a(awr awr2, ams ams2, et et2, aou aou2, et et3) {
        if (ams2.G) {
            return;
        }
        b b2 = awr2.c(this.g());
        boolean \u26032 = false;
        if (!ams2.o(et2.b()).q()) {
            \u26032 = true;
        }
        if (b2 == aoq$b.c && !ams2.o(et2.f()).q()) {
            \u26032 = true;
        } else if (b2 == aoq$b.d && !ams2.o(et2.e()).q()) {
            \u26032 = true;
        } else if (b2 == aoq$b.e && !ams2.o(et2.c()).q()) {
            \u26032 = true;
        } else if (b2 == aoq$b.f && !ams2.o(et2.d()).q()) {
            \u26032 = true;
        }
        if (\u26032 && !ams2.d(et2)) {
            this.b(ams2, et2, awr2, 0);
            ams2.g(et2);
        } else {
            this.a(awr2, ams2, et2, aou2);
        }
    }

    protected void a(awr awr2, ams ams2, et et2, aou aou2) {
    }

    protected awr a(ams ams2, et et2, awr awr2, boolean bl2) {
        if (ams2.G) {
            return awr2;
        }
        return new a(ams2, et2, awr2).a(ams2.y(et2), bl2).c();
    }

    @Override
    public bda h(awr awr2) {
        return bda.a;
    }

    @Override
    public amk f() {
        return amk.c;
    }

    @Override
    public void b(ams ams2, et et2, awr awr2) {
        super.b(ams2, et2, awr2);
        if (awr2.c(this.g()).c()) {
            ams2.b(et2.a(), (aou)this, false);
        }
        if (this.c) {
            ams2.b(et2, (aou)this, false);
            ams2.b(et2.b(), (aou)this, false);
        }
    }

    public abstract axh<b> g();

    public static enum b implements rm
    {
        a(0, "north_south"),
        b(1, "east_west"),
        c(2, "ascending_east"),
        d(3, "ascending_west"),
        e(4, "ascending_north"),
        f(5, "ascending_south"),
        g(6, "south_east"),
        h(7, "south_west"),
        i(8, "north_west"),
        j(9, "north_east");

        private static final b[] k;
        private final int l;
        private final String m;

        private b(int n3, String string2) {
            this.l = n3;
            this.m = string2;
        }

        public int a() {
            return this.l;
        }

        public String toString() {
            return this.m;
        }

        public boolean c() {
            return this == e || this == c || this == f || this == d;
        }

        public static b a(int n2) {
            if (n2 < 0 || n2 >= k.length) {
                n2 = 0;
            }
            return k[n2];
        }

        @Override
        public String m() {
            return this.m;
        }

        static {
            k = new b[aoq$b.values().length];
            b[] arrb = aoq$b.values();
            int n2 = arrb.length;
            for (int i2 = 0; i2 < n2; ++i2) {
                b b2;
                aoq$b.k[b2.a()] = b2 = arrb[i2];
            }
        }
    }

    public class a {
        private final ams b;
        private final et c;
        private final aoq d;
        private awr e;
        private final boolean f;
        private final List<et> g = Lists.newArrayList();

        public a(ams ams2, et et2, awr awr2) {
            this.b = ams2;
            this.c = et2;
            this.e = awr2;
            this.d = (aoq)awr2.u();
            b b2 = awr2.c(this.d.g());
            this.f = this.d.c;
            this.a(b2);
        }

        public List<et> a() {
            return this.g;
        }

        private void a(b b2) {
            this.g.clear();
            switch (b2) {
                case a: {
                    this.g.add(this.c.c());
                    this.g.add(this.c.d());
                    break;
                }
                case b: {
                    this.g.add(this.c.e());
                    this.g.add(this.c.f());
                    break;
                }
                case c: {
                    this.g.add(this.c.e());
                    this.g.add(this.c.f().a());
                    break;
                }
                case d: {
                    this.g.add(this.c.e().a());
                    this.g.add(this.c.f());
                    break;
                }
                case e: {
                    this.g.add(this.c.c().a());
                    this.g.add(this.c.d());
                    break;
                }
                case f: {
                    this.g.add(this.c.c());
                    this.g.add(this.c.d().a());
                    break;
                }
                case g: {
                    this.g.add(this.c.f());
                    this.g.add(this.c.d());
                    break;
                }
                case h: {
                    this.g.add(this.c.e());
                    this.g.add(this.c.d());
                    break;
                }
                case i: {
                    this.g.add(this.c.e());
                    this.g.add(this.c.c());
                    break;
                }
                case j: {
                    this.g.add(this.c.f());
                    this.g.add(this.c.c());
                }
            }
        }

        private void d() {
            for (int i2 = 0; i2 < this.g.size(); ++i2) {
                a a2 = this.b(this.g.get(i2));
                if (a2 == null || !a2.a(this)) {
                    this.g.remove(i2--);
                    continue;
                }
                this.g.set(i2, a2.c);
            }
        }

        private boolean a(et et2) {
            return aoq.b(this.b, et2) || aoq.b(this.b, et2.a()) || aoq.b(this.b, et2.b());
        }

        @Nullable
        private a b(et et2) {
            \u26032 = et2;
            awr awr2 = this.b.o(\u26032);
            if (aoq.i(awr2)) {
                return new a(this.b, \u26032, awr2);
            }
            et \u26032 = et2.a();
            awr2 = this.b.o(\u26032);
            if (aoq.i(awr2)) {
                return new a(this.b, \u26032, awr2);
            }
            \u26032 = et2.b();
            awr2 = this.b.o(\u26032);
            if (aoq.i(awr2)) {
                return new a(this.b, \u26032, awr2);
            }
            return null;
        }

        private boolean a(a a2) {
            return this.c(a2.c);
        }

        private boolean c(et et2) {
            for (int i2 = 0; i2 < this.g.size(); ++i2) {
                et et3 = this.g.get(i2);
                if (et3.p() != et2.p() || et3.r() != et2.r()) continue;
                return true;
            }
            return false;
        }

        protected int b() {
            int n2 = 0;
            for (fa fa2 : fa.c.a) {
                if (!this.a(this.c.a(fa2))) continue;
                ++n2;
            }
            return n2;
        }

        private boolean b(a a2) {
            return this.a(a2) || this.g.size() != 2;
        }

        private void c(a a2) {
            this.g.add(a2.c);
            et et2 = this.c.c();
            \u2603 = this.c.d();
            \u2603 = this.c.e();
            \u2603 = this.c.f();
            boolean \u26032 = this.c(et2);
            boolean \u26033 = this.c(\u2603);
            boolean \u26034 = this.c(\u2603);
            boolean \u26035 = this.c(\u2603);
            b \u26036 = null;
            if (\u26032 || \u26033) {
                \u26036 = aoq$b.a;
            }
            if (\u26034 || \u26035) {
                \u26036 = aoq$b.b;
            }
            if (!this.f) {
                if (\u26033 && \u26035 && !\u26032 && !\u26034) {
                    \u26036 = aoq$b.g;
                }
                if (\u26033 && \u26034 && !\u26032 && !\u26035) {
                    \u26036 = aoq$b.h;
                }
                if (\u26032 && \u26034 && !\u26033 && !\u26035) {
                    \u26036 = aoq$b.i;
                }
                if (\u26032 && \u26035 && !\u26033 && !\u26034) {
                    \u26036 = aoq$b.j;
                }
            }
            if (\u26036 == aoq$b.a) {
                if (aoq.b(this.b, et2.a())) {
                    \u26036 = aoq$b.e;
                }
                if (aoq.b(this.b, \u2603.a())) {
                    \u26036 = aoq$b.f;
                }
            }
            if (\u26036 == aoq$b.b) {
                if (aoq.b(this.b, \u2603.a())) {
                    \u26036 = aoq$b.c;
                }
                if (aoq.b(this.b, \u2603.a())) {
                    \u26036 = aoq$b.d;
                }
            }
            if (\u26036 == null) {
                \u26036 = aoq$b.a;
            }
            this.e = this.e.a(this.d.g(), \u26036);
            this.b.a(this.c, this.e, 3);
        }

        private boolean d(et et2) {
            a a2 = this.b(et2);
            if (a2 == null) {
                return false;
            }
            a2.d();
            return a2.b(this);
        }

        public a a(boolean bl2, boolean bl3) {
            et et2 = this.c.c();
            \u2603 = this.c.d();
            \u2603 = this.c.e();
            \u2603 = this.c.f();
            boolean \u26032 = this.d(et2);
            boolean \u26033 = this.d(\u2603);
            boolean \u26034 = this.d(\u2603);
            boolean \u26035 = this.d(\u2603);
            b \u26036 = null;
            if ((\u26032 || \u26033) && !\u26034 && !\u26035) {
                \u26036 = aoq$b.a;
            }
            if ((\u26034 || \u26035) && !\u26032 && !\u26033) {
                \u26036 = aoq$b.b;
            }
            if (!this.f) {
                if (\u26033 && \u26035 && !\u26032 && !\u26034) {
                    \u26036 = aoq$b.g;
                }
                if (\u26033 && \u26034 && !\u26032 && !\u26035) {
                    \u26036 = aoq$b.h;
                }
                if (\u26032 && \u26034 && !\u26033 && !\u26035) {
                    \u26036 = aoq$b.i;
                }
                if (\u26032 && \u26035 && !\u26033 && !\u26034) {
                    \u26036 = aoq$b.j;
                }
            }
            if (\u26036 == null) {
                if (\u26032 || \u26033) {
                    \u26036 = aoq$b.a;
                }
                if (\u26034 || \u26035) {
                    \u26036 = aoq$b.b;
                }
                if (!this.f) {
                    if (bl2) {
                        if (\u26033 && \u26035) {
                            \u26036 = aoq$b.g;
                        }
                        if (\u26034 && \u26033) {
                            \u26036 = aoq$b.h;
                        }
                        if (\u26035 && \u26032) {
                            \u26036 = aoq$b.j;
                        }
                        if (\u26032 && \u26034) {
                            \u26036 = aoq$b.i;
                        }
                    } else {
                        if (\u26032 && \u26034) {
                            \u26036 = aoq$b.i;
                        }
                        if (\u26035 && \u26032) {
                            \u26036 = aoq$b.j;
                        }
                        if (\u26034 && \u26033) {
                            \u26036 = aoq$b.h;
                        }
                        if (\u26033 && \u26035) {
                            \u26036 = aoq$b.g;
                        }
                    }
                }
            }
            if (\u26036 == aoq$b.a) {
                if (aoq.b(this.b, et2.a())) {
                    \u26036 = aoq$b.e;
                }
                if (aoq.b(this.b, \u2603.a())) {
                    \u26036 = aoq$b.f;
                }
            }
            if (\u26036 == aoq$b.b) {
                if (aoq.b(this.b, \u2603.a())) {
                    \u26036 = aoq$b.c;
                }
                if (aoq.b(this.b, \u2603.a())) {
                    \u26036 = aoq$b.d;
                }
            }
            if (\u26036 == null) {
                \u26036 = aoq$b.a;
            }
            this.a(\u26036);
            this.e = this.e.a(this.d.g(), \u26036);
            if (bl3 || this.b.o(this.c) != this.e) {
                this.b.a(this.c, this.e, 3);
                for (int i2 = 0; i2 < this.g.size(); ++i2) {
                    a a2 = this.b(this.g.get(i2));
                    if (a2 == null) continue;
                    a2.d();
                    if (!a2.b(this)) continue;
                    a2.c(this);
                }
            }
            return this;
        }

        public awr c() {
            return this.e;
        }
    }
}

