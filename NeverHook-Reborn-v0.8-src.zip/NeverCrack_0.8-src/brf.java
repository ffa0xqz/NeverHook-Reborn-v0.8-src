/*
 * Decompiled with CFR 0.150.
 */
public class brf
extends bpv {
    public brf() {
        this(0.0f, 0.0f, false);
    }

    public brf(float f2, float f3, boolean bl2) {
        super(f2, 0.0f, 64, bl2 ? 32 : 64);
        if (bl2) {
            this.e = new brq(this, 0, 0);
            this.e.a(-4.0f, -10.0f, -4.0f, 8, 8, 8, f2);
            this.e.a(0.0f, 0.0f + f3, 0.0f);
            this.g = new brq(this, 16, 16);
            this.g.a(0.0f, 0.0f + f3, 0.0f);
            this.g.a(-4.0f, 0.0f, -2.0f, 8, 12, 4, f2 + 0.1f);
            this.j = new brq(this, 0, 16);
            this.j.a(-2.0f, 12.0f + f3, 0.0f);
            this.j.a(-2.0f, 0.0f, -2.0f, 4, 12, 4, f2 + 0.1f);
            this.k = new brq(this, 0, 16);
            this.k.i = true;
            this.k.a(2.0f, 12.0f + f3, 0.0f);
            this.k.a(-2.0f, 0.0f, -2.0f, 4, 12, 4, f2 + 0.1f);
        } else {
            this.e = new brq(this, 0, 0);
            this.e.a(0.0f, f3, 0.0f);
            this.e.a(0, 0).a(-4.0f, -10.0f, -4.0f, 8, 10, 8, f2);
            this.e.a(24, 0).a(-1.0f, -3.0f, -6.0f, 2, 4, 2, f2);
            this.g = new brq(this, 16, 20);
            this.g.a(0.0f, 0.0f + f3, 0.0f);
            this.g.a(-4.0f, 0.0f, -3.0f, 8, 12, 6, f2);
            this.g.a(0, 38).a(-4.0f, 0.0f, -3.0f, 8, 18, 6, f2 + 0.05f);
            this.h = new brq(this, 44, 38);
            this.h.a(-3.0f, -2.0f, -2.0f, 4, 12, 4, f2);
            this.h.a(-5.0f, 2.0f + f3, 0.0f);
            this.i = new brq(this, 44, 38);
            this.i.i = true;
            this.i.a(-1.0f, -2.0f, -2.0f, 4, 12, 4, f2);
            this.i.a(5.0f, 2.0f + f3, 0.0f);
            this.j = new brq(this, 0, 22);
            this.j.a(-2.0f, 12.0f + f3, 0.0f);
            this.j.a(-2.0f, 0.0f, -2.0f, 4, 12, 4, f2);
            this.k = new brq(this, 0, 22);
            this.k.i = true;
            this.k.a(2.0f, 12.0f + f3, 0.0f);
            this.k.a(-2.0f, 0.0f, -2.0f, 4, 12, 4, f2);
        }
    }

    @Override
    public void a(float f2, float f3, float f4, float f5, float f6, float f7, ve ve2) {
        super.a(f2, f3, f4, f5, f6, f7, ve2);
        adr adr2 = (adr)ve2;
        float \u26032 = ri.a(this.o * (float)Math.PI);
        float \u26033 = ri.a((1.0f - (1.0f - this.o) * (1.0f - this.o)) * (float)Math.PI);
        this.h.h = 0.0f;
        this.i.h = 0.0f;
        this.h.g = -(0.1f - \u26032 * 0.6f);
        this.i.g = 0.1f - \u26032 * 0.6f;
        this.h.f = \u2603 = (float)(-Math.PI) / (adr2.dq() ? 1.5f : 2.25f);
        this.i.f = \u2603;
        this.h.f += \u26032 * 1.2f - \u26033 * 0.4f;
        this.i.f += \u26032 * 1.2f - \u26033 * 0.4f;
        this.h.h += ri.b(f4 * 0.09f) * 0.05f + 0.05f;
        this.i.h -= ri.b(f4 * 0.09f) * 0.05f + 0.05f;
        this.h.f += ri.a(f4 * 0.067f) * 0.05f;
        this.i.f -= ri.a(f4 * 0.067f) * 0.05f;
    }
}

