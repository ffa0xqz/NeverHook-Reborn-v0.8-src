/*
 * Decompiled with CFR 0.150.
 */
public class bve
extends buj {
    private cdx a;

    @Override
    public void a(bui bui2) {
        bui2.b();
        this.a.a(bui2.f());
    }

    public void a(cdx cdx2) {
        this.a = cdx2;
    }
}

