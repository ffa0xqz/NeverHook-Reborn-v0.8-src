/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 */
package top.nhprem.client.features;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import top.nhprem.Main;
import top.nhprem.api.event.EventManager;
import top.nhprem.api.guis.draggable.component.DraggableComponent;
import top.nhprem.api.utils.not.Notification;
import top.nhprem.api.utils.not.NotificationManager;
import top.nhprem.api.utils.not.NotificationType;
import top.nhprem.api.utils.render.Translate;
import top.nhprem.api.utils.world.TimerHelper;
import top.nhprem.client.features.Category;
import top.nhprem.client.features.impl.misc.ModuleSoundAlert;
import top.nhprem.client.ui.clickgui.ScreenHelper;
import top.nhprem.client.ui.settings.Configurable;
import top.nhprem.client.ui.settings.Setting;
import top.nhprem.client.ui.settings.impl.BooleanSetting;
import top.nhprem.client.ui.settings.impl.ColorSetting;
import top.nhprem.client.ui.settings.impl.ListSetting;
import top.nhprem.client.ui.settings.impl.NumberSetting;

public class Feature
extends Configurable {
    protected static bhz mc = bhz.z();
    protected static bhz nh = bhz.z();
    public static TimerHelper timerHelper = new TimerHelper();
    private final Translate translate = new Translate(0.0f, 0.0f);
    protected String label;
    protected String desc;
    private String moduleName;
    private String suffix;
    private int key;
    private int bind;
    public float animYto;
    private Category category;
    private boolean toggled;
    public double slidex = 0.0;
    public boolean visible = true;
    public ScreenHelper screenHelper = new ScreenHelper(0.0f, 0.0f);

    public Feature(String name, String desc, int key, Category category) {
        this.label = name;
        this.desc = desc;
        this.key = key;
        this.category = category;
        this.toggled = false;
        this.bind = 0;
        this.setup();
    }

    public JsonObject save() {
        JsonObject object = new JsonObject();
        JsonObject jsonComp = new JsonObject();
        for (DraggableComponent comp : Main.getInstance().getDraggableHUD().getComponents()) {
            jsonComp.addProperty(comp.getName(), comp.getX() + ", " + comp.getY());
        }
        object.add("draggable_components", (JsonElement)jsonComp);
        object.addProperty("state", Boolean.valueOf(this.isToggled()));
        object.addProperty("keyIndex", (Number)this.getKey());
        object.addProperty("visible", Boolean.valueOf(this.isVisible()));
        JsonObject propertiesObject = new JsonObject();
        for (Setting set : this.getSettings()) {
            if (this.getSettings() != null) {
                if (set instanceof BooleanSetting) {
                    propertiesObject.addProperty(set.getName(), Boolean.valueOf(((BooleanSetting)set).getBoolValue()));
                } else if (set instanceof ListSetting) {
                    propertiesObject.addProperty(set.getName(), ((ListSetting)set).getCurrentMode());
                } else if (set instanceof NumberSetting) {
                    propertiesObject.addProperty(set.getName(), (Number)Float.valueOf(((NumberSetting)set).getNumberValue()));
                } else if (set instanceof ColorSetting) {
                    propertiesObject.addProperty(set.getName(), (Number)((ColorSetting)set).getColorValue());
                }
            }
            object.add("Settings", (JsonElement)propertiesObject);
        }
        return object;
    }

    public void load(JsonObject object) {
        if (object != null) {
            if (object.has("draggable_components")) {
                JsonObject jsonComp = object.getAsJsonObject("draggable_components");
                for (DraggableComponent comp : Main.getInstance().getDraggableHUD().getComponents()) {
                    if (!jsonComp.has(comp.getName())) continue;
                    String[] args = jsonComp.get(comp.getName()).getAsString().split(", ");
                    comp.setX(Integer.parseInt(args[0]));
                    comp.setY(Integer.parseInt(args[1]));
                }
            }
            if (object.has("state")) {
                this.setEnabled(object.get("state").getAsBoolean());
            }
            if (object.has("visible")) {
                this.setVisible(object.get("visible").getAsBoolean());
            }
            if (object.has("keyIndex")) {
                this.setKey(object.get("keyIndex").getAsInt());
            }
            for (Setting set : this.getSettings()) {
                JsonObject propertiesObject = object.getAsJsonObject("Settings");
                if (set == null || propertiesObject == null || !propertiesObject.has(set.getName())) continue;
                if (set instanceof BooleanSetting) {
                    ((BooleanSetting)set).setBoolValue(propertiesObject.get(set.getName()).getAsBoolean());
                    continue;
                }
                if (set instanceof ListSetting) {
                    ((ListSetting)set).setListMode(propertiesObject.get(set.getName()).getAsString());
                    continue;
                }
                if (set instanceof NumberSetting) {
                    ((NumberSetting)set).setValueNumber(propertiesObject.get(set.getName()).getAsFloat());
                    continue;
                }
                if (!(set instanceof ColorSetting)) continue;
                ((ColorSetting)set).setColorValue(propertiesObject.get(set.getName()).getAsInt());
            }
        }
    }

    public void onEnable() {
        EventManager.register(this);
        if (!this.getLabel().contains("ClickGui") && Main.instance.featureDirector.getFeatureByClass(ModuleSoundAlert.class).isToggled()) {
            nh.U().a(cgn.a(qd.dI, 1.0f));
        }
    }

    public ScreenHelper getScreenHelper() {
        return this.screenHelper;
    }

    public void onDisable() {
        EventManager.unregister(this);
        if (!this.getLabel().contains("ClickGui") && Main.instance.featureDirector.getFeatureByClass(ModuleSoundAlert.class).isToggled()) {
            nh.U().a(cgn.a(qd.dI, 1.0f));
        }
    }

    public boolean isVisible() {
        return this.visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public boolean isHidden() {
        return !this.visible;
    }

    public void setHidden(boolean visible) {
        this.visible = !visible;
    }

    public void setEnabled(boolean enabled) {
        if (enabled) {
            EventManager.register(this);
        } else {
            EventManager.unregister(this);
        }
        this.toggled = enabled;
    }

    public void onToggle() {
    }

    public void toggle() {
        this.toggled = !this.toggled;
        this.onToggle();
        if (this.toggled) {
            NotificationManager.addNotificationToQueue(new Notification("Module toggled", this.getLabel() + " was \u00a7aEnabled!", NotificationType.SUCCESS));
            this.onEnable();
        } else {
            NotificationManager.addNotificationToQueue(new Notification("Module toggled", this.getLabel() + " was \u00a7cDisabled!", NotificationType.SUCCESS));
            this.onDisable();
        }
    }

    public String getLabel() {
        return this.label;
    }

    public void setLabel(String name) {
        this.label = name;
    }

    public String getDesc() {
        return this.desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getKey() {
        return this.key;
    }

    public void setKey(int key) {
        this.key = key;
    }

    public int getBind() {
        return this.bind;
    }

    public void setBind(int bind) {
        this.bind = bind;
    }

    public Category getCategory() {
        return this.category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public boolean isToggled() {
        return this.toggled;
    }

    public String getSuffix() {
        return this.suffix;
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }

    public String getModuleName() {
        return this.moduleName == null ? this.label : this.moduleName;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    public void setup() {
    }

    public static double deltaTime() {
        double d2;
        bhz.z();
        if (bhz.af() > 0) {
            bhz.z();
            d2 = 1.0 / (double)bhz.af();
        } else {
            d2 = 1.0;
        }
        return d2;
    }

    public Translate getTranslate() {
        return this.translate;
    }
}

