/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.lwjgl.BufferUtils
 *  org.lwjgl.opengl.Display
 *  org.lwjgl.opengl.GL11
 */
package top.nhprem.client.features.impl.visuals;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;
import top.nhprem.Main;
import top.nhprem.api.event.EventTarget;
import top.nhprem.api.event.event.Event3D;
import top.nhprem.api.event.event.EventNameTags;
import top.nhprem.api.event.event.EventRender2D;
import top.nhprem.api.utils.math.MathematicHelper;
import top.nhprem.api.utils.render.ClientHelper;
import top.nhprem.api.utils.render.DrawHelper;
import top.nhprem.api.utils.render.PaletteHelper;
import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;
import top.nhprem.client.features.impl.visuals.CustomModel;
import top.nhprem.client.features.impl.visuals.NameProtect;
import top.nhprem.client.ui.settings.impl.BooleanSetting;
import top.nhprem.client.ui.settings.impl.ListSetting;
import top.nhprem.client.ui.settings.impl.NumberSetting;

public class NameTags
extends Feature {
    public static Map<vn, double[]> entityPositions = new HashMap<vn, double[]>();
    public ListSetting fontMode;
    public BooleanSetting armor;
    public BooleanSetting potion;
    public BooleanSetting backGround;
    public ListSetting backGroundMode = new ListSetting("Background Mode", "Default", () -> true, "Default", "Shader");
    public BooleanSetting offHand;
    public BooleanSetting noNPC;
    public NumberSetting opacity;
    public NumberSetting size;
    public ListSetting hpMode;
    boolean bl = false;

    public NameTags() {
        super("NameTags", "\u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0435\u0442 \u0438\u0433\u0440\u043e\u043a\u043e\u0432, \u043d\u0438\u043a, \u0431\u0440\u043e\u043d\u044e \u0438 \u0438\u0445 \u0437\u0434\u043e\u0440\u043e\u0432\u044c\u0435 \u0441\u043a\u0432\u043e\u0437\u044c \u0441\u0442\u0435\u043d\u044b", 0, Category.VISUALS);
        this.fontMode = new ListSetting("Font Mode", "Minecraft", () -> true, "Client", "Minecraft");
        this.hpMode = new ListSetting("Health Mode", "HP", () -> true, "HP", "Percentage");
        this.size = new NumberSetting("NameTags Size", 1.0f, 0.5f, 2.0f, 0.1f, () -> true);
        this.backGround = new BooleanSetting("NameTags Background", true, () -> true);
        this.opacity = new NumberSetting("Background Opacity", 150.0f, 0.0f, 255.0f, 5.0f, () -> this.backGround.getCurrentValue());
        this.offHand = new BooleanSetting("OffHand Render", true, () -> true);
        this.armor = new BooleanSetting("Show Armor", true, () -> true);
        this.potion = new BooleanSetting("Show Potions", true, () -> true);
        this.noNPC = new BooleanSetting("No NPC", false, () -> true);
        this.addSettings(this.fontMode, this.hpMode, this.noNPC, this.size, this.backGround, this.backGroundMode, this.opacity, this.offHand, this.armor, this.potion);
    }

    public static a getHealthColor(float f2) {
        if (f2 <= 4.0f) {
            return a.m;
        }
        if (f2 <= 8.0f) {
            return a.g;
        }
        if (f2 <= 12.0f) {
            return a.o;
        }
        if (f2 <= 16.0f) {
            return a.c;
        }
        return a.k;
    }

    @EventTarget
    public void onRender3D(Event3D eventRender3D) {
        this.updatePositions();
    }

    @EventTarget
    public void onNickRemove(EventNameTags event) {
        if (this.isToggled()) {
            event.setCancelled(true);
        }
    }

    @EventTarget
    public void onRender2D(EventRender2D eventRender2D) {
        bir scaledResolution = new bir(mc);
        buq.G();
        for (vn entityLivingBase : entityPositions.keySet()) {
            if (entityLivingBase == null || entityLivingBase == NameTags.mc.h || entityLivingBase.h_().startsWith("npc") && this.noNPC.getCurrentValue()) continue;
            buq.G();
            if (entityLivingBase instanceof aeb) {
                int n2;
                double[] dArray = entityPositions.get(entityLivingBase);
                if (dArray[3] < 0.0 || dArray[3] >= 1.0) {
                    buq.H();
                    continue;
                }
                double d2 = bir.e();
                buq.b(dArray[0] / d2, dArray[1] / d2 + (double)(Main.instance.featureDirector.getFeatureByClass(CustomModel.class).isToggled() && (CustomModel.modelMode.currentMode.equals("Crab") || CustomModel.modelMode.currentMode.equals("Chni") || CustomModel.modelMode.currentMode.equals("Red Panda")) && !CustomModel.onlyMe.getCurrentValue() ? 20 : 0), 0.0);
                this.scale();
                String string = Main.instance.featureDirector.getFeatureByClass(NameProtect.class).isToggled() && NameProtect.otherNames.getCurrentValue() ? "Protected" : (Main.instance.friendManager.isFriend(entityLivingBase.h_()) ? (Main.instance.featureDirector.getFeatureByClass(NameProtect.class).isToggled() && NameProtect.friendNames.getCurrentValue() ? "Protected" : (Object)((Object)ChatFormatting.GREEN) + "[F] " + (Object)((Object)ChatFormatting.RESET) + entityLivingBase.i_().c()) : entityLivingBase.i_().c());
                String string2 = this.hpMode.currentMode.equals("Percentage") ? MathematicHelper.round(entityLivingBase.cd() / entityLivingBase.cj() * 100.0f, 1) + "% " : MathematicHelper.round(entityLivingBase.cd(), 1) + " ";
                String string3 = "" + string2;
                float f2 = this.fontMode.currentMode.equals("Minecraft") ? (float)(bhz.k.a(string3 + " " + string) + 4) : (float)(ClientHelper.getFontRender().getStringWidth(string3 + " " + string) + 5);
                buq.b(0.0, -10.0, 0.0);
                if (this.backGround.getCurrentValue()) {
                    if (this.backGroundMode.currentMode.equals("Default")) {
                        DrawHelper.drawRect(-f2 / 2.0f, -10.0, f2 / 2.0f, 2.0, PaletteHelper.getColor(0, (int)this.opacity.getCurrentValue()));
                    } else if (this.backGroundMode.currentMode.equals("Shader")) {
                        DrawHelper.renderBlurredShadow(new Color(0, 0, 0, (int)this.opacity.getCurrentValue()), (double)(-f2 / 2.0f - 2.0f), -10.0, (double)(f2 + 3.0f), 11.0, 20);
                    }
                }
                if (this.fontMode.currentMode.equals("Minecraft")) {
                    bhz.k.a(string + " " + (Object)((Object)NameTags.getHealthColor(entityLivingBase.cd())) + string3, -f2 / 2.0f + 2.0f, -7.5f, -1);
                } else {
                    ClientHelper.getFontRender().drawStringWithShadow(string + " " + (Object)((Object)NameTags.getHealthColor(entityLivingBase.cd())) + string3, -f2 / 2.0f + 2.0f, -7.5, -1);
                }
                ain itemStack = entityLivingBase.b(tz.b);
                ArrayList<ain> arrayList = new ArrayList<ain>();
                for (n2 = 0; n2 < 5; ++n2) {
                    ain itemStack2 = ((aeb)entityLivingBase).getEquipmentInSlot(n2);
                    arrayList.add(itemStack2);
                }
                n2 = -(arrayList.size() * 9) - 8;
                if (this.armor.getCurrentValue()) {
                    buq.G();
                    buq.c(0.0f, -2.0f, 0.0f);
                    if (this.offHand.getCurrentValue()) {
                        if (this.fontMode.currentMode.equals("Minecraft")) {
                            mc.ad().a(itemStack, n2 + 86, -28);
                            mc.ad().a(bhz.k, itemStack, n2 + 86, -28);
                        } else {
                            mc.ad().a(itemStack, n2 + 86, -28);
                            mc.ad().a(bhz.k, itemStack, n2 + 86, -28);
                        }
                    }
                    for (ain itemStack3 : arrayList) {
                        int n22;
                        int n3;
                        int n4;
                        bhx.c();
                        mc.ad().a(itemStack3, n2 + 6, -28);
                        if (this.fontMode.currentMode.equals("Minecraft")) {
                            mc.ad().a(bhz.k, itemStack3, n2 + 5, -28);
                        } else {
                            mc.ad().a(bhz.k, itemStack3, n2 + 5, -28);
                        }
                        n2 += 3;
                        bhx.a();
                        int n5 = 7;
                        int n6 = alk.a(Objects.requireNonNull(ali.c(16)), itemStack3);
                        int n7 = alk.a(Objects.requireNonNull(ali.c(20)), itemStack3);
                        int n8 = alk.a(Objects.requireNonNull(ali.c(19)), itemStack3);
                        if (n6 > 0) {
                            this.drawEnchantTag("S" + this.getColor(n6) + n6, n2, n5);
                            n5 += 8;
                        }
                        if (n7 > 0) {
                            this.drawEnchantTag("F" + this.getColor(n7) + n7, n2, n5);
                            n5 += 8;
                        }
                        if (n8 > 0) {
                            this.drawEnchantTag("Kb" + this.getColor(n8) + n8, n2, n5);
                        } else if (itemStack3.c() instanceof agt) {
                            n4 = alk.a(Objects.requireNonNull(ali.c(0)), itemStack3);
                            n3 = alk.a(Objects.requireNonNull(ali.c(7)), itemStack3);
                            n22 = alk.a(Objects.requireNonNull(ali.c(34)), itemStack3);
                            if (n4 > 0) {
                                this.drawEnchantTag("P" + this.getColor(n4) + n4, n2, n5);
                                n5 += 8;
                            }
                            if (n3 > 0) {
                                this.drawEnchantTag("Th" + this.getColor(n3) + n3, n2, n5);
                                n5 += 8;
                            }
                            if (n22 > 0) {
                                this.drawEnchantTag("U" + this.getColor(n22) + n22, n2, n5);
                            }
                        } else if (itemStack3.c() instanceof ahe) {
                            n4 = alk.a(Objects.requireNonNull(ali.c(48)), itemStack3);
                            n3 = alk.a(Objects.requireNonNull(ali.c(49)), itemStack3);
                            n22 = alk.a(Objects.requireNonNull(ali.c(50)), itemStack3);
                            if (n4 > 0) {
                                this.drawEnchantTag("P" + this.getColor(n4) + n4, n2, n5);
                                n5 += 8;
                            }
                            if (n3 > 0) {
                                this.drawEnchantTag("P" + this.getColor(n3) + n3, n2, n5);
                                n5 += 8;
                            }
                            if (n22 > 0) {
                                this.drawEnchantTag("F" + this.getColor(n22) + n22, n2, n5);
                            }
                        }
                        n2 = (int)((double)n2 + 13.5);
                    }
                    buq.H();
                }
                if (this.potion.getCurrentValue()) {
                    this.drawPotionEffect((aeb)entityLivingBase);
                }
            }
            buq.H();
        }
        buq.H();
        buq.m();
    }

    private void drawPotionEffect(aeb entityPlayer) {
        int n2 = -25;
        if (entityPlayer.cg() > 0 || !entityPlayer.co().isEmpty() && !entityPlayer.cp().isEmpty()) {
            n2 -= 37;
        }
        for (uy potionEffect : entityPlayer.ca()) {
            float f2;
            ux potion = potionEffect.a();
            boolean bl2 = (double)potionEffect.b() != 0.0;
            String string = "";
            if (!entityPlayer.a(potion) || !bl2) continue;
            if (potionEffect.c() == 1) {
                string = "II";
            } else if (potionEffect.c() == 2) {
                string = "III";
            } else if (potionEffect.c() == 3) {
                string = "IV";
            }
            buq.G();
            buq.c(1.0f, 1.0f, 1.0f, 1.0f);
            float f3 = this.fontMode.currentMode.equals("Minecraft") ? (float)bhz.k.a(cew.a(potion.a(), new Object[0]) + " " + string + (Object)((Object)a.h) + " " + ux.getDurationString(potionEffect)) / 2.0f : (f2 = (float)ClientHelper.getFontRender().getStringWidth(cew.a(potion.a(), new Object[0]) + " " + string + (Object)((Object)a.h) + " " + ux.getDurationString(potionEffect)) / 2.0f);
            if (this.fontMode.currentMode.equals("Minecraft")) {
                bhz.k.a(cew.a(potion.a(), new Object[0]) + " " + string + (Object)((Object)a.h) + " " + ux.getDurationString(potionEffect), f2, n2, -1);
            } else if (this.fontMode.currentMode.equals("Client")) {
                ClientHelper.getFontRender().drawStringWithShadow(cew.a(potion.a(), new Object[0]) + " " + string + (Object)((Object)a.h) + " " + ux.getDurationString(potionEffect), f2, n2, -1);
            }
            n2 -= 10;
            buq.H();
        }
    }

    private void drawEnchantTag(String string, int n2, int n22) {
        buq.G();
        buq.j();
        n22 -= 7;
        if (this.fontMode.currentMode.equals("Minecraft")) {
            bhz.k.a(string, n2 + 6, -35 - n22, -1);
        } else {
            ClientHelper.getFontRender().drawStringWithShadow(string, n2 + 6, -35 - n22, -1);
        }
        buq.k();
        buq.H();
    }

    private String getColor(int n2) {
        if (n2 != 1) {
            if (n2 == 2) {
                return "";
            }
            if (n2 == 3) {
                return "";
            }
            if (n2 == 4) {
                return "";
            }
            if (n2 >= 5) {
                return "";
            }
        }
        return "";
    }

    private void updatePositions() {
        entityPositions.clear();
        float f2 = NameTags.mc.Y.renderPartialTicks;
        for (ve entity : NameTags.mc.f.e) {
            double d2;
            if (entity == null || entity == NameTags.mc.h || !(entity instanceof aeb)) continue;
            double d3 = entity.M + (entity.p - entity.M) * (double)f2;
            mc.ac();
            double d4 = d3 - bzd.h;
            double d5 = entity.N + (entity.q - entity.N) * (double)f2;
            mc.ac();
            double d22 = d5 - bzd.i;
            double d6 = entity.O + (entity.r - entity.O) * (double)f2;
            mc.ac();
            double d32 = d6 - bzd.j;
            if (!(Objects.requireNonNull(this.convertTo2D(d4, d2, d32))[2] >= 0.0) || !(Objects.requireNonNull(this.convertTo2D(d4, d22 += (double)entity.H + 0.2, d32))[2] < 2.0)) continue;
            entityPositions.put((aeb)entity, new double[]{Objects.requireNonNull(this.convertTo2D(d4, d22, d32))[0], Objects.requireNonNull(this.convertTo2D(d4, d22, d32))[1], Math.abs(Objects.requireNonNull(this.convertTo2D(d4, d22 + 1.0, d32))[1] - Objects.requireNonNull(this.convertTo2D(d4, d22, d32))[1]), Objects.requireNonNull(this.convertTo2D(d4, d22, d32))[2]});
        }
    }

    private double[] convertTo2D(double d2, double d22, double d3) {
        FloatBuffer floatBuffer = BufferUtils.createFloatBuffer((int)3);
        IntBuffer intBuffer = BufferUtils.createIntBuffer((int)16);
        FloatBuffer floatBuffer2 = BufferUtils.createFloatBuffer((int)16);
        FloatBuffer floatBuffer3 = BufferUtils.createFloatBuffer((int)16);
        GL11.glGetFloat((int)2982, (FloatBuffer)floatBuffer2);
        GL11.glGetFloat((int)2983, (FloatBuffer)floatBuffer3);
        GL11.glGetInteger((int)2978, (IntBuffer)intBuffer);
        boolean bl2 = GLU.gluProject((float)d2, (float)d22, (float)d3, floatBuffer2, floatBuffer3, intBuffer, floatBuffer);
        if (bl2) {
            return new double[]{floatBuffer.get(0), (float)Display.getHeight() - floatBuffer.get(1), floatBuffer.get(2)};
        }
        return null;
    }

    private void scale() {
        float f2 = NameTags.mc.t.aB ? 2.0f : this.size.getCurrentValue();
        buq.b(f2, f2, f2);
    }
}

