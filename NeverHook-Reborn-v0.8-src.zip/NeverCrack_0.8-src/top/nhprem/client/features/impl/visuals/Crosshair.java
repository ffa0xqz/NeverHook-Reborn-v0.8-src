/*
 * Decompiled with CFR 0.150.
 */
package top.nhprem.client.features.impl.visuals;

import java.awt.Color;
import top.nhprem.api.event.EventTarget;
import top.nhprem.api.event.event.EventRender2D;
import top.nhprem.api.utils.combat.MovementHelper;
import top.nhprem.api.utils.render.AnimationHelper;
import top.nhprem.api.utils.render.DrawHelper;
import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;
import top.nhprem.client.ui.settings.impl.BooleanSetting;
import top.nhprem.client.ui.settings.impl.ColorSetting;
import top.nhprem.client.ui.settings.impl.ListSetting;
import top.nhprem.client.ui.settings.impl.NumberSetting;

public class Crosshair
extends Feature {
    public static ColorSetting colorGlobal;
    public static ListSetting crosshairMode;
    public BooleanSetting dynamic;
    public NumberSetting width;
    public NumberSetting gap;
    public NumberSetting length;
    public NumberSetting dynamicGap;
    private double cooldownBarWidth;
    private float barWidth;

    public Crosshair() {
        super("Crosshair", "\u0418\u0437\u043c\u0435\u043d\u044f\u0435\u0442 \u0432\u0430\u0448\u0435 \u0437\u0440\u0435\u043d\u0438\u0435", 0, Category.VISUALS);
        crosshairMode = new ListSetting("Crosshair Mode", "Smooth", () -> true, "Smooth", "Border", "Rect", "Nursultan");
        this.dynamic = new BooleanSetting("Dynamic", false, () -> true);
        this.dynamicGap = new NumberSetting("Dynamic Gap", 3.0f, 1.0f, 20.0f, 1.0f, this.dynamic::getBoolValue);
        this.gap = new NumberSetting("Gap", 2.0f, 0.0f, 10.0f, 0.1f, () -> true);
        colorGlobal = new ColorSetting("Crosshair Color", new Color(0xFFFFFF).getRGB(), () -> true);
        this.width = new NumberSetting("Width", 1.0f, 0.0f, 8.0f, 1.0f, () -> true);
        this.length = new NumberSetting("Length", 3.0f, 0.5f, 30.0f, 1.0f, () -> true);
        this.addSettings(crosshairMode, this.dynamic, this.dynamicGap, this.gap, colorGlobal, this.width, this.length);
    }

    @EventTarget
    public void onRender2D(EventRender2D event) {
        bir sr2 = event.getResolution();
        double cooldownPercentage = ri.a((double)Crosshair.mc.h.n(1.0f), 0.0, 1.0);
        double cooldownWidth = 357.0 * cooldownPercentage;
        this.cooldownBarWidth = AnimationHelper.animate(cooldownWidth, this.cooldownBarWidth, 0.0529999);
        int crosshairColor = colorGlobal.getColorValue();
        float screenWidth = event.getResolution().a();
        float screenHeight = event.getResolution().b();
        float width = screenWidth / 2.0f;
        float height = screenHeight / 2.0f;
        boolean dyn = this.dynamic.getBoolValue();
        float dyngap = this.dynamicGap.getNumberValue();
        float wid = this.width.getNumberValue();
        float len = this.length.getNumberValue();
        boolean isMoving = dyn && MovementHelper.isMoving();
        float gaps = isMoving ? dyngap : this.gap.getNumberValue();
        String mode = crosshairMode.getOptions();
        this.setSuffix(mode);
        if (mode.equalsIgnoreCase("Smooth")) {
            DrawHelper.drawSmoothRect(width - gaps - len, height - wid / 2.0f, width - gaps, height + wid / 2.0f, crosshairColor);
            DrawHelper.drawSmoothRect(width + gaps, height - wid / 2.0f, width + gaps + len, height + wid / 2.0f, crosshairColor);
            DrawHelper.drawSmoothRect(width - wid / 2.0f, height - gaps - len, width + wid / 2.0f, height - gaps, crosshairColor);
            DrawHelper.drawSmoothRect(width - wid / 2.0f, height + gaps, width + wid / 2.0f, height + gaps + len, crosshairColor);
        } else if (mode.equalsIgnoreCase("Border")) {
            DrawHelper.drawBorderedRect(width - gaps - len, height - wid / 2.0f, width - gaps, height + wid / 2.0f, 0.5, Color.WHITE.getRGB(), crosshairColor, true);
            DrawHelper.drawBorderedRect(width + gaps, height - wid / 2.0f, width + gaps + len, height + wid / 2.0f, 0.5, Color.WHITE.getRGB(), crosshairColor, true);
            DrawHelper.drawBorderedRect(width - wid / 2.0f, height - gaps - len, width + wid / 2.0f, height - gaps, 0.5, Color.WHITE.getRGB(), crosshairColor, true);
            DrawHelper.drawBorderedRect(width - wid / 2.0f, height + gaps, width + wid / 2.0f, height + gaps + len, 0.5, Color.WHITE.getRGB(), crosshairColor, true);
        } else if (mode.equalsIgnoreCase("Rect")) {
            DrawHelper.drawRect(width - gaps - len, height - wid / 2.0f, width - gaps, height + wid / 2.0f, crosshairColor);
            DrawHelper.drawRect(width + gaps, height - wid / 2.0f, width + gaps + len, height + wid / 2.0f, crosshairColor);
            DrawHelper.drawRect(width - wid / 2.0f, height - gaps - len, width + wid / 2.0f, height - gaps, crosshairColor);
            DrawHelper.drawRect(width - wid / 2.0f, height + gaps, width + wid / 2.0f, height + gaps + len, crosshairColor);
        } else if (mode.equalsIgnoreCase("Nursultan")) {
            float coef = Crosshair.mc.h.aD / 0.8333333f;
            float valueWidth = 360.0f * coef;
            this.barWidth = (float)AnimationHelper.animate(valueWidth, this.barWidth, 0.1529999);
            DrawHelper.drawCircle(sr2.a() / 2, sr2.b() / 2, 0.0f, 360.0f, 4.0f, 4.0f, Color.GRAY);
            DrawHelper.drawCircle(sr2.a() / 2, sr2.b() / 2, 0.0f, (float)this.cooldownBarWidth, 4.0f, 4.0f, Color.WHITE);
        }
    }
}

