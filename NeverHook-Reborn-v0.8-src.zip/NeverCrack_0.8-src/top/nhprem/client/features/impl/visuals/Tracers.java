/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 */
package top.nhprem.client.features.impl.visuals;

import org.lwjgl.opengl.GL11;
import top.nhprem.Main;
import top.nhprem.api.event.EventTarget;
import top.nhprem.api.event.event.Event3D;
import top.nhprem.api.utils.render.DrawHelper;
import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;

public class Tracers
extends Feature {
    public Tracers() {
        super("Tracers", "Draws lines that go to entity", 0, Category.VISUALS);
    }

    @EventTarget
    public void onEvent3D(Event3D event) {
        boolean old = Tracers.mc.t.f;
        Tracers.mc.t.f = false;
        Tracers.mc.o.a(event.getPartialTicks(), 2);
        Tracers.mc.t.f = old;
        GL11.glPushMatrix();
        GL11.glEnable((int)2848);
        DrawHelper.startSmooth();
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2896);
        GL11.glBlendFunc((int)770, (int)771);
        DrawHelper.enableSmoothLine(0.6f);
        for (ve entity : Tracers.mc.f.e) {
            if (entity == Tracers.mc.h || !(entity instanceof aeb)) continue;
            assert (mc.aa() != null);
            mc.aa().g(entity);
            mc.ac();
            double d2 = entity.M + (entity.p - entity.M) - bzd.h;
            mc.ac();
            double d22 = entity.N + (entity.q - entity.N) - bzd.i;
            mc.ac();
            double d3 = entity.O + (entity.r - entity.O) - bzd.j;
            if (!Main.instance.friendManager.isFriend(entity.h_())) {
                GL11.glColor4f((float)255.0f, (float)255.0f, (float)255.0f, (float)255.0f);
            } else {
                GL11.glColor4f((float)0.0f, (float)255.0f, (float)0.0f, (float)255.0f);
            }
            buq.I();
            bhc vec3d = new bhc(0.0, 0.0, 1.0);
            vec3d = vec3d.a(-((float)Math.toRadians(Tracers.mc.h.w)));
            bhc vec3d2 = vec3d.b(-((float)Math.toRadians(Tracers.mc.h.v)));
            GL11.glBegin((int)2);
            GL11.glVertex3d((double)vec3d2.b, (double)((double)Tracers.mc.h.by() + vec3d2.c), (double)vec3d2.d);
            GL11.glVertex3d((double)d2, (double)(d22 + 1.1), (double)d3);
            GL11.glEnd();
        }
        DrawHelper.endSmooth();
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        DrawHelper.disableSmoothLine();
        GL11.glPopMatrix();
    }
}

