/*
 * Decompiled with CFR 0.150.
 */
package top.nhprem.client.features.impl.visuals;

import top.nhprem.api.event.EventTarget;
import top.nhprem.api.event.event.EventUpdate;
import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;

public class FullBright
extends Feature {
    private float oldBrightness;

    public FullBright() {
        super("FullBright", "Changes the gamut", 0, Category.VISUALS);
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        FullBright.mc.t.aE = 10.0f;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        this.oldBrightness = FullBright.mc.t.aE;
    }

    @Override
    public void onDisable() {
        FullBright.mc.t.aE = this.oldBrightness;
        super.onDisable();
    }
}

