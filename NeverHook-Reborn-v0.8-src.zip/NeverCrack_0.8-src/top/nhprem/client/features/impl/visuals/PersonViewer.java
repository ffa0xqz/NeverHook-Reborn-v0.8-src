/*
 * Decompiled with CFR 0.150.
 */
package top.nhprem.client.features.impl.visuals;

import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;
import top.nhprem.client.ui.settings.impl.NumberSetting;

public class PersonViewer
extends Feature {
    public static NumberSetting viewerYaw;
    public static NumberSetting fovModifier;
    public static NumberSetting viewerPitch;

    public PersonViewer() {
        super("PersonViewer", "\u0423\u043c\u0435\u0435\u0442 \u043c\u0435\u043d\u044f\u0442\u044c \u043f\u043e\u043b\u043e\u0436\u0435\u043d\u0438\u0435 \u043a\u0430\u043c\u0435\u0440\u044b \u043e\u0442 \u0432\u0442\u043e\u0440\u043e\u0433\u043e \u0438 \u0442\u0440\u0435\u0442\u044c\u0435\u0433\u043e \u043b\u0438\u0446\u0430", 0, Category.VISUALS);
        fovModifier = new NumberSetting("FOV Modifier", 4.0f, 1.0f, 50.0f, 1.0f, () -> true);
        viewerYaw = new NumberSetting("Viewer Yaw", 10.0f, -50.0f, 50.0f, 5.0f, () -> true);
        viewerPitch = new NumberSetting("Viewer Pitch", 10.0f, -50.0f, 50.0f, 5.0f, () -> true);
        this.addSettings(fovModifier, viewerYaw, viewerPitch);
    }
}

