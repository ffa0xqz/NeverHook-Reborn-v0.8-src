/*
 * Decompiled with CFR 0.150.
 */
package top.nhprem.client.features.impl.visuals;

import java.awt.Color;
import top.nhprem.Main;
import top.nhprem.api.event.EventTarget;
import top.nhprem.api.event.event.Event2D;
import top.nhprem.api.event.event.EventUpdateLiving;
import top.nhprem.api.guis.draggable.component.impl.DraggableGAppleTimer;
import top.nhprem.api.utils.render.ClientHelper;
import top.nhprem.api.utils.render.DrawHelper;
import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;
import top.nhprem.client.ui.settings.impl.BooleanSetting;
import top.nhprem.client.ui.settings.impl.NumberSetting;

public class GAppleTimer
extends Feature {
    public static NumberSetting Timer;
    public static BooleanSetting suffix;

    public GAppleTimer() {
        super("GAppleTimer", "", 0, Category.DISPLAY);
        Timer = new NumberSetting("time", "", 3.0f, 1.0f, 60.0f, 1.0f, () -> true);
        suffix = new BooleanSetting("display", true, () -> true);
        this.addSettings(Timer, suffix);
    }

    @EventTarget
    public void tupidor(EventUpdateLiving e2) {
        if (GAppleTimer.mc.h.dt().a(aip.ar) && GAppleTimer.mc.h.cJ().c() instanceof aii) {
            GAppleTimer.mc.t.ad.i = false;
        }
    }

    @EventTarget
    public void onNergda(Event2D e2) {
        if (suffix.getBoolValue()) {
            DraggableGAppleTimer dgat = (DraggableGAppleTimer)Main.getInstance().getDraggableHUD().getDraggableComponentByClass(DraggableGAppleTimer.class);
            dgat.setWidth(50);
            dgat.setHeight(50);
            DrawHelper.drawRectWithGlow(dgat.getX(), dgat.getY(), dgat.getX() + dgat.getWidth(), dgat.getY() + dgat.getHeight(), 4.5, 5.0, Color.BLACK);
            DrawHelper.drawCircle(dgat.getX() + 25, dgat.getY() + 25, 0.0f, 360.0f, 20.0f, 3.0f, false, Color.DARK_GRAY);
            if (GAppleTimer.mc.h.dt().a(aip.ar)) {
                float coef = GAppleTimer.mc.h.dt().a(aip.ar, mc.aj()) / 1.0f;
                float end = coef * 360.0f;
                DrawHelper.drawCircle(dgat.getX() + 25, dgat.getY() + 25, 0.0f, end, 20.0f, 3.0f, false, ClientHelper.getClientColor());
            }
            buq.G();
            buq.c((float)(dgat.getX() + 13), (float)(dgat.getY() + 13), 0.0f);
            buq.a(1.5, 1.5, 1.5);
            DrawHelper.renderItem(new ain(aip.ar), 0, 0);
            buq.b(1.0f, 1.0f, 1.0f);
            buq.c((float)(-dgat.getX() + 13), (float)(-dgat.getY() + 13), 0.0f);
            buq.H();
        }
    }
}

