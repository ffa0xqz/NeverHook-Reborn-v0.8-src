/*
 * Decompiled with CFR 0.150.
 */
package top.nhprem.client.features.impl.visuals;

import java.awt.Color;
import top.nhprem.api.event.EventTarget;
import top.nhprem.api.event.event.Event3D;
import top.nhprem.api.utils.render.DrawHelper;
import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;

public class ChestEsp
extends Feature {
    private float oldBrightness;

    public ChestEsp() {
        super("ChestEsp", "Changes the gamut", 0, Category.VISUALS);
    }

    @EventTarget
    public void onRender3D(Event3D event) {
        if (ChestEsp.mc.h != null || ChestEsp.mc.f != null) {
            for (avh entity : ChestEsp.mc.f.g) {
                et pos = entity.w();
                if (!(entity instanceof avj)) continue;
                DrawHelper.blockEsp(pos, new Color(255, 200, 0, 187), false);
            }
        }
    }
}

