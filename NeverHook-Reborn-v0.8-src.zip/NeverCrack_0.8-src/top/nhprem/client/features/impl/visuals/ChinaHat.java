/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 */
package top.nhprem.client.features.impl.visuals;

import org.lwjgl.opengl.GL11;
import top.nhprem.api.event.EventTarget;
import top.nhprem.api.event.event.Event3D;
import top.nhprem.api.utils.math.MathHelper;
import top.nhprem.api.utils.render.ClientHelper;
import top.nhprem.api.utils.render.DrawHelper;
import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;
import top.nhprem.client.ui.settings.impl.BooleanSetting;
import top.nhprem.client.ui.settings.impl.NumberSetting;

public class ChinaHat
extends Feature {
    public static NumberSetting alpha;
    public static BooleanSetting firstPerson;

    public ChinaHat() {
        super("ChinaHat", "Kitayoz yaya", 0, Category.VISUALS);
        firstPerson = new BooleanSetting("FirstPerson", "", true, () -> true);
        alpha = new NumberSetting("Alpha", "", 255.0f, 0.0f, 255.0f, 1.0f, () -> true);
        this.addSettings(alpha, firstPerson);
    }

    @EventTarget
    public void asf(Event3D event) {
        int i2;
        if (ChinaHat.mc.h == null || ChinaHat.mc.f == null || ChinaHat.mc.h.aX() || ChinaHat.mc.h.F) {
            return;
        }
        if (!firstPerson.getBoolValue() && ChinaHat.mc.t.aw == 0) {
            return;
        }
        double d2 = ChinaHat.mc.h.M + (ChinaHat.mc.h.p - ChinaHat.mc.h.M) * (double)ChinaHat.mc.Y.renderPartialTicks;
        mc.ac();
        double posX = d2 - bzd.o;
        double d3 = ChinaHat.mc.h.N + (ChinaHat.mc.h.q - ChinaHat.mc.h.N) * (double)ChinaHat.mc.Y.renderPartialTicks;
        mc.ac();
        double posY = d3 - bzd.p;
        double d4 = ChinaHat.mc.h.O + (ChinaHat.mc.h.r - ChinaHat.mc.h.O) * (double)ChinaHat.mc.Y.renderPartialTicks;
        mc.ac();
        double posZ = d4 - bzd.q;
        bgz axisalignedbb = ChinaHat.mc.h.bw();
        double height = axisalignedbb.e - axisalignedbb.b + 0.02;
        double radius = axisalignedbb.d - axisalignedbb.a;
        GL11.glPushMatrix();
        buq.r();
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        GL11.glDisable((int)3553);
        GL11.glShadeModel((int)7425);
        GL11.glEnable((int)3042);
        buq.g();
        buq.c(1.0f, 1.0f, 1.0f, 1.0f);
        cig.c(770, 771, 1, 0);
        float yaw = MathHelper.interpolate(ChinaHat.mc.h.x, ChinaHat.mc.h.v, ChinaHat.mc.Y.renderPartialTicks).floatValue();
        float pitchInterpolate = MathHelper.interpolate(ChinaHat.mc.h.bY, ChinaHat.mc.h.bW, ChinaHat.mc.Y.renderPartialTicks).floatValue();
        GL11.glTranslated((double)posX, (double)posY, (double)posZ);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glRotated((double)yaw, (double)0.0, (double)-1.0, (double)0.0);
        GL11.glRotated((double)((double)pitchInterpolate / 3.0), (double)0.0, (double)0.0, (double)0.0);
        GL11.glTranslatef((float)0.0f, (float)0.0f, (float)(pitchInterpolate / 270.0f));
        GL11.glLineWidth((float)3.0f);
        GL11.glBegin((int)2);
        for (i2 = 0; i2 <= 180; ++i2) {
            buq.c(1.0f, 1.0f, 1.0f, 1.0f);
            DrawHelper.glColor(ClientHelper.getClientColor(), alpha.getNumberValue());
            GL11.glVertex3d((double)(posX - Math.sin((float)i2 * ((float)Math.PI * 2) / 90.0f) * radius), (double)(posY + height - (ChinaHat.mc.h.aU() ? 0.23 : 0.0) - 0.002), (double)(posZ + Math.cos((float)i2 * ((float)Math.PI * 2) / 90.0f) * radius));
        }
        GL11.glEnd();
        GL11.glLineWidth((float)2.0f);
        GL11.glBegin((int)6);
        DrawHelper.glColor(ClientHelper.getClientColor(), alpha.getNumberValue());
        GL11.glVertex3d((double)posX, (double)(posY + height + 0.3 - (ChinaHat.mc.h.aU() ? 0.23 : 0.0)), (double)posZ);
        for (i2 = 0; i2 <= 180; ++i2) {
            buq.c(1.0f, 1.0f, 1.0f, 1.0f);
            DrawHelper.glColor(ClientHelper.getClientColor(), alpha.getNumberValue());
            GL11.glVertex3d((double)(posX - Math.sin((float)i2 * ((float)Math.PI * 2) / 90.0f) * radius), (double)(posY + height - (double)(ChinaHat.mc.h.aU() ? 0.23f : 0.0f)), (double)(posZ + Math.cos((float)i2 * ((float)Math.PI * 2) / 90.0f) * radius));
        }
        GL11.glVertex3d((double)posX, (double)(posY + height + 0.3 - (ChinaHat.mc.h.aU() ? 0.23 : 0.0)), (double)posZ);
        GL11.glEnd();
        GL11.glPopMatrix();
        GL11.glEnable((int)2884);
        GL11.glEnable((int)3553);
        GL11.glShadeModel((int)7424);
        GL11.glDepthMask((boolean)true);
        GL11.glEnable((int)2929);
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }
}

