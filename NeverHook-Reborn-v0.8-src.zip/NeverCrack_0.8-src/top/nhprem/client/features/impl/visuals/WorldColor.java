/*
 * Decompiled with CFR 0.150.
 */
package top.nhprem.client.features.impl.visuals;

import java.awt.Color;
import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;
import top.nhprem.client.ui.settings.impl.ColorSetting;

public class WorldColor
extends Feature {
    public static ColorSetting worldColor = new ColorSetting("World Color", Color.RED.getRGB(), () -> true);

    public WorldColor() {
        super("WorldColor", "\u041c\u0435\u043d\u044f\u0435\u0442 \u0446\u0432\u0435\u0442 \u0438\u0433\u0440\u044b", 0, Category.VISUALS);
        this.addSettings(worldColor);
    }
}

