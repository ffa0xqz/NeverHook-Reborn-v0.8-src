/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.Display
 *  org.lwjgl.opengl.GL11
 */
package top.nhprem.client.features.impl.visuals;

import java.awt.Color;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import top.nhprem.Main;
import top.nhprem.api.event.EventTarget;
import top.nhprem.api.event.event.Event2D;
import top.nhprem.api.utils.math.MathematicHelper;
import top.nhprem.api.utils.render.DrawHelper;
import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;
import top.nhprem.client.features.impl.combat.KillAura;
import top.nhprem.client.ui.settings.impl.BooleanSetting;
import top.nhprem.client.ui.settings.impl.ColorSetting;
import top.nhprem.client.ui.settings.impl.ListSetting;
import top.nhprem.client.ui.settings.impl.NumberSetting;

public class TargetHUD
extends Feature {
    public static ListSetting targetHudMode;
    public static BooleanSetting targetHud;
    public static NumberSetting thudX;
    public static NumberSetting thudY;
    public static ColorSetting targetHudColor;
    vn target = KillAura.target;

    public TargetHUD() {
        super("TargetHUD", "desc", 0, Category.VISUALS);
        targetHudMode = new ListSetting("TargetHud Mode", "NeverHook", () -> true, "NeverHook");
        thudX = new NumberSetting("TargetHud X", 360.0f, -500.0f, 500.0f, 1.0f, () -> true);
        thudY = new NumberSetting("TargetHud Y", 150.0f, -300.0f, 300.0f, 1.0f, () -> true);
        targetHudColor = new ColorSetting("TargetHUD Color", Color.PINK.getRGB(), () -> TargetHUD.targetHudMode.currentMode.equalsIgnoreCase("NeverHook"));
        this.addSettings(targetHudMode, thudX, thudY, targetHudColor);
    }

    @EventTarget
    public void e(Event2D e2) {
        String mode = targetHudMode.getOptions();
        if (this.isToggled() && Main.instance.featureDirector.getFeatureByClass(KillAura.class).isToggled() && mode.equalsIgnoreCase("NeverHook")) {
            float x2 = (float)new bir(mc).a() / 2.0f - thudX.getNumberValue();
            float y2 = (float)new bir(mc).b() / 2.0f + thudY.getNumberValue();
            int color123 = targetHudColor.getColorValue();
            if (this.target != null) {
                float x22 = x2;
                float y22 = y2;
                bli.drawRectxy(x2, y2, 185.0, 50.0, Color.BLACK);
                DrawHelper.drawGlowedRect(x2, y2 - 1.0f, 185.0f, 5.0f, new Color(color123).getRGB(), 1);
                bli.drawRectxy(x2, y2, 185.0, 2.0, new Color(color123));
                if (this.target.bm() != null && mc.v().a(this.target.bm()) != null) {
                    float hurtPercent = TargetHUD.getHurtPercent(this.target);
                    TargetHUD.drawHeadWithWH(mc.v().a(this.target.bm()).g(), x2 + 3.0f + (float)(this.target.ay / 2), y2 + 5.0f + (float)(this.target.ay / 2), 40 - this.target.ay, 40 - this.target.ay);
                }
                TargetHUD.mc.sfui16.drawString(this.target.h_(), x2 + 40.0f + 10.0f, y2 + 5.0f + 2.0f, 0xFFFFFF);
                double coef = 135 / (int)this.target.cj();
                double health = (double)((int)this.target.cd()) * coef;
                bli.drawRectxy(x2 + 50.0f, y2 + 20.0f + 10.0f, health, 5.0, new Color(color123));
                double x21 = health - 5.0;
                String text = MathematicHelper.round(this.target.cd() / this.target.cj() * 100.0f, 1) + "%";
                TargetHUD.mc.elegant_18.drawString(text, (float)((double)(x2 + 33.0f + 2.0f) + x21), (float)((double)(y2 + 18.0f) + 2.5), new Color(color123).getRGB());
                int tX = Display.getWidth() / 2 / (TargetHUD.mc.t.aG == 0 ? 1 : TargetHUD.mc.t.aG);
                int tY = Display.getHeight() / 2 / (TargetHUD.mc.t.aG == 0 ? 1 : TargetHUD.mc.t.aG);
                int rotate = 180;
                DrawHelper.renderItem(this.target.cp(), (int)x2 + 200 - 15, (int)(y2 - 18.0f));
            }
        }
    }

    public static float getHurtPercent(vn hurt) {
        return TargetHUD.getRenderHurtTime(hurt) / 10.0f;
    }

    public static float getRenderHurtTime(vn hurt) {
        return (float)hurt.ay - (hurt.ay != 0 ? TargetHUD.nh.Y.renderPartialTicks : 0.0f);
    }

    public static void drawHeadWithWH(nd skin, double x2, double y2, int w2, int h2) {
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        nh.N().a(skin);
        bip.drawScaledCustomSizeModalRect(x2, y2, 8.0f, 8.0f, 8.0f, 8.0f, w2, h2, 64.0f, 64.0f);
    }
}

