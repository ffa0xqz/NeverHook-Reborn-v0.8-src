/*
 * Decompiled with CFR 0.150.
 */
package top.nhprem.client.features.impl.misc;

import top.nhprem.Main;
import top.nhprem.api.event.EventTarget;
import top.nhprem.api.event.event.EventMouseKey;
import top.nhprem.api.utils.friend.Friend;
import top.nhprem.api.utils.not.Notification;
import top.nhprem.api.utils.not.NotificationManager;
import top.nhprem.api.utils.not.NotificationType;
import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;

public class MCF
extends Feature {
    vn friend;

    public MCF() {
        super("MCF", "\u0434\u043e\u0431\u0430\u0432\u043b\u044f\u0435\u0442 \u0434\u0440\u0443\u0437\u0435\u0439 \u043f\u043e \u043a\u043e\u043b\u0435\u0441\u0443 \u043c\u044b\u0448\u0438", 0, Category.MISC);
    }

    @EventTarget
    public void onMouseEvent(EventMouseKey event) {
        if (event.getKey() == 2 && MCF.mc.i instanceof vn) {
            if (Main.instance.friendManager.getFriends().stream().anyMatch(friend -> friend.getName().equals(MCF.mc.i.h_()))) {
                Main.instance.friendManager.getFriends().remove(Main.instance.friendManager.getFriend(MCF.mc.i.h_()));
                Main.msg((Object)((Object)a.m) + "Removed " + (Object)((Object)a.v) + "'" + MCF.mc.i.h_() + "' as Friend!", true);
                NotificationManager.addNotificationToQueue(new Notification("MCF", "Removed '" + MCF.mc.i.h_() + "' as Friend!", NotificationType.INFO));
            } else {
                Main.instance.friendManager.addFriend(new Friend(MCF.mc.i.h_()));
                Main.msg((Object)((Object)a.k) + "Added " + (Object)((Object)a.v) + "'" + MCF.mc.i.h_() + "' as Friend!", true);
                NotificationManager.addNotificationToQueue(new Notification("MCF", "Added '" + MCF.mc.i.h_() + "' as Friend!", NotificationType.SUCCESS));
            }
        }
    }
}

