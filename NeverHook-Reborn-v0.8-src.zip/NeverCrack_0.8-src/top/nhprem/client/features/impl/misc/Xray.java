/*
 * Decompiled with CFR 0.150.
 */
package top.nhprem.client.features.impl.misc;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import top.nhprem.Main;
import top.nhprem.api.event.EventTarget;
import top.nhprem.api.event.event.Event3D;
import top.nhprem.api.event.event.EventReceivePacket;
import top.nhprem.api.event.event.EventUpdate;
import top.nhprem.api.utils.render.BlockUtils;
import top.nhprem.api.utils.render.DrawHelper;
import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;
import top.nhprem.client.ui.settings.impl.ListSetting;
import top.nhprem.client.ui.settings.impl.NumberSetting;

public class Xray
extends Feature {
    private List<et> blocks = new ArrayList<et>();
    private long max;
    private et current;
    private final List<et> DETECTED_BLOCKS = new ArrayList<et>();
    public static ListSetting xmode;
    public static NumberSetting rangex;

    public Xray() {
        super("Xray", "", 0, Category.MISC);
        xmode = new ListSetting("Mode", "Default", () -> true, "Default");
        rangex = new NumberSetting("Range", 15.0f, 5.0f, 75.0f, 1.0f, () -> true);
        this.addSettings(xmode, rangex);
    }

    @Override
    public void onEnable() {
        String mode = xmode.getOptions();
        if (mode.equalsIgnoreCase("XrayMode")) {
            this.DETECTED_BLOCKS.clear();
            this.blocks.clear();
            for (et block : BlockUtils.getBlocksInDistance((int)rangex.getNumberValue())) {
                if (Xray.mc.f.o(block).u() == aov.a || Xray.mc.f.o(block).u() == aov.b) continue;
                this.blocks.add(block);
            }
            new Thread(() -> {
                for (et block : this.blocks) {
                    if (!this.isToggled()) {
                        return;
                    }
                    this.current = this.current == null ? this.blocks.get(0) : this.blocks.get(this.blocks.indexOf(this.current) + 1);
                    mc.v().a(new lo(lo.a.a, this.current, fa.c));
                    try {
                        Thread.sleep(26L);
                    }
                    catch (InterruptedException e2) {
                        e2.printStackTrace();
                    }
                }
            }).start();
        }
        super.onEnable();
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        this.setSuffix(this.blocks.indexOf(this.current) + " / " + this.blocks.size());
    }

    @EventTarget
    public void onRender(Event3D event) {
        double[] cords;
        Color color;
        aou b2;
        String mode = xmode.getOptions();
        if (mode.equalsIgnoreCase("XrayMode")) {
            for (et block : this.DETECTED_BLOCKS) {
                b2 = Xray.mc.f.o(block).u();
                color = Color.WHITE;
                if (b2 == aov.ag) {
                    color = Color.CYAN;
                } else if (b2 == aov.o) {
                    color = Color.YELLOW;
                } else if (b2 == aov.p) {
                    color = Color.PINK;
                } else if (b2 == aov.aC) {
                    color = Color.RED;
                }
                double[] arrd = new double[3];
                double d2 = block.p();
                mc.ac();
                arrd[0] = d2 - bzd.o;
                double d3 = block.q();
                mc.ac();
                arrd[1] = d3 - bzd.p;
                double d4 = block.r();
                mc.ac();
                arrd[2] = d4 - bzd.q;
                cords = arrd;
                DrawHelper.drawOutline(new bgz(cords[0], cords[1], cords[2], cords[0] + 1.0, cords[1] + 1.0, cords[2] + 1.0), 1.4f, color);
            }
        }
        if (mode.equalsIgnoreCase("Default")) {
            for (et block : BlockUtils.getBlocksInDistance((int)rangex.getNumberValue())) {
                b2 = Xray.mc.f.o(block).u();
                if (!this.isValidBlock(b2)) continue;
                color = Color.WHITE;
                if (b2 == aov.ag) {
                    color = Color.CYAN;
                } else if (b2 == aov.o) {
                    color = Color.YELLOW;
                } else if (b2 == aov.p) {
                    color = Color.PINK;
                } else if (b2 == aov.aC) {
                    color = Color.RED;
                }
                double[] arrd = new double[3];
                double d5 = block.p();
                mc.ac();
                arrd[0] = d5 - bzd.o;
                double d6 = block.q();
                mc.ac();
                arrd[1] = d6 - bzd.p;
                double d7 = block.r();
                mc.ac();
                arrd[2] = d7 - bzd.q;
                cords = arrd;
                DrawHelper.drawOutline(new bgz(cords[0], cords[1], cords[2], cords[0] + 1.0, cords[1] + 1.0, cords[2] + 1.0), 1.7f, color);
            }
        }
    }

    @EventTarget
    public void onPacket(EventReceivePacket event) {
        String mode = xmode.getOptions();
        if (mode.equalsIgnoreCase("XrayMode")) {
            if (event.getPacket() instanceof ij) {
                ij packet = (ij)event.getPacket();
                if (this.isValidBlock(packet.a().u()) && !this.DETECTED_BLOCKS.contains(packet.b())) {
                    this.DETECTED_BLOCKS.add(packet.b());
                    Main.msg("Detected " + packet.a().u().c() + " at " + packet.b().p() + ":" + packet.b().q() + ":" + packet.b().r(), true);
                }
            } else if (event.getPacket() instanceof io) {
                io packet = (io)event.getPacket();
                for (io.a block : packet.a()) {
                    if (!this.isValidBlock(block.c().u()) || this.DETECTED_BLOCKS.contains(block.a())) continue;
                    this.DETECTED_BLOCKS.add(block.a());
                    Main.msg("Detected " + block.c().u().c() + " at " + block.a().p() + ":" + block.a().q() + ":" + block.a().r(), true);
                }
            }
        }
    }

    private boolean isValidBlock(aou block) {
        return block == aov.ag || block == aov.o || block == aov.p || block == aov.aC;
    }
}

