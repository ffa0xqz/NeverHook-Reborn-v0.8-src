/*
 * Decompiled with CFR 0.150.
 */
package top.nhprem.client.features.impl.misc;

import top.nhprem.Main;
import top.nhprem.api.event.EventTarget;
import top.nhprem.api.event.event.EventPreMotionUpdate;
import top.nhprem.api.event.event.EventReceivePacket;
import top.nhprem.api.utils.math.MathematicHelper;
import top.nhprem.api.utils.not.Notification;
import top.nhprem.api.utils.not.NotificationManager;
import top.nhprem.api.utils.not.NotificationType;
import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;

public class PlayerFinder
extends Feature {
    public PlayerFinder() {
        super("PlayerFinder", "", 0, Category.MISC);
    }

    @EventTarget
    public void onFind(EventPreMotionUpdate eventPreMotionUpdate) {
        mc.v().a(new lo(lo.a.a, new et(MathematicHelper.randInt(-50000, 50000), 0, MathematicHelper.randInt(-50000, 50000)), fa.a));
    }

    @EventTarget
    public void onFindReceive(EventReceivePacket eventReceivePacket) {
        ij packetBlockChange = (ij)eventReceivePacket.getPacket();
        if (eventReceivePacket.getPacket() instanceof ij) {
            Main.msg("\u0418\u0433\u0440\u043e\u043a \u0437\u0430\u043c\u0435\u0447\u0435\u043d \u043d\u0430 \u043a\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u0430\u0445 > " + packetBlockChange.b().p() + " " + packetBlockChange.b().q() + " " + packetBlockChange.b().r(), true);
            NotificationManager.addNotificationToQueue(new Notification("Player Tracker", "> " + packetBlockChange.b().p() + " " + packetBlockChange.b().q() + " " + packetBlockChange.b().r(), NotificationType.INFO));
        }
    }
}

