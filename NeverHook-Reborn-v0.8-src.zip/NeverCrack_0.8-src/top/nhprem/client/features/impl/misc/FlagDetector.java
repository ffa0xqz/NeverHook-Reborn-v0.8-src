/*
 * Decompiled with CFR 0.150.
 */
package top.nhprem.client.features.impl.misc;

import top.nhprem.Main;
import top.nhprem.api.event.EventTarget;
import top.nhprem.api.event.event.EventReceivePacket;
import top.nhprem.api.utils.not.Notification;
import top.nhprem.api.utils.not.NotificationManager;
import top.nhprem.api.utils.not.NotificationType;
import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;
import top.nhprem.client.features.impl.combat.KillAura;
import top.nhprem.client.features.impl.movement.Flight;
import top.nhprem.client.features.impl.movement.Jesus;
import top.nhprem.client.features.impl.movement.LongJump;
import top.nhprem.client.features.impl.movement.Speed;
import top.nhprem.client.features.impl.movement.TargetStrafe;
import top.nhprem.client.features.impl.movement.Timer;

public class FlagDetector
extends Feature {
    public FlagDetector() {
        super("FlagDetector", "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u0432\u044b\u043a\u043b\u044e\u0447\u0430\u0435\u0442 \u043c\u043e\u0434\u0443\u043b\u044c \u043f\u0440\u0438 \u043e\u0431\u043d\u0430\u0440\u0443\u0436\u0435\u043d\u0438\u0438", 0, Category.MISC);
    }

    @EventTarget
    public void onReceivePacket(EventReceivePacket event) {
        if (this.isToggled() && event.getPacket() instanceof jp) {
            if (Main.instance.featureDirector.getFeatureByClass(Speed.class).isToggled()) {
                Main.msg("\u0410\u043d\u0442\u0438-\u0427\u0438\u0442 \u0437\u0430\u0434\u0435\u0442\u0435\u043a\u0442\u0438\u043b Speed", true);
                this.featureAlert("Speed");
                Main.instance.featureDirector.getFeatureByClass(Speed.class).toggle();
            } else if (Main.instance.featureDirector.getFeatureByClass(Flight.class).isToggled()) {
                Main.msg("\u0410\u043d\u0442\u0438-\u0427\u0438\u0442 \u0437\u0430\u0434\u0435\u0442\u0435\u043a\u0442\u0438\u043b Flight", true);
                this.featureAlert("Flight");
                Main.instance.featureDirector.getFeatureByClass(Flight.class).toggle();
            } else if (Main.instance.featureDirector.getFeatureByClass(TargetStrafe.class).isToggled() && KillAura.target != null) {
                Main.msg("\u0410\u043d\u0442\u0438-\u0427\u0438\u0442 \u0437\u0430\u0434\u0435\u0442\u0435\u043a\u0442\u0438\u043b TargetStrafe", true);
                this.featureAlert("TargetStrafe");
                Main.instance.featureDirector.getFeatureByClass(TargetStrafe.class).toggle();
            } else if (Main.instance.featureDirector.getFeatureByClass(LongJump.class).isToggled()) {
                Main.msg("\u0410\u043d\u0442\u0438-\u0427\u0438\u0442 \u0437\u0430\u0434\u0435\u0442\u0435\u043a\u0442\u0438\u043b LongJump", true);
                this.featureAlert("LongJump");
                Main.instance.featureDirector.getFeatureByClass(LongJump.class).toggle();
            } else if (Main.instance.featureDirector.getFeatureByClass(Jesus.class).isToggled() && FlagDetector.nh.h.isInLiquid()) {
                Main.msg("\u0410\u043d\u0442\u0438-\u0427\u0438\u0442 \u0437\u0430\u0434\u0435\u0442\u0435\u043a\u0442\u0438\u043b Jesus", true);
                this.featureAlert("Jesus");
                Main.instance.featureDirector.getFeatureByClass(Jesus.class).toggle();
            } else if (Main.instance.featureDirector.getFeatureByClass(Timer.class).isToggled()) {
                Main.msg("\u0410\u043d\u0442\u0438-\u0427\u0438\u0442 \u0437\u0430\u0434\u0435\u0442\u0435\u043a\u0442\u0438\u043b Timer", true);
                this.featureAlert("Timer");
                Main.instance.featureDirector.getFeatureByClass(Timer.class).toggle();
            }
        }
    }

    public void featureAlert(String feature) {
        NotificationManager.addNotificationToQueue(new Notification(feature, "Disabling due to lag back", NotificationType.WARN));
    }
}

