/*
 * Decompiled with CFR 0.150.
 */
package top.nhprem.client.features.impl.misc;

import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;
import top.nhprem.client.ui.settings.impl.BooleanSetting;

public class Optimization
extends Feature {
    public static BooleanSetting cpu;

    public Optimization() {
        super("Optimization", "\u043e\u043f\u0442\u0438\u043c\u0438\u0437\u0430\u0446\u0438\u044f", 0, Category.MISC);
        cpu = new BooleanSetting("CPU", "\u0423\u043c\u0435\u043d\u044c\u0448\u0430\u0435\u0442 \u0444\u043f\u0441 \u043f\u0440\u0438 \u0441\u0432\u0435\u0440\u043d\u0443\u0442\u043e\u0439 \u0438\u0433\u0440\u0435, \u0447\u0442\u043e\u0431\u044b \u044d\u043a\u043e\u043d\u043e\u043c\u0438\u0442\u044c \u0440\u0435\u0441\u0443\u0440\u0441\u044b \u041f\u041a", true, () -> true);
        this.addSettings(cpu);
    }
}

