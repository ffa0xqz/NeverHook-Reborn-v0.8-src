/*
 * Decompiled with CFR 0.150.
 */
package top.nhprem.client.features.impl.misc;

import com.mojang.realmsclient.gui.ChatFormatting;
import top.nhprem.Main;
import top.nhprem.api.event.EventTarget;
import top.nhprem.api.event.event.EventReceivePacket;
import top.nhprem.api.event.event.EventUpdateLiving;
import top.nhprem.api.utils.not.Notification;
import top.nhprem.api.utils.not.NotificationManager;
import top.nhprem.api.utils.not.NotificationType;
import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;

public class StaffAlert
extends Feature {
    private boolean isJoined;

    public StaffAlert() {
        super("StaffAlert", "\u043f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0435\u0442 \u043a\u043e\u0433\u0434\u0430 \u0445\u0435\u043b\u043f\u0435\u0440 \u0437\u0430\u0448\u0435\u043b \u0432 \u0432\u0430\u043d\u0438\u0448", 0, Category.MISC);
    }

    @EventTarget
    public void onReceivePacket(EventReceivePacket event) {
        jo packetPlayInPlayerListItem;
        if (event.getPacket() instanceof jo && (packetPlayInPlayerListItem = (jo)event.getPacket()).b() == jo.a.c) {
            this.isJoined = true;
        }
    }

    @EventTarget
    public void onUpdate(EventUpdateLiving event) {
        for (aeb staffPlayer : bjo.getPlayers()) {
            if (staffPlayer == null || staffPlayer == StaffAlert.mc.h || !staffPlayer.i_().c().contains("HELPER") && !staffPlayer.i_().c().contains("SHELPER-1") && !staffPlayer.i_().c().contains("SHELPER") && !staffPlayer.i_().c().contains("SHELPER-2") && !staffPlayer.i_().c().contains("MODER") && !staffPlayer.i_().c().contains("J.MODER") || staffPlayer.T >= 10 || !this.isJoined) continue;
            Main.msg((Object)((Object)ChatFormatting.RED) + "Staff " + (Object)((Object)ChatFormatting.UNDERLINE) + staffPlayer.h_() + (Object)((Object)ChatFormatting.WHITE) + " was connected to server, or teleported!", true);
            NotificationManager.addNotificationToQueue(new Notification("Staff Alert", (Object)((Object)ChatFormatting.RED) + "Staff " + (Object)((Object)ChatFormatting.UNDERLINE) + staffPlayer.h_() + (Object)((Object)ChatFormatting.WHITE) + " was connected to server, or teleported!", NotificationType.SUCCESS));
            this.isJoined = false;
        }
    }
}

