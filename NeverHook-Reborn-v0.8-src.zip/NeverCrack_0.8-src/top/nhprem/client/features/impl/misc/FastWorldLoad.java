/*
 * Decompiled with CFR 0.150.
 */
package top.nhprem.client.features.impl.misc;

import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;

public class FastWorldLoad
extends Feature {
    public FastWorldLoad() {
        super("FastWorldLoad", "\u0431\u044b\u0441\u0442\u0440\u043e \u043b\u043e\u0430\u0434\u0438\u0442 \u043c\u0438\u0440\u042b", 0, Category.MISC);
    }
}

