/*
 * Decompiled with CFR 0.150.
 */
package top.nhprem.client.features.impl.misc;

import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;

public class ModuleSoundAlert
extends Feature {
    public ModuleSoundAlert() {
        super("ModuleSound", "\u0437\u0432\u0443\u043a \u043a\u043e\u0433\u0434\u0430 \u0432\u043a\u043b\u044e\u0447\u0435\u043d\u0430 \u0444\u0443\u043d\u043a\u0446\u0438\u044f", 0, Category.MISC);
    }
}

