/*
 * Decompiled with CFR 0.150.
 */
package top.nhprem.client.features.impl.misc;

import com.mojang.realmsclient.util.Pair;
import java.util.ArrayList;
import java.util.List;
import top.nhprem.api.event.EventTarget;
import top.nhprem.api.event.event.EventMotion;
import top.nhprem.api.utils.not.Notification;
import top.nhprem.api.utils.not.NotificationManager;
import top.nhprem.api.utils.not.NotificationType;
import top.nhprem.api.utils.world.TimerHelper;
import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;
import top.nhprem.client.ui.settings.impl.BooleanSetting;

public class HackerDetector
extends Feature {
    public BooleanSetting pingSpoof;
    public BooleanSetting criticals = new BooleanSetting("Criticals", false, () -> true);
    public BooleanSetting invalidPitch = new BooleanSetting("Invalid Pitch", false, () -> true);
    public BooleanSetting noSlow = new BooleanSetting("NoSlow", false, () -> true);
    public BooleanSetting highjump = new BooleanSetting("HighJump", false, () -> true);
    public BooleanSetting omnisprint = new BooleanSetting("OmniSprint", false, () -> true);
    public BooleanSetting longjump = new BooleanSetting("LongJump", false, () -> true);
    public BooleanSetting speed = new BooleanSetting("Speed", false, () -> true);
    public BooleanSetting step = new BooleanSetting("Step", false, () -> true);
    public BooleanSetting velocity = new BooleanSetting("Velocity", false, () -> true);
    public BooleanSetting killaura = new BooleanSetting("Killaura", false, () -> true);
    public BooleanSetting fly = new BooleanSetting("Fly", false, () -> true);
    private final List<Pair<aeb, String>> data = new ArrayList<Pair<aeb, String>>();
    public static final ArrayList<aeb> hackers = new ArrayList();
    private final ArrayList<String> hacker = new ArrayList();
    TimerHelper time = new TimerHelper();
    double motionvlY;
    double speedvl;
    double NoKBvl;
    double auravl;
    double noslowvl;
    public static boolean enabled = false;

    @Override
    public void onEnable() {
        super.onEnable();
        hackers.clear();
        this.data.clear();
        this.hacker.clear();
        enabled = true;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        hackers.clear();
        enabled = false;
    }

    public HackerDetector() {
        super("HackerDetector", "\u043f\u0438\u0448\u0435\u0442 \u0435\u0441\u043b\u0438 \u0447\u0435\u043b \u0447\u0438\u0442\u0435\u0440", 0, Category.MISC);
        this.addSettings(this.pingSpoof, this.criticals, this.invalidPitch, this.noSlow, this.highjump, this.omnisprint, this.longjump, this.speed, this.step, this.velocity, this.killaura, this.fly);
    }

    @EventTarget
    public void onEvent(EventMotion e2) {
        aeb player;
        if (HackerDetector.mc.h.T <= 105) {
            hackers.clear();
            return;
        }
        if (HackerDetector.mc.f == null) {
            return;
        }
        for (ve entity : HackerDetector.mc.f.L()) {
            if (!(entity instanceof aeb)) continue;
            player = null;
            if (entity instanceof buc) {
                player = (buc)entity;
                if (this.time.hasElapsed(1003L)) {
                    this.time.reset();
                }
                if (!((buc)player).isBlocking()) {
                    this.time.reset();
                }
                if (((buc)player).isBlocking() && ((buc)player).isEating() && (double)((buc)player).bf >= 0.9 && this.time.hasElapsed(200L)) {
                    this.informPlayer(player, "No Slow Down");
                }
                if (this.fly.getBoolValue() && ((buc)player).t == 0.0 && this.getSpeed(player) > 0.2775 && HackerDetector.mc.h.T % 2 == 0 && ((buc)player).q - ((buc)player).N > 0.02 && !this.isInLiquid(player)) {
                    this.informPlayer(player, "Flight");
                }
            }
            if ((player = (aeb)entity) instanceof bub || !player.aC() || HackerDetector.mc.c.a() || player.y()) continue;
            if (this.criticals.getBoolValue() && player.L > 0.0f && !this.checkGround(player.q) && player.au == null && (player.q % 1.0 == 0.0 || player.q % 0.5 == 0.0) && (double)player.L < 0.06251) {
                this.informPlayer(player, "Criticals(Invalid Pos)");
                hackers.add(player);
            }
            if (!this.invalidPitch.getBoolValue() || player.w <= 90.0f && player.w >= -90.0f) continue;
            this.informPlayer(player, "Invalid Pitch");
            hackers.add(player);
        }
        for (ve entity : HackerDetector.mc.f.i) {
            double d2;
            double d3;
            player = (aeb)entity;
            if (player instanceof bub || player == HackerDetector.mc.h || player.T < 105 || hackers.contains(player) || player.bO.b || player.bO.d) continue;
            double playerSpeed = HackerDetector.getBPS(player);
            if (this.killaura.getBoolValue() && player.aD < 2.0f && player.aD != 0.0f) {
                float[] rots = HackerDetector.getFacePosEntityRemote(HackerDetector.mc.h, player);
                boolean highYawRate = false;
                if (Math.abs(player.v - player.x) > 40.0f) {
                    highYawRate = true;
                }
                if (Math.abs(player.v - rots[0]) < 2.0f) {
                    if (highYawRate) {
                        this.auravl += 1.0;
                        if (this.auravl >= 30.0) {
                            NotificationManager.addNotificationToQueue(new Notification("Hacker Detected!", "\u00a7f" + player.h_() + "\u00a7f is using Kill Aura", NotificationType.WARN));
                            this.auravl = 0.0;
                            hackers.add(player);
                        }
                    }
                    this.auravl += 1.0;
                    if (this.auravl >= 30.0) {
                        NotificationManager.addNotificationToQueue(new Notification("Hacker Detected!", "\u00a7f" + player.h_() + "\u00a7f is using Kill Aura", NotificationType.WARN));
                        this.auravl = 0.0;
                        hackers.add(player);
                    }
                }
            }
            if (this.noSlow.getBoolValue() && player.isBlocking() && HackerDetector.SpeedBs(player) >= 6.0) {
                this.noslowvl += 1.0;
                if (this.noslowvl >= 30.0) {
                    NotificationManager.addNotificationToQueue(new Notification("Hacker Detected!", "\u00a7f" + player.h_() + "\u00a7f is using No Slow", NotificationType.WARN));
                    this.noslowvl = 0.0;
                    hackers.add(player);
                }
            }
            if (this.highjump.getBoolValue() && player.t > 1.0) {
                this.motionvlY += 1.0;
                if (this.motionvlY >= 25.0) {
                    NotificationManager.addNotificationToQueue(new Notification("Hacker Detected!", "\u00a7f" + player.h_() + "\u00a7f is using High Jump", NotificationType.WARN));
                    this.motionvlY = 0.0;
                    hackers.add(player);
                }
            }
            if (this.omnisprint.getBoolValue() && player.aV() && (player.bf < 0.0f || player.bf == 0.0f && player.be != 0.0f)) {
                NotificationManager.addNotificationToQueue(new Notification("Hacker Detected!", "\u00a7f" + player.h_() + "\u00a7f is using Omni Sprint", NotificationType.WARN));
                hackers.add(player);
            }
            if (this.longjump.getBoolValue() && !HackerDetector.mc.f.a((ve)player, HackerDetector.mc.h.bw().d(0.0, player.t, 0.0)).isEmpty() && player.t > 0.0 && playerSpeed > 10.0) {
                NotificationManager.addNotificationToQueue(new Notification("Hacker Detected!", "\u00a7f" + player.h_() + "\u00a7f is using Long Jump", NotificationType.WARN));
                hackers.add(player);
            }
            double xDif = player.p - player.m;
            double zDif = player.r - player.o;
            double lastDist = Math.sqrt(xDif * xDif + zDif * zDif) * 20.0;
            if (this.speed.getBoolValue() && Math.round(lastDist) > 15L) {
                this.speedvl += 1.0;
                if (this.speedvl >= 150.0) {
                    NotificationManager.addNotificationToQueue(new Notification("Hacker Detected!", "\u00a7f" + player.h_() + "\u00a7f is using Speed", NotificationType.WARN));
                    this.speedvl = 0.0;
                    hackers.add(player);
                }
            }
            double y2 = Math.abs((int)player.q);
            double lastY = Math.abs((int)player.N);
            double d4 = d3 > d2 ? y2 - lastY : lastY - y2;
            double yDiff = d4;
            if (this.step.getBoolValue() && yDiff > 0.0 && HackerDetector.mc.h.z && player.t == -0.0784000015258789) {
                NotificationManager.addNotificationToQueue(new Notification("Hacker Detected!", "\u00a7f" + player.h_() + "\u00a7f is using Step", NotificationType.WARN));
                this.speedvl = 0.0;
                hackers.add(player);
            }
            if (!this.velocity.getBoolValue()) continue;
            if (player.V > 6 && player.V < 12 && player.M == player.p && player.r == player.O && !HackerDetector.mc.f.c(player.bw().c(0.05, 0.0, 0.05))) {
                this.NoKBvl += 1.0;
                if (this.NoKBvl >= 50.0) {
                    NotificationManager.addNotificationToQueue(new Notification("Hacker Detected!", "\u00a7f" + player.h_() + "\u00a7f is using Velocity", NotificationType.WARN));
                    this.NoKBvl = 0.0;
                    hackers.add(player);
                }
            }
            if (player.V <= 6 || player.V >= 12 || player.N != player.q) continue;
            this.NoKBvl += 1.0;
            if (this.NoKBvl < 40.0) continue;
            NotificationManager.addNotificationToQueue(new Notification("Hacker Detected!", "\u00a7f" + player.h_() + "\u00a7f is using Velocity", NotificationType.WARN));
            this.NoKBvl = 0.0;
            hackers.add(player);
        }
    }

    public static boolean isHacker(vn ent) {
        for (aeb hacker : hackers) {
            if (!ent.h_().equals(hacker.h_())) continue;
            return true;
        }
        return false;
    }

    private boolean checkGround(double y2) {
        return y2 % 0.015625 == 0.0;
    }

    private void informPlayer(aeb player, String hakk) {
        for (Pair<aeb, String> pair : this.data) {
            if (pair.first() != player || !pair.second().equalsIgnoreCase(hakk)) continue;
            return;
        }
        NotificationManager.addNotificationToQueue(new Notification("Hacker Detected!", String.format("\u00a7f%s is using %s", player.h_(), hakk, Float.valueOf(player.cd()), Float.valueOf(player.cj())), NotificationType.WARN));
    }

    private double getSpeed(aeb player) {
        return Math.sqrt(player.s * player.s + player.u * player.u);
    }

    private boolean isInLiquid(ve e2) {
        for (int x2 = ri.floor_double(e2.bw().b); x2 < ri.floor_double(e2.bw().d) + 1; ++x2) {
            for (int z2 = ri.floor_double(e2.bw().c); z2 < ri.floor_double(e2.bw().f) + 1; ++z2) {
                et pos = new et(x2, (int)e2.bw().b, z2);
                aou block = bhz.z().f.o(pos).u();
                if (block == null || block instanceof aok) continue;
                return block instanceof ars;
            }
        }
        return false;
    }

    private static float[] getFacePosRemote(bhc src, bhc dest) {
        double diffX = dest.b - src.b;
        double diffY = dest.c - src.c;
        double diffZ = dest.d - src.d;
        double dist = ri.floor_double(diffX * diffX + diffZ * diffZ);
        float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-Math.atan2(diffY, dist) * 180.0 / Math.PI);
        return new float[]{ri.wrapAngleTo180_float(yaw), ri.wrapAngleTo180_float(pitch)};
    }

    public static float sqrt_double(double value) {
        return (float)Math.sqrt(value);
    }

    public static double getBPS(ve entityIn) {
        double xDist = entityIn.p - entityIn.m;
        double zDist = entityIn.r - entityIn.o;
        double bps2 = Math.sqrt(xDist * xDist + zDist * zDist) * 20.0;
        return (double)((int)bps2) + bps2 - (double)((int)bps2);
    }

    public static double SpeedBs(ve entity) {
        double xDif = entity.p - entity.m;
        double zDif = entity.r - entity.o;
        double lastDist = Math.sqrt(xDif * xDif + zDif * zDif) * 20.0;
        return Math.round(lastDist);
    }

    public static float[] getFacePosEntityRemote(vn facing, ve en2) {
        if (en2 == null) {
            return new float[]{facing.aP, facing.w};
        }
        return HackerDetector.getFacePosRemote(new bhc(facing.p, facing.q + (double)en2.by(), facing.r), new bhc(en2.p, en2.q + (double)en2.by(), en2.r));
    }
}

