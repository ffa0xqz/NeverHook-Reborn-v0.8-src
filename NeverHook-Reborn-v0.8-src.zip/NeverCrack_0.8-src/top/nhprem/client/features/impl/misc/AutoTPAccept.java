/*
 * Decompiled with CFR 0.150.
 */
package top.nhprem.client.features.impl.misc;

import java.util.Iterator;
import top.nhprem.Main;
import top.nhprem.api.event.EventTarget;
import top.nhprem.api.event.event.EventReceiveMessage;
import top.nhprem.api.event.event.EventUpdate;
import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;
import top.nhprem.client.ui.settings.impl.BooleanSetting;
import top.nhprem.client.ui.settings.impl.NumberSetting;

public class AutoTPAccept
extends Feature {
    private final NumberSetting tpadelay = new NumberSetting("Accept Delay", 500.0f, 100.0f, 1000.0f, 100.0f, () -> true);
    private final BooleanSetting friendOnlytp = new BooleanSetting("Only Friend", false, () -> true);

    public AutoTPAccept() {
        super("AutoTPAccept", "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u043f\u0438\u0448\u0435\u0442 /tpyes , \u043a\u043e\u0433\u0434\u0430 \u043a \u0432\u0430\u043c \u043a\u0442\u043e-\u0442\u043e \u0442\u0435\u043b\u0435\u043f\u043e\u0440\u0442\u0438\u0440\u0443\u0435\u0442\u0441\u044f", 0, Category.PLAYER);
        this.addSettings(this.tpadelay, this.friendOnlytp);
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        this.setSuffix("" + this.tpadelay.getNumberValue());
    }

    @EventTarget
    public void onReceiveChat(EventReceiveMessage event) {
        if (this.friendOnlytp.getBoolValue()) {
            Iterator var2 = AutoTPAccept.mc.f.i.iterator();
            while (true) {
                if (!var2.hasNext()) {
                    return;
                }
                aeb entity = (aeb)var2.next();
                if (!event.getMessage().contains("/tpyes") && !event.getMessage().contains("/tpaccept") && (!event.getMessage().contains("\u043f\u0440\u043e\u0441\u0438\u0442 \u0442\u0435\u043b\u0435\u043f\u043e\u0440\u0442\u0438\u0440\u043e\u0432\u0430\u0442\u044c\u0441\u044f \u043a \u0412\u0430\u043c") || !Main.instance.friendManager.isFriend(entity.h_()) || !timerHelper.hasReached(500.0))) continue;
                AutoTPAccept.mc.h.g("/tpaccept");
                timerHelper.reset();
            }
        }
        if ((event.getMessage().contains("/tpyes") || event.getMessage().contains("/tpaccept") || event.getMessage().contains("\u043f\u0440\u043e\u0441\u0438\u0442 \u0442\u0435\u043b\u0435\u043f\u043e\u0440\u0442\u0438\u0440\u043e\u0432\u0430\u0442\u044c\u0441\u044f \u043a \u0412\u0430\u043c")) && timerHelper.hasReached(500.0)) {
            AutoTPAccept.mc.h.g("/tpaccept");
            timerHelper.reset();
        }
    }
}

