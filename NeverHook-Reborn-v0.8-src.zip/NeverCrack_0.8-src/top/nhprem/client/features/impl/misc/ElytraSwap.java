/*
 * Decompiled with CFR 0.150.
 */
package top.nhprem.client.features.impl.misc;

import top.nhprem.Main;
import top.nhprem.api.event.EventTarget;
import top.nhprem.api.event.event.EventPreMotionUpdate;
import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;

public class ElytraSwap
extends Feature {
    private int lastSlot;
    boolean top1;

    public ElytraSwap() {
        super("ElytraSwap", "\u0441\u0432\u0430\u043f\u0430\u0435\u0442 \u043d\u0430 \u044d\u043b\u0438\u0442\u0440\u044b \u0438 \u043e\u0431\u0440\u0430\u0442\u043d\u043e", 0, Category.MISC);
    }

    @Override
    public void onDisable() {
        ElytraSwap.mc.c.a(0, 6, 1, afu.a, ElytraSwap.mc.h);
        ElytraSwap.mc.c.a(0, this.findarmor(), 0, afu.a, ElytraSwap.mc.h);
        ElytraSwap.mc.c.a(0, 6, 1, afu.a, ElytraSwap.mc.h);
        this.top1 = false;
        super.onDisable();
    }

    @EventTarget
    public void negrin(EventPreMotionUpdate event) {
        int slot = this.findElytraSlot();
        this.lastSlot = this.findFreeSlot();
        ElytraSwap.mc.c.a(0, slot, 0, afu.a, ElytraSwap.mc.h);
        ElytraSwap.mc.c.a(0, 6, 0, afu.a, ElytraSwap.mc.h);
        ElytraSwap.mc.c.a(0, 9, 1, afu.a, ElytraSwap.mc.h);
        mc.v().a(new lp(ElytraSwap.mc.h, lp.a.i));
        ElytraSwap.mc.c.a(0, 6, 0, afu.a, ElytraSwap.mc.h);
        ElytraSwap.mc.c.a(0, this.findarmor(), 0, afu.a, ElytraSwap.mc.h);
        ElytraSwap.mc.c.a(0, 6, 0, afu.a, ElytraSwap.mc.h);
        this.top1 = true;
        if (this.top1) {
            Main.instance.featureDirector.getFeatureByClass(ElytraSwap.class).toggle();
        }
    }

    private int findElytraSlot() {
        for (int i2 = 0; i2 < 45; ++i2) {
            if (ElytraSwap.mc.h.bx.a(i2).d() == null || ElytraSwap.mc.h.bx.a(i2).d().c() != aip.cS) continue;
            return i2;
        }
        return -1;
    }

    private int findFreeSlot() {
        for (int i2 = 0; i2 < 45; ++i2) {
            if (ElytraSwap.mc.h.bx.a(i2).d() != null && ElytraSwap.mc.h.bx.a(i2).d().c() != aip.a) continue;
            return i2;
        }
        return -1;
    }

    private int findarmor() {
        for (int i2 = 0; i2 < 45; ++i2) {
            if (ElytraSwap.mc.h.bx.a(i2).d() == null || !ElytraSwap.mc.h.bx.a(i2).d().a().contains("chestplate")) continue;
            return i2;
        }
        return -1;
    }
}

