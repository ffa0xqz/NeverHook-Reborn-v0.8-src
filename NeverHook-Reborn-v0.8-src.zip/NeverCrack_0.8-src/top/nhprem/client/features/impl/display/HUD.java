/*
 * Decompiled with CFR 0.150.
 */
package top.nhprem.client.features.impl.display;

import java.awt.Color;
import java.util.concurrent.CopyOnWriteArrayList;
import top.nhprem.api.event.EventTarget;
import top.nhprem.api.event.event.EventRender2D;
import top.nhprem.api.utils.world.TimerHelper;
import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;

public class HUD
extends Feature {
    float xd = 0.0f;
    private static bin font;
    public static String clientName;
    public static float count;
    public TimerHelper timer;
    double potionCheck = 0.0;
    bir sr = new bir(mc);
    Feature nextModule = null;
    int colorArray = -1;
    public static float globalOffset;

    public HUD() {
        super("HUD", "\u0445\u0443\u0434", 0, Category.DISPLAY);
    }

    @EventTarget
    public void onRender2D(EventRender2D e2) {
        bir sr2 = new bir(mc);
        if (!Double.isFinite(globalOffset -= globalOffset / (float)Math.max(1, bhz.af()) * 10.0f)) {
            globalOffset = 0.0f;
        }
        if (globalOffset > 15.0f) {
            globalOffset = 15.0f;
        }
        if (globalOffset < 0.0f) {
            globalOffset = 0.0f;
        }
        this.hotBar();
    }

    public void hotBar() {
    }

    private static Feature getNextEnabledModule(CopyOnWriteArrayList<Feature> features, int startingIndex) {
        for (int i2 = startingIndex; i2 < features.size(); ++i2) {
            Feature feature = features.get(i2);
            if (!feature.isToggled() || feature.getModuleName().equals("ClickGui")) continue;
            return feature;
        }
        return null;
    }

    public static int rainbow(int delay, long index) {
        double rainbowState = Math.ceil(System.currentTimeMillis() + index + (long)delay) / 15.0;
        return Color.getHSBColor((float)((rainbowState %= 360.0) / 360.0), 0.4f, 1.0f).getRGB();
    }

    static {
        count = 0.0f;
    }
}

