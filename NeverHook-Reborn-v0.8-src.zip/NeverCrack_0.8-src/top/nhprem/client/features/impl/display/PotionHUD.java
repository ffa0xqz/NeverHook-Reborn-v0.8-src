/*
 * Decompiled with CFR 0.150.
 */
package top.nhprem.client.features.impl.display;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Objects;
import optifine.CustomColors;
import top.nhprem.Main;
import top.nhprem.api.event.EventTarget;
import top.nhprem.api.event.event.EventRender2D;
import top.nhprem.api.guis.draggable.component.impl.DraggablePotionHUD;
import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;

public class PotionHUD
extends Feature {
    public PotionHUD() {
        super("PotionHUD", "\u043e\u0442\u043e\u0431\u0440\u0430\u0436\u0430\u0435\u0442 \u0437\u0435\u043b\u044c\u044f", 0, Category.DISPLAY);
    }

    @EventTarget
    public void onRender2d(EventRender2D e2) {
        DraggablePotionHUD dph = (DraggablePotionHUD)Main.getInstance().getDraggableHUD().getDraggableComponentByClass(DraggablePotionHUD.class);
        int x2 = dph.getX();
        int y2 = dph.getY();
        int xOff = 21;
        int yOff = 14;
        int counter = 16;
        Collection<uy> collection = PotionHUD.mc.h.ca();
        if (!collection.isEmpty()) {
            buq.c(1.0f, 1.0f, 1.0f, 1.0f);
            buq.g();
            int listOffset = 23;
            if (collection.size() > 5) {
                listOffset = 132 / (collection.size() - 1);
            }
            ArrayList<uy> potions = new ArrayList<uy>(PotionHUD.mc.h.ca());
            potions.sort(Comparator.comparingDouble(effect -> bhz.k.a(Objects.requireNonNull(ux.a(CustomColors.getPotionId(effect.f()))).a())));
            for (uy potion : potions) {
                ux effect2 = ux.a(CustomColors.getPotionId(potion.f()));
                buq.c(1.0f, 1.0f, 1.0f, 1.0f);
                assert (effect2 != null);
                if (effect2.c()) {
                    mc.N().a(new nd("textures/gui/container/inventory.png"));
                    int statusIconIndex = effect2.d();
                    bip.a(x2 + xOff - 20, y2 + counter - yOff, statusIconIndex % 8 * 18, 198 + statusIconIndex / 8 * 18, 18, 18);
                }
                String level = cew.a(effect2.a(), new Object[0]);
                if (potion.c() == 1) {
                    level = level + " " + cew.a("enchantment.level.2", new Object[0]);
                } else if (potion.c() == 2) {
                    level = level + " " + cew.a("enchantment.level.3", new Object[0]);
                } else if (potion.c() == 3) {
                    level = level + " " + cew.a("enchantment.level.4", new Object[0]);
                }
                int getPotionColor = -1;
                if (potion.b() < 200) {
                    getPotionColor = new Color(215, 59, 59).getRGB();
                } else if (potion.b() < 400) {
                    getPotionColor = new Color(231, 143, 32).getRGB();
                } else if (potion.b() > 400) {
                    getPotionColor = new Color(172, 171, 171).getRGB();
                }
                String durationString = ux.getDurationString(potion);
                bhz.k.a(level, x2 + xOff, y2 + counter - yOff, -1);
                bhz.k.a(durationString, x2 + xOff, y2 + counter + 10 - yOff, Color.gray.getRGB());
                counter += listOffset;
            }
        }
    }
}

