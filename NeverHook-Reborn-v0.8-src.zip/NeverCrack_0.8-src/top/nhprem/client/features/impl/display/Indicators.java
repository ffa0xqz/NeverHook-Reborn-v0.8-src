/*
 * Decompiled with CFR 0.150.
 */
package top.nhprem.client.features.impl.display;

import java.awt.Color;
import top.nhprem.Main;
import top.nhprem.api.event.EventTarget;
import top.nhprem.api.event.event.Event2D;
import top.nhprem.api.guis.draggable.component.impl.DraggableIndicators;
import top.nhprem.api.utils.render.AnimationHelper;
import top.nhprem.api.utils.render.ClientHelper;
import top.nhprem.api.utils.render.DrawHelper;
import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;
import top.nhprem.client.ui.settings.impl.BooleanSetting;
import top.nhprem.client.ui.settings.impl.ListSetting;

public class Indicators
extends Feature {
    public static ListSetting Indicators;
    public static BooleanSetting glow;
    private double cooldownBarWidth;
    private double hurttimeBarWidth;

    public Indicators() {
        super("Indicators", "\u043f\u043e\u043a\u0430\u0437\u044b\u0432 \u043a\u0443\u043b\u0434\u0430\u0443\u043d \u0438 HurtTime", 0, Category.DISPLAY);
        Indicators = new ListSetting("Indicators Mode", "Akrien", () -> true, "Akrien", "WexSide");
        glow = new BooleanSetting("Glow", "\u0433\u043b\u043e\u0443 \u0432\u0438\u043d\u0433", true, () -> true);
        this.addSettings(Indicators, glow);
    }

    @EventTarget
    public void nergaboba(Event2D e2) {
        String mode = Indicators.getOptions();
        if (mode.equalsIgnoreCase("WexSide")) {
            double cooldownPercentage = ri.a((double)top.nhprem.client.features.impl.display.Indicators.mc.h.n(1.0f), 0.0, 1.0);
            double cooldownWidth = 50.0 * cooldownPercentage;
            this.cooldownBarWidth = AnimationHelper.animate(cooldownWidth, this.cooldownBarWidth, 0.0529999);
            double hurttimePercentage = ri.a((double)top.nhprem.client.features.impl.display.Indicators.mc.h.ay, 0.0, 0.6);
            double hurttimeWidth = 51.0 * hurttimePercentage;
            this.hurttimeBarWidth = AnimationHelper.animate(hurttimeWidth, this.hurttimeBarWidth, 0.0529999);
            int color = Color.LIGHT_GRAY.getRGB();
            DraggableIndicators di2 = (DraggableIndicators)Main.getInstance().getDraggableHUD().getDraggableComponentByClass(DraggableIndicators.class);
            int x2 = di2.getX();
            int y2 = di2.getY();
            int width = di2.getWidth();
            int height = di2.getHeight();
            di2.setWidth(105);
            di2.setHeight(40);
            DrawHelper.drawRectWithGlow(x2, y2, x2 + width, y2 + height, 6.0, 6.0, Color.black);
            top.nhprem.client.features.impl.display.Indicators.mc.neverlose500_17.drawString("Indicators", x2 + 3, (float)((double)y2 + 4.5), color);
            bli.drawRectxy(x2 + width - 51 - 2, y2 + 20, 51.0, 5.0, Color.DARK_GRAY);
            bli.drawRectxy(x2 + width - 51 - 2, y2 + 20 + 8, 51.0, 5.0, Color.DARK_GRAY);
            top.nhprem.client.features.impl.display.Indicators.mc.neverlose500_16.drawString("Cooldown", x2 + 3, y2 + 20, color);
            bli.drawRectxy(x2 + width - 51 - 2, y2 + 20, this.cooldownBarWidth + 1.1, 5.0, ClientHelper.getClientColor());
            top.nhprem.client.features.impl.display.Indicators.mc.neverlose500_16.drawString("HurtTime", x2 + 3, y2 + 20 + 8, color);
            bli.drawRectxy(x2 + width - 51 - 2, y2 + 20 + 8, this.hurttimeBarWidth, 5.0, ClientHelper.getClientColor());
            if (glow.getBoolValue()) {
                DrawHelper.drawRectWithGlow(x2 + width - 51 - 2, y2 + 20, (double)(x2 + width - 51 - 2) + this.cooldownBarWidth, y2 + 20 + 5, 7.0, 5.0, ClientHelper.getClientColor());
            }
            if (this.hurttimeBarWidth > 1.0) {
                DrawHelper.drawRectWithGlow(x2 + width - 51 - 2, y2 + 20 + 8, (double)(x2 + width - 51 - 2) + this.hurttimeBarWidth, y2 + 20 + 8 + 5, 7.0, 5.0, ClientHelper.getClientColor());
            }
        } else if (mode.equalsIgnoreCase("Akrien")) {
            DraggableIndicators di3 = (DraggableIndicators)Main.getInstance().getDraggableHUD().getDraggableComponentByClass(DraggableIndicators.class);
            int x3 = di3.getX();
            int y3 = di3.getY();
            int width = di3.getWidth();
            int height = di3.getHeight();
            di3.setWidth(120);
            di3.setHeight(40);
            bli.drawRectxy(x3, y3, width, height, Color.decode("#323234"));
            bli.drawRectxy(x3, (double)y3 + 1.5, width, 13.0, Color.BLACK);
            top.nhprem.client.features.impl.display.Indicators.mc.neverlose900_16.drawBlurredString("Indicators", x3 + ri.getCenter(width, top.nhprem.client.features.impl.display.Indicators.mc.neverlose900_16.getStringWidth("Indicators")), (float)((double)y3 + 5.5), 8, new Color(255, 255, 255, 80), -1);
            DrawHelper.drawBlurredShadow(x3, y3, width, 1.5f, 1, ClientHelper.getClientColor(200));
            bli.drawRectxy(x3, y3, width, 1.5, ClientHelper.getClientColor());
            if (glow.getBoolValue()) {
                top.nhprem.client.features.impl.display.Indicators.mc.neverlose900_15.drawBlurredString("Cooldown", x3 + 4, y3 + 19, 8, new Color(255, 255, 255, 80), -1);
                top.nhprem.client.features.impl.display.Indicators.mc.neverlose900_15.drawBlurredString("Hurt-time", x3 + 4, y3 + 19 + 9, 8, new Color(255, 255, 255, 80), -1);
            } else {
                top.nhprem.client.features.impl.display.Indicators.mc.neverlose900_15.drawString("Cooldown", x3 + 4, y3 + 19, -1);
                top.nhprem.client.features.impl.display.Indicators.mc.neverlose900_15.drawString("Hurt-time", x3 + 4, y3 + 19 + 9, -1);
            }
            if (glow.getBoolValue()) {
                DrawHelper.drawBlurredShadow(x3 + 50, y3 + 19, (float)this.cooldownBarWidth, 5.0f, 8, ClientHelper.getClientColor(200));
                DrawHelper.drawBlurredShadow(x3 + 50, y3 + 19 + 9, (float)this.hurttimeBarWidth, 5.0f, 8, ClientHelper.getClientColor(200));
            }
            double coef = top.nhprem.client.features.impl.display.Indicators.mc.h.n(1.0f) / 1.0f;
            double wid = coef * 65.0;
            this.cooldownBarWidth = AnimationHelper.animate(wid, this.cooldownBarWidth, 0.0299999);
            double coef2 = ri.a((double)top.nhprem.client.features.impl.display.Indicators.mc.h.ay, 0.0, 0.6);
            double wid2 = coef2 * 65.0;
            this.hurttimeBarWidth = AnimationHelper.animate(wid2, this.hurttimeBarWidth, 0.0299999);
            bli.drawRectxy(x3 + 50, y3 + 19, 65.0, 5.0, Color.DARK_GRAY);
            bli.drawRectxy(x3 + 50, y3 + 19 + 9, 65.0, 5.0, Color.DARK_GRAY);
            bli.drawGradientRected(x3 + 50, y3 + 19, (float)this.cooldownBarWidth, 5.0f, ClientHelper.getClientColor(1).getRGB(), ClientHelper.getClientColor(200).getRGB());
            bli.drawGradientRected(x3 + 50, y3 + 19 + 9, (float)this.hurttimeBarWidth, 5.0f, ClientHelper.getClientColor(1).getRGB(), ClientHelper.getClientColor(200).getRGB());
        }
    }
}

