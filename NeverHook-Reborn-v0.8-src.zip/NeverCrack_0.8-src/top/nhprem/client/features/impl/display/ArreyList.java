/*
 * Decompiled with CFR 0.150.
 */
package top.nhprem.client.features.impl.display;

import java.awt.Color;
import java.util.Comparator;
import top.nhprem.Main;
import top.nhprem.api.event.EventTarget;
import top.nhprem.api.event.event.EventRender2D;
import top.nhprem.api.event.event.EventUpdate;
import top.nhprem.api.utils.render.ClientHelper;
import top.nhprem.api.utils.render.DrawHelper;
import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;
import top.nhprem.client.features.impl.display.ClientFont;
import top.nhprem.client.ui.clickgui.ScreenHelper;
import top.nhprem.client.ui.settings.impl.BooleanSetting;
import top.nhprem.client.ui.settings.impl.ColorSetting;
import top.nhprem.client.ui.settings.impl.ListSetting;
import top.nhprem.client.ui.settings.impl.NumberSetting;

public class ArreyList
extends Feature {
    public final ListSetting fontRenderType;
    public final ListSetting borderMode;
    public BooleanSetting backGround;
    public final ColorSetting backGroundColor = new ColorSetting("BackGround Color", Color.BLACK.getRGB(), () -> this.backGround.getBoolValue());
    public BooleanSetting border;
    public final BooleanSetting rightBorder;
    public NumberSetting xOffset;
    public NumberSetting yOffset;
    public final NumberSetting offset;
    public NumberSetting size;
    public final NumberSetting borderWidth;
    public final NumberSetting rainbowSaturation;
    public final NumberSetting rainbowBright;
    public final NumberSetting fontX;
    public final ListSetting backgroundMode;
    public final NumberSetting fontY;
    public BooleanSetting blur = new BooleanSetting("Blur", false, () -> this.backGround.getBoolValue());
    public static ListSetting colorList;
    public static NumberSetting colortime;
    public BooleanSetting shadow;
    public final ColorSetting shadowColor;
    public static ColorSetting onecolor;
    public static ColorSetting twocolor;

    public ArreyList() {
        super("ArrayList", "0", 0, Category.DISPLAY);
        colorList = new ListSetting("ArrayList Color", "Astolfo", () -> true, "Custom", "Rainbow", "Astolfo");
        this.borderMode = new ListSetting("Border Mode", "Full", () -> this.border.getBoolValue(), "Full", "Single");
        this.fontRenderType = new ListSetting("FontRender Type", "Shadow", () -> true, "Shadow");
        this.backGround = new BooleanSetting("Background", true, () -> true);
        this.backgroundMode = new ListSetting("Background Mode", "Rect", () -> this.backGround.getBoolValue(), "Rect", "Smooth Rect");
        this.shadow = new BooleanSetting("Shadow", false, () -> true);
        this.shadowColor = new ColorSetting("Shadow Color", new Color(0xFFFFFF).getRGB(), () -> this.shadow.getBoolValue());
        this.border = new BooleanSetting("Border", true, () -> true);
        this.rightBorder = new BooleanSetting("Right Border", true, () -> true);
        this.rainbowSaturation = new NumberSetting("Rainbow Saturation", 0.8f, 0.1f, 1.0f, 0.1f, () -> ArreyList.colorList.currentMode.equals("Rainbow"));
        this.rainbowBright = new NumberSetting("Rainbow Brightness", 1.0f, 0.1f, 1.0f, 0.1f, () -> ArreyList.colorList.currentMode.equals("Rainbow"));
        this.fontX = new NumberSetting("FontX", 0.0f, -4.0f, 20.0f, 0.1f, () -> true);
        this.fontY = new NumberSetting("FontY", 0.0f, -4.0f, 20.0f, 0.01f, () -> true);
        this.xOffset = new NumberSetting("FeatureList X", 0.0f, 0.0f, 500.0f, 1.0f, () -> !this.blur.getBoolValue());
        this.yOffset = new NumberSetting("FeatureList Y", 0.0f, 0.0f, 500.0f, 1.0f, () -> !this.blur.getBoolValue());
        this.offset = new NumberSetting("Font Offset", 11.0f, 7.0f, 20.0f, 0.5f, () -> true);
        this.borderWidth = new NumberSetting("Border Width", 1.0f, 0.0f, 10.0f, 0.1f, () -> this.rightBorder.getBoolValue());
        this.addSettings(colorList, onecolor, twocolor, this.fontRenderType, this.borderMode, this.fontX, this.fontY, this.border, this.rightBorder, this.borderWidth, this.backGround, this.backgroundMode, this.backGroundColor, this.shadow, this.shadowColor, colortime, this.rainbowSaturation, this.rainbowBright, this.xOffset, this.yOffset, this.offset);
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        this.setSuffix(colorList.getCurrentMode());
    }

    @EventTarget
    public void onRender2D(EventRender2D event) {
        float width = (float)event.getResolution().a() - (this.rightBorder.getBoolValue() ? this.borderWidth.getNumberValue() : 0.0f);
        float y2 = 1.0f;
        int yTotal = 0;
        for (int i2 = 0; i2 < Main.instance.featureDirector.getFeatureList().size(); ++i2) {
            yTotal += ClientHelper.getFontRender().getFontHeight() + 3;
        }
        if (Main.instance.featureDirector.getFeatureByClass(ArreyList.class).isToggled() && !ArreyList.mc.t.ax) {
            Main.instance.featureDirector.getFeatureList().sort(Comparator.comparingInt(module -> !ClientFont.minecraftfont.getBoolValue() ? -ClientHelper.getFontRender().getStringWidth(module.getModuleName()) : -bhz.k.a(module.getModuleName())));
            for (Feature feature : Main.instance.featureDirector.getFeatureList()) {
                float yOffset;
                boolean state;
                ScreenHelper animationHelper = feature.getScreenHelper();
                String featureSuffix = feature.getModuleName();
                float listOffset = this.offset.getNumberValue();
                float length = !ClientFont.minecraftfont.getBoolValue() ? (float)ClientHelper.getFontRender().getStringWidth(featureSuffix) : (float)bhz.k.a(featureSuffix);
                float featureX = width - length;
                boolean bl2 = state = feature.isToggled() && feature.visible;
                if (state) {
                    animationHelper.interpolate(featureX, y2, 4.0 * bhz.frameTime / 4.0);
                } else {
                    animationHelper.interpolate(width, y2, 4.0 * bhz.frameTime / 4.0);
                }
                float translateY = animationHelper.getY();
                float translateX = animationHelper.getX() - (this.rightBorder.getBoolValue() ? 2.5f : 1.5f) - this.fontX.getNumberValue();
                int color = 0;
                if (this.shadow.getBoolValue()) {
                    DrawHelper.drawGlow1((double)translateX + 2.0, (double)translateY - 6.0, width, (double)(translateY + listOffset) + 5.0, new Color(20, 20, 20, 150).getRGB(), 200.0);
                    DrawHelper.drawGlow1((double)translateX + 2.0, (double)translateY - 6.0, width, (double)(translateY + listOffset) + 5.0, new Color(20, 20, 20, 150).getRGB(), 200.0);
                }
                int colorCustom = onecolor.getColorValue();
                int colorCustom2 = twocolor.getColorValue();
                double time = colortime.getNumberValue();
                String mode = colorList.getOptions();
                boolean visible = animationHelper.getX() < width;
                if (!visible) continue;
                switch (mode.toLowerCase()) {
                    case "rainbow": {
                        color = DrawHelper.rainbow((int)((double)y2 * time), this.rainbowSaturation.getNumberValue(), this.rainbowBright.getNumberValue()).getRGB();
                        break;
                    }
                    case "astolfo": {
                        color = DrawHelper.astolfoColors45(y2, yTotal, 0.5f, 5.0f).getRGB();
                        break;
                    }
                    case "custom": {
                        color = DrawHelper.fadeColor(new Color(colorCustom).getRGB(), new Color(colorCustom2).getRGB(), (float)Math.abs(((double)System.currentTimeMillis() / time / time + (double)(y2 * 6.0f / 61.0f * 2.0f)) % 2.0));
                    }
                }
                buq.G();
                buq.c(-this.xOffset.getNumberValue(), this.yOffset.getNumberValue(), 1.0f);
                Feature nextFeature = null;
                if (this.border.getBoolValue() && this.borderMode.currentMode.equals("Full")) {
                    DrawHelper.drawRect((double)translateX - 3.5, translateY - 1.0f, translateX - 2.0f, translateY + listOffset - 1.0f, color);
                }
                if (nextFeature != null && this.borderMode.currentMode.equals("Full")) {
                    String name = nextFeature.getModuleName();
                    float font = !ClientFont.minecraftfont.getBoolValue() ? (float)ClientHelper.getFontRender().getStringWidth(name) : (float)bhz.k.a(name);
                    float dif = length - font;
                    if (this.border.getBoolValue() && this.borderMode.currentMode.equals("Full")) {
                        DrawHelper.drawRect((double)translateX - 3.5, translateY + listOffset + 1.0f, translateX - 2.0f + dif, translateY + listOffset - 1.0f, color);
                    }
                } else if (this.border.getBoolValue() && this.borderMode.currentMode.equals("Full")) {
                    DrawHelper.drawRect((double)translateX - 3.5, translateY + listOffset + 1.0f, width, translateY + listOffset - 1.0f, color);
                }
                if (this.borderMode.currentMode.equals("Single") && this.border.getBoolValue()) {
                    DrawHelper.drawRect((double)translateX - 3.5, translateY - 1.0f, translateX - 2.0f, translateY + listOffset - 1.0f, color);
                }
                if (this.backGround.getBoolValue() && this.backgroundMode.currentMode.equalsIgnoreCase("Smooth Rect")) {
                    DrawHelper.drawSmoothRect2(translateX - 2.0f, translateY - 1.0f, width, (double)(translateY + listOffset) - 1.5, this.backGroundColor.getColorValue());
                }
                if (this.backGround.getBoolValue() && this.backgroundMode.currentMode.equalsIgnoreCase("Rect")) {
                    DrawHelper.drawRect(translateX - 2.0f, translateY - 1.0f, width, translateY + listOffset - 1.0f, this.backGroundColor.getColorValue());
                }
                if (ClientFont.minecraftfont.getBoolValue()) continue;
                String modeArrayFont = ClientFont.fontMode.getOptions();
                float f2 = modeArrayFont.equalsIgnoreCase("Lato") ? 1.2f : (modeArrayFont.equalsIgnoreCase("Myseo") ? 0.5f : (modeArrayFont.equalsIgnoreCase("URWGeometric") ? 0.5f : (modeArrayFont.equalsIgnoreCase("Roboto Regular") ? 0.5f : (yOffset = modeArrayFont.equalsIgnoreCase("SFUI") ? 1.3f : 2.0f))));
                if (!ClientFont.minecraftfont.getBoolValue() && this.fontRenderType.currentMode.equals("Shadow")) {
                    ClientHelper.getFontRender().drawStringWithShadow(feature.getModuleName(), translateX, translateY + yOffset + this.fontY.getNumberValue(), color);
                } else if (!ClientFont.minecraftfont.getBoolValue() && this.fontRenderType.currentMode.equals("Default") ? !ClientFont.minecraftfont.getBoolValue() && this.fontRenderType.currentMode.equals("Outline") : this.fontRenderType.currentMode.equals("Shadow") || this.fontRenderType.currentMode.equals("Default") || this.fontRenderType.currentMode.equals("Outline")) {
                    // empty if block
                }
                y2 += listOffset;
                if (this.rightBorder.getBoolValue()) {
                    float checkY = this.border.getBoolValue() ? 0.0f : 0.6f;
                    DrawHelper.drawRect(width, translateY - 1.0f, width + this.borderWidth.getNumberValue(), translateY + listOffset - checkY, color);
                }
                buq.H();
            }
        }
    }

    static {
        colortime = new NumberSetting("Color Time", 30.0f, 1.0f, 100.0f, 1.0f, () -> ArreyList.colorList.currentMode.equalsIgnoreCase("Custom"));
        onecolor = new ColorSetting("One Color", new Color(0xFFFFFF).getRGB(), () -> ArreyList.colorList.currentMode.equals("Custom"));
        twocolor = new ColorSetting("Two Color", new Color(0xFF0000).getRGB(), () -> ArreyList.colorList.currentMode.equals("Custom"));
    }
}

