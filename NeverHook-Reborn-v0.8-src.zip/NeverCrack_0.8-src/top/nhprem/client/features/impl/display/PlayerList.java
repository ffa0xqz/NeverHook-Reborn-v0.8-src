/*
 * Decompiled with CFR 0.150.
 */
package top.nhprem.client.features.impl.display;

import java.awt.Color;
import java.util.List;
import top.nhprem.Main;
import top.nhprem.api.event.EventTarget;
import top.nhprem.api.event.event.Event2D;
import top.nhprem.api.guis.draggable.component.impl.DraggablePlayers;
import top.nhprem.api.utils.render.DrawHelper;
import top.nhprem.api.utils.render.PaletteHelper;
import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;
import top.nhprem.client.ui.settings.impl.ListSetting;

public class PlayerList
extends Feature {
    public static ListSetting mode;

    public PlayerList() {
        super("PlayerList", "\u0438\u0433\u0440\u043e\u043a\u0438 \u0432\u043e\u043a\u0440\u0443\u0433 \u0432\u0430\u0441\u044b", 0, Category.DISPLAY);
        mode = new ListSetting("Mode", "Nearby", () -> true, "Nearby", "Server");
    }

    @EventTarget
    public void onRender(Event2D e2) {
        int width = bhz.k.a("aaaaaaaaaaaaa") + 40;
        brx nethandlerplayclient = PlayerList.mc.h.d;
        List list = bjo.a.sortedCopy(nethandlerplayclient.d());
        String var8 = mode.getOptions();
        int var9 = -1;
        switch (var8.hashCode()) {
            case -1965615457: {
                if (!var8.equals("Nearby")) break;
                var9 = 1;
                break;
            }
            case -1821959325: {
                if (!var8.equals("Server")) break;
                var9 = 0;
            }
        }
        DraggablePlayers players = (DraggablePlayers)Main.getInstance().getDraggableHUD().getDraggableComponentByClass(DraggablePlayers.class);
        int x2 = players.getX();
        int y2 = players.getY();
        players.setWidth(width);
        players.setHeight(12 * list.size() + 16);
        int theY = y2 + 16;
        switch (var9) {
            case 0: {
                DrawHelper.drawRect(x2 - 1, y2 - 3, x2 + width + 1, y2 + 12 * list.size() + 17, DrawHelper.transparency(new Color(37, 37, 37).getRGB(), 0.6f));
                DrawHelper.drawRect(x2, y2, x2 + width, y2 + 12 * list.size() + 16, DrawHelper.transparency(new Color(45, 45, 45, 255).getRGB(), 0.8f));
                DrawHelper.drawRect(x2, y2, x2 + width, y2 + 13, DrawHelper.transparency(new Color(35, 35, 35, 255).getRGB(), 0.8f));
                DrawHelper.drawRect(x2, y2 - 2, x2 + width, y2, DrawHelper.transparency(PaletteHelper.astolfo(false, 10).getRGB(), 0.8f));
                bhz.k.a("Players", x2 + 2, y2 + 3, -1);
                for (bsa networkplayerinfo : list) {
                    bhz.k.a(networkplayerinfo.a().getName(), (float)x2 + 15.0f, theY + 1, new Color(200, 200, 200).getRGB());
                    DrawHelper.drawHead((bty)PlayerList.mc.f.b(nethandlerplayclient.e().getId()), x2 + 2, theY, 10, 10);
                    bhz.k.a(String.valueOf(list.size()), x2 + width - 2 - bhz.k.a(String.valueOf(list.size())), y2 + 3, -1);
                    theY += 12;
                }
            }
            case 1: {
                int count = 0;
                for (ve ent : PlayerList.mc.f.e) {
                    if (!(ent instanceof aeb) || ent.aX()) continue;
                    ++count;
                }
                DrawHelper.drawRect(x2 - 1, y2 - 3, x2 + width + 1, y2 + 12 * count + 17, DrawHelper.transparency(new Color(37, 37, 37).getRGB(), 0.6f));
                DrawHelper.drawRect(x2, y2, x2 + width, y2 + 12 * count + 16, DrawHelper.transparency(new Color(45, 45, 45, 255).getRGB(), 0.8f));
                DrawHelper.drawRect(x2, y2, x2 + width, y2 + 13, DrawHelper.transparency(new Color(35, 35, 35, 255).getRGB(), 0.8f));
                DrawHelper.drawRect(x2, y2 - 2, x2 + width, y2, DrawHelper.transparency(PaletteHelper.astolfo(false, 10).getRGB(), 0.8f));
                bhz.k.a("Players", x2 + 2, y2 + 3, -1);
                for (ve ent : PlayerList.mc.f.e) {
                    if (!(ent instanceof aeb) || ent.aX()) continue;
                    bhz.k.a(ent.h_(), (float)x2 + 15.0f, theY + 1, new Color(200, 200, 200).getRGB());
                    DrawHelper.drawHead((bty)ent, x2 + 2, theY, 10, 10);
                    theY += 12;
                }
                bhz.k.a(String.valueOf(count), x2 + width - 2 - bhz.k.a(String.valueOf(count)), y2 + 3, -1);
            }
        }
    }
}

