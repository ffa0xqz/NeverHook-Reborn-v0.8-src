/*
 * Decompiled with CFR 0.150.
 */
package top.nhprem.client.features.impl.display;

import java.awt.Color;
import java.util.Objects;
import top.nhprem.Main;
import top.nhprem.api.event.EventTarget;
import top.nhprem.api.event.event.Event2D;
import top.nhprem.api.guis.draggable.component.impl.DraggableWatermark;
import top.nhprem.api.socket.UserData;
import top.nhprem.api.utils.render.ClientHelper;
import top.nhprem.api.utils.render.DrawHelper;
import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;
import top.nhprem.client.features.impl.visuals.NameProtect;
import top.nhprem.client.ui.settings.impl.ListSetting;

public class Watermark
extends Feature {
    public static ListSetting waterMarkMode;
    String server;

    public Watermark() {
        super("Watermark", "Client logo.", 0, Category.DISPLAY);
        waterMarkMode = new ListSetting("WaterMark Mode", "OneTap", () -> true, "Simple", "Neverlose", "NeverHook", "Akrien", "OneTap", "Akrien 2");
        this.addSettings(waterMarkMode);
    }

    @EventTarget
    public void render(Event2D render) {
        int yTotal = 0;
        for (int i2 = 0; i2 < Main.instance.featureDirector.getFeatureList().size(); ++i2) {
            yTotal += bhz.z().sfui16.getFontHeight() + 5;
        }
        String watermark = waterMarkMode.getOptions();
        String name = Main.instance.featureDirector.getFeatureByClass(NameProtect.class).isToggled() ? UserData.instance().getName() : Watermark.mc.af.c();
        this.setModuleName("Watermark \u00a77" + watermark + "");
        DraggableWatermark dw2 = (DraggableWatermark)Main.getInstance().getDraggableHUD().getDraggableComponentByClass(DraggableWatermark.class);
        int x2 = dw2.getX();
        int y2 = dw2.getY();
        int width = dw2.getWidth();
        int height = dw2.getHeight();
        dw2.setWidth(bhz.z().neverlose500_17.getStringWidth(Main.instance.name + Main.version));
        dw2.setHeight(bhz.z().neverlose500_17.getFontHeight());
        if (watermark.equalsIgnoreCase("Simple")) {
            bhz.z().neverlose500_17.drawStringWithShadow(Main.instance.name + Main.version, x2, y2, ClientHelper.getClientColor().getRGB());
        } else if (watermark.equalsIgnoreCase("Neverlose")) {
            String server = mc.E() ? "local" : (mc.C() != null ? Watermark.mc.C().b.toLowerCase() : "null");
            String text = (Main.instance.featureDirector.getFeatureByClass(NameProtect.class).isToggled() ? UserData.instance().getName() : Watermark.mc.af.c()) + " | " + bhz.af() + " fps | " + server;
            String scam = "NEVERHOOK | " + (Main.instance.featureDirector.getFeatureByClass(NameProtect.class).isToggled() ? UserData.instance().getName() : Watermark.mc.af.c()) + " | " + bhz.af() + " fps | " + server;
            DrawHelper.drawGlowRoundedRect3(2.0f + (float)x2, 4.0f + (float)y2, x2 + (bhz.z().neverlose500_15.getStringWidth(scam) + 15), (float)y2 + 20.0f, new Color(10, 10, 10, 200).getRGB(), 5.0f, 5.0f);
            DrawHelper.drawSmoothRect2(5.0 + (double)x2, 6.0 + (double)y2, x2 + (bhz.z().neverlose500_15.getStringWidth(scam) + 12), (double)y2 + 18.0, new Color(10, 10, 10, 255).getRGB());
            bhz.z().neverlose900_15.drawStringWithShadow("NEVERHOOK", 7.5 + (double)x2, 10.0 + (double)y2, new Color(22, 97, 141).getRGB());
            bhz.z().neverlose900_15.drawStringWithShadow("NEVERHOOK", 8.0 + (double)x2, 10.5 + (double)y2, -1);
            bhz.z().neverlose500_15.drawStringWithShadow("| " + text, x2 + (7 + bhz.z().neverlose500_15.getStringWidth("NEVERHOOK | ")), (double)y2 + 10.5, -1);
        } else if (watermark.equals("NeverHook")) {
            Color color = Color.BLACK;
            int ping = nh.E() ? 0 : (int)Watermark.nh.C().e;
            Watermark.nh.neverlose500_20.drawString("neverhook.pw \u00a77v" + Main.version + " \u00a77[\u00a7f" + bhz.af() + " FPS\u00a77] \u00a77[\u00a7f" + ping + " PING\u00a77]", x2, y2, color.getRGB());
        } else if (watermark.equalsIgnoreCase("Akrien")) {
            String text = "NeverHook v" + Main.version;
            bip.drawRect(x2, y2, x2 + Watermark.mc.neverlose500_16.getStringWidth(text) + 5, y2 + 10, new Color(0, 0, 0).getRGB());
            bip.drawRect(x2, y2, (double)x2 + 2.1, y2 + 10, new Color(0, 191, 255).getRGB());
            Watermark.mc.neverlose500_16.drawStringWithShadow(text, (double)x2 + 3.5, y2 + 3, -1);
        } else if (watermark.equalsIgnoreCase("OneTap")) {
            String server = mc.E() ? "local" : Watermark.mc.C().b.toLowerCase();
            String text = Main.instance.name + Main.version + " | " + name + " | " + server + " | " + bhz.af() + " fps | " + Objects.requireNonNull(mc.v()).a(Watermark.mc.h.bm()).c() + "ms";
            bip.drawRect(5 + x2, 6 + y2, x2 + bhz.z().neverlose500_15.getStringWidth(text) + 9, y2 + 18, new Color(0, 0, 0, 176).getRGB());
            for (float l2 = 0.0f; l2 < (float)(bhz.z().neverlose500_15.getStringWidth(text) + 4); l2 += 1.0f) {
                bip.drawRect(5.0f + l2 + (float)x2, 5 + y2, l2 + 6.0f + (float)x2, 6 + y2, ClientHelper.getClientColor(5.0f, l2, 5).getRGB());
            }
            bhz.z().neverlose500_15.drawStringWithShadow(text, 7 + x2, 10.5 + (double)y2, -1);
        } else if (watermark.equalsIgnoreCase("Akrien 2")) {
            String server = mc.E() ? "local" : (mc.C() != null ? Watermark.mc.C().b.toLowerCase() : "null");
            String text = "NeverHook Premium v" + Main.version + " | " + name + " | " + bhz.af() + "fps | " + server;
            dw2.setWidth(Watermark.mc.rubik_regular_16.getStringWidth(text) + 4);
            dw2.setHeight(12);
            DrawHelper.drawRectWithGlow(x2, y2, x2 + width, y2 + height, 3.0, 50.0, Color.decode("#20201c"));
            bli.drawRectxy(x2, y2, width, height, Color.decode("#20201c"));
            bli.drawRoundedRect2(x2, y2, width, 1.0, 1, ClientHelper.getClientColor());
            Watermark.mc.rubik_regular_16.drawString(text, x2 + 2, y2 + 5, -1);
        }
    }
}

