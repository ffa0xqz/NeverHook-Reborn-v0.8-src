/*
 * Decompiled with CFR 0.150.
 */
package top.nhprem.client.features.impl.display;

import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;

public class Notifications
extends Feature {
    public Notifications() {
        super("Notifications", "\u043e\u043f\u043e\u0432\u0438\u0449\u0435\u043d\u0438\u0435", 0, Category.DISPLAY);
    }
}

