/*
 * Decompiled with CFR 0.150.
 */
package top.nhprem.client.features.impl.display;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Objects;
import top.nhprem.api.event.EventTarget;
import top.nhprem.api.event.event.Event2D;
import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;

public class Hotbar
extends Feature {
    public Hotbar() {
        super("Hotbar", "beautiful hotbar", 0, Category.DISPLAY);
    }

    @EventTarget
    public void hotbar(Event2D event2D) {
        bir scaledResolution = new bir(mc);
        if (!(Hotbar.mc.m instanceof bkl)) {
            String fpsandping = "FPS: " + bhz.af() + " Ping: " + Objects.requireNonNull(mc.v()).a(Hotbar.mc.h.bm()).c();
            String cords = "X:" + (int)Hotbar.mc.h.p + " Y:" + (int)Hotbar.mc.h.q + " Z:" + (int)Hotbar.mc.h.r;
            String time = " BPS: " + String.format("%.1f", Math.abs(Math.hypot(Hotbar.mc.h.p - Hotbar.mc.h.m, Hotbar.mc.h.r - Hotbar.mc.h.o)) * 15.0);
            String date = new SimpleDateFormat("dd/MM/yyyy").format(Calendar.getInstance().getTime());
            bhz.z().sfui16.drawStringWithShadow(fpsandping, 3.0, scaledResolution.b() - 17, -1);
            bhz.z().sfui16.drawStringWithShadow(cords, 3.0, scaledResolution.b() - 8, -1);
            bhz.z().sfui16.drawStringWithShadow(time, scaledResolution.a() - bhz.z().sfui16.getStringWidth(time) - 18, (double)scaledResolution.b() - 17.5, -1);
            bhz.z().sfui16.drawStringWithShadow(date, scaledResolution.a() - bhz.z().sfui16.getStringWidth(date) - 7, (double)scaledResolution.b() - 8.5, -1);
        }
    }
}

