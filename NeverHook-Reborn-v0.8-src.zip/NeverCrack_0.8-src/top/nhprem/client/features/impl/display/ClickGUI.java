/*
 * Decompiled with CFR 0.150.
 */
package top.nhprem.client.features.impl.display;

import java.awt.Color;
import top.nhprem.Main;
import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;
import top.nhprem.client.ui.click.ClickGuiScreen;
import top.nhprem.client.ui.hydra.HydraClickGui;
import top.nhprem.client.ui.settings.impl.BooleanSetting;
import top.nhprem.client.ui.settings.impl.ListSetting;

public class ClickGUI
extends Feature {
    public static BooleanSetting anime;
    public static BooleanSetting blur;
    public static ListSetting animemode;
    public static ListSetting animemode123;
    public static ListSetting clickguimode;

    public ClickGUI() {
        super("ClickGUI", "\u0447\u0438\u0442 \u043c\u0435\u043d\u044e", 54, Category.DISPLAY);
        clickguimode = new ListSetting("ClickGui mode", "Nursultan", () -> true, "Nursultan", "Eternity", "Hydra");
        animemode123 = new ListSetting("Anime mode", "Anime1", () -> true, "Anime1", "Anime2", "Anime3", "Anime4", "Anime5", "Anime6", "Anime7", "Anime8", "Anime9", "Anime10", "Anime11", "Anime12", "Fluger", "None");
        this.setKey(54);
        this.addSettings(clickguimode, animemode123, blur);
    }

    @Override
    public void onEnable() {
        String mode = clickguimode.getOptions();
        if (mode.equalsIgnoreCase("Eternity")) {
            mc.a(new ClickGuiScreen(false, false, Color.red));
        } else if (mode.equalsIgnoreCase("Nursultan")) {
            mc.a(Main.instance.clickGui);
        } else if (mode.equalsIgnoreCase("Hydra")) {
            mc.a(new HydraClickGui());
        }
        Main.instance.featureDirector.getFeatureByClass(ClickGUI.class).setEnabled(false);
        super.onEnable();
    }

    static {
        blur = new BooleanSetting("Blur", true, () -> true);
    }
}

