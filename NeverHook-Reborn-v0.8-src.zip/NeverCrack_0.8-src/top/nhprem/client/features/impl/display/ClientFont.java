/*
 * Decompiled with CFR 0.150.
 */
package top.nhprem.client.features.impl.display;

import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;
import top.nhprem.client.ui.settings.impl.BooleanSetting;
import top.nhprem.client.ui.settings.impl.ListSetting;

public class ClientFont
extends Feature {
    public static ListSetting fontMode;
    public static BooleanSetting minecraftfont;

    public ClientFont() {
        super("ClientFont", "", 0, Category.DISPLAY);
        fontMode = new ListSetting("FontList", "URWGeometric", () -> !minecraftfont.getBoolValue(), "URWGeometric", "Myseo", "SFUI", "Lato", "Roboto Regular", "bebasbook", "minecraft");
        minecraftfont = new BooleanSetting("Minecraft Font", false, () -> true);
        this.addSettings(fontMode);
    }

    @Override
    public void onEnable() {
        this.toggle();
        super.onEnable();
    }
}

