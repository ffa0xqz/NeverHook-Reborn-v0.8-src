/*
 * Decompiled with CFR 0.150.
 */
package top.nhprem.client.features;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import top.nhprem.client.features.Category;
import top.nhprem.client.features.Feature;
import top.nhprem.client.features.impl.combat.AntiBot;
import top.nhprem.client.features.impl.combat.AutoArmor;
import top.nhprem.client.features.impl.combat.AutoGapple;
import top.nhprem.client.features.impl.combat.AutoPotion;
import top.nhprem.client.features.impl.combat.AutoTotem;
import top.nhprem.client.features.impl.combat.DamageParticles;
import top.nhprem.client.features.impl.combat.HitBox;
import top.nhprem.client.features.impl.combat.KeepSprint;
import top.nhprem.client.features.impl.combat.KillAura;
import top.nhprem.client.features.impl.combat.NoFriendDamage;
import top.nhprem.client.features.impl.combat.ShieldDesync;
import top.nhprem.client.features.impl.combat.SuperBow;
import top.nhprem.client.features.impl.combat.TriggerBot;
import top.nhprem.client.features.impl.combat.Velocity;
import top.nhprem.client.features.impl.display.ArreyList;
import top.nhprem.client.features.impl.display.ClickGUI;
import top.nhprem.client.features.impl.display.ClientFont;
import top.nhprem.client.features.impl.display.HUD;
import top.nhprem.client.features.impl.display.Hotbar;
import top.nhprem.client.features.impl.display.Indicators;
import top.nhprem.client.features.impl.display.Notifications;
import top.nhprem.client.features.impl.display.PlayerList;
import top.nhprem.client.features.impl.display.PotionHUD;
import top.nhprem.client.features.impl.display.Watermark;
import top.nhprem.client.features.impl.misc.AutoTPAccept;
import top.nhprem.client.features.impl.misc.ElytraSwap;
import top.nhprem.client.features.impl.misc.FastWorldLoad;
import top.nhprem.client.features.impl.misc.FlagDetector;
import top.nhprem.client.features.impl.misc.HackerDetector;
import top.nhprem.client.features.impl.misc.MCF;
import top.nhprem.client.features.impl.misc.ModuleSoundAlert;
import top.nhprem.client.features.impl.misc.Optimization;
import top.nhprem.client.features.impl.misc.PlayerFinder;
import top.nhprem.client.features.impl.misc.StaffAlert;
import top.nhprem.client.features.impl.misc.Xray;
import top.nhprem.client.features.impl.movement.AirJump;
import top.nhprem.client.features.impl.movement.AutoSprint;
import top.nhprem.client.features.impl.movement.DMGSpeed;
import top.nhprem.client.features.impl.movement.DamageFly;
import top.nhprem.client.features.impl.movement.EClip;
import top.nhprem.client.features.impl.movement.ElytraFlight;
import top.nhprem.client.features.impl.movement.ElytraLeave;
import top.nhprem.client.features.impl.movement.ElytraSpeed;
import top.nhprem.client.features.impl.movement.Flight;
import top.nhprem.client.features.impl.movement.GlideFly;
import top.nhprem.client.features.impl.movement.HighJump;
import top.nhprem.client.features.impl.movement.Jesus;
import top.nhprem.client.features.impl.movement.LongJump;
import top.nhprem.client.features.impl.movement.NoFall;
import top.nhprem.client.features.impl.movement.NoSlowDown;
import top.nhprem.client.features.impl.movement.PerlLeave;
import top.nhprem.client.features.impl.movement.Phase;
import top.nhprem.client.features.impl.movement.SafeWalk;
import top.nhprem.client.features.impl.movement.Speed;
import top.nhprem.client.features.impl.movement.Step;
import top.nhprem.client.features.impl.movement.Strafe;
import top.nhprem.client.features.impl.movement.TargetStrafe;
import top.nhprem.client.features.impl.movement.TeleportExploit;
import top.nhprem.client.features.impl.movement.TestFeature;
import top.nhprem.client.features.impl.movement.Timer;
import top.nhprem.client.features.impl.movement.WaterLeave;
import top.nhprem.client.features.impl.movement.WaterSpeed;
import top.nhprem.client.features.impl.player.AirStuck;
import top.nhprem.client.features.impl.player.AntiPearlBlocker;
import top.nhprem.client.features.impl.player.AutoTool;
import top.nhprem.client.features.impl.player.AutoVClip;
import top.nhprem.client.features.impl.player.ChestStealer;
import top.nhprem.client.features.impl.player.DeathCoordinates;
import top.nhprem.client.features.impl.player.FastEat;
import top.nhprem.client.features.impl.player.FreeCam;
import top.nhprem.client.features.impl.player.GuiMove;
import top.nhprem.client.features.impl.player.ItemScroller;
import top.nhprem.client.features.impl.player.MiddleClickPearl;
import top.nhprem.client.features.impl.player.MultiAction;
import top.nhprem.client.features.impl.player.NoClip;
import top.nhprem.client.features.impl.player.NoDelay;
import top.nhprem.client.features.impl.player.NoInteract;
import top.nhprem.client.features.impl.player.NoPush;
import top.nhprem.client.features.impl.player.NoServerRotations;
import top.nhprem.client.features.impl.player.NoWeb;
import top.nhprem.client.features.impl.player.OnHealth;
import top.nhprem.client.features.impl.player.SpeedMine;
import top.nhprem.client.features.impl.player.Spider;
import top.nhprem.client.features.impl.visuals.Chams;
import top.nhprem.client.features.impl.visuals.ChestEsp;
import top.nhprem.client.features.impl.visuals.ChinaHat;
import top.nhprem.client.features.impl.visuals.Crosshair;
import top.nhprem.client.features.impl.visuals.CustomModel;
import top.nhprem.client.features.impl.visuals.ESP;
import top.nhprem.client.features.impl.visuals.FullBright;
import top.nhprem.client.features.impl.visuals.GAppleTimer;
import top.nhprem.client.features.impl.visuals.JumpCircle;
import top.nhprem.client.features.impl.visuals.NameProtect;
import top.nhprem.client.features.impl.visuals.NameTags;
import top.nhprem.client.features.impl.visuals.NoRender;
import top.nhprem.client.features.impl.visuals.PearlESP;
import top.nhprem.client.features.impl.visuals.PersonViewer;
import top.nhprem.client.features.impl.visuals.ScoreBoard;
import top.nhprem.client.features.impl.visuals.SwingAnimations;
import top.nhprem.client.features.impl.visuals.TargetESP;
import top.nhprem.client.features.impl.visuals.Tracers;
import top.nhprem.client.features.impl.visuals.Trails;
import top.nhprem.client.features.impl.visuals.ViewModel;
import top.nhprem.client.features.impl.visuals.WorldColor;

public class FeatureDirector {
    public static CopyOnWriteArrayList<Feature> features = new CopyOnWriteArrayList();

    public FeatureDirector() {
        features.add(new SafeWalk());
        features.add(new DMGSpeed());
        features.add(new Xray());
        features.add(new ClientFont());
        features.add(new ElytraFlight());
        features.add(new AutoTPAccept());
        features.add(new MultiAction());
        features.add(new Optimization());
        features.add(new NoServerRotations());
        features.add(new AutoPotion());
        features.add(new AntiPearlBlocker());
        features.add(new Phase());
        features.add(new AutoGapple());
        features.add(new OnHealth());
        features.add(new DamageFly());
        features.add(new TestFeature());
        features.add(new ElytraSwap());
        features.add(new PersonViewer());
        features.add(new WorldColor());
        features.add(new Crosshair());
        features.add(new EClip());
        features.add(new GlideFly());
        features.add(new ElytraLeave());
        features.add(new Strafe());
        features.add(new ElytraSpeed());
        features.add(new FastEat());
        features.add(new GAppleTimer());
        features.add(new CustomModel());
        features.add(new Spider());
        features.add(new HackerDetector());
        features.add(new AirStuck());
        features.add(new PerlLeave());
        features.add(new HitBox());
        features.add(new ChestEsp());
        features.add(new HighJump());
        features.add(new PlayerFinder());
        features.add(new Timer());
        features.add(new ESP());
        features.add(new AutoVClip());
        features.add(new Indicators());
        features.add(new AutoTool());
        features.add(new FlagDetector());
        features.add(new TeleportExploit());
        features.add(new TargetStrafe());
        features.add(new GuiMove());
        features.add(new ShieldDesync());
        features.add(new DamageParticles());
        features.add(new NoWeb());
        features.add(new Notifications());
        features.add(new WaterLeave());
        features.add(new AntiBot());
        features.add(new Jesus());
        features.add(new StaffAlert());
        features.add(new JumpCircle());
        features.add(new Trails());
        features.add(new KeepSprint());
        features.add(new PlayerList());
        features.add(new Chams());
        features.add(new AirJump());
        features.add(new NoClip());
        features.add(new WaterSpeed());
        features.add(new NoFriendDamage());
        features.add(new Tracers());
        features.add(new NoFall());
        features.add(new NoRender());
        features.add(new FullBright());
        features.add(new LongJump());
        features.add(new Hotbar());
        features.add(new TargetESP());
        features.add(new DeathCoordinates());
        features.add(new Velocity());
        features.add(new PotionHUD());
        features.add(new SuperBow());
        features.add(new ClickGUI());
        features.add(new NoInteract());
        features.add(new MCF());
        features.add(new NoPush());
        features.add(new SwingAnimations());
        features.add(new FreeCam());
        features.add(new NameProtect());
        features.add(new ChinaHat());
        features.add(new ModuleSoundAlert());
        features.add(new Watermark());
        features.add(new KillAura());
        features.add(new ItemScroller());
        features.add(new Flight());
        features.add(new ScoreBoard());
        features.add(new NameTags());
        features.add(new SpeedMine());
        features.add(new ChestStealer());
        features.add(new MiddleClickPearl());
        features.add(new AutoSprint());
        features.add(new Step());
        features.add(new PearlESP());
        features.add(new TriggerBot());
        features.add(new ViewModel());
        features.add(new NoSlowDown());
        features.add(new NoDelay());
        features.add(new Speed());
        features.add(new HUD());
        features.add(new AutoArmor());
        features.add(new AutoTotem());
        features.add(new FastWorldLoad());
        features.add(new ArreyList());
    }

    public List<Feature> getFeatureList() {
        return features;
    }

    public List<Feature> getFeaturesForCategory(Category category) {
        ArrayList<Feature> featureList = new ArrayList<Feature>();
        for (Feature feature : this.getFeatureList()) {
            if (feature.getCategory() != category) continue;
            featureList.add(feature);
        }
        return featureList;
    }

    public Feature getFeatureByClass(Class<? extends Feature> classFeature) {
        for (Feature feature : this.getFeatureList()) {
            if (feature == null || feature.getClass() != classFeature) continue;
            return feature;
        }
        return null;
    }

    public Feature getFeatureByLabel(String name) {
        for (Feature feature : this.getFeatureList()) {
            if (!feature.getLabel().equals(name)) continue;
            return feature;
        }
        return null;
    }
}

