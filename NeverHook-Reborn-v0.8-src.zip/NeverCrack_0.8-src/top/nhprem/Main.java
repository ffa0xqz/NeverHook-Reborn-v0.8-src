/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Keyboard
 *  org.lwjgl.opengl.Display
 */
package top.nhprem;

import java.io.IOException;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;
import top.nhprem.api.changelogs.ChangeManager;
import top.nhprem.api.command.CommandManager;
import top.nhprem.api.command.impl.macro.Macro;
import top.nhprem.api.command.impl.macro.MacroManager;
import top.nhprem.api.event.EventManager;
import top.nhprem.api.event.EventTarget;
import top.nhprem.api.event.event.EventKey;
import top.nhprem.api.guis.draggable.DraggableHUD;
import top.nhprem.api.socket.Client;
import top.nhprem.api.utils.friend.FriendManager;
import top.nhprem.api.utils.other.DiscordHelper;
import top.nhprem.api.utils.shader.ShaderShell;
import top.nhprem.api.utils.world.TimerHelper;
import top.nhprem.client.features.Feature;
import top.nhprem.client.features.FeatureDirector;
import top.nhprem.client.ui.altmanager.alt.AltManager;
import top.nhprem.client.ui.clickgui.ClickGuiScreen;
import top.nhprem.client.ui.settings.FileManager;
import top.nhprem.client.ui.settings.config.ConfigManager;
import top.nhprem.client.ui.settings.impls.AltConfig;
import top.nhprem.client.ui.settings.impls.FriendConfig;
import top.nhprem.client.ui.settings.impls.MacroConfig;

public class Main {
    public static Main instance = new Main();
    public String name = "NeverHook Premium";
    public static String version = " 0.8";
    public EventManager eventManager;
    public FeatureDirector featureDirector;
    public ConfigManager configManager;
    public FriendManager friendManager;
    public FileManager fileManager;
    public AltManager altManager;
    private DraggableHUD draggableHUD;
    public ChangeManager changeManager;
    public MacroManager macroManager;
    public CommandManager commandManager;
    public Client client;
    public ClickGuiScreen clickGui;
    private final TimerHelper timer = new TimerHelper();

    public DraggableHUD getDraggableHUD() {
        return this.draggableHUD;
    }

    public static double deltaTime() {
        return bhz.af() > 0 ? 1.0 / (double)bhz.af() : 1.0;
    }

    public void reloadCFGManager() {
        this.configManager = new ConfigManager();
    }

    public void startClient() throws IOException {
        ShaderShell.init();
        this.client = new Client();
        this.eventManager = new EventManager();
        this.featureDirector = new FeatureDirector();
        this.reloadCFGManager();
        this.commandManager = new CommandManager();
        this.macroManager = new MacroManager();
        this.altManager = new AltManager();
        this.changeManager = new ChangeManager();
        this.draggableHUD = new DraggableHUD();
        this.clickGui = new ClickGuiScreen();
        this.friendManager = new FriendManager();
        DiscordHelper.startRPC();
        this.fileManager = new FileManager();
        this.fileManager.loadFiles();
        Display.setTitle((String)(this.name + " " + version));
        try {
            this.fileManager.getFile(FriendConfig.class).loadFile();
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            this.fileManager.getFile(MacroConfig.class).loadFile();
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            this.fileManager.getFile(AltConfig.class).loadFile();
        }
        catch (Exception exception) {
            // empty catch block
        }
        EventManager.register(this);
    }

    public Client getClient() {
        return this.client;
    }

    public void playSound(String name, int volume) {
        new Thread(() -> {
            try {
                Clip clip = AudioSystem.getClip();
                AudioInputStream inputStream = AudioSystem.getAudioInputStream(Main.class.getResourceAsStream("/assets/minecraft/neverhook/songs/" + name));
                clip.open(inputStream);
                FloatControl control = (FloatControl)clip.getControl(FloatControl.Type.MASTER_GAIN);
                float range = control.getMinimum();
                float result = range * (1.0f - (float)volume / 100.0f);
                control.setValue(result);
                clip.start();
            }
            catch (Exception exception) {
                // empty catch block
            }
        }).start();
    }

    public void stopClient() {
        EventManager.unregister(instance);
        this.fileManager = new FileManager();
        this.fileManager.saveFiles();
        DiscordHelper.stopRPC();
    }

    public static void msg(String s2, boolean prefix) {
        s2 = (prefix ? "\u00a77[" + (Object)((Object)a.m) + "N" + (Object)((Object)a.p) + "ever" + (Object)((Object)a.m) + "H" + (Object)((Object)a.p) + "ook" + (Object)((Object)a.v) + "\u00a77] " + (Object)((Object)a.v) + ": " : "") + s2;
        bhz.z().h.a(new hp(s2.replace("&", "??"), new Object[0]));
    }

    public static Main getInstance() {
        if (instance == null) {
            instance = new Main();
        }
        return instance;
    }

    @EventTarget
    public void onKey1(EventKey event) {
        for (Macro macro : this.macroManager.getMacros()) {
            if (macro.getKey() != Keyboard.getEventKey() || !(bhz.z().h.cd() > 0.0f) || bhz.z().h == null) continue;
            bhz.z().h.g(macro.getValue());
        }
    }

    @EventTarget
    public void onKey(EventKey event) {
        for (Feature feature : this.featureDirector.getFeatureList()) {
            if (feature.getKey() != event.getKey()) continue;
            feature.toggle();
        }
    }
}

