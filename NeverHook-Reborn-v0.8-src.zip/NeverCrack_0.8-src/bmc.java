/*
 * Decompiled with CFR 0.150.
 */
public class bmc
extends bli {
    private static final bib.a[] h = new bib.a[]{bib.a.a, bib.a.b, bib.a.y, bib.a.M};
    private final bli i;
    protected String a = "Controls";
    private final bib s;
    public bhw f;
    public long g;
    private bmb t;
    private biy u;

    public bmc(bli bli2, bib bib2) {
        this.i = bli2;
        this.s = bib2;
    }

    @Override
    public void b() {
        this.t = new bmb(this, this.j);
        this.n.add(new biy(200, this.l / 2 - 155 + 160, this.m - 29, 150, 20, cew.a("gui.done", new Object[0])));
        this.u = this.b(new biy(201, this.l / 2 - 155, this.m - 29, 150, 20, cew.a("controls.resetAll", new Object[0])));
        this.a = cew.a("controls.title", new Object[0]);
        int n2 = 0;
        for (bib.a a2 : h) {
            if (a2.a()) {
                this.n.add(new bjq(a2.c(), this.l / 2 - 155 + n2 % 2 * 160, 18 + 24 * (n2 >> 1), a2));
            } else {
                this.n.add(new bjl(a2.c(), this.l / 2 - 155 + n2 % 2 * 160, 18 + 24 * (n2 >> 1), a2, this.s.c(a2)));
            }
            ++n2;
        }
    }

    @Override
    public void k() {
        super.k();
        this.t.p();
    }

    @Override
    protected void a(biy biy22) {
        biy biy22;
        if (biy22.k == 200) {
            this.j.a(this.i);
        } else if (biy22.k == 201) {
            for (bhw bhw2 : this.j.t.as) {
                bhw2.b(bhw2.i());
            }
            bhw.c();
        } else if (biy22.k < 100 && biy22 instanceof bjl) {
            this.s.a(((bjl)biy22).c(), 1);
            biy22.j = this.s.c(bib.a.a(biy22.k));
        }
    }

    @Override
    protected void a(int n2, int n3, int n4) {
        if (this.f != null) {
            this.s.a(this.f, -100 + n4);
            this.f = null;
            bhw.c();
        } else if (n4 != 0 || !this.t.a(n2, n3, n4)) {
            super.a(n2, n3, n4);
        }
    }

    @Override
    protected void b(int n2, int n3, int n4) {
        if (n4 != 0 || !this.t.b(n2, n3, n4)) {
            super.b(n2, n3, n4);
        }
    }

    @Override
    protected void a(char c2, int n2) {
        if (this.f != null) {
            if (n2 == 1) {
                this.s.a(this.f, 0);
            } else if (n2 != 0) {
                this.s.a(this.f, n2);
            } else if (c2 > '\u0000') {
                this.s.a(this.f, c2 + 256);
            }
            this.f = null;
            this.g = bhz.I();
            bhw.c();
        } else {
            super.a(c2, n2);
        }
    }

    @Override
    public void a(int n2, int n3, float f2) {
        this.c();
        this.t.a(n2, n3, f2);
        this.a(this.q, this.a, this.l / 2, 8, 0xFFFFFF);
        boolean bl2 = false;
        for (bhw bhw2 : this.s.as) {
            if (bhw2.j() == bhw2.i()) continue;
            bl2 = true;
            break;
        }
        this.u.l = bl2;
        super.a(n2, n3, f2);
    }
}

