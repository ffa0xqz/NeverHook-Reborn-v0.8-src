/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

public class dc
extends bi {
    @Override
    public String c() {
        return "save-all";
    }

    @Override
    public String b(bn bn2) {
        return "commands.save.usage";
    }

    @Override
    public void a(MinecraftServer minecraftServer, bn bn2, String[] arrstring) throws ei {
        bn2.a(new hp("commands.save.start", new Object[0]));
        if (minecraftServer.am() != null) {
            minecraftServer.am().j();
        }
        try {
            boolean \u26032;
            int \u26033;
            for (\u26033 = 0; \u26033 < minecraftServer.d.length; ++\u26033) {
                if (minecraftServer.d[\u26033] == null) continue;
                om om2 = minecraftServer.d[\u26033];
                \u26032 = om2.b;
                om2.b = false;
                om2.a(true, null);
                om2.b = \u26032;
            }
            if (arrstring.length > 0 && "flush".equals(arrstring[0])) {
                bn2.a(new hp("commands.save.flushStart", new Object[0]));
                for (\u26033 = 0; \u26033 < minecraftServer.d.length; ++\u26033) {
                    if (minecraftServer.d[\u26033] == null) continue;
                    om2 = minecraftServer.d[\u26033];
                    \u26032 = om2.b;
                    om2.b = false;
                    om2.q();
                    om2.b = \u26032;
                }
                bn2.a(new hp("commands.save.flushEnd", new Object[0]));
            }
        }
        catch (amt amt2) {
            dc.a(bn2, (bk)this, "commands.save.failed", amt2.getMessage());
            return;
        }
        dc.a(bn2, (bk)this, "commands.save.success", new Object[0]);
    }

    @Override
    public List<String> a(MinecraftServer minecraftServer, bn bn2, String[] arrstring, @Nullable et et2) {
        if (arrstring.length == 1) {
            return dc.a(arrstring, "flush");
        }
        return Collections.emptyList();
    }
}

