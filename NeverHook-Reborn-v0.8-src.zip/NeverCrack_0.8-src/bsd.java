/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.common.collect.Lists;
import java.io.File;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class bsd {
    private static final Logger a = LogManager.getLogger();
    private final bhz b;
    private final List<bsc> c = Lists.newArrayList();

    public bsd(bhz bhz2) {
        this.b = bhz2;
        this.a();
    }

    public void a() {
        try {
            this.c.clear();
            fy fy2 = gi.a(new File(this.b.w, "servers.dat"));
            if (fy2 == null) {
                return;
            }
            ge \u26032 = fy2.c("servers", 10);
            for (int i2 = 0; i2 < \u26032.c(); ++i2) {
                this.c.add(bsc.a(\u26032.b(i2)));
            }
        }
        catch (Exception exception) {
            a.error("Couldn't load server list", (Throwable)exception);
        }
    }

    public void b() {
        try {
            ge ge2 = new ge();
            for (bsc bsc2 : this.c) {
                ge2.a(bsc2.a());
            }
            fy fy2 = new fy();
            fy2.a("servers", ge2);
            gi.a(fy2, new File(this.b.w, "servers.dat"));
        }
        catch (Exception exception) {
            a.error("Couldn't save server list", (Throwable)exception);
        }
    }

    public bsc a(int n2) {
        return this.c.get(n2);
    }

    public void b(int n2) {
        this.c.remove(n2);
    }

    public void a(bsc bsc2) {
        this.c.add(bsc2);
    }

    public int c() {
        return this.c.size();
    }

    public void a(int n2, int n3) {
        bsc bsc2 = this.a(n2);
        this.c.set(n2, this.a(n3));
        this.c.set(n3, bsc2);
        this.b();
    }

    public void a(int n2, bsc bsc2) {
        this.c.set(n2, bsc2);
    }

    public static void b(bsc bsc2) {
        bsd bsd2 = new bsd(bhz.z());
        bsd2.a();
        for (int i2 = 0; i2 < bsd2.c(); ++i2) {
            bsc bsc3 = bsd2.a(i2);
            if (!bsc3.a.equals(bsc2.a) || !bsc3.b.equals(bsc2.b)) continue;
            bsd2.a(i2, bsc2);
            break;
        }
        bsd2.b();
    }
}

