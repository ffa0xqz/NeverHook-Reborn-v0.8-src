/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 */
import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class bbn {
    public static void a() {
        bbt.a(h.class, "OMB");
        bbt.a(j.class, "OMCR");
        bbt.a(k.class, "OMDXR");
        bbt.a(l.class, "OMDXYR");
        bbt.a(m.class, "OMDYR");
        bbt.a(n.class, "OMDYZR");
        bbt.a(o.class, "OMDZR");
        bbt.a(p.class, "OMEntry");
        bbt.a(q.class, "OMPenthouse");
        bbt.a(s.class, "OMSimple");
        bbt.a(t.class, "OMSimpleT");
    }

    static class d
    implements i {
        private d() {
        }

        @Override
        public boolean a(v v2) {
            if (v2.c[fa.c.a()] && !v2.b[fa.c.a()].d && v2.c[fa.b.a()] && !v2.b[fa.b.a()].d) {
                \u2603 = v2.b[fa.c.a()];
                return \u2603.c[fa.b.a()] && !\u2603.b[fa.b.a()].d;
            }
            return false;
        }

        @Override
        public r a(fa fa2, v v2, Random random) {
            v2.d = true;
            v2.b[fa.c.a()].d = true;
            v2.b[fa.b.a()].d = true;
            v2.b[fa.c.a()].b[fa.b.a()].d = true;
            return new n(fa2, v2, random);
        }
    }

    static class b
    implements i {
        private b() {
        }

        @Override
        public boolean a(v v2) {
            if (v2.c[fa.f.a()] && !v2.b[fa.f.a()].d && v2.c[fa.b.a()] && !v2.b[fa.b.a()].d) {
                \u2603 = v2.b[fa.f.a()];
                return \u2603.c[fa.b.a()] && !\u2603.b[fa.b.a()].d;
            }
            return false;
        }

        @Override
        public r a(fa fa2, v v2, Random random) {
            v2.d = true;
            v2.b[fa.f.a()].d = true;
            v2.b[fa.b.a()].d = true;
            v2.b[fa.f.a()].b[fa.b.a()].d = true;
            return new l(fa2, v2, random);
        }
    }

    static class e
    implements i {
        private e() {
        }

        @Override
        public boolean a(v v2) {
            return v2.c[fa.c.a()] && !v2.b[fa.c.a()].d;
        }

        @Override
        public r a(fa fa2, v v2, Random random) {
            v v3 = v2;
            if (!v2.c[fa.c.a()] || v2.b[fa.c.a()].d) {
                v3 = v2.b[fa.d.a()];
            }
            v3.d = true;
            v3.b[fa.c.a()].d = true;
            return new o(fa2, v3, random);
        }
    }

    static class a
    implements i {
        private a() {
        }

        @Override
        public boolean a(v v2) {
            return v2.c[fa.f.a()] && !v2.b[fa.f.a()].d;
        }

        @Override
        public r a(fa fa2, v v2, Random random) {
            v2.d = true;
            v2.b[fa.f.a()].d = true;
            return new k(fa2, v2, random);
        }
    }

    static class c
    implements i {
        private c() {
        }

        @Override
        public boolean a(v v2) {
            return v2.c[fa.b.a()] && !v2.b[fa.b.a()].d;
        }

        @Override
        public r a(fa fa2, v v2, Random random) {
            v2.d = true;
            v2.b[fa.b.a()].d = true;
            return new m(fa2, v2, random);
        }
    }

    static class g
    implements i {
        private g() {
        }

        @Override
        public boolean a(v v2) {
            return !v2.c[fa.e.a()] && !v2.c[fa.f.a()] && !v2.c[fa.c.a()] && !v2.c[fa.d.a()] && !v2.c[fa.b.a()];
        }

        @Override
        public r a(fa fa2, v v2, Random random) {
            v2.d = true;
            return new t(fa2, v2, random);
        }
    }

    static class f
    implements i {
        private f() {
        }

        @Override
        public boolean a(v v2) {
            return true;
        }

        @Override
        public r a(fa fa2, v v2, Random random) {
            v2.d = true;
            return new s(fa2, v2, random);
        }
    }

    static interface i {
        public boolean a(v var1);

        public r a(fa var1, v var2, Random var3);
    }

    static class v {
        int a;
        v[] b = new v[6];
        boolean[] c = new boolean[6];
        boolean d;
        boolean e;
        int f;

        public v(int n2) {
            this.a = n2;
        }

        public void a(fa fa2, v v2) {
            this.b[fa2.a()] = v2;
            v2.b[fa2.d().a()] = this;
        }

        public void a() {
            for (int i2 = 0; i2 < 6; ++i2) {
                this.c[i2] = this.b[i2] != null;
            }
        }

        public boolean a(int n2) {
            if (this.e) {
                return true;
            }
            this.f = n2;
            for (\u2603 = 0; \u2603 < 6; ++\u2603) {
                if (this.b[\u2603] == null || !this.c[\u2603] || this.b[\u2603].f == n2 || !this.b[\u2603].a(n2)) continue;
                return true;
            }
            return false;
        }

        public boolean b() {
            return this.a >= 75;
        }

        public int c() {
            int n2 = 0;
            for (\u2603 = 0; \u2603 < 6; ++\u2603) {
                if (!this.c[\u2603]) continue;
                ++n2;
            }
            return n2;
        }
    }

    public static class q
    extends r {
        public q() {
        }

        public q(fa fa2, bbe bbe2) {
            super(fa2, bbe2);
        }

        @Override
        public boolean a(ams ams22, Random random, bbe bbe2) {
            ams ams22;
            int \u26032;
            this.a(ams22, bbe2, 2, -1, 2, 11, -1, 11, b, b, false);
            this.a(ams22, bbe2, 0, -1, 0, 1, -1, 11, a, a, false);
            this.a(ams22, bbe2, 12, -1, 0, 13, -1, 11, a, a, false);
            this.a(ams22, bbe2, 2, -1, 0, 11, -1, 1, a, a, false);
            this.a(ams22, bbe2, 2, -1, 12, 11, -1, 13, a, a, false);
            this.a(ams22, bbe2, 0, 0, 0, 0, 0, 13, b, b, false);
            this.a(ams22, bbe2, 13, 0, 0, 13, 0, 13, b, b, false);
            this.a(ams22, bbe2, 1, 0, 0, 12, 0, 0, b, b, false);
            this.a(ams22, bbe2, 1, 0, 13, 12, 0, 13, b, b, false);
            for (\u26032 = 2; \u26032 <= 11; \u26032 += 3) {
                this.a(ams22, e, 0, 0, \u26032, bbe2);
                this.a(ams22, e, 13, 0, \u26032, bbe2);
                this.a(ams22, e, \u26032, 0, 0, bbe2);
            }
            this.a(ams22, bbe2, 2, 0, 3, 4, 0, 9, b, b, false);
            this.a(ams22, bbe2, 9, 0, 3, 11, 0, 9, b, b, false);
            this.a(ams22, bbe2, 4, 0, 9, 9, 0, 11, b, b, false);
            this.a(ams22, b, 5, 0, 8, bbe2);
            this.a(ams22, b, 8, 0, 8, bbe2);
            this.a(ams22, b, 10, 0, 10, bbe2);
            this.a(ams22, b, 3, 0, 10, bbe2);
            this.a(ams22, bbe2, 3, 0, 3, 3, 0, 7, c, c, false);
            this.a(ams22, bbe2, 10, 0, 3, 10, 0, 7, c, c, false);
            this.a(ams22, bbe2, 6, 0, 10, 7, 0, 10, c, c, false);
            \u26032 = 3;
            for (int i2 = 0; i2 < 2; ++i2) {
                for (\u2603 = 2; \u2603 <= 8; \u2603 += 3) {
                    this.a(ams22, bbe2, \u26032, 0, \u2603, \u26032, 2, \u2603, b, b, false);
                }
                \u26032 = 10;
            }
            this.a(ams22, bbe2, 5, 0, 10, 5, 2, 10, b, b, false);
            this.a(ams22, bbe2, 8, 0, 10, 8, 2, 10, b, b, false);
            this.a(ams22, bbe2, 6, -1, 7, 7, -1, 8, c, c, false);
            this.a(ams22, bbe2, 6, -1, 3, 7, -1, 4, false);
            this.a(ams22, bbe2, 6, 1, 6);
            return true;
        }
    }

    public static class u
    extends r {
        private int n;

        public u() {
        }

        public u(fa fa2, bbe bbe2, int n2) {
            super(fa2, bbe2);
            this.n = n2 & 1;
        }

        @Override
        public boolean a(ams ams22, Random random, bbe bbe2) {
            ams ams22;
            if (this.n == 0) {
                int n2;
                for (n2 = 0; n2 < 4; ++n2) {
                    this.a(ams22, bbe2, 10 - n2, 3 - n2, 20 - n2, 12 + n2, 3 - n2, 20, b, b, false);
                }
                this.a(ams22, bbe2, 7, 0, 6, 15, 0, 16, b, b, false);
                this.a(ams22, bbe2, 6, 0, 6, 6, 3, 20, b, b, false);
                this.a(ams22, bbe2, 16, 0, 6, 16, 3, 20, b, b, false);
                this.a(ams22, bbe2, 7, 1, 7, 7, 1, 20, b, b, false);
                this.a(ams22, bbe2, 15, 1, 7, 15, 1, 20, b, b, false);
                this.a(ams22, bbe2, 7, 1, 6, 9, 3, 6, b, b, false);
                this.a(ams22, bbe2, 13, 1, 6, 15, 3, 6, b, b, false);
                this.a(ams22, bbe2, 8, 1, 7, 9, 1, 7, b, b, false);
                this.a(ams22, bbe2, 13, 1, 7, 14, 1, 7, b, b, false);
                this.a(ams22, bbe2, 9, 0, 5, 13, 0, 5, b, b, false);
                this.a(ams22, bbe2, 10, 0, 7, 12, 0, 7, c, c, false);
                this.a(ams22, bbe2, 8, 0, 10, 8, 0, 12, c, c, false);
                this.a(ams22, bbe2, 14, 0, 10, 14, 0, 12, c, c, false);
                for (n2 = 18; n2 >= 7; n2 -= 3) {
                    this.a(ams22, e, 6, 3, n2, bbe2);
                    this.a(ams22, e, 16, 3, n2, bbe2);
                }
                this.a(ams22, e, 10, 0, 10, bbe2);
                this.a(ams22, e, 12, 0, 10, bbe2);
                this.a(ams22, e, 10, 0, 12, bbe2);
                this.a(ams22, e, 12, 0, 12, bbe2);
                this.a(ams22, e, 8, 3, 6, bbe2);
                this.a(ams22, e, 14, 3, 6, bbe2);
                this.a(ams22, b, 4, 2, 4, bbe2);
                this.a(ams22, e, 4, 1, 4, bbe2);
                this.a(ams22, b, 4, 0, 4, bbe2);
                this.a(ams22, b, 18, 2, 4, bbe2);
                this.a(ams22, e, 18, 1, 4, bbe2);
                this.a(ams22, b, 18, 0, 4, bbe2);
                this.a(ams22, b, 4, 2, 18, bbe2);
                this.a(ams22, e, 4, 1, 18, bbe2);
                this.a(ams22, b, 4, 0, 18, bbe2);
                this.a(ams22, b, 18, 2, 18, bbe2);
                this.a(ams22, e, 18, 1, 18, bbe2);
                this.a(ams22, b, 18, 0, 18, bbe2);
                this.a(ams22, b, 9, 7, 20, bbe2);
                this.a(ams22, b, 13, 7, 20, bbe2);
                this.a(ams22, bbe2, 6, 0, 21, 7, 4, 21, b, b, false);
                this.a(ams22, bbe2, 15, 0, 21, 16, 4, 21, b, b, false);
                this.a(ams22, bbe2, 11, 2, 16);
            } else if (this.n == 1) {
                int n3;
                this.a(ams22, bbe2, 9, 3, 18, 13, 3, 20, b, b, false);
                this.a(ams22, bbe2, 9, 0, 18, 9, 2, 18, b, b, false);
                this.a(ams22, bbe2, 13, 0, 18, 13, 2, 18, b, b, false);
                int \u26032 = 9;
                int \u26033 = 20;
                int \u26034 = 5;
                for (n3 = 0; n3 < 2; ++n3) {
                    this.a(ams22, b, \u26032, 6, 20, bbe2);
                    this.a(ams22, e, \u26032, 5, 20, bbe2);
                    this.a(ams22, b, \u26032, 4, 20, bbe2);
                    \u26032 = 13;
                }
                this.a(ams22, bbe2, 7, 3, 7, 15, 3, 14, b, b, false);
                \u26032 = 10;
                for (n3 = 0; n3 < 2; ++n3) {
                    this.a(ams22, bbe2, \u26032, 0, 10, \u26032, 6, 10, b, b, false);
                    this.a(ams22, bbe2, \u26032, 0, 12, \u26032, 6, 12, b, b, false);
                    this.a(ams22, e, \u26032, 0, 10, bbe2);
                    this.a(ams22, e, \u26032, 0, 12, bbe2);
                    this.a(ams22, e, \u26032, 4, 10, bbe2);
                    this.a(ams22, e, \u26032, 4, 12, bbe2);
                    \u26032 = 12;
                }
                \u26032 = 8;
                for (n3 = 0; n3 < 2; ++n3) {
                    this.a(ams22, bbe2, \u26032, 0, 7, \u26032, 2, 7, b, b, false);
                    this.a(ams22, bbe2, \u26032, 0, 14, \u26032, 2, 14, b, b, false);
                    \u26032 = 14;
                }
                this.a(ams22, bbe2, 8, 3, 8, 8, 3, 13, c, c, false);
                this.a(ams22, bbe2, 14, 3, 8, 14, 3, 13, c, c, false);
                this.a(ams22, bbe2, 11, 5, 13);
            }
            return true;
        }
    }

    public static class j
    extends r {
        public j() {
        }

        public j(fa fa2, v v2, Random random) {
            super(1, fa2, v2, 2, 2, 2);
        }

        @Override
        public boolean a(ams ams2, Random random, bbe bbe2) {
            this.a(ams2, bbe2, 1, 8, 0, 14, 8, 14, a);
            int n2 = 7;
            awr \u26032 = b;
            this.a(ams2, bbe2, 0, 7, 0, 0, 7, 15, \u26032, \u26032, false);
            this.a(ams2, bbe2, 15, 7, 0, 15, 7, 15, \u26032, \u26032, false);
            this.a(ams2, bbe2, 1, 7, 0, 15, 7, 0, \u26032, \u26032, false);
            this.a(ams2, bbe2, 1, 7, 15, 14, 7, 15, \u26032, \u26032, false);
            for (n2 = 1; n2 <= 6; ++n2) {
                \u26032 = b;
                if (n2 == 2 || n2 == 6) {
                    \u26032 = a;
                }
                for (\u2603 = 0; \u2603 <= 15; \u2603 += 15) {
                    this.a(ams2, bbe2, \u2603, n2, 0, \u2603, n2, 1, \u26032, \u26032, false);
                    this.a(ams2, bbe2, \u2603, n2, 6, \u2603, n2, 9, \u26032, \u26032, false);
                    this.a(ams2, bbe2, \u2603, n2, 14, \u2603, n2, 15, \u26032, \u26032, false);
                }
                this.a(ams2, bbe2, 1, n2, 0, 1, n2, 0, \u26032, \u26032, false);
                this.a(ams2, bbe2, 6, n2, 0, 9, n2, 0, \u26032, \u26032, false);
                this.a(ams2, bbe2, 14, n2, 0, 14, n2, 0, \u26032, \u26032, false);
                this.a(ams2, bbe2, 1, n2, 15, 14, n2, 15, \u26032, \u26032, false);
            }
            this.a(ams2, bbe2, 6, 3, 6, 9, 6, 9, c, c, false);
            this.a(ams2, bbe2, 7, 4, 7, 8, 5, 8, aov.R.t(), aov.R.t(), false);
            for (n2 = 3; n2 <= 6; n2 += 3) {
                for (\u2603 = 6; \u2603 <= 9; \u2603 += 3) {
                    this.a(ams2, e, \u2603, n2, 6, bbe2);
                    this.a(ams2, e, \u2603, n2, 9, bbe2);
                }
            }
            this.a(ams2, bbe2, 5, 1, 6, 5, 2, 6, b, b, false);
            this.a(ams2, bbe2, 5, 1, 9, 5, 2, 9, b, b, false);
            this.a(ams2, bbe2, 10, 1, 6, 10, 2, 6, b, b, false);
            this.a(ams2, bbe2, 10, 1, 9, 10, 2, 9, b, b, false);
            this.a(ams2, bbe2, 6, 1, 5, 6, 2, 5, b, b, false);
            this.a(ams2, bbe2, 9, 1, 5, 9, 2, 5, b, b, false);
            this.a(ams2, bbe2, 6, 1, 10, 6, 2, 10, b, b, false);
            this.a(ams2, bbe2, 9, 1, 10, 9, 2, 10, b, b, false);
            this.a(ams2, bbe2, 5, 2, 5, 5, 6, 5, b, b, false);
            this.a(ams2, bbe2, 5, 2, 10, 5, 6, 10, b, b, false);
            this.a(ams2, bbe2, 10, 2, 5, 10, 6, 5, b, b, false);
            this.a(ams2, bbe2, 10, 2, 10, 10, 6, 10, b, b, false);
            this.a(ams2, bbe2, 5, 7, 1, 5, 7, 6, b, b, false);
            this.a(ams2, bbe2, 10, 7, 1, 10, 7, 6, b, b, false);
            this.a(ams2, bbe2, 5, 7, 9, 5, 7, 14, b, b, false);
            this.a(ams2, bbe2, 10, 7, 9, 10, 7, 14, b, b, false);
            this.a(ams2, bbe2, 1, 7, 5, 6, 7, 5, b, b, false);
            this.a(ams2, bbe2, 1, 7, 10, 6, 7, 10, b, b, false);
            this.a(ams2, bbe2, 9, 7, 5, 14, 7, 5, b, b, false);
            this.a(ams2, bbe2, 9, 7, 10, 14, 7, 10, b, b, false);
            this.a(ams2, bbe2, 2, 1, 2, 2, 1, 3, b, b, false);
            this.a(ams2, bbe2, 3, 1, 2, 3, 1, 2, b, b, false);
            this.a(ams2, bbe2, 13, 1, 2, 13, 1, 3, b, b, false);
            this.a(ams2, bbe2, 12, 1, 2, 12, 1, 2, b, b, false);
            this.a(ams2, bbe2, 2, 1, 12, 2, 1, 13, b, b, false);
            this.a(ams2, bbe2, 3, 1, 13, 3, 1, 13, b, b, false);
            this.a(ams2, bbe2, 13, 1, 12, 13, 1, 13, b, b, false);
            this.a(ams2, bbe2, 12, 1, 13, 12, 1, 13, b, b, false);
            return true;
        }
    }

    public static class n
    extends r {
        public n() {
        }

        public n(fa fa2, v v2, Random random) {
            super(1, fa2, v2, 1, 2, 2);
        }

        @Override
        public boolean a(ams ams2, Random random, bbe bbe2) {
            v v2;
            awr awr2;
            int n2;
            v v3 = this.k.b[fa.c.a()];
            v2 = this.k;
            \u2603 = v3.b[fa.b.a()];
            \u2603 = v2.b[fa.b.a()];
            if (this.k.a / 25 > 0) {
                this.a(ams2, bbe2, 0, 8, v3.c[fa.a.a()]);
                this.a(ams2, bbe2, 0, 0, v2.c[fa.a.a()]);
            }
            if (\u2603.b[fa.b.a()] == null) {
                this.a(ams2, bbe2, 1, 8, 1, 6, 8, 7, a);
            }
            if (\u2603.b[fa.b.a()] == null) {
                this.a(ams2, bbe2, 1, 8, 8, 6, 8, 14, a);
            }
            for (n2 = 1; n2 <= 7; ++n2) {
                awr2 = b;
                if (n2 == 2 || n2 == 6) {
                    awr2 = a;
                }
                this.a(ams2, bbe2, 0, n2, 0, 0, n2, 15, awr2, awr2, false);
                this.a(ams2, bbe2, 7, n2, 0, 7, n2, 15, awr2, awr2, false);
                this.a(ams2, bbe2, 1, n2, 0, 6, n2, 0, awr2, awr2, false);
                this.a(ams2, bbe2, 1, n2, 15, 6, n2, 15, awr2, awr2, false);
            }
            for (n2 = 1; n2 <= 7; ++n2) {
                awr2 = c;
                if (n2 == 2 || n2 == 6) {
                    awr2 = e;
                }
                this.a(ams2, bbe2, 3, n2, 7, 4, n2, 8, awr2, awr2, false);
            }
            if (v2.c[fa.d.a()]) {
                this.a(ams2, bbe2, 3, 1, 0, 4, 2, 0, false);
            }
            if (v2.c[fa.f.a()]) {
                this.a(ams2, bbe2, 7, 1, 3, 7, 2, 4, false);
            }
            if (v2.c[fa.e.a()]) {
                this.a(ams2, bbe2, 0, 1, 3, 0, 2, 4, false);
            }
            if (v3.c[fa.c.a()]) {
                this.a(ams2, bbe2, 3, 1, 15, 4, 2, 15, false);
            }
            if (v3.c[fa.e.a()]) {
                this.a(ams2, bbe2, 0, 1, 11, 0, 2, 12, false);
            }
            if (v3.c[fa.f.a()]) {
                this.a(ams2, bbe2, 7, 1, 11, 7, 2, 12, false);
            }
            if (\u2603.c[fa.d.a()]) {
                this.a(ams2, bbe2, 3, 5, 0, 4, 6, 0, false);
            }
            if (\u2603.c[fa.f.a()]) {
                this.a(ams2, bbe2, 7, 5, 3, 7, 6, 4, false);
                this.a(ams2, bbe2, 5, 4, 2, 6, 4, 5, b, b, false);
                this.a(ams2, bbe2, 6, 1, 2, 6, 3, 2, b, b, false);
                this.a(ams2, bbe2, 6, 1, 5, 6, 3, 5, b, b, false);
            }
            if (\u2603.c[fa.e.a()]) {
                this.a(ams2, bbe2, 0, 5, 3, 0, 6, 4, false);
                this.a(ams2, bbe2, 1, 4, 2, 2, 4, 5, b, b, false);
                this.a(ams2, bbe2, 1, 1, 2, 1, 3, 2, b, b, false);
                this.a(ams2, bbe2, 1, 1, 5, 1, 3, 5, b, b, false);
            }
            if (\u2603.c[fa.c.a()]) {
                this.a(ams2, bbe2, 3, 5, 15, 4, 6, 15, false);
            }
            if (\u2603.c[fa.e.a()]) {
                this.a(ams2, bbe2, 0, 5, 11, 0, 6, 12, false);
                this.a(ams2, bbe2, 1, 4, 10, 2, 4, 13, b, b, false);
                this.a(ams2, bbe2, 1, 1, 10, 1, 3, 10, b, b, false);
                this.a(ams2, bbe2, 1, 1, 13, 1, 3, 13, b, b, false);
            }
            if (\u2603.c[fa.f.a()]) {
                this.a(ams2, bbe2, 7, 5, 11, 7, 6, 12, false);
                this.a(ams2, bbe2, 5, 4, 10, 6, 4, 13, b, b, false);
                this.a(ams2, bbe2, 6, 1, 10, 6, 3, 10, b, b, false);
                this.a(ams2, bbe2, 6, 1, 13, 6, 3, 13, b, b, false);
            }
            return true;
        }
    }

    public static class l
    extends r {
        public l() {
        }

        public l(fa fa2, v v2, Random random) {
            super(1, fa2, v2, 2, 2, 1);
        }

        @Override
        public boolean a(ams ams22, Random random, bbe bbe2) {
            ams ams22;
            v v2 = this.k.b[fa.f.a()];
            \u2603 = this.k;
            \u2603 = \u2603.b[fa.b.a()];
            \u2603 = v2.b[fa.b.a()];
            if (this.k.a / 25 > 0) {
                this.a(ams22, bbe2, 8, 0, v2.c[fa.a.a()]);
                this.a(ams22, bbe2, 0, 0, \u2603.c[fa.a.a()]);
            }
            if (\u2603.b[fa.b.a()] == null) {
                this.a(ams22, bbe2, 1, 8, 1, 7, 8, 6, a);
            }
            if (\u2603.b[fa.b.a()] == null) {
                this.a(ams22, bbe2, 8, 8, 1, 14, 8, 6, a);
            }
            for (int i2 = 1; i2 <= 7; ++i2) {
                awr awr2 = b;
                if (i2 == 2 || i2 == 6) {
                    awr2 = a;
                }
                this.a(ams22, bbe2, 0, i2, 0, 0, i2, 7, awr2, awr2, false);
                this.a(ams22, bbe2, 15, i2, 0, 15, i2, 7, awr2, awr2, false);
                this.a(ams22, bbe2, 1, i2, 0, 15, i2, 0, awr2, awr2, false);
                this.a(ams22, bbe2, 1, i2, 7, 14, i2, 7, awr2, awr2, false);
            }
            this.a(ams22, bbe2, 2, 1, 3, 2, 7, 4, b, b, false);
            this.a(ams22, bbe2, 3, 1, 2, 4, 7, 2, b, b, false);
            this.a(ams22, bbe2, 3, 1, 5, 4, 7, 5, b, b, false);
            this.a(ams22, bbe2, 13, 1, 3, 13, 7, 4, b, b, false);
            this.a(ams22, bbe2, 11, 1, 2, 12, 7, 2, b, b, false);
            this.a(ams22, bbe2, 11, 1, 5, 12, 7, 5, b, b, false);
            this.a(ams22, bbe2, 5, 1, 3, 5, 3, 4, b, b, false);
            this.a(ams22, bbe2, 10, 1, 3, 10, 3, 4, b, b, false);
            this.a(ams22, bbe2, 5, 7, 2, 10, 7, 5, b, b, false);
            this.a(ams22, bbe2, 5, 5, 2, 5, 7, 2, b, b, false);
            this.a(ams22, bbe2, 10, 5, 2, 10, 7, 2, b, b, false);
            this.a(ams22, bbe2, 5, 5, 5, 5, 7, 5, b, b, false);
            this.a(ams22, bbe2, 10, 5, 5, 10, 7, 5, b, b, false);
            this.a(ams22, b, 6, 6, 2, bbe2);
            this.a(ams22, b, 9, 6, 2, bbe2);
            this.a(ams22, b, 6, 6, 5, bbe2);
            this.a(ams22, b, 9, 6, 5, bbe2);
            this.a(ams22, bbe2, 5, 4, 3, 6, 4, 4, b, b, false);
            this.a(ams22, bbe2, 9, 4, 3, 10, 4, 4, b, b, false);
            this.a(ams22, e, 5, 4, 2, bbe2);
            this.a(ams22, e, 5, 4, 5, bbe2);
            this.a(ams22, e, 10, 4, 2, bbe2);
            this.a(ams22, e, 10, 4, 5, bbe2);
            if (\u2603.c[fa.d.a()]) {
                this.a(ams22, bbe2, 3, 1, 0, 4, 2, 0, false);
            }
            if (\u2603.c[fa.c.a()]) {
                this.a(ams22, bbe2, 3, 1, 7, 4, 2, 7, false);
            }
            if (\u2603.c[fa.e.a()]) {
                this.a(ams22, bbe2, 0, 1, 3, 0, 2, 4, false);
            }
            if (v2.c[fa.d.a()]) {
                this.a(ams22, bbe2, 11, 1, 0, 12, 2, 0, false);
            }
            if (v2.c[fa.c.a()]) {
                this.a(ams22, bbe2, 11, 1, 7, 12, 2, 7, false);
            }
            if (v2.c[fa.f.a()]) {
                this.a(ams22, bbe2, 15, 1, 3, 15, 2, 4, false);
            }
            if (\u2603.c[fa.d.a()]) {
                this.a(ams22, bbe2, 3, 5, 0, 4, 6, 0, false);
            }
            if (\u2603.c[fa.c.a()]) {
                this.a(ams22, bbe2, 3, 5, 7, 4, 6, 7, false);
            }
            if (\u2603.c[fa.e.a()]) {
                this.a(ams22, bbe2, 0, 5, 3, 0, 6, 4, false);
            }
            if (\u2603.c[fa.d.a()]) {
                this.a(ams22, bbe2, 11, 5, 0, 12, 6, 0, false);
            }
            if (\u2603.c[fa.c.a()]) {
                this.a(ams22, bbe2, 11, 5, 7, 12, 6, 7, false);
            }
            if (\u2603.c[fa.f.a()]) {
                this.a(ams22, bbe2, 15, 5, 3, 15, 6, 4, false);
            }
            return true;
        }
    }

    public static class o
    extends r {
        public o() {
        }

        public o(fa fa2, v v2, Random random) {
            super(1, fa2, v2, 1, 1, 2);
        }

        @Override
        public boolean a(ams ams2, Random random, bbe bbe2) {
            v v2 = this.k.b[fa.c.a()];
            \u2603 = this.k;
            if (this.k.a / 25 > 0) {
                this.a(ams2, bbe2, 0, 8, v2.c[fa.a.a()]);
                this.a(ams2, bbe2, 0, 0, \u2603.c[fa.a.a()]);
            }
            if (\u2603.b[fa.b.a()] == null) {
                this.a(ams2, bbe2, 1, 4, 1, 6, 4, 7, a);
            }
            if (v2.b[fa.b.a()] == null) {
                this.a(ams2, bbe2, 1, 4, 8, 6, 4, 14, a);
            }
            this.a(ams2, bbe2, 0, 3, 0, 0, 3, 15, b, b, false);
            this.a(ams2, bbe2, 7, 3, 0, 7, 3, 15, b, b, false);
            this.a(ams2, bbe2, 1, 3, 0, 7, 3, 0, b, b, false);
            this.a(ams2, bbe2, 1, 3, 15, 6, 3, 15, b, b, false);
            this.a(ams2, bbe2, 0, 2, 0, 0, 2, 15, a, a, false);
            this.a(ams2, bbe2, 7, 2, 0, 7, 2, 15, a, a, false);
            this.a(ams2, bbe2, 1, 2, 0, 7, 2, 0, a, a, false);
            this.a(ams2, bbe2, 1, 2, 15, 6, 2, 15, a, a, false);
            this.a(ams2, bbe2, 0, 1, 0, 0, 1, 15, b, b, false);
            this.a(ams2, bbe2, 7, 1, 0, 7, 1, 15, b, b, false);
            this.a(ams2, bbe2, 1, 1, 0, 7, 1, 0, b, b, false);
            this.a(ams2, bbe2, 1, 1, 15, 6, 1, 15, b, b, false);
            this.a(ams2, bbe2, 1, 1, 1, 1, 1, 2, b, b, false);
            this.a(ams2, bbe2, 6, 1, 1, 6, 1, 2, b, b, false);
            this.a(ams2, bbe2, 1, 3, 1, 1, 3, 2, b, b, false);
            this.a(ams2, bbe2, 6, 3, 1, 6, 3, 2, b, b, false);
            this.a(ams2, bbe2, 1, 1, 13, 1, 1, 14, b, b, false);
            this.a(ams2, bbe2, 6, 1, 13, 6, 1, 14, b, b, false);
            this.a(ams2, bbe2, 1, 3, 13, 1, 3, 14, b, b, false);
            this.a(ams2, bbe2, 6, 3, 13, 6, 3, 14, b, b, false);
            this.a(ams2, bbe2, 2, 1, 6, 2, 3, 6, b, b, false);
            this.a(ams2, bbe2, 5, 1, 6, 5, 3, 6, b, b, false);
            this.a(ams2, bbe2, 2, 1, 9, 2, 3, 9, b, b, false);
            this.a(ams2, bbe2, 5, 1, 9, 5, 3, 9, b, b, false);
            this.a(ams2, bbe2, 3, 2, 6, 4, 2, 6, b, b, false);
            this.a(ams2, bbe2, 3, 2, 9, 4, 2, 9, b, b, false);
            this.a(ams2, bbe2, 2, 2, 7, 2, 2, 8, b, b, false);
            this.a(ams2, bbe2, 5, 2, 7, 5, 2, 8, b, b, false);
            this.a(ams2, e, 2, 2, 5, bbe2);
            this.a(ams2, e, 5, 2, 5, bbe2);
            this.a(ams2, e, 2, 2, 10, bbe2);
            this.a(ams2, e, 5, 2, 10, bbe2);
            this.a(ams2, b, 2, 3, 5, bbe2);
            this.a(ams2, b, 5, 3, 5, bbe2);
            this.a(ams2, b, 2, 3, 10, bbe2);
            this.a(ams2, b, 5, 3, 10, bbe2);
            if (\u2603.c[fa.d.a()]) {
                this.a(ams2, bbe2, 3, 1, 0, 4, 2, 0, false);
            }
            if (\u2603.c[fa.f.a()]) {
                this.a(ams2, bbe2, 7, 1, 3, 7, 2, 4, false);
            }
            if (\u2603.c[fa.e.a()]) {
                this.a(ams2, bbe2, 0, 1, 3, 0, 2, 4, false);
            }
            if (v2.c[fa.c.a()]) {
                this.a(ams2, bbe2, 3, 1, 15, 4, 2, 15, false);
            }
            if (v2.c[fa.e.a()]) {
                this.a(ams2, bbe2, 0, 1, 11, 0, 2, 12, false);
            }
            if (v2.c[fa.f.a()]) {
                this.a(ams2, bbe2, 7, 1, 11, 7, 2, 12, false);
            }
            return true;
        }
    }

    public static class k
    extends r {
        public k() {
        }

        public k(fa fa2, v v2, Random random) {
            super(1, fa2, v2, 2, 1, 1);
        }

        @Override
        public boolean a(ams ams2, Random random, bbe bbe2) {
            v v2 = this.k.b[fa.f.a()];
            \u2603 = this.k;
            if (this.k.a / 25 > 0) {
                this.a(ams2, bbe2, 8, 0, v2.c[fa.a.a()]);
                this.a(ams2, bbe2, 0, 0, \u2603.c[fa.a.a()]);
            }
            if (\u2603.b[fa.b.a()] == null) {
                this.a(ams2, bbe2, 1, 4, 1, 7, 4, 6, a);
            }
            if (v2.b[fa.b.a()] == null) {
                this.a(ams2, bbe2, 8, 4, 1, 14, 4, 6, a);
            }
            this.a(ams2, bbe2, 0, 3, 0, 0, 3, 7, b, b, false);
            this.a(ams2, bbe2, 15, 3, 0, 15, 3, 7, b, b, false);
            this.a(ams2, bbe2, 1, 3, 0, 15, 3, 0, b, b, false);
            this.a(ams2, bbe2, 1, 3, 7, 14, 3, 7, b, b, false);
            this.a(ams2, bbe2, 0, 2, 0, 0, 2, 7, a, a, false);
            this.a(ams2, bbe2, 15, 2, 0, 15, 2, 7, a, a, false);
            this.a(ams2, bbe2, 1, 2, 0, 15, 2, 0, a, a, false);
            this.a(ams2, bbe2, 1, 2, 7, 14, 2, 7, a, a, false);
            this.a(ams2, bbe2, 0, 1, 0, 0, 1, 7, b, b, false);
            this.a(ams2, bbe2, 15, 1, 0, 15, 1, 7, b, b, false);
            this.a(ams2, bbe2, 1, 1, 0, 15, 1, 0, b, b, false);
            this.a(ams2, bbe2, 1, 1, 7, 14, 1, 7, b, b, false);
            this.a(ams2, bbe2, 5, 1, 0, 10, 1, 4, b, b, false);
            this.a(ams2, bbe2, 6, 2, 0, 9, 2, 3, a, a, false);
            this.a(ams2, bbe2, 5, 3, 0, 10, 3, 4, b, b, false);
            this.a(ams2, e, 6, 2, 3, bbe2);
            this.a(ams2, e, 9, 2, 3, bbe2);
            if (\u2603.c[fa.d.a()]) {
                this.a(ams2, bbe2, 3, 1, 0, 4, 2, 0, false);
            }
            if (\u2603.c[fa.c.a()]) {
                this.a(ams2, bbe2, 3, 1, 7, 4, 2, 7, false);
            }
            if (\u2603.c[fa.e.a()]) {
                this.a(ams2, bbe2, 0, 1, 3, 0, 2, 4, false);
            }
            if (v2.c[fa.d.a()]) {
                this.a(ams2, bbe2, 11, 1, 0, 12, 2, 0, false);
            }
            if (v2.c[fa.c.a()]) {
                this.a(ams2, bbe2, 11, 1, 7, 12, 2, 7, false);
            }
            if (v2.c[fa.f.a()]) {
                this.a(ams2, bbe2, 15, 1, 3, 15, 2, 4, false);
            }
            return true;
        }
    }

    public static class m
    extends r {
        public m() {
        }

        public m(fa fa2, v v2, Random random) {
            super(1, fa2, v2, 1, 2, 1);
        }

        @Override
        public boolean a(ams ams2, Random random, bbe bbe2) {
            if (this.k.a / 25 > 0) {
                this.a(ams2, bbe2, 0, 0, this.k.c[fa.a.a()]);
            }
            v v2 = this.k.b[fa.b.a()];
            if (v2.b[fa.b.a()] == null) {
                this.a(ams2, bbe2, 1, 8, 1, 6, 8, 6, a);
            }
            this.a(ams2, bbe2, 0, 4, 0, 0, 4, 7, b, b, false);
            this.a(ams2, bbe2, 7, 4, 0, 7, 4, 7, b, b, false);
            this.a(ams2, bbe2, 1, 4, 0, 6, 4, 0, b, b, false);
            this.a(ams2, bbe2, 1, 4, 7, 6, 4, 7, b, b, false);
            this.a(ams2, bbe2, 2, 4, 1, 2, 4, 2, b, b, false);
            this.a(ams2, bbe2, 1, 4, 2, 1, 4, 2, b, b, false);
            this.a(ams2, bbe2, 5, 4, 1, 5, 4, 2, b, b, false);
            this.a(ams2, bbe2, 6, 4, 2, 6, 4, 2, b, b, false);
            this.a(ams2, bbe2, 2, 4, 5, 2, 4, 6, b, b, false);
            this.a(ams2, bbe2, 1, 4, 5, 1, 4, 5, b, b, false);
            this.a(ams2, bbe2, 5, 4, 5, 5, 4, 6, b, b, false);
            this.a(ams2, bbe2, 6, 4, 5, 6, 4, 5, b, b, false);
            v3 = this.k;
            for (int i2 = 1; i2 <= 5; i2 += 4) {
                \u2603 = 0;
                if (v3.c[fa.d.a()]) {
                    this.a(ams2, bbe2, 2, i2, \u2603, 2, i2 + 2, \u2603, b, b, false);
                    this.a(ams2, bbe2, 5, i2, \u2603, 5, i2 + 2, \u2603, b, b, false);
                    this.a(ams2, bbe2, 3, i2 + 2, \u2603, 4, i2 + 2, \u2603, b, b, false);
                } else {
                    this.a(ams2, bbe2, 0, i2, \u2603, 7, i2 + 2, \u2603, b, b, false);
                    this.a(ams2, bbe2, 0, i2 + 1, \u2603, 7, i2 + 1, \u2603, a, a, false);
                }
                \u2603 = 7;
                if (v3.c[fa.c.a()]) {
                    this.a(ams2, bbe2, 2, i2, \u2603, 2, i2 + 2, \u2603, b, b, false);
                    this.a(ams2, bbe2, 5, i2, \u2603, 5, i2 + 2, \u2603, b, b, false);
                    this.a(ams2, bbe2, 3, i2 + 2, \u2603, 4, i2 + 2, \u2603, b, b, false);
                } else {
                    this.a(ams2, bbe2, 0, i2, \u2603, 7, i2 + 2, \u2603, b, b, false);
                    this.a(ams2, bbe2, 0, i2 + 1, \u2603, 7, i2 + 1, \u2603, a, a, false);
                }
                \u2603 = 0;
                if (v3.c[fa.e.a()]) {
                    this.a(ams2, bbe2, \u2603, i2, 2, \u2603, i2 + 2, 2, b, b, false);
                    this.a(ams2, bbe2, \u2603, i2, 5, \u2603, i2 + 2, 5, b, b, false);
                    this.a(ams2, bbe2, \u2603, i2 + 2, 3, \u2603, i2 + 2, 4, b, b, false);
                } else {
                    this.a(ams2, bbe2, \u2603, i2, 0, \u2603, i2 + 2, 7, b, b, false);
                    this.a(ams2, bbe2, \u2603, i2 + 1, 0, \u2603, i2 + 1, 7, a, a, false);
                }
                \u2603 = 7;
                if (v3.c[fa.f.a()]) {
                    this.a(ams2, bbe2, \u2603, i2, 2, \u2603, i2 + 2, 2, b, b, false);
                    this.a(ams2, bbe2, \u2603, i2, 5, \u2603, i2 + 2, 5, b, b, false);
                    this.a(ams2, bbe2, \u2603, i2 + 2, 3, \u2603, i2 + 2, 4, b, b, false);
                } else {
                    this.a(ams2, bbe2, \u2603, i2, 0, \u2603, i2 + 2, 7, b, b, false);
                    this.a(ams2, bbe2, \u2603, i2 + 1, 0, \u2603, i2 + 1, 7, a, a, false);
                }
                v v3 = v2;
            }
            return true;
        }
    }

    public static class t
    extends r {
        public t() {
        }

        public t(fa fa2, v v2, Random random) {
            super(1, fa2, v2, 1, 1, 1);
        }

        @Override
        public boolean a(ams ams22, Random random, bbe bbe2) {
            ams ams22;
            if (this.k.a / 25 > 0) {
                this.a(ams22, bbe2, 0, 0, this.k.c[fa.a.a()]);
            }
            if (this.k.b[fa.b.a()] == null) {
                this.a(ams22, bbe2, 1, 4, 1, 6, 4, 6, a);
            }
            for (int i2 = 1; i2 <= 6; ++i2) {
                for (\u2603 = 1; \u2603 <= 6; ++\u2603) {
                    if (random.nextInt(3) == 0) continue;
                    \u2603 = 2 + (random.nextInt(4) == 0 ? 0 : 1);
                    this.a(ams22, bbe2, i2, \u2603, \u2603, i2, 3, \u2603, aov.v.a(1), aov.v.a(1), false);
                }
            }
            this.a(ams22, bbe2, 0, 1, 0, 0, 1, 7, b, b, false);
            this.a(ams22, bbe2, 7, 1, 0, 7, 1, 7, b, b, false);
            this.a(ams22, bbe2, 1, 1, 0, 6, 1, 0, b, b, false);
            this.a(ams22, bbe2, 1, 1, 7, 6, 1, 7, b, b, false);
            this.a(ams22, bbe2, 0, 2, 0, 0, 2, 7, c, c, false);
            this.a(ams22, bbe2, 7, 2, 0, 7, 2, 7, c, c, false);
            this.a(ams22, bbe2, 1, 2, 0, 6, 2, 0, c, c, false);
            this.a(ams22, bbe2, 1, 2, 7, 6, 2, 7, c, c, false);
            this.a(ams22, bbe2, 0, 3, 0, 0, 3, 7, b, b, false);
            this.a(ams22, bbe2, 7, 3, 0, 7, 3, 7, b, b, false);
            this.a(ams22, bbe2, 1, 3, 0, 6, 3, 0, b, b, false);
            this.a(ams22, bbe2, 1, 3, 7, 6, 3, 7, b, b, false);
            this.a(ams22, bbe2, 0, 1, 3, 0, 2, 4, c, c, false);
            this.a(ams22, bbe2, 7, 1, 3, 7, 2, 4, c, c, false);
            this.a(ams22, bbe2, 3, 1, 0, 4, 2, 0, c, c, false);
            this.a(ams22, bbe2, 3, 1, 7, 4, 2, 7, c, c, false);
            if (this.k.c[fa.d.a()]) {
                this.a(ams22, bbe2, 3, 1, 0, 4, 2, 0, false);
            }
            return true;
        }
    }

    public static class s
    extends r {
        private int n;

        public s() {
        }

        public s(fa fa2, v v2, Random random) {
            super(1, fa2, v2, 1, 1, 1);
            this.n = random.nextInt(3);
        }

        @Override
        public boolean a(ams ams2, Random random, bbe bbe2) {
            if (this.k.a / 25 > 0) {
                this.a(ams2, bbe2, 0, 0, this.k.c[fa.a.a()]);
            }
            if (this.k.b[fa.b.a()] == null) {
                this.a(ams2, bbe2, 1, 4, 1, 6, 4, 6, a);
            }
            boolean bl2 = \u2603 = this.n != 0 && random.nextBoolean() && !this.k.c[fa.a.a()] && !this.k.c[fa.b.a()] && this.k.c() > 1;
            if (this.n == 0) {
                this.a(ams2, bbe2, 0, 1, 0, 2, 1, 2, b, b, false);
                this.a(ams2, bbe2, 0, 3, 0, 2, 3, 2, b, b, false);
                this.a(ams2, bbe2, 0, 2, 0, 0, 2, 2, a, a, false);
                this.a(ams2, bbe2, 1, 2, 0, 2, 2, 0, a, a, false);
                this.a(ams2, e, 1, 2, 1, bbe2);
                this.a(ams2, bbe2, 5, 1, 0, 7, 1, 2, b, b, false);
                this.a(ams2, bbe2, 5, 3, 0, 7, 3, 2, b, b, false);
                this.a(ams2, bbe2, 7, 2, 0, 7, 2, 2, a, a, false);
                this.a(ams2, bbe2, 5, 2, 0, 6, 2, 0, a, a, false);
                this.a(ams2, e, 6, 2, 1, bbe2);
                this.a(ams2, bbe2, 0, 1, 5, 2, 1, 7, b, b, false);
                this.a(ams2, bbe2, 0, 3, 5, 2, 3, 7, b, b, false);
                this.a(ams2, bbe2, 0, 2, 5, 0, 2, 7, a, a, false);
                this.a(ams2, bbe2, 1, 2, 7, 2, 2, 7, a, a, false);
                this.a(ams2, e, 1, 2, 6, bbe2);
                this.a(ams2, bbe2, 5, 1, 5, 7, 1, 7, b, b, false);
                this.a(ams2, bbe2, 5, 3, 5, 7, 3, 7, b, b, false);
                this.a(ams2, bbe2, 7, 2, 5, 7, 2, 7, a, a, false);
                this.a(ams2, bbe2, 5, 2, 7, 6, 2, 7, a, a, false);
                this.a(ams2, e, 6, 2, 6, bbe2);
                if (this.k.c[fa.d.a()]) {
                    this.a(ams2, bbe2, 3, 3, 0, 4, 3, 0, b, b, false);
                } else {
                    this.a(ams2, bbe2, 3, 3, 0, 4, 3, 1, b, b, false);
                    this.a(ams2, bbe2, 3, 2, 0, 4, 2, 0, a, a, false);
                    this.a(ams2, bbe2, 3, 1, 0, 4, 1, 1, b, b, false);
                }
                if (this.k.c[fa.c.a()]) {
                    this.a(ams2, bbe2, 3, 3, 7, 4, 3, 7, b, b, false);
                } else {
                    this.a(ams2, bbe2, 3, 3, 6, 4, 3, 7, b, b, false);
                    this.a(ams2, bbe2, 3, 2, 7, 4, 2, 7, a, a, false);
                    this.a(ams2, bbe2, 3, 1, 6, 4, 1, 7, b, b, false);
                }
                if (this.k.c[fa.e.a()]) {
                    this.a(ams2, bbe2, 0, 3, 3, 0, 3, 4, b, b, false);
                } else {
                    this.a(ams2, bbe2, 0, 3, 3, 1, 3, 4, b, b, false);
                    this.a(ams2, bbe2, 0, 2, 3, 0, 2, 4, a, a, false);
                    this.a(ams2, bbe2, 0, 1, 3, 1, 1, 4, b, b, false);
                }
                if (this.k.c[fa.f.a()]) {
                    this.a(ams2, bbe2, 7, 3, 3, 7, 3, 4, b, b, false);
                } else {
                    this.a(ams2, bbe2, 6, 3, 3, 7, 3, 4, b, b, false);
                    this.a(ams2, bbe2, 7, 2, 3, 7, 2, 4, a, a, false);
                    this.a(ams2, bbe2, 6, 1, 3, 7, 1, 4, b, b, false);
                }
            } else if (this.n == 1) {
                this.a(ams2, bbe2, 2, 1, 2, 2, 3, 2, b, b, false);
                this.a(ams2, bbe2, 2, 1, 5, 2, 3, 5, b, b, false);
                this.a(ams2, bbe2, 5, 1, 5, 5, 3, 5, b, b, false);
                this.a(ams2, bbe2, 5, 1, 2, 5, 3, 2, b, b, false);
                this.a(ams2, e, 2, 2, 2, bbe2);
                this.a(ams2, e, 2, 2, 5, bbe2);
                this.a(ams2, e, 5, 2, 5, bbe2);
                this.a(ams2, e, 5, 2, 2, bbe2);
                this.a(ams2, bbe2, 0, 1, 0, 1, 3, 0, b, b, false);
                this.a(ams2, bbe2, 0, 1, 1, 0, 3, 1, b, b, false);
                this.a(ams2, bbe2, 0, 1, 7, 1, 3, 7, b, b, false);
                this.a(ams2, bbe2, 0, 1, 6, 0, 3, 6, b, b, false);
                this.a(ams2, bbe2, 6, 1, 7, 7, 3, 7, b, b, false);
                this.a(ams2, bbe2, 7, 1, 6, 7, 3, 6, b, b, false);
                this.a(ams2, bbe2, 6, 1, 0, 7, 3, 0, b, b, false);
                this.a(ams2, bbe2, 7, 1, 1, 7, 3, 1, b, b, false);
                this.a(ams2, a, 1, 2, 0, bbe2);
                this.a(ams2, a, 0, 2, 1, bbe2);
                this.a(ams2, a, 1, 2, 7, bbe2);
                this.a(ams2, a, 0, 2, 6, bbe2);
                this.a(ams2, a, 6, 2, 7, bbe2);
                this.a(ams2, a, 7, 2, 6, bbe2);
                this.a(ams2, a, 6, 2, 0, bbe2);
                this.a(ams2, a, 7, 2, 1, bbe2);
                if (!this.k.c[fa.d.a()]) {
                    this.a(ams2, bbe2, 1, 3, 0, 6, 3, 0, b, b, false);
                    this.a(ams2, bbe2, 1, 2, 0, 6, 2, 0, a, a, false);
                    this.a(ams2, bbe2, 1, 1, 0, 6, 1, 0, b, b, false);
                }
                if (!this.k.c[fa.c.a()]) {
                    this.a(ams2, bbe2, 1, 3, 7, 6, 3, 7, b, b, false);
                    this.a(ams2, bbe2, 1, 2, 7, 6, 2, 7, a, a, false);
                    this.a(ams2, bbe2, 1, 1, 7, 6, 1, 7, b, b, false);
                }
                if (!this.k.c[fa.e.a()]) {
                    this.a(ams2, bbe2, 0, 3, 1, 0, 3, 6, b, b, false);
                    this.a(ams2, bbe2, 0, 2, 1, 0, 2, 6, a, a, false);
                    this.a(ams2, bbe2, 0, 1, 1, 0, 1, 6, b, b, false);
                }
                if (!this.k.c[fa.f.a()]) {
                    this.a(ams2, bbe2, 7, 3, 1, 7, 3, 6, b, b, false);
                    this.a(ams2, bbe2, 7, 2, 1, 7, 2, 6, a, a, false);
                    this.a(ams2, bbe2, 7, 1, 1, 7, 1, 6, b, b, false);
                }
            } else if (this.n == 2) {
                this.a(ams2, bbe2, 0, 1, 0, 0, 1, 7, b, b, false);
                this.a(ams2, bbe2, 7, 1, 0, 7, 1, 7, b, b, false);
                this.a(ams2, bbe2, 1, 1, 0, 6, 1, 0, b, b, false);
                this.a(ams2, bbe2, 1, 1, 7, 6, 1, 7, b, b, false);
                this.a(ams2, bbe2, 0, 2, 0, 0, 2, 7, c, c, false);
                this.a(ams2, bbe2, 7, 2, 0, 7, 2, 7, c, c, false);
                this.a(ams2, bbe2, 1, 2, 0, 6, 2, 0, c, c, false);
                this.a(ams2, bbe2, 1, 2, 7, 6, 2, 7, c, c, false);
                this.a(ams2, bbe2, 0, 3, 0, 0, 3, 7, b, b, false);
                this.a(ams2, bbe2, 7, 3, 0, 7, 3, 7, b, b, false);
                this.a(ams2, bbe2, 1, 3, 0, 6, 3, 0, b, b, false);
                this.a(ams2, bbe2, 1, 3, 7, 6, 3, 7, b, b, false);
                this.a(ams2, bbe2, 0, 1, 3, 0, 2, 4, c, c, false);
                this.a(ams2, bbe2, 7, 1, 3, 7, 2, 4, c, c, false);
                this.a(ams2, bbe2, 3, 1, 0, 4, 2, 0, c, c, false);
                this.a(ams2, bbe2, 3, 1, 7, 4, 2, 7, c, c, false);
                if (this.k.c[fa.d.a()]) {
                    this.a(ams2, bbe2, 3, 1, 0, 4, 2, 0, false);
                }
                if (this.k.c[fa.c.a()]) {
                    this.a(ams2, bbe2, 3, 1, 7, 4, 2, 7, false);
                }
                if (this.k.c[fa.e.a()]) {
                    this.a(ams2, bbe2, 0, 1, 3, 0, 2, 4, false);
                }
                if (this.k.c[fa.f.a()]) {
                    this.a(ams2, bbe2, 7, 1, 3, 7, 2, 4, false);
                }
            }
            if (\u2603) {
                this.a(ams2, bbe2, 3, 1, 3, 4, 1, 4, b, b, false);
                this.a(ams2, bbe2, 3, 2, 3, 4, 2, 4, a, a, false);
                this.a(ams2, bbe2, 3, 3, 3, 4, 3, 4, b, b, false);
            }
            return true;
        }
    }

    public static class p
    extends r {
        public p() {
        }

        public p(fa fa2, v v2) {
            super(1, fa2, v2, 1, 1, 1);
        }

        @Override
        public boolean a(ams ams2, Random random, bbe bbe2) {
            this.a(ams2, bbe2, 0, 3, 0, 2, 3, 7, b, b, false);
            this.a(ams2, bbe2, 5, 3, 0, 7, 3, 7, b, b, false);
            this.a(ams2, bbe2, 0, 2, 0, 1, 2, 7, b, b, false);
            this.a(ams2, bbe2, 6, 2, 0, 7, 2, 7, b, b, false);
            this.a(ams2, bbe2, 0, 1, 0, 0, 1, 7, b, b, false);
            this.a(ams2, bbe2, 7, 1, 0, 7, 1, 7, b, b, false);
            this.a(ams2, bbe2, 0, 1, 7, 7, 3, 7, b, b, false);
            this.a(ams2, bbe2, 1, 1, 0, 2, 3, 0, b, b, false);
            this.a(ams2, bbe2, 5, 1, 0, 6, 3, 0, b, b, false);
            if (this.k.c[fa.c.a()]) {
                this.a(ams2, bbe2, 3, 1, 7, 4, 2, 7, false);
            }
            if (this.k.c[fa.e.a()]) {
                this.a(ams2, bbe2, 0, 1, 3, 1, 2, 4, false);
            }
            if (this.k.c[fa.f.a()]) {
                this.a(ams2, bbe2, 6, 1, 3, 7, 2, 4, false);
            }
            return true;
        }
    }

    public static class h
    extends r {
        private v n;
        private v o;
        private final List<r> p = Lists.newArrayList();

        public h() {
        }

        public h(Random random, int n2, int n3, fa fa2) {
            super(0);
            this.a(fa2);
            fa fa3 = this.f();
            this.l = fa3.k() == fa.a.c ? new bbe(n2, 39, n3, n2 + 58 - 1, 61, n3 + 58 - 1) : new bbe(n2, 39, n3, n2 + 58 - 1, 61, n3 + 58 - 1);
            List<v> list = this.a(random);
            this.n.d = true;
            this.p.add(new p(fa3, this.n));
            this.p.add(new j(fa3, this.o, random));
            ArrayList \u26032 = Lists.newArrayList();
            \u26032.add(new b());
            \u26032.add(new d());
            \u26032.add(new e());
            \u26032.add(new a());
            \u26032.add(new c());
            \u26032.add(new g());
            \u26032.add(new f());
            block0: for (v v2 : list) {
                if (v2.d || v2.b()) continue;
                for (Object object2 : \u26032) {
                    if (!object2.a(v2)) continue;
                    this.p.add(object2.a(fa3, v2, random));
                    continue block0;
                }
            }
            int n4 = this.l.b;
            int \u26035 = this.a(9, 22);
            int \u26036 = this.b(9, 22);
            for (r r2 : this.p) {
                r2.d().a(\u26035, n4, \u26036);
            }
            bbe \u26037 = bbe.a(this.a(1, 1), this.d(1), this.b(1, 1), this.a(23, 21), this.d(8), this.b(23, 21));
            bbe bbe2 = bbe.a(this.a(34, 1), this.d(1), this.b(34, 1), this.a(56, 21), this.d(8), this.b(56, 21));
            bbe \u26033 = bbe.a(this.a(22, 22), this.d(13), this.b(22, 22), this.a(35, 35), this.d(17), this.b(35, 35));
            int \u26034 = random.nextInt();
            this.p.add(new u(fa3, \u26037, \u26034++));
            this.p.add(new u(fa3, bbe2, \u26034++));
            this.p.add(new q(fa3, \u26033));
        }

        private List<v> a(Random random) {
            int n2;
            v[] arrv = new v[75];
            for (int n22 = 0; n22 < 5; ++n22) {
                for (int i2 = 0; i2 < 4; ++i2) {
                    \u2603 = 0;
                    \u2603 = h.b(n22, 0, i2);
                    arrv[\u2603] = new v(\u2603);
                }
            }
            for (n2 = 0; n2 < 5; ++n2) {
                for (i2 = 0; i2 < 4; ++i2) {
                    \u2603 = 1;
                    \u2603 = h.b(n2, 1, i2);
                    arrv[\u2603] = new v(\u2603);
                }
            }
            for (n2 = 1; n2 < 4; ++n2) {
                for (i2 = 0; i2 < 2; ++i2) {
                    \u2603 = 2;
                    \u2603 = h.b(n2, 2, i2);
                    arrv[\u2603] = new v(\u2603);
                }
            }
            this.n = arrv[g];
            for (n2 = 0; n2 < 5; ++n2) {
                for (i2 = 0; i2 < 5; ++i2) {
                    for (\u2603 = 0; \u2603 < 3; ++\u2603) {
                        \u2603 = h.b(n2, \u2603, i2);
                        if (arrv[\u2603] == null) continue;
                        for (fa fa2 : fa.values()) {
                            int n3 = n2 + fa2.g();
                            \u2603 = \u2603 + fa2.h();
                            \u2603 = i2 + fa2.i();
                            if (n3 < 0 || n3 >= 5 || \u2603 < 0 || \u2603 >= 5 || \u2603 < 0 || \u2603 >= 3 || arrv[\u2603 = h.b(n3, \u2603, \u2603)] == null) continue;
                            if (\u2603 == i2) {
                                arrv[\u2603].a(fa2, arrv[\u2603]);
                                continue;
                            }
                            arrv[\u2603].a(fa2.d(), arrv[\u2603]);
                        }
                    }
                }
            }
            v v2 = new v(1003);
            v v3 = new v(1001);
            \u2603 = new v(1002);
            arrv[h].a(fa.b, v2);
            arrv[i].a(fa.d, v3);
            arrv[j].a(fa.d, \u2603);
            v2.d = true;
            v3.d = true;
            \u2603.d = true;
            this.n.e = true;
            this.o = arrv[h.b(random.nextInt(4), 0, 2)];
            this.o.d = true;
            this.o.b[fa.f.a()].d = true;
            this.o.b[fa.c.a()].d = true;
            this.o.b[fa.f.a()].b[fa.c.a()].d = true;
            this.o.b[fa.b.a()].d = true;
            this.o.b[fa.f.a()].b[fa.b.a()].d = true;
            this.o.b[fa.c.a()].b[fa.b.a()].d = true;
            this.o.b[fa.f.a()].b[fa.c.a()].b[fa.b.a()].d = true;
            ArrayList \u26032 = Lists.newArrayList();
            for (v v4 : arrv) {
                if (v4 == null) continue;
                v4.a();
                \u26032.add(v4);
            }
            v2.a();
            Collections.shuffle(\u26032, random);
            int \u26033 = 1;
            for (v v32 : \u26032) {
                int n3 = 0;
                for (int i3 = 0; n3 < 2 && i3 < 5; ++i3) {
                    \u2603 = random.nextInt(6);
                    if (!v32.c[\u2603]) continue;
                    \u2603 = fa.a(\u2603).d().a();
                    v32.c[\u2603] = false;
                    v32.b[\u2603].c[\u2603] = false;
                    if (v32.a(\u26033++) && v32.b[\u2603].a(\u26033++)) {
                        ++n3;
                        continue;
                    }
                    v32.c[\u2603] = true;
                    v32.b[\u2603].c[\u2603] = true;
                }
            }
            \u26032.add(v2);
            \u26032.add(v3);
            \u26032.add(\u2603);
            return \u26032;
        }

        @Override
        public boolean a(ams ams2, Random random, bbe bbe2) {
            int n2 = Math.max(ams2.M(), 64) - this.l.b;
            this.a(ams2, bbe2, 0, 0, 0, 58, n2, 58, false);
            this.a(false, 0, ams2, random, bbe2);
            this.a(true, 33, ams2, random, bbe2);
            this.b(ams2, random, bbe2);
            this.c(ams2, random, bbe2);
            this.d(ams2, random, bbe2);
            this.e(ams2, random, bbe2);
            this.f(ams2, random, bbe2);
            this.g(ams2, random, bbe2);
            for (\u2603 = 0; \u2603 < 7; ++\u2603) {
                \u2603 = 0;
                while (\u2603 < 7) {
                    if (\u2603 == 0 && \u2603 == 3) {
                        \u2603 = 6;
                    }
                    \u2603 = \u2603 * 9;
                    \u2603 = \u2603 * 9;
                    for (\u2603 = 0; \u2603 < 4; ++\u2603) {
                        for (\u2603 = 0; \u2603 < 4; ++\u2603) {
                            this.a(ams2, b, \u2603 + \u2603, 0, \u2603 + \u2603, bbe2);
                            this.b(ams2, b, \u2603 + \u2603, -1, \u2603 + \u2603, bbe2);
                        }
                    }
                    if (\u2603 == 0 || \u2603 == 6) {
                        ++\u2603;
                        continue;
                    }
                    \u2603 += 6;
                }
            }
            for (\u2603 = 0; \u2603 < 5; ++\u2603) {
                this.a(ams2, bbe2, -1 - \u2603, 0 + \u2603 * 2, -1 - \u2603, -1 - \u2603, 23, 58 + \u2603, false);
                this.a(ams2, bbe2, 58 + \u2603, 0 + \u2603 * 2, -1 - \u2603, 58 + \u2603, 23, 58 + \u2603, false);
                this.a(ams2, bbe2, 0 - \u2603, 0 + \u2603 * 2, -1 - \u2603, 57 + \u2603, 23, -1 - \u2603, false);
                this.a(ams2, bbe2, 0 - \u2603, 0 + \u2603 * 2, 58 + \u2603, 57 + \u2603, 23, 58 + \u2603, false);
            }
            for (r r2 : this.p) {
                if (!r2.d().a(bbe2)) continue;
                r2.a(ams2, random, bbe2);
            }
            return true;
        }

        private void a(boolean bl2, int n2, ams ams2, Random random, bbe bbe2) {
            int n3 = 24;
            if (this.a(bbe2, n2, 0, n2 + 23, 20)) {
                this.a(ams2, bbe2, n2 + 0, 0, 0, n2 + 24, 0, 20, a, a, false);
                this.a(ams2, bbe2, n2 + 0, 1, 0, n2 + 24, 10, 20, false);
                for (\u2603 = 0; \u2603 < 4; ++\u2603) {
                    this.a(ams2, bbe2, n2 + \u2603, \u2603 + 1, \u2603, n2 + \u2603, \u2603 + 1, 20, b, b, false);
                    this.a(ams2, bbe2, n2 + \u2603 + 7, \u2603 + 5, \u2603 + 7, n2 + \u2603 + 7, \u2603 + 5, 20, b, b, false);
                    this.a(ams2, bbe2, n2 + 17 - \u2603, \u2603 + 5, \u2603 + 7, n2 + 17 - \u2603, \u2603 + 5, 20, b, b, false);
                    this.a(ams2, bbe2, n2 + 24 - \u2603, \u2603 + 1, \u2603, n2 + 24 - \u2603, \u2603 + 1, 20, b, b, false);
                    this.a(ams2, bbe2, n2 + \u2603 + 1, \u2603 + 1, \u2603, n2 + 23 - \u2603, \u2603 + 1, \u2603, b, b, false);
                    this.a(ams2, bbe2, n2 + \u2603 + 8, \u2603 + 5, \u2603 + 7, n2 + 16 - \u2603, \u2603 + 5, \u2603 + 7, b, b, false);
                }
                this.a(ams2, bbe2, n2 + 4, 4, 4, n2 + 6, 4, 20, a, a, false);
                this.a(ams2, bbe2, n2 + 7, 4, 4, n2 + 17, 4, 6, a, a, false);
                this.a(ams2, bbe2, n2 + 18, 4, 4, n2 + 20, 4, 20, a, a, false);
                this.a(ams2, bbe2, n2 + 11, 8, 11, n2 + 13, 8, 20, a, a, false);
                this.a(ams2, d, n2 + 12, 9, 12, bbe2);
                this.a(ams2, d, n2 + 12, 9, 15, bbe2);
                this.a(ams2, d, n2 + 12, 9, 18, bbe2);
                \u2603 = n2 + (bl2 ? 19 : 5);
                \u2603 = n2 + (bl2 ? 5 : 19);
                for (\u2603 = 20; \u2603 >= 5; \u2603 -= 3) {
                    this.a(ams2, d, \u2603, 5, \u2603, bbe2);
                }
                for (\u2603 = 19; \u2603 >= 7; \u2603 -= 3) {
                    this.a(ams2, d, \u2603, 5, \u2603, bbe2);
                }
                for (\u2603 = 0; \u2603 < 4; ++\u2603) {
                    \u2603 = bl2 ? n2 + (24 - (17 - \u2603 * 3)) : n2 + 17 - \u2603 * 3;
                    this.a(ams2, d, \u2603, 5, 5, bbe2);
                }
                this.a(ams2, d, \u2603, 5, 5, bbe2);
                this.a(ams2, bbe2, n2 + 11, 1, 12, n2 + 13, 7, 12, a, a, false);
                this.a(ams2, bbe2, n2 + 12, 1, 11, n2 + 12, 7, 13, a, a, false);
            }
        }

        private void b(ams ams2, Random random, bbe bbe2) {
            if (this.a(bbe2, 22, 5, 35, 17)) {
                this.a(ams2, bbe2, 25, 0, 0, 32, 8, 20, false);
                for (int i2 = 0; i2 < 4; ++i2) {
                    this.a(ams2, bbe2, 24, 2, 5 + i2 * 4, 24, 4, 5 + i2 * 4, b, b, false);
                    this.a(ams2, bbe2, 22, 4, 5 + i2 * 4, 23, 4, 5 + i2 * 4, b, b, false);
                    this.a(ams2, b, 25, 5, 5 + i2 * 4, bbe2);
                    this.a(ams2, b, 26, 6, 5 + i2 * 4, bbe2);
                    this.a(ams2, e, 26, 5, 5 + i2 * 4, bbe2);
                    this.a(ams2, bbe2, 33, 2, 5 + i2 * 4, 33, 4, 5 + i2 * 4, b, b, false);
                    this.a(ams2, bbe2, 34, 4, 5 + i2 * 4, 35, 4, 5 + i2 * 4, b, b, false);
                    this.a(ams2, b, 32, 5, 5 + i2 * 4, bbe2);
                    this.a(ams2, b, 31, 6, 5 + i2 * 4, bbe2);
                    this.a(ams2, e, 31, 5, 5 + i2 * 4, bbe2);
                    this.a(ams2, bbe2, 27, 6, 5 + i2 * 4, 30, 6, 5 + i2 * 4, a, a, false);
                }
            }
        }

        private void c(ams ams22, Random random, bbe bbe2) {
            if (this.a(bbe2, 15, 20, 42, 21)) {
                ams ams22;
                int n2;
                this.a(ams22, bbe2, 15, 0, 21, 42, 0, 21, a, a, false);
                this.a(ams22, bbe2, 26, 1, 21, 31, 3, 21, false);
                this.a(ams22, bbe2, 21, 12, 21, 36, 12, 21, a, a, false);
                this.a(ams22, bbe2, 17, 11, 21, 40, 11, 21, a, a, false);
                this.a(ams22, bbe2, 16, 10, 21, 41, 10, 21, a, a, false);
                this.a(ams22, bbe2, 15, 7, 21, 42, 9, 21, a, a, false);
                this.a(ams22, bbe2, 16, 6, 21, 41, 6, 21, a, a, false);
                this.a(ams22, bbe2, 17, 5, 21, 40, 5, 21, a, a, false);
                this.a(ams22, bbe2, 21, 4, 21, 36, 4, 21, a, a, false);
                this.a(ams22, bbe2, 22, 3, 21, 26, 3, 21, a, a, false);
                this.a(ams22, bbe2, 31, 3, 21, 35, 3, 21, a, a, false);
                this.a(ams22, bbe2, 23, 2, 21, 25, 2, 21, a, a, false);
                this.a(ams22, bbe2, 32, 2, 21, 34, 2, 21, a, a, false);
                this.a(ams22, bbe2, 28, 4, 20, 29, 4, 21, b, b, false);
                this.a(ams22, b, 27, 3, 21, bbe2);
                this.a(ams22, b, 30, 3, 21, bbe2);
                this.a(ams22, b, 26, 2, 21, bbe2);
                this.a(ams22, b, 31, 2, 21, bbe2);
                this.a(ams22, b, 25, 1, 21, bbe2);
                this.a(ams22, b, 32, 1, 21, bbe2);
                for (n2 = 0; n2 < 7; ++n2) {
                    this.a(ams22, c, 28 - n2, 6 + n2, 21, bbe2);
                    this.a(ams22, c, 29 + n2, 6 + n2, 21, bbe2);
                }
                for (n2 = 0; n2 < 4; ++n2) {
                    this.a(ams22, c, 28 - n2, 9 + n2, 21, bbe2);
                    this.a(ams22, c, 29 + n2, 9 + n2, 21, bbe2);
                }
                this.a(ams22, c, 28, 12, 21, bbe2);
                this.a(ams22, c, 29, 12, 21, bbe2);
                for (n2 = 0; n2 < 3; ++n2) {
                    this.a(ams22, c, 22 - n2 * 2, 8, 21, bbe2);
                    this.a(ams22, c, 22 - n2 * 2, 9, 21, bbe2);
                    this.a(ams22, c, 35 + n2 * 2, 8, 21, bbe2);
                    this.a(ams22, c, 35 + n2 * 2, 9, 21, bbe2);
                }
                this.a(ams22, bbe2, 15, 13, 21, 42, 15, 21, false);
                this.a(ams22, bbe2, 15, 1, 21, 15, 6, 21, false);
                this.a(ams22, bbe2, 16, 1, 21, 16, 5, 21, false);
                this.a(ams22, bbe2, 17, 1, 21, 20, 4, 21, false);
                this.a(ams22, bbe2, 21, 1, 21, 21, 3, 21, false);
                this.a(ams22, bbe2, 22, 1, 21, 22, 2, 21, false);
                this.a(ams22, bbe2, 23, 1, 21, 24, 1, 21, false);
                this.a(ams22, bbe2, 42, 1, 21, 42, 6, 21, false);
                this.a(ams22, bbe2, 41, 1, 21, 41, 5, 21, false);
                this.a(ams22, bbe2, 37, 1, 21, 40, 4, 21, false);
                this.a(ams22, bbe2, 36, 1, 21, 36, 3, 21, false);
                this.a(ams22, bbe2, 33, 1, 21, 34, 1, 21, false);
                this.a(ams22, bbe2, 35, 1, 21, 35, 2, 21, false);
            }
        }

        private void d(ams ams22, Random random, bbe bbe2) {
            if (this.a(bbe2, 21, 21, 36, 36)) {
                ams ams22;
                this.a(ams22, bbe2, 21, 0, 22, 36, 0, 36, a, a, false);
                this.a(ams22, bbe2, 21, 1, 22, 36, 23, 36, false);
                for (int i2 = 0; i2 < 4; ++i2) {
                    this.a(ams22, bbe2, 21 + i2, 13 + i2, 21 + i2, 36 - i2, 13 + i2, 21 + i2, b, b, false);
                    this.a(ams22, bbe2, 21 + i2, 13 + i2, 36 - i2, 36 - i2, 13 + i2, 36 - i2, b, b, false);
                    this.a(ams22, bbe2, 21 + i2, 13 + i2, 22 + i2, 21 + i2, 13 + i2, 35 - i2, b, b, false);
                    this.a(ams22, bbe2, 36 - i2, 13 + i2, 22 + i2, 36 - i2, 13 + i2, 35 - i2, b, b, false);
                }
                this.a(ams22, bbe2, 25, 16, 25, 32, 16, 32, a, a, false);
                this.a(ams22, bbe2, 25, 17, 25, 25, 19, 25, b, b, false);
                this.a(ams22, bbe2, 32, 17, 25, 32, 19, 25, b, b, false);
                this.a(ams22, bbe2, 25, 17, 32, 25, 19, 32, b, b, false);
                this.a(ams22, bbe2, 32, 17, 32, 32, 19, 32, b, b, false);
                this.a(ams22, b, 26, 20, 26, bbe2);
                this.a(ams22, b, 27, 21, 27, bbe2);
                this.a(ams22, e, 27, 20, 27, bbe2);
                this.a(ams22, b, 26, 20, 31, bbe2);
                this.a(ams22, b, 27, 21, 30, bbe2);
                this.a(ams22, e, 27, 20, 30, bbe2);
                this.a(ams22, b, 31, 20, 31, bbe2);
                this.a(ams22, b, 30, 21, 30, bbe2);
                this.a(ams22, e, 30, 20, 30, bbe2);
                this.a(ams22, b, 31, 20, 26, bbe2);
                this.a(ams22, b, 30, 21, 27, bbe2);
                this.a(ams22, e, 30, 20, 27, bbe2);
                this.a(ams22, bbe2, 28, 21, 27, 29, 21, 27, a, a, false);
                this.a(ams22, bbe2, 27, 21, 28, 27, 21, 29, a, a, false);
                this.a(ams22, bbe2, 28, 21, 30, 29, 21, 30, a, a, false);
                this.a(ams22, bbe2, 30, 21, 28, 30, 21, 29, a, a, false);
            }
        }

        private void e(ams ams22, Random random, bbe bbe22) {
            bbe bbe22;
            ams ams22;
            int n2;
            if (this.a(bbe22, 0, 21, 6, 58)) {
                this.a(ams22, bbe22, 0, 0, 21, 6, 0, 57, a, a, false);
                this.a(ams22, bbe22, 0, 1, 21, 6, 7, 57, false);
                this.a(ams22, bbe22, 4, 4, 21, 6, 4, 53, a, a, false);
                for (n2 = 0; n2 < 4; ++n2) {
                    this.a(ams22, bbe22, n2, n2 + 1, 21, n2, n2 + 1, 57 - n2, b, b, false);
                }
                for (n2 = 23; n2 < 53; n2 += 3) {
                    this.a(ams22, d, 5, 5, n2, bbe22);
                }
                this.a(ams22, d, 5, 5, 52, bbe22);
                for (n2 = 0; n2 < 4; ++n2) {
                    this.a(ams22, bbe22, n2, n2 + 1, 21, n2, n2 + 1, 57 - n2, b, b, false);
                }
                this.a(ams22, bbe22, 4, 1, 52, 6, 3, 52, a, a, false);
                this.a(ams22, bbe22, 5, 1, 51, 5, 3, 53, a, a, false);
            }
            if (this.a(bbe22, 51, 21, 58, 58)) {
                this.a(ams22, bbe22, 51, 0, 21, 57, 0, 57, a, a, false);
                this.a(ams22, bbe22, 51, 1, 21, 57, 7, 57, false);
                this.a(ams22, bbe22, 51, 4, 21, 53, 4, 53, a, a, false);
                for (n2 = 0; n2 < 4; ++n2) {
                    this.a(ams22, bbe22, 57 - n2, n2 + 1, 21, 57 - n2, n2 + 1, 57 - n2, b, b, false);
                }
                for (n2 = 23; n2 < 53; n2 += 3) {
                    this.a(ams22, d, 52, 5, n2, bbe22);
                }
                this.a(ams22, d, 52, 5, 52, bbe22);
                this.a(ams22, bbe22, 51, 1, 52, 53, 3, 52, a, a, false);
                this.a(ams22, bbe22, 52, 1, 51, 52, 3, 53, a, a, false);
            }
            if (this.a(bbe22, 0, 51, 57, 57)) {
                this.a(ams22, bbe22, 7, 0, 51, 50, 0, 57, a, a, false);
                this.a(ams22, bbe22, 7, 1, 51, 50, 10, 57, false);
                for (n2 = 0; n2 < 4; ++n2) {
                    this.a(ams22, bbe22, n2 + 1, n2 + 1, 57 - n2, 56 - n2, n2 + 1, 57 - n2, b, b, false);
                }
            }
        }

        private void f(ams ams22, Random random, bbe bbe22) {
            bbe bbe22;
            int n2;
            if (this.a(bbe22, 7, 21, 13, 50)) {
                this.a(ams22, bbe22, 7, 0, 21, 13, 0, 50, a, a, false);
                this.a(ams22, bbe22, 7, 1, 21, 13, 10, 50, false);
                this.a(ams22, bbe22, 11, 8, 21, 13, 8, 53, a, a, false);
                for (n2 = 0; n2 < 4; ++n2) {
                    this.a(ams22, bbe22, n2 + 7, n2 + 5, 21, n2 + 7, n2 + 5, 54, b, b, false);
                }
                for (n2 = 21; n2 <= 45; n2 += 3) {
                    this.a(ams22, d, 12, 9, n2, bbe22);
                }
            }
            if (this.a(bbe22, 44, 21, 50, 54)) {
                this.a(ams22, bbe22, 44, 0, 21, 50, 0, 50, a, a, false);
                this.a(ams22, bbe22, 44, 1, 21, 50, 10, 50, false);
                this.a(ams22, bbe22, 44, 8, 21, 46, 8, 53, a, a, false);
                for (n2 = 0; n2 < 4; ++n2) {
                    this.a(ams22, bbe22, 50 - n2, n2 + 5, 21, 50 - n2, n2 + 5, 54, b, b, false);
                }
                for (n2 = 21; n2 <= 45; n2 += 3) {
                    this.a(ams22, d, 45, 9, n2, bbe22);
                }
            }
            if (this.a(bbe22, 8, 44, 49, 54)) {
                ams ams22;
                this.a(ams22, bbe22, 14, 0, 44, 43, 0, 50, a, a, false);
                this.a(ams22, bbe22, 14, 1, 44, 43, 10, 50, false);
                for (n2 = 12; n2 <= 45; n2 += 3) {
                    this.a(ams22, d, n2, 9, 45, bbe22);
                    this.a(ams22, d, n2, 9, 52, bbe22);
                    if (n2 != 12 && n2 != 18 && n2 != 24 && n2 != 33 && n2 != 39 && n2 != 45) continue;
                    this.a(ams22, d, n2, 9, 47, bbe22);
                    this.a(ams22, d, n2, 9, 50, bbe22);
                    this.a(ams22, d, n2, 10, 45, bbe22);
                    this.a(ams22, d, n2, 10, 46, bbe22);
                    this.a(ams22, d, n2, 10, 51, bbe22);
                    this.a(ams22, d, n2, 10, 52, bbe22);
                    this.a(ams22, d, n2, 11, 47, bbe22);
                    this.a(ams22, d, n2, 11, 50, bbe22);
                    this.a(ams22, d, n2, 12, 48, bbe22);
                    this.a(ams22, d, n2, 12, 49, bbe22);
                }
                for (n2 = 0; n2 < 3; ++n2) {
                    this.a(ams22, bbe22, 8 + n2, 5 + n2, 54, 49 - n2, 5 + n2, 54, a, a, false);
                }
                this.a(ams22, bbe22, 11, 8, 54, 46, 8, 54, b, b, false);
                this.a(ams22, bbe22, 14, 8, 44, 43, 8, 53, a, a, false);
            }
        }

        private void g(ams ams2, Random random, bbe bbe22) {
            bbe bbe22;
            int n2;
            if (this.a(bbe22, 14, 21, 20, 43)) {
                this.a(ams2, bbe22, 14, 0, 21, 20, 0, 43, a, a, false);
                this.a(ams2, bbe22, 14, 1, 22, 20, 14, 43, false);
                this.a(ams2, bbe22, 18, 12, 22, 20, 12, 39, a, a, false);
                this.a(ams2, bbe22, 18, 12, 21, 20, 12, 21, b, b, false);
                for (n2 = 0; n2 < 4; ++n2) {
                    this.a(ams2, bbe22, n2 + 14, n2 + 9, 21, n2 + 14, n2 + 9, 43 - n2, b, b, false);
                }
                for (n2 = 23; n2 <= 39; n2 += 3) {
                    this.a(ams2, d, 19, 13, n2, bbe22);
                }
            }
            if (this.a(bbe22, 37, 21, 43, 43)) {
                this.a(ams2, bbe22, 37, 0, 21, 43, 0, 43, a, a, false);
                this.a(ams2, bbe22, 37, 1, 22, 43, 14, 43, false);
                this.a(ams2, bbe22, 37, 12, 22, 39, 12, 39, a, a, false);
                this.a(ams2, bbe22, 37, 12, 21, 39, 12, 21, b, b, false);
                for (n2 = 0; n2 < 4; ++n2) {
                    this.a(ams2, bbe22, 43 - n2, n2 + 9, 21, 43 - n2, n2 + 9, 43 - n2, b, b, false);
                }
                for (n2 = 23; n2 <= 39; n2 += 3) {
                    this.a(ams2, d, 38, 13, n2, bbe22);
                }
            }
            if (this.a(bbe22, 15, 37, 42, 43)) {
                this.a(ams2, bbe22, 21, 0, 37, 36, 0, 43, a, a, false);
                this.a(ams2, bbe22, 21, 1, 37, 36, 14, 43, false);
                this.a(ams2, bbe22, 21, 12, 37, 36, 12, 39, a, a, false);
                for (n2 = 0; n2 < 4; ++n2) {
                    this.a(ams2, bbe22, 15 + n2, n2 + 9, 43 - n2, 42 - n2, n2 + 9, 43 - n2, b, b, false);
                }
                for (n2 = 21; n2 <= 36; n2 += 3) {
                    this.a(ams2, d, n2, 13, 38, bbe22);
                }
            }
        }
    }

    public static abstract class r
    extends bbv {
        protected static final awr a = aov.cI.a(asv.b);
        protected static final awr b = aov.cI.a(asv.c);
        protected static final awr c = aov.cI.a(asv.d);
        protected static final awr d = b;
        protected static final awr e = aov.cJ.t();
        protected static final awr f = aov.j.t();
        protected static final int g = r.b(2, 0, 0);
        protected static final int h = r.b(2, 2, 0);
        protected static final int i = r.b(0, 1, 0);
        protected static final int j = r.b(4, 1, 0);
        protected v k;

        protected static final int b(int n2, int n3, int n4) {
            return n3 * 25 + n4 * 5 + n2;
        }

        public r() {
            super(0);
        }

        public r(int n2) {
            super(n2);
        }

        public r(fa fa2, bbe bbe2) {
            super(1);
            this.a(fa2);
            this.l = bbe2;
        }

        protected r(int n2, fa fa2, v v2, int n3, int n4, int n5) {
            super(n2);
            this.a(fa2);
            this.k = v2;
            \u2603 = v2.a;
            \u2603 = \u2603 % 5;
            \u2603 = \u2603 / 5 % 5;
            \u2603 = \u2603 / 25;
            this.l = fa2 == fa.c || fa2 == fa.d ? new bbe(0, 0, 0, n3 * 8 - 1, n4 * 4 - 1, n5 * 8 - 1) : new bbe(0, 0, 0, n5 * 8 - 1, n4 * 4 - 1, n3 * 8 - 1);
            switch (fa2) {
                case c: {
                    this.l.a(\u2603 * 8, \u2603 * 4, -(\u2603 + n5) * 8 + 1);
                    break;
                }
                case d: {
                    this.l.a(\u2603 * 8, \u2603 * 4, \u2603 * 8);
                    break;
                }
                case e: {
                    this.l.a(-(\u2603 + n5) * 8 + 1, \u2603 * 4, \u2603 * 8);
                    break;
                }
                default: {
                    this.l.a(\u2603 * 8, \u2603 * 4, \u2603 * 8);
                }
            }
        }

        @Override
        protected void a(fy fy2) {
        }

        @Override
        protected void a(fy fy2, bce bce2) {
        }

        protected void a(ams ams2, bbe bbe2, int n2, int n3, int n4, int n5, int n6, int n7, boolean bl2) {
            for (int i2 = n3; i2 <= n6; ++i2) {
                for (\u2603 = n2; \u2603 <= n5; ++\u2603) {
                    for (\u2603 = n4; \u2603 <= n7; ++\u2603) {
                        if (bl2 && this.a(ams2, \u2603, i2, \u2603, bbe2).a() == bcx.a) continue;
                        if (this.d(i2) >= ams2.M()) {
                            this.a(ams2, aov.a.t(), \u2603, i2, \u2603, bbe2);
                            continue;
                        }
                        this.a(ams2, f, \u2603, i2, \u2603, bbe2);
                    }
                }
            }
        }

        protected void a(ams ams2, bbe bbe2, int n2, int n3, boolean bl2) {
            if (bl2) {
                this.a(ams2, bbe2, n2 + 0, 0, n3 + 0, n2 + 2, 0, n3 + 8 - 1, a, a, false);
                this.a(ams2, bbe2, n2 + 5, 0, n3 + 0, n2 + 8 - 1, 0, n3 + 8 - 1, a, a, false);
                this.a(ams2, bbe2, n2 + 3, 0, n3 + 0, n2 + 4, 0, n3 + 2, a, a, false);
                this.a(ams2, bbe2, n2 + 3, 0, n3 + 5, n2 + 4, 0, n3 + 8 - 1, a, a, false);
                this.a(ams2, bbe2, n2 + 3, 0, n3 + 2, n2 + 4, 0, n3 + 2, b, b, false);
                this.a(ams2, bbe2, n2 + 3, 0, n3 + 5, n2 + 4, 0, n3 + 5, b, b, false);
                this.a(ams2, bbe2, n2 + 2, 0, n3 + 3, n2 + 2, 0, n3 + 4, b, b, false);
                this.a(ams2, bbe2, n2 + 5, 0, n3 + 3, n2 + 5, 0, n3 + 4, b, b, false);
            } else {
                this.a(ams2, bbe2, n2 + 0, 0, n3 + 0, n2 + 8 - 1, 0, n3 + 8 - 1, a, a, false);
            }
        }

        protected void a(ams ams2, bbe bbe2, int n2, int n3, int n4, int n5, int n6, int n7, awr awr2) {
            for (int i2 = n3; i2 <= n6; ++i2) {
                for (\u2603 = n2; \u2603 <= n5; ++\u2603) {
                    for (\u2603 = n4; \u2603 <= n7; ++\u2603) {
                        if (this.a(ams2, \u2603, i2, \u2603, bbe2) != f) continue;
                        this.a(ams2, awr2, \u2603, i2, \u2603, bbe2);
                    }
                }
            }
        }

        protected boolean a(bbe bbe2, int n2, int n3, int n4, int n5) {
            \u2603 = this.a(n2, n3);
            \u2603 = this.b(n2, n3);
            \u2603 = this.a(n4, n5);
            \u2603 = this.b(n4, n5);
            return bbe2.a(Math.min(\u2603, \u2603), Math.min(\u2603, \u2603), Math.max(\u2603, \u2603), Math.max(\u2603, \u2603));
        }

        protected boolean a(ams ams2, bbe bbe2, int n2, int n3, int n4) {
            \u2603 = this.a(n2, n4);
            if (bbe2.b(new et(\u2603, \u2603 = this.d(n3), \u2603 = this.b(n2, n4)))) {
                acr acr2 = new acr(ams2);
                acr2.b(acr2.cj());
                acr2.b((double)\u2603 + 0.5, \u2603, (double)\u2603 + 0.5, 0.0f, 0.0f);
                acr2.a(ams2.D(new et(acr2)), null);
                ams2.a(acr2);
                return true;
            }
            return false;
        }
    }
}

