/*
 * Decompiled with CFR 0.150.
 */
public class apw
extends aou {
    public static final axf<a> a = axf.a("variant", a.class);
    public static final axd b = axd.a("snowy");

    protected apw() {
        super(bcx.c);
        this.w(this.A.b().a(a, apw$a.a).a(b, false));
        this.a(ahn.b);
    }

    @Override
    public bcy c(awr awr2, amw amw2, et et2) {
        return awr2.c(a).d();
    }

    @Override
    public awr d(awr \u260322, amw amw2, et et2) {
        awr \u260322;
        if (\u260322.c(a) == apw$a.c) {
            aou aou2 = amw2.o(et2.a()).u();
            \u260322 = \u260322.a(b, aou2 == aov.aJ || aou2 == aov.aH);
        }
        return \u260322;
    }

    @Override
    public void a(ahn ahn2, fi<ain> fi2) {
        fi2.add(new ain(this, 1, apw$a.a.a()));
        fi2.add(new ain(this, 1, apw$a.b.a()));
        fi2.add(new ain(this, 1, apw$a.c.a()));
    }

    @Override
    public ain a(ams ams2, et et2, awr awr2) {
        return new ain(this, 1, awr2.c(a).a());
    }

    @Override
    public awr a(int n2) {
        return this.t().a(a, apw$a.a(n2));
    }

    @Override
    public int e(awr awr2) {
        return awr2.c(a).a();
    }

    @Override
    protected aws b() {
        return new aws((aou)this, a, b);
    }

    @Override
    public int d(awr awr2) {
        a a2 = awr2.c(a);
        if (a2 == apw$a.c) {
            a2 = apw$a.a;
        }
        return a2.a();
    }

    public static enum a implements rm
    {
        a(0, "dirt", "default", bcy.m),
        b(1, "coarse_dirt", "coarse", bcy.m),
        c(2, "podzol", bcy.K);

        private static final a[] d;
        private final int e;
        private final String f;
        private final String g;
        private final bcy h;

        private a(int n3, String string2, bcy bcy2) {
            this(n3, string2, string2, bcy2);
        }

        private a(int n3, String string2, String string3, bcy bcy2) {
            this.e = n3;
            this.f = string2;
            this.g = string3;
            this.h = bcy2;
        }

        public int a() {
            return this.e;
        }

        public String c() {
            return this.g;
        }

        public bcy d() {
            return this.h;
        }

        public String toString() {
            return this.f;
        }

        public static a a(int n2) {
            if (n2 < 0 || n2 >= d.length) {
                n2 = 0;
            }
            return d[n2];
        }

        @Override
        public String m() {
            return this.f;
        }

        static {
            d = new a[apw$a.values().length];
            a[] arra = apw$a.values();
            int n2 = arra.length;
            for (int i2 = 0; i2 < n2; ++i2) {
                a a2;
                apw$a.d[a2.a()] = a2 = arra[i2];
            }
        }
    }
}

