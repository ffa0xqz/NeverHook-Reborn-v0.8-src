/*
 * Decompiled with CFR 0.150.
 */
public class avm
extends avh
implements nv {
    @Override
    public void e() {
        if (this.b != null && !this.b.G && this.b.R() % 20L == 0L) {
            this.e = this.x();
            if (this.e instanceof apr) {
                ((apr)this.e).c(this.b, this.c);
            }
        }
    }
}

