/*
 * Decompiled with CFR 0.150.
 */
public class bhn
extends bhm {
    public bhn(String string) {
        super(string);
    }

    @Override
    public boolean b() {
        return true;
    }

    @Override
    public bho.a c() {
        return bho.a.b;
    }
}

