/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import java.io.IOException;
import javax.annotation.Nullable;

public interface ayd {
    @Nullable
    public axu a(ams var1, int var2, int var3) throws IOException;

    public void a(ams var1, axu var2) throws IOException, amt;

    public void b(ams var1, axu var2) throws IOException;

    public void b();

    public void c();

    public boolean a(int var1, int var2);
}

