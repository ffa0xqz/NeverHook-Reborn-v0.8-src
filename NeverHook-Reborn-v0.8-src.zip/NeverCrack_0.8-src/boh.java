/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.apache.commons.io.FileUtils
 *  org.lwjgl.input.Keyboard
 */
import java.io.File;
import org.apache.commons.io.FileUtils;
import org.lwjgl.input.Keyboard;

public class boh
extends bli {
    private final bli a;
    private bjc f;
    private final String g;

    public boh(bli bli2, String string) {
        this.a = bli2;
        this.g = string;
    }

    @Override
    public void e() {
        this.f.a();
    }

    @Override
    public void b() {
        Keyboard.enableRepeatEvents((boolean)true);
        this.n.clear();
        biy biy2 = this.b(new biy(3, this.l / 2 - 100, this.m / 4 + 24 + 12, cew.a("selectWorld.edit.resetIcon", new Object[0])));
        this.n.add(new biy(4, this.l / 2 - 100, this.m / 4 + 48 + 12, cew.a("selectWorld.edit.openFolder", new Object[0])));
        this.n.add(new biy(0, this.l / 2 - 100, this.m / 4 + 96 + 12, cew.a("selectWorld.edit.save", new Object[0])));
        this.n.add(new biy(1, this.l / 2 - 100, this.m / 4 + 120 + 12, cew.a("gui.cancel", new Object[0])));
        biy2.l = this.j.g().b(this.g, "icon.png").isFile();
        bfe \u26032 = this.j.g();
        bfb \u26033 = \u26032.c(this.g);
        String \u26034 = \u26033 == null ? "" : \u26033.j();
        this.f = new bjc(2, this.q, this.l / 2 - 100, 60, 200, 20);
        this.f.b(true);
        this.f.a(\u26034);
    }

    @Override
    public void m() {
        Keyboard.enableRepeatEvents((boolean)false);
    }

    @Override
    protected void a(biy biy22) {
        biy biy22;
        if (!biy22.l) {
            return;
        }
        if (biy22.k == 1) {
            this.j.a(this.a);
        } else if (biy22.k == 0) {
            bfe bfe2 = this.j.g();
            bfe2.a(this.g, this.f.b().trim());
            this.j.a(this.a);
        } else if (biy22.k == 3) {
            bfe bfe3 = this.j.g();
            FileUtils.deleteQuietly((File)bfe3.b(this.g, "icon.png"));
            biy22.l = false;
        } else if (biy22.k == 4) {
            bfe bfe4 = this.j.g();
            cig.a(bfe4.b(this.g, "icon.png").getParentFile());
        }
    }

    @Override
    protected void a(char c2, int n2) {
        this.f.a(c2, n2);
        boolean bl2 = ((biy)this.n.get((int)2)).l = !this.f.b().trim().isEmpty();
        if (n2 == 28 || n2 == 156) {
            this.a((biy)this.n.get(2));
        }
    }

    @Override
    protected void a(int n2, int n3, int n4) {
        super.a(n2, n3, n4);
        this.f.a(n2, n3, n4);
    }

    @Override
    public void a(int n2, int n3, float f2) {
        this.c();
        this.a(this.q, cew.a("selectWorld.edit.title", new Object[0]), this.l / 2, 20, 0xFFFFFF);
        this.c(this.q, cew.a("selectWorld.enterName", new Object[0]), this.l / 2 - 100, 47, 0xA0A0A0);
        this.f.g();
        super.a(n2, n3, f2);
    }
}

