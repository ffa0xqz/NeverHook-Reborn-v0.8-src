/*
 * Decompiled with CFR 0.150.
 */
import java.util.Random;

public class auj
extends aoo {
    public static final axf<awc.a> a = axf.a("mode", awc.a.class);

    public auj() {
        super(bcx.f, bcy.y);
        this.w(this.A.b());
    }

    @Override
    public avh a(ams ams2, int n2) {
        return new awc();
    }

    @Override
    public boolean a(ams ams2, et et2, awr awr2, aeb aeb2, tz tz2, fa fa2, float f2, float f3, float f4) {
        avh avh2 = ams2.r(et2);
        if (avh2 instanceof awc) {
            return ((awc)avh2).a(aeb2);
        }
        return false;
    }

    @Override
    public void a(ams ams2, et et2, awr awr2, vn vn2, ain ain2) {
        if (ams2.G) {
            return;
        }
        avh avh2 = ams2.r(et2);
        if (!(avh2 instanceof awc)) {
            return;
        }
        awc \u26032 = (awc)avh2;
        \u26032.a(vn2);
    }

    @Override
    public int a(Random random) {
        return 0;
    }

    @Override
    public ath a(awr awr2) {
        return ath.d;
    }

    @Override
    public awr a(ams ams2, et et2, fa fa2, float f2, float f3, float f4, int n2, vn vn2) {
        return this.t().a(a, awc.a.d);
    }

    @Override
    public awr a(int n2) {
        return this.t().a(a, awc.a.a(n2));
    }

    @Override
    public int e(awr awr2) {
        return awr2.c(a).a();
    }

    @Override
    protected aws b() {
        return new aws((aou)this, a);
    }

    @Override
    public void a(awr awr2, ams ams2, et et2, aou aou2, et et3) {
        if (ams2.G) {
            return;
        }
        avh avh2 = ams2.r(et2);
        if (!(avh2 instanceof awc)) {
            return;
        }
        awc \u26032 = (awc)avh2;
        boolean \u26033 = ams2.y(et2);
        boolean \u26034 = \u26032.F();
        if (\u26033 && !\u26034) {
            \u26032.d(true);
            this.a(\u26032);
        } else if (!\u26033 && \u26034) {
            \u26032.d(false);
        }
    }

    private void a(awc awc2) {
        switch (awc2.k()) {
            case a: {
                awc2.b(false);
                break;
            }
            case b: {
                awc2.c(false);
                break;
            }
            case c: {
                awc2.s();
                break;
            }
            case d: {
                break;
            }
        }
    }
}

