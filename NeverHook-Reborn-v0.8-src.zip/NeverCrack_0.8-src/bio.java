/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 *  com.google.common.collect.Iterables
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Maps
 *  com.google.common.collect.Ordering
 *  javax.annotation.Nullable
 */
import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Ordering;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import javax.annotation.Nullable;
import optifine.Config;
import optifine.CustomColors;
import optifine.CustomItems;
import optifine.Reflector;
import optifine.ReflectorForge;
import optifine.TextureAnimations;
import top.nhprem.Main;
import top.nhprem.api.event.event.Event2D;
import top.nhprem.api.event.event.EventRender2D;
import top.nhprem.api.utils.render.ClientHelper;
import top.nhprem.api.utils.render.DrawHelper;
import top.nhprem.client.features.Feature;
import top.nhprem.client.features.impl.display.Hotbar;
import top.nhprem.client.features.impl.player.NoClip;
import top.nhprem.client.features.impl.visuals.Crosshair;
import top.nhprem.client.features.impl.visuals.NoRender;
import top.nhprem.client.features.impl.visuals.ScoreBoard;

public class bio
extends bip {
    private static final nd f = new nd("textures/misc/vignette.png");
    private static final nd g = new nd("textures/gui/widgets.png");
    private static final nd h = new nd("textures/misc/pumpkinblur.png");
    private final Random i = new Random();
    private final bhz j;
    private final bzu k;
    private final biz l;
    private int m;
    private String n = "";
    private int o;
    private boolean p;
    public float a = 1.0f;
    private int q;
    private ain r = ain.a;
    private final bjb s;
    private final bjs t;
    private final bju u;
    private final bjo v;
    private final bix w;
    private int x;
    private String y = "";
    private String z = "";
    private int A;
    private int B;
    private int C;
    private int D;
    private int E;
    private long F;
    private long G;
    private final Map<hf, List<bis>> H = Maps.newHashMap();
    double deltaSpeed = 0.0;
    double last = 0.0;

    public bio(bhz mcIn) {
        this.j = mcIn;
        this.k = mcIn.ad();
        this.s = new bjb(mcIn);
        this.u = new bju(mcIn);
        this.l = new biz(mcIn);
        this.v = new bjo(mcIn, this);
        this.w = new bix(mcIn);
        this.t = new bjs(mcIn);
        for (hf chattype : hf.values()) {
            this.H.put(chattype, Lists.newArrayList());
        }
        bit ichatlistener = bit.a;
        this.H.get((Object)hf.a).add(new biv(mcIn));
        this.H.get((Object)hf.a).add(ichatlistener);
        this.H.get((Object)hf.b).add(new biv(mcIn));
        this.H.get((Object)hf.b).add(ichatlistener);
        this.H.get((Object)hf.c).add(new biu(mcIn));
        this.a();
    }

    public void a() {
        this.A = 10;
        this.B = 70;
        this.C = 20;
    }

    public void a(float partialTicks) {
        bhe scoreobjective1;
        int i1;
        float f2;
        bir scaledresolution = new bir(this.j);
        int i2 = scaledresolution.a();
        int j2 = scaledresolution.b();
        bin fontrenderer = this.f();
        buq.m();
        if (Config.isVignetteEnabled()) {
            this.b(this.j.h.aw(), scaledresolution);
        } else {
            buq.k();
            buq.a(buq.r.l, buq.l.j, buq.r.e, buq.l.n);
        }
        ain itemstack = this.j.h.bv.g(3);
        if (this.j.t.aw == 0 && itemstack.c() == ail.a(aov.aU)) {
            this.f(scaledresolution);
        }
        if (!this.j.h.a(uz.i) && (f2 = this.j.h.ca + (this.j.h.bZ - this.j.h.ca) * partialTicks) > 0.0f) {
            this.c(f2, scaledresolution);
        }
        if (this.j.c.a()) {
            this.u.a(scaledresolution, partialTicks);
        } else {
            this.a(scaledresolution, partialTicks);
        }
        Event2D event2D = new Event2D(scaledresolution.a(), scaledresolution.b());
        event2D.call();
        buq.c(1.0f, 1.0f, 1.0f, 1.0f);
        this.j.N().a(d);
        buq.m();
        this.a(partialTicks, scaledresolution);
        buq.a(buq.r.l, buq.l.j, buq.r.e, buq.l.n);
        this.j.B.a("bossHealth");
        if (!Main.instance.featureDirector.getFeatureByClass(NoRender.class).isToggled() || !NoRender.noBoss.getBoolValue()) {
            this.w.a();
        }
        this.j.B.b();
        buq.c(1.0f, 1.0f, 1.0f, 1.0f);
        this.j.N().a(d);
        if (this.j.c.b()) {
            this.d(scaledresolution);
        }
        this.e(scaledresolution);
        buq.l();
        if (this.j.h.dd() > 0) {
            this.j.B.a("sleep");
            buq.j();
            buq.d();
            int j1 = this.j.h.dd();
            float f1 = (float)j1 / 100.0f;
            if (f1 > 1.0f) {
                f1 = 1.0f - (float)(j1 - 100) / 10.0f;
            }
            int k2 = (int)(220.0f * f1) << 24 | 0x101020;
            bio.drawRect(0.0, 0.0, i2, j2, k2);
            buq.e();
            buq.k();
            this.j.B.b();
        }
        buq.c(1.0f, 1.0f, 1.0f, 1.0f);
        int k1 = i2 / 2 - 91;
        if (this.j.h.H()) {
            this.a(scaledresolution, k1);
        } else if (this.j.c.f()) {
            this.b(scaledresolution, k1);
        }
        if (this.j.t.F && !this.j.c.a()) {
            this.b(scaledresolution);
        } else if (this.j.h.y()) {
            this.u.a(scaledresolution);
        }
        if (this.j.u()) {
            this.c(scaledresolution);
        }
        this.a(scaledresolution);
        if (this.j.t.ax) {
            this.s.a(scaledresolution);
        }
        if (this.o > 0) {
            this.j.B.a("overlayMessage");
            float f22 = (float)this.o - partialTicks;
            int l1 = (int)(f22 * 255.0f / 20.0f);
            if (l1 > 255) {
                l1 = 255;
            }
            if (l1 > 8) {
                buq.G();
                buq.c((float)(i2 / 2), (float)(j2 - 68), 0.0f);
                buq.m();
                buq.a(buq.r.l, buq.l.j, buq.r.e, buq.l.n);
                int l2 = 0xFFFFFF;
                if (this.p) {
                    l2 = ri.c(f22 / 50.0f, 0.7f, 0.6f) & 0xFFFFFF;
                }
                fontrenderer.drawString(this.n, -fontrenderer.a(this.n) / 2, -4.0f, l2 + (l1 << 24 & 0xFF000000));
                buq.l();
                buq.H();
            }
            this.j.B.b();
        }
        this.t.a(scaledresolution);
        if (this.x > 0) {
            this.j.B.a("titleAndSubtitle");
            float f3 = (float)this.x - partialTicks;
            int i22 = 255;
            if (this.x > this.C + this.B) {
                float f4 = (float)(this.A + this.B + this.C) - f3;
                i22 = (int)(f4 * 255.0f / (float)this.A);
            }
            if (this.x <= this.C) {
                i22 = (int)(f3 * 255.0f / (float)this.C);
            }
            if ((i22 = ri.a(i22, 0, 255)) > 8) {
                buq.G();
                buq.c((float)(i2 / 2), (float)(j2 / 2), 0.0f);
                buq.m();
                buq.a(buq.r.l, buq.l.j, buq.r.e, buq.l.n);
                buq.G();
                buq.b(4.0f, 4.0f, 4.0f);
                int j22 = i22 << 24 & 0xFF000000;
                fontrenderer.a(this.y, (float)(-fontrenderer.a(this.y) / 2), -10.0f, 0xFFFFFF | j22, true);
                buq.H();
                buq.G();
                buq.b(2.0f, 2.0f, 2.0f);
                fontrenderer.a(this.z, (float)(-fontrenderer.a(this.z) / 2), 5.0f, 0xFFFFFF | j22, true);
                buq.H();
                buq.l();
                buq.H();
            }
            this.j.B.b();
        }
        bhi scoreboard = this.j.f.af();
        bhe scoreobjective = null;
        bhf scoreplayerteam = scoreboard.g(this.j.h.h_());
        if (scoreplayerteam != null && (i1 = scoreplayerteam.m().b()) >= 0) {
            scoreobjective = scoreboard.a(3 + i1);
        }
        bhe bhe2 = scoreobjective1 = scoreobjective != null ? scoreobjective : scoreboard.a(1);
        if (!(scoreobjective1 == null || Main.instance.featureDirector.getFeatureByClass(ScoreBoard.class).isToggled() && ScoreBoard.noScore.getBoolValue())) {
            this.a(scoreobjective1, scaledresolution);
        }
        EventRender2D eventRender2D = new EventRender2D(scaledresolution, partialTicks);
        eventRender2D.call();
        buq.m();
        buq.a(buq.r.l, buq.l.j, buq.r.e, buq.l.n);
        buq.d();
        buq.G();
        buq.c(0.0f, (float)(j2 - 48), 0.0f);
        this.j.B.a("chat");
        this.l.a(this.m);
        this.j.B.b();
        buq.H();
        scoreobjective1 = scoreboard.a(0);
        if (this.j.t.ah.e() && (!this.j.D() || this.j.h.d.d().size() > 1 || scoreobjective1 != null)) {
            this.v.a(true);
            this.v.a(i2, scoreboard, scoreobjective1);
        } else {
            this.v.a(false);
        }
        buq.c(1.0f, 1.0f, 1.0f, 1.0f);
        buq.g();
        buq.e();
    }

    private void a(float p_184045_1_, bir p_184045_2_) {
        bib gamesettings = this.j.t;
        if (gamesettings.aw == 0) {
            if (this.j.c.a() && this.j.i == null || Main.instance.featureDirector.getFeatureByClass(NoClip.class).isToggled()) {
                bha raytraceresult = this.j.s;
                if (raytraceresult == null || raytraceresult.a != bha.a.b) {
                    return;
                }
                et blockpos = raytraceresult.a();
                awr iblockstate = this.j.f.o(blockpos);
                if (!ReflectorForge.blockHasTileEntity(iblockstate) || !(this.j.f.r(blockpos) instanceof tt)) {
                    return;
                }
            }
            int l2 = p_184045_2_.a();
            int i1 = p_184045_2_.b();
            if (gamesettings.ax && !gamesettings.av && !this.j.h.do() && !gamesettings.x) {
                buq.G();
                buq.c((float)(l2 / 2), (float)(i1 / 2), e);
                ve entity = this.j.aa();
                buq.b(entity.y + (entity.w - entity.y) * p_184045_1_, -1.0f, 0.0f, 0.0f);
                buq.b(entity.x + (entity.v - entity.x) * p_184045_1_, 0.0f, 1.0f, 0.0f);
                buq.b(-1.0f, -1.0f, -1.0f);
                cig.m(10);
                buq.H();
            } else {
                buq.a(buq.r.i, buq.l.k, buq.r.e, buq.l.n);
                buq.e();
                if (!Main.instance.featureDirector.getFeatureByClass(Crosshair.class).isToggled()) {
                    this.b(l2 / 2 - 7, i1 / 2 - 7, 0, 0, 16, 16);
                }
                if (this.j.t.N == 1) {
                    float f2 = this.j.h.n(0.0f);
                    boolean flag = false;
                    if (this.j.i != null && this.j.i instanceof vn && f2 >= 1.0f) {
                        flag = this.j.h.dr() > 5.0f;
                        flag &= ((vn)this.j.i).aC();
                    }
                    int i2 = i1 / 2 - 7 + 16;
                    int j2 = l2 / 2 - 8;
                    if (flag) {
                        this.b(j2, i2, 68, 94, 16, 16);
                    } else if (f2 < 1.0f) {
                        int k2 = (int)(f2 * 17.0f);
                        this.b(j2, i2, 36, 94, 16, 4);
                        this.b(j2, i2, 52, 94, k2, 4);
                    }
                }
            }
        }
    }

    protected void a(bir resolution) {
        bir sr2 = new bir(this.j);
        Collection<uy> collection = this.j.h.ca();
        if (!collection.isEmpty()) {
            this.j.N().a(bme.a);
            buq.m();
            int i2 = 0;
            int j2 = 0;
            Iterator iterator = Ordering.natural().reverse().sortedCopy(collection).iterator();
            while (true) {
                if (!iterator.hasNext()) {
                    return;
                }
                uy potioneffect = (uy)iterator.next();
                ux potion = potioneffect.a();
                boolean flag = potion.c();
                if (Reflector.ForgePotion_shouldRenderHUD.exists()) {
                    if (!Reflector.callBoolean(potion, Reflector.ForgePotion_shouldRenderHUD, potioneffect)) continue;
                    this.j.N().a(bme.a);
                    flag = true;
                }
                if (!flag || !potioneffect.e()) continue;
                int k2 = resolution.a();
                int l2 = 1;
                if (this.j.u()) {
                    l2 += 15;
                }
                int i1 = potion.d();
                if (potion.i()) {
                    k2 -= 25 * ++i2;
                } else {
                    k2 -= 25 * ++j2;
                    l2 += 26;
                }
                buq.c(1.0f, 1.0f, 1.0f, 1.0f);
                float f2 = 1.0f;
                if (potioneffect.d() && potioneffect.b() <= 200) {
                    int j1 = 10 - potioneffect.b() / 20;
                    f2 = ri.a((float)potioneffect.b() / 10.0f / 5.0f * 0.5f, 0.0f, 0.5f) + ri.b((float)potioneffect.b() * (float)Math.PI / 5.0f) * ri.a((float)j1 / 10.0f * 0.25f, 0.0f, 0.25f);
                }
                buq.c(1.0f, 1.0f, 1.0f, f2);
                if (Reflector.ForgePotion_renderHUDEffect.exists()) {
                    if (potion.c()) {
                        this.b(k2 + 4, -l2 + sr2.b() - 20, i1 % 8 * 18, 198 + i1 / 8 * 18, 18, 18);
                    }
                    Reflector.call(potion, Reflector.ForgePotion_renderHUDEffect, k2, l2, potioneffect, this.j, Float.valueOf(f2));
                    continue;
                }
                this.b(k2 + 4, -l2 + sr2.b() - 20, i1 % 8 * 18, 198 + i1 / 8 * 18, 18, 18);
            }
        }
    }

    protected void a(bir sr2, float partialTicks) {
        if (!(this.j.m instanceof bkl)) {
            float f2;
            int i2;
            ain itemstack;
            if (Main.instance.featureDirector.getFeatureByClass(Hotbar.class).isToggled()) {
                bio.drawRect(0.0, (double)(sr2.b() - 23) - Feature.deltaTime(), sr2.a(), sr2.b(), -1728053248);
                double target = sr2.a() / 2 - 91 + this.j.h.bv.d * 20;
                double delta = (target - this.last) / (double)Math.max((float)bhz.af(), 5.0f) * 15.0;
                this.last = Math.abs(delta) > Math.abs(target - this.last) ? target : (this.last += delta);
                DrawHelper.drawRect((float)this.last, (double)(sr2.b() - 23) - Feature.deltaTime(), (float)this.last + 182.0f - (float)(this.j.h.bv.d * 20) - (float)(20 * (8 - this.j.h.bv.d)), (double)sr2.b() - Feature.deltaTime(), ClientHelper.getClientColor().getRGB());
                buq.l();
            } else if (this.j.aa() instanceof aeb) {
                buq.c(1.0f, 1.0f, 1.0f, 1.0f);
                this.j.N().a(g);
                aeb entityplayer = (aeb)this.j.aa();
                itemstack = entityplayer.cp();
                vm enumhandside = entityplayer.cF().a();
                i2 = sr2.a() / 2;
                f2 = e;
                int j2 = 182;
                int k2 = 91;
                e = -90.0f;
                bio.a(i2 - 91, (float)((double)(sr2.b() - 22) - Feature.deltaTime()), 0, 0, 182, 22);
                bio.a(i2 - 91 - 1 + entityplayer.bv.d * 20, (float)((double)(sr2.b() - 22 - 1) - Feature.deltaTime()), 0, 22, 24, 22);
            }
            if (this.j.aa() instanceof aeb) {
                float f1;
                buq.c(1.0f, 1.0f, 1.0f, 1.0f);
                this.j.N().a(g);
                aeb entityplayer = (aeb)this.j.aa();
                itemstack = entityplayer.cp();
                vm enumhandside = entityplayer.cF().a();
                i2 = sr2.a() / 2;
                f2 = e;
                e = -90.0f;
                if (Main.instance.featureDirector.getFeatureByClass(Hotbar.class).isToggled() && !itemstack.b()) {
                    if (enumhandside == vm.a) {
                        bio.a(i2 - 91 - 29, (float)((double)(sr2.b() - 23) - Feature.deltaTime()), 24, 22, 29, 24);
                    } else {
                        bio.a(i2 + 91, (float)((double)(sr2.b() - 23) - Feature.deltaTime()), 53, 22, 29, 24);
                    }
                }
                e = f2;
                buq.D();
                buq.m();
                buq.a(buq.r.l, buq.l.j, buq.r.e, buq.l.n);
                bhx.c();
                CustomItems.setRenderOffHand(false);
                for (int l2 = 0; l2 < 9; ++l2) {
                    int i1 = i2 - 90 + l2 * 20 + 2;
                    int j1 = sr2.b() - 16 - 3;
                    this.a(i1, (int)((double)j1 - Feature.deltaTime()), partialTicks, entityplayer, entityplayer.bv.a.get(l2));
                }
                if (!itemstack.b()) {
                    CustomItems.setRenderOffHand(true);
                    int l1 = (int)((double)(sr2.b() - 16 - 3) - Feature.deltaTime());
                    if (enumhandside == vm.a) {
                        this.a(i2 - 91 - 26, l1, partialTicks, entityplayer, itemstack);
                    } else {
                        this.a(i2 + 91 + 10, l1, partialTicks, entityplayer, itemstack);
                    }
                    CustomItems.setRenderOffHand(false);
                }
                if (this.j.t.N == 2 && (f1 = this.j.h.n(0.0f)) < 1.0f) {
                    int i22 = sr2.b() - 20;
                    int j2 = i2 + 91 + 6;
                    if (enumhandside == vm.b) {
                        j2 = i2 - 91 - 22;
                    }
                    this.j.N().a(bip.d);
                    int k1 = (int)(f1 * 19.0f);
                    buq.c(1.0f, 1.0f, 1.0f, 1.0f);
                    this.b(j2, i22, 0, 94, 18, 18);
                    this.b(j2, i22 + 18 - k1, 18, 112 - k1, 18, k1);
                }
                bhx.a();
                buq.E();
                buq.l();
            }
        }
    }

    public void a(bir scaledRes, int x2) {
        this.j.B.a("jumpBar");
        this.j.N().a(bip.d);
        float f2 = this.j.h.J();
        int i2 = 182;
        int j2 = (int)(f2 * 183.0f);
        int k2 = scaledRes.b() - 32 + 3;
        this.b(x2, k2, 0, 84, 182, 5);
        if (j2 > 0) {
            this.b(x2, k2, 0, 89, j2, 5);
        }
        this.j.B.b();
    }

    public void b(bir scaledRes, int x2) {
        this.j.B.a("expBar");
        this.j.N().a(bip.d);
        int i2 = this.j.h.dh();
        if (i2 > 0) {
            int j2 = 182;
            int k2 = (int)(this.j.h.bR * 183.0f);
            int l2 = scaledRes.b() - 32 + 3;
            this.b(x2, l2, 0, 64, 182, 5);
            if (k2 > 0) {
                this.b(x2, l2, 0, 69, k2, 5);
            }
        }
        this.j.B.b();
        if (this.j.h.bP > 0) {
            this.j.B.a("expLevel");
            int j1 = 8453920;
            if (Config.isCustomColors()) {
                j1 = CustomColors.getExpBarTextColor(j1);
            }
            String s2 = "" + this.j.h.bP;
            int k1 = (scaledRes.a() - this.f().a(s2)) / 2;
            int i1 = scaledRes.b() - 31 - 4;
            this.f().drawString(s2, k1 + 1, i1, 0);
            this.f().drawString(s2, k1 - 1, i1, 0);
            this.f().drawString(s2, k1, i1 + 1, 0);
            this.f().drawString(s2, k1, i1 - 1, 0);
            this.f().drawString(s2, k1, i1, j1);
            this.j.B.b();
        }
    }

    public void b(bir scaledRes) {
        this.j.B.a("selectedItemName");
        if (this.q > 0 && !this.r.b()) {
            int k2;
            String s2 = this.r.r();
            if (this.r.t()) {
                s2 = (Object)((Object)a.u) + s2;
            }
            int i2 = (scaledRes.a() - this.f().a(s2)) / 2;
            int j2 = scaledRes.b() - 59;
            if (!this.j.c.b()) {
                j2 += 14;
            }
            if ((k2 = (int)((float)this.q * 256.0f / 10.0f)) > 255) {
                k2 = 255;
            }
            if (k2 > 0) {
                buq.G();
                buq.m();
                buq.a(buq.r.l, buq.l.j, buq.r.e, buq.l.n);
                this.f().a(s2, i2, j2, 0xFFFFFF + (k2 << 24));
                buq.l();
                buq.H();
            }
        }
        this.j.B.b();
    }

    public void c(bir scaledRes) {
        this.j.B.a("demo");
        String s2 = this.j.f.R() >= 120500L ? cew.a("demo.demoExpired", new Object[0]) : cew.a("demo.remainingTime", rn.a((int)(120500L - this.j.f.R())));
        int i2 = this.f().a(s2);
        this.f().a(s2, scaledRes.a() - i2 - 10, 5.0f, 0xFFFFFF);
        this.j.B.b();
    }

    private void a(bhe objective, bir scaledRes) {
        bhi scoreboard = objective.a();
        ArrayList collection = scoreboard.i(objective);
        ArrayList list = Lists.newArrayList((Iterable)Iterables.filter(collection, (Predicate)new Predicate<bhg>(){

            public boolean a(@Nullable bhg p_apply_1_) {
                return p_apply_1_.e() != null && !p_apply_1_.e().startsWith("#");
            }
        }));
        collection = list.size() > 15 ? Lists.newArrayList((Iterable)Iterables.skip((Iterable)list, (int)(collection.size() - 15))) : list;
        int i2 = this.f().a(objective.d());
        for (bhg score : collection) {
            bhf scoreplayerteam = scoreboard.g(score.e());
            String s2 = bhf.a(scoreplayerteam, score.e()) + ": " + (Object)((Object)a.m) + score.c();
            i2 = Math.max(i2, this.f().a(s2));
        }
        int i1 = collection.size() * this.f().a;
        int j1 = scaledRes.b() / 2 + i1 / 3;
        int k1 = 3;
        int l1 = scaledRes.a() - i2 - 3;
        int j2 = 0;
        for (bhg score1 : collection) {
            bhf scoreplayerteam1 = scoreboard.g(score1.e());
            String s1 = bhf.a(scoreplayerteam1, score1.e());
            String s2 = (Object)((Object)a.m) + "" + score1.c();
            int k2 = j1 - ++j2 * this.f().a;
            int l2 = scaledRes.a() - 3 + 2;
            bio.drawRect(l1 - 2, k2, l2, k2 + this.f().a, 0x50000000);
            this.f().drawString(s1, l1, k2, 0x20FFFFFF);
            this.f().drawString(s2, l2 - this.f().a(s2), k2, 0x20FFFFFF);
            if (j2 != collection.size()) continue;
            String s3 = objective.d();
            bio.drawRect(l1 - 2, k2 - this.f().a - 1, l2, k2 - 1, 0x60000000);
            bio.drawRect(l1 - 2, k2 - 1, l2, k2, 0x50000000);
            this.f().drawString(s3, l1 + i2 / 2 - this.f().a(s3) / 2, k2 - this.f().a, 0x20FFFFFF);
        }
    }

    private void d(bir scaledRes) {
        if (this.j.aa() instanceof aeb) {
            boolean flag;
            aeb entityplayer = (aeb)this.j.aa();
            int i2 = ri.f(entityplayer.cd());
            boolean bl2 = flag = this.G > (long)this.m && (this.G - (long)this.m) / 3L % 2L == 1L;
            if (i2 < this.D && entityplayer.V > 0) {
                this.F = bhz.I();
                this.G = this.m + 20;
            } else if (i2 > this.D && entityplayer.V > 0) {
                this.F = bhz.I();
                this.G = this.m + 10;
            }
            if (bhz.I() - this.F > 1000L) {
                this.D = i2;
                this.E = i2;
                this.F = bhz.I();
            }
            this.D = i2;
            int j2 = this.E;
            this.i.setSeed(this.m * 312871);
            afn foodstats = entityplayer.di();
            int k2 = foodstats.a();
            wb iattributeinstance = entityplayer.a(adf.a);
            int l2 = scaledRes.a() / 2 - 91;
            int i1 = scaledRes.a() / 2 + 91;
            int j1 = scaledRes.b() - 39;
            float f2 = (float)iattributeinstance.e();
            int k1 = ri.f(entityplayer.cD());
            int l1 = ri.f((f2 + (float)k1) / 2.0f / 10.0f);
            int i22 = Math.max(10 - (l1 - 2), 3);
            int j22 = j1 - (l1 - 1) * i22 - 10;
            int k22 = j1 - 10;
            int l22 = k1;
            int i3 = entityplayer.cg();
            int j3 = -1;
            if (entityplayer.a(uz.j)) {
                j3 = this.m % ri.f(f2 + 5.0f);
            }
            this.j.B.a("armor");
            for (int k3 = 0; k3 < 10; ++k3) {
                if (i3 <= 0) continue;
                int l3 = l2 + k3 * 8;
                if (k3 * 2 + 1 < i3) {
                    this.b(l3, j22, 34, 9, 9, 9);
                }
                if (k3 * 2 + 1 == i3) {
                    this.b(l3, j22, 25, 9, 9, 9);
                }
                if (k3 * 2 + 1 <= i3) continue;
                this.b(l3, j22, 16, 9, 9, 9);
            }
            this.j.B.c("health");
            for (int j5 = ri.f((f2 + (float)k1) / 2.0f) - 1; j5 >= 0; --j5) {
                int k5 = 16;
                if (entityplayer.a(uz.s)) {
                    k5 += 36;
                } else if (entityplayer.a(uz.t)) {
                    k5 += 72;
                }
                int i4 = 0;
                if (flag) {
                    i4 = 1;
                }
                int j4 = ri.f((float)(j5 + 1) / 10.0f) - 1;
                int k4 = l2 + j5 % 10 * 8;
                int l4 = j1 - j4 * i22;
                if (i2 <= 4) {
                    l4 += this.i.nextInt(2);
                }
                if (l22 <= 0 && j5 == j3) {
                    l4 -= 2;
                }
                int i5 = 0;
                if (entityplayer.l.V().s()) {
                    i5 = 5;
                }
                this.b(k4, l4, 16 + i4 * 9, 9 * i5, 9, 9);
                if (flag) {
                    if (j5 * 2 + 1 < j2) {
                        this.b(k4, l4, k5 + 54, 9 * i5, 9, 9);
                    }
                    if (j5 * 2 + 1 == j2) {
                        this.b(k4, l4, k5 + 63, 9 * i5, 9, 9);
                    }
                }
                if (l22 > 0) {
                    if (l22 == k1 && k1 % 2 == 1) {
                        this.b(k4, l4, k5 + 153, 9 * i5, 9, 9);
                        --l22;
                        continue;
                    }
                    this.b(k4, l4, k5 + 144, 9 * i5, 9, 9);
                    l22 -= 2;
                    continue;
                }
                if (j5 * 2 + 1 < i2) {
                    this.b(k4, l4, k5 + 36, 9 * i5, 9, 9);
                }
                if (j5 * 2 + 1 != i2) continue;
                this.b(k4, l4, k5 + 45, 9 * i5, 9, 9);
            }
            ve entity = entityplayer.bJ();
            if (entity == null || !(entity instanceof vn)) {
                this.j.B.c("food");
                for (int l5 = 0; l5 < 10; ++l5) {
                    int j6 = j1;
                    int l6 = 16;
                    int j7 = 0;
                    if (entityplayer.a(uz.q)) {
                        l6 += 36;
                        j7 = 13;
                    }
                    if (entityplayer.di().e() <= 0.0f && this.m % (k2 * 3 + 1) == 0) {
                        j6 = j1 + (this.i.nextInt(3) - 1);
                    }
                    int l7 = i1 - l5 * 8 - 9;
                    this.b(l7, j6, 16 + j7 * 9, 27, 9, 9);
                    if (l5 * 2 + 1 < k2) {
                        this.b(l7, j6, l6 + 36, 27, 9, 9);
                    }
                    if (l5 * 2 + 1 != k2) continue;
                    this.b(l7, j6, l6 + 45, 27, 9, 9);
                }
            }
            this.j.B.c("air");
            if (entityplayer.a(bcx.h)) {
                int i6 = this.j.h.aZ();
                int k6 = ri.f((double)(i6 - 2) * 10.0 / 300.0);
                int i7 = ri.f((double)i6 * 10.0 / 300.0) - k6;
                for (int k7 = 0; k7 < k6 + i7; ++k7) {
                    if (k7 < k6) {
                        this.b(i1 - k7 * 8 - 9, k22, 16, 18, 9, 9);
                        continue;
                    }
                    this.b(i1 - k7 * 8 - 9, k22, 25, 18, 9, 9);
                }
            }
            this.j.B.b();
        }
    }

    private void e(bir p_184047_1_) {
        aeb entityplayer;
        ve entity;
        if (this.j.aa() instanceof aeb && (entity = (entityplayer = (aeb)this.j.aa()).bJ()) instanceof vn) {
            this.j.B.c("mountHealth");
            vn entitylivingbase = (vn)entity;
            int i2 = (int)Math.ceil(entitylivingbase.cd());
            float f2 = entitylivingbase.cj();
            int j2 = (int)(f2 + 0.5f) / 2;
            if (j2 > 30) {
                j2 = 30;
            }
            int k2 = p_184047_1_.b() - 39;
            int l2 = p_184047_1_.a() / 2 + 91;
            int i1 = k2;
            int j1 = 0;
            boolean flag = false;
            while (j2 > 0) {
                int k1 = Math.min(j2, 10);
                j2 -= k1;
                for (int l1 = 0; l1 < k1; ++l1) {
                    int i22 = 52;
                    int j22 = 0;
                    int k22 = l2 - l1 * 8 - 9;
                    this.b(k22, i1, 52 + j22 * 9, 9, 9, 9);
                    if (l1 * 2 + 1 + j1 < i2) {
                        this.b(k22, i1, 88, 9, 9, 9);
                    }
                    if (l1 * 2 + 1 + j1 != i2) continue;
                    this.b(k22, i1, 97, 9, 9, 9);
                }
                i1 -= 10;
                j1 += 20;
            }
        }
    }

    private void f(bir scaledRes) {
        buq.j();
        buq.a(false);
        buq.a(buq.r.l, buq.l.j, buq.r.e, buq.l.n);
        buq.c(1.0f, 1.0f, 1.0f, 1.0f);
        buq.d();
        this.j.N().a(h);
        bvc tessellator = bvc.a();
        bui bufferbuilder = tessellator.c();
        bufferbuilder.a(7, cdw.g);
        bufferbuilder.b(0.0, (double)scaledRes.b(), -90.0).a(0.0, 1.0).d();
        bufferbuilder.b((double)scaledRes.a(), (double)scaledRes.b(), -90.0).a(1.0, 1.0).d();
        bufferbuilder.b((double)scaledRes.a(), 0.0, -90.0).a(1.0, 0.0).d();
        bufferbuilder.b(0.0, 0.0, -90.0).a(0.0, 0.0).d();
        tessellator.b();
        buq.a(true);
        buq.k();
        buq.e();
        buq.c(1.0f, 1.0f, 1.0f, 1.0f);
    }

    private void b(float lightLevel, bir scaledRes) {
        if (!Config.isVignetteEnabled()) {
            buq.k();
            buq.a(buq.r.l, buq.l.j, buq.r.e, buq.l.n);
        } else {
            lightLevel = 1.0f - lightLevel;
            lightLevel = ri.a(lightLevel, 0.0f, 1.0f);
            axl worldborder = this.j.f.al();
            float f2 = (float)worldborder.a(this.j.h);
            double d0 = Math.min(worldborder.o() * (double)worldborder.p() * 1000.0, Math.abs(worldborder.j() - worldborder.h()));
            double d1 = Math.max((double)worldborder.q(), d0);
            f2 = (double)f2 < d1 ? 1.0f - (float)((double)f2 / d1) : 0.0f;
            this.a = (float)((double)this.a + (double)(lightLevel - this.a) * 0.01);
            buq.j();
            buq.a(false);
            buq.a(buq.r.o, buq.l.k, buq.r.e, buq.l.n);
            if (f2 > 0.0f) {
                buq.c(0.0f, f2, f2, 1.0f);
            } else {
                buq.c(this.a, this.a, this.a, 1.0f);
            }
            this.j.N().a(f);
            bvc tessellator = bvc.a();
            bui bufferbuilder = tessellator.c();
            bufferbuilder.a(7, cdw.g);
            bufferbuilder.b(0.0, (double)scaledRes.b(), -90.0).a(0.0, 1.0).d();
            bufferbuilder.b((double)scaledRes.a(), (double)scaledRes.b(), -90.0).a(1.0, 1.0).d();
            bufferbuilder.b((double)scaledRes.a(), 0.0, -90.0).a(1.0, 0.0).d();
            bufferbuilder.b(0.0, 0.0, -90.0).a(0.0, 0.0).d();
            tessellator.b();
            buq.a(true);
            buq.k();
            buq.c(1.0f, 1.0f, 1.0f, 1.0f);
            buq.a(buq.r.l, buq.l.j, buq.r.e, buq.l.n);
        }
    }

    private void c(float timeInPortal, bir scaledRes) {
        if (timeInPortal < 1.0f) {
            timeInPortal *= timeInPortal;
            timeInPortal *= timeInPortal;
            timeInPortal = timeInPortal * 0.8f + 0.2f;
        }
        buq.d();
        buq.j();
        buq.a(false);
        buq.a(buq.r.l, buq.l.j, buq.r.e, buq.l.n);
        buq.c(1.0f, 1.0f, 1.0f, timeInPortal);
        this.j.N().a(cdn.g);
        cdo textureatlassprite = this.j.ab().a().a(aov.aY.t());
        float f2 = textureatlassprite.e();
        float f1 = textureatlassprite.g();
        float f22 = textureatlassprite.f();
        float f3 = textureatlassprite.h();
        bvc tessellator = bvc.a();
        bui bufferbuilder = tessellator.c();
        bufferbuilder.a(7, cdw.g);
        bufferbuilder.b(0.0, (double)scaledRes.b(), -90.0).a(f2, f3).d();
        bufferbuilder.b((double)scaledRes.a(), (double)scaledRes.b(), -90.0).a(f22, f3).d();
        bufferbuilder.b((double)scaledRes.a(), 0.0, -90.0).a(f22, f1).d();
        bufferbuilder.b(0.0, 0.0, -90.0).a(f2, f1).d();
        tessellator.b();
        buq.a(true);
        buq.k();
        buq.e();
        buq.c(1.0f, 1.0f, 1.0f, 1.0f);
    }

    private void a(int p_184044_1_, int p_184044_2_, float p_184044_3_, aeb player, ain stack) {
        if (!stack.b()) {
            float f2 = (float)stack.D() - p_184044_3_;
            if (f2 > 0.0f) {
                buq.G();
                float f1 = 1.0f + f2 / 5.0f;
                buq.c((float)(p_184044_1_ + 8), (float)(p_184044_2_ + 12), 0.0f);
                buq.b(1.0f / f1, (f1 + 1.0f) / 2.0f, 1.0f);
                buq.c((float)(-(p_184044_1_ + 8)), (float)(-(p_184044_2_ + 12)), 0.0f);
            }
            this.k.a(player, stack, p_184044_1_, p_184044_2_);
            if (f2 > 0.0f) {
                buq.H();
            }
            this.k.a(bhz.k, stack, p_184044_1_, p_184044_2_);
        }
    }

    public void c() {
        if (this.j.f == null) {
            TextureAnimations.updateAnimations();
        }
        if (this.o > 0) {
            --this.o;
        }
        if (this.x > 0) {
            --this.x;
            if (this.x <= 0) {
                this.y = "";
                this.z = "";
            }
        }
        ++this.m;
        if (this.j.h != null) {
            ain itemstack = this.j.h.bv.i();
            if (itemstack.b()) {
                this.q = 0;
            } else if (!this.r.b() && itemstack.c() == this.r.c() && ain.a(itemstack, this.r) && (itemstack.f() || itemstack.j() == this.r.j())) {
                if (this.q > 0) {
                    --this.q;
                }
            } else {
                this.q = 40;
            }
            this.r = itemstack;
        }
    }

    public void a(String recordName) {
        this.a(cew.a("record.nowPlaying", recordName), true);
    }

    public void a(String message, boolean isPlaying) {
        this.n = message;
        this.o = 60;
        this.p = isPlaying;
    }

    public void a(String title, String subTitle, int timeFadeIn, int displayTime, int timeFadeOut) {
        if (title == null && subTitle == null && timeFadeIn < 0 && displayTime < 0 && timeFadeOut < 0) {
            this.y = "";
            this.z = "";
            this.x = 0;
        } else if (title != null) {
            this.y = title;
            this.x = this.A + this.B + this.C;
        } else if (subTitle != null) {
            this.z = subTitle;
        } else {
            if (timeFadeIn >= 0) {
                this.A = timeFadeIn;
            }
            if (displayTime >= 0) {
                this.B = displayTime;
            }
            if (timeFadeOut >= 0) {
                this.C = timeFadeOut;
            }
            if (this.x > 0) {
                this.x = this.A + this.B + this.C;
            }
        }
    }

    public void a(hh component, boolean isPlaying) {
        this.a(component.c(), isPlaying);
    }

    public void a(hf p_191742_1_, hh p_191742_2_) {
        for (bis ichatlistener : this.H.get((Object)p_191742_1_)) {
            ichatlistener.a(p_191742_1_, p_191742_2_);
        }
    }

    public biz d() {
        return this.l;
    }

    public int e() {
        return this.m;
    }

    public bin f() {
        return bhz.k;
    }

    public bju g() {
        return this.u;
    }

    public bjo h() {
        return this.v;
    }

    public void i() {
        this.v.a();
        this.w.b();
        this.j.ao().a();
    }

    public bix j() {
        return this.w;
    }
}

