/*
 * Decompiled with CFR 0.150.
 */
public class arc
extends asg {
    @Override
    public boolean e() {
        return false;
    }
}

