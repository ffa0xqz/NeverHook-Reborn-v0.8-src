/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

public class cw
extends bi {
    @Override
    public String c() {
        return "particle";
    }

    @Override
    public int a() {
        return 2;
    }

    @Override
    public String b(bn bn2) {
        return "commands.particle.usage";
    }

    @Override
    public void a(MinecraftServer minecraftServer, bn bn22, String[] arrstring) throws ei {
        bn bn22;
        if (arrstring.length < 8) {
            throw new ep("commands.particle.usage", new Object[0]);
        }
        boolean bl2 = false;
        fj \u26032 = fj.a(arrstring[0]);
        if (\u26032 == null) {
            throw new ei("commands.particle.notFound", arrstring[0]);
        }
        String \u26033 = arrstring[0];
        bhc \u26034 = bn22.d();
        double \u26035 = (float)cw.b(\u26034.b, arrstring[1], true);
        double \u26036 = (float)cw.b(\u26034.c, arrstring[2], true);
        double \u26037 = (float)cw.b(\u26034.d, arrstring[3], true);
        double \u26038 = (float)cw.c(arrstring[4]);
        double \u26039 = (float)cw.c(arrstring[5]);
        double \u260310 = (float)cw.c(arrstring[6]);
        double \u260311 = (float)cw.c(arrstring[7]);
        int \u260312 = 0;
        if (arrstring.length > 8) {
            \u260312 = cw.a(arrstring[8], 0);
        }
        \u2603 = false;
        if (arrstring.length > 9 && "force".equals(arrstring[9])) {
            \u2603 = true;
        }
        oo \u260313 = arrstring.length > 10 ? cw.b(minecraftServer, bn22, arrstring[10]) : null;
        int[] \u260314 = new int[\u26032.d()];
        for (int i2 = 0; i2 < \u260314.length; ++i2) {
            if (arrstring.length <= 11 + i2) continue;
            try {
                \u260314[i2] = Integer.parseInt(arrstring[11 + i2]);
                continue;
            }
            catch (NumberFormatException numberFormatException) {
                throw new ei("commands.particle.invalidParam", arrstring[11 + i2]);
            }
        }
        ams \u260315 = bn22.e();
        if (\u260315 instanceof om) {
            om om2 = (om)\u260315;
            if (\u260313 == null) {
                om2.a(\u26032, \u2603, \u26035, \u26036, \u26037, \u260312, \u26038, \u26039, \u260310, \u260311, \u260314);
            } else {
                om2.a(\u260313, \u26032, \u2603, \u26035, \u26036, \u26037, \u260312, \u26038, \u26039, \u260310, \u260311, \u260314);
            }
            cw.a(bn22, (bk)this, "commands.particle.success", \u26033, Math.max(\u260312, 1));
        }
    }

    @Override
    public List<String> a(MinecraftServer minecraftServer, bn bn2, String[] arrstring, @Nullable et et2) {
        if (arrstring.length == 1) {
            return cw.a(arrstring, fj.a());
        }
        if (arrstring.length > 1 && arrstring.length <= 4) {
            return cw.a(arrstring, 1, et2);
        }
        if (arrstring.length == 10) {
            return cw.a(arrstring, "normal", "force");
        }
        if (arrstring.length == 11) {
            return cw.a(arrstring, minecraftServer.J());
        }
        return Collections.emptyList();
    }

    @Override
    public boolean b(String[] arrstring, int n2) {
        return n2 == 10;
    }
}

