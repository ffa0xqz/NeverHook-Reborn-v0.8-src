/*
 * Decompiled with CFR 0.150.
 */
public class ej
extends ei {
    public ej(String string) {
        this("commands.generic.entity.notFound", string);
    }

    public ej(String string, Object ... arrobject) {
        super(string, arrobject);
    }

    @Override
    public synchronized Throwable fillInStackTrace() {
        return this;
    }
}

