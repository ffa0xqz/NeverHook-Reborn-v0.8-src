/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Maps
 *  com.google.common.collect.Sets
 *  javax.annotation.Nullable
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public abstract class bj
implements bl {
    private static final Logger a = LogManager.getLogger();
    private final Map<String, bk> b = Maps.newHashMap();
    private final Set<bk> c = Sets.newHashSet();

    @Override
    public int a(bn sender, String rawCommand) {
        if ((rawCommand = rawCommand.trim()).startsWith("/")) {
            rawCommand = rawCommand.substring(1);
        }
        String[] astring = rawCommand.split(" ");
        String s2 = astring[0];
        astring = bj.a(astring);
        bk icommand = this.b.get(s2);
        int i2 = 0;
        try {
            int j2 = this.a(icommand, astring);
            if (icommand == null) {
                hp textcomponenttranslation1 = new hp("commands.generic.notFound", new Object[0]);
                textcomponenttranslation1.b().a(a.m);
                sender.a(textcomponenttranslation1);
            } else if (icommand.a(this.a(), sender)) {
                if (j2 > -1) {
                    List<ve> list = bq.b(sender, astring[j2], ve.class);
                    String s1 = astring[j2];
                    sender.a(bp.a.c, list.size());
                    if (list.isEmpty()) {
                        throw new en("commands.generic.selector.notFound", astring[j2]);
                    }
                    for (ve entity : list) {
                        astring[j2] = entity.bn();
                        if (!this.a(sender, astring, icommand, rawCommand)) continue;
                        ++i2;
                    }
                    astring[j2] = s1;
                } else {
                    sender.a(bp.a.c, 1);
                    if (this.a(sender, astring, icommand, rawCommand)) {
                        ++i2;
                    }
                }
            } else {
                hp textcomponenttranslation2 = new hp("commands.generic.permission", new Object[0]);
                textcomponenttranslation2.b().a(a.m);
                sender.a(textcomponenttranslation2);
            }
        }
        catch (ei commandexception) {
            hp textcomponenttranslation = new hp(commandexception.getMessage(), commandexception.a());
            textcomponenttranslation.b().a(a.m);
            sender.a(textcomponenttranslation);
        }
        sender.a(bp.a.a, i2);
        return i2;
    }

    protected boolean a(bn sender, String[] args, bk command, String input) {
        try {
            command.a(this.a(), sender, args);
            return true;
        }
        catch (ep wrongusageexception) {
            hp textcomponenttranslation2 = new hp("commands.generic.usage", new hp(wrongusageexception.getMessage(), wrongusageexception.a()));
            textcomponenttranslation2.b().a(a.m);
            sender.a(textcomponenttranslation2);
        }
        catch (ei commandexception) {
            hp textcomponenttranslation1 = new hp(commandexception.getMessage(), commandexception.a());
            textcomponenttranslation1.b().a(a.m);
            sender.a(textcomponenttranslation1);
        }
        catch (Throwable throwable) {
            hp textcomponenttranslation = new hp("commands.generic.exception", new Object[0]);
            textcomponenttranslation.b().a(a.m);
            sender.a(textcomponenttranslation);
            a.warn("Couldn't process command: " + input, throwable);
        }
        return false;
    }

    protected abstract MinecraftServer a();

    public bk a(bk command) {
        this.b.put(command.c(), command);
        this.c.add(command);
        for (String s2 : command.b()) {
            bk icommand = this.b.get(s2);
            if (icommand != null && icommand.c().equals(s2)) continue;
            this.b.put(s2, command);
        }
        return command;
    }

    private static String[] a(String[] input) {
        String[] astring = new String[input.length - 1];
        System.arraycopy(input, 1, astring, 0, input.length - 1);
        return astring;
    }

    @Override
    public List<String> a(bn sender, String input, @Nullable et pos) {
        bk icommand;
        String[] astring = input.split(" ", -1);
        String s2 = astring[0];
        if (astring.length == 1) {
            ArrayList list = Lists.newArrayList();
            for (Map.Entry<String, bk> entry : this.b.entrySet()) {
                if (!bi.a(s2, entry.getKey()) || !entry.getValue().a(this.a(), sender)) continue;
                list.add(entry.getKey());
            }
            return list;
        }
        if (astring.length > 1 && (icommand = this.b.get(s2)) != null && icommand.a(this.a(), sender)) {
            return icommand.a(this.a(), sender, bj.a(astring), pos);
        }
        return Collections.emptyList();
    }

    @Override
    public List<bk> a(bn sender) {
        ArrayList list = Lists.newArrayList();
        for (bk icommand : this.c) {
            if (!icommand.a(this.a(), sender)) continue;
            list.add(icommand);
        }
        return list;
    }

    @Override
    public Map<String, bk> b() {
        return this.b;
    }

    private int a(bk command, String[] args) throws ei {
        if (command == null) {
            return -1;
        }
        for (int i2 = 0; i2 < args.length; ++i2) {
            if (!command.b(args, i2) || !bq.a(args[i2])) continue;
            return i2;
        }
        return -1;
    }
}

