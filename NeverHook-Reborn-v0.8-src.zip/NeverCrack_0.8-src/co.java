/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

public class co
extends bi {
    @Override
    public String c() {
        return "kick";
    }

    @Override
    public int a() {
        return 3;
    }

    @Override
    public String b(bn bn2) {
        return "commands.kick.usage";
    }

    @Override
    public void a(MinecraftServer minecraftServer, bn bn2, String[] arrstring) throws ei {
        if (arrstring.length <= 0 || arrstring[0].length() <= 1) {
            throw new ep("commands.kick.usage", new Object[0]);
        }
        oo oo2 = minecraftServer.am().a(arrstring[0]);
        if (oo2 == null) {
            throw new en("commands.generic.player.notFound", arrstring[0]);
        }
        if (arrstring.length >= 2) {
            hh hh2 = co.a(bn2, arrstring, 1);
            oo2.a.b(hh2);
            co.a(bn2, (bk)this, "commands.kick.success.reason", oo2.h_(), hh2.c());
        } else {
            oo2.a.b(new hp("multiplayer.disconnect.kicked", new Object[0]));
            co.a(bn2, (bk)this, "commands.kick.success", oo2.h_());
        }
    }

    @Override
    public List<String> a(MinecraftServer minecraftServer, bn bn2, String[] arrstring, @Nullable et et2) {
        if (arrstring.length >= 1) {
            return co.a(arrstring, minecraftServer.J());
        }
        return Collections.emptyList();
    }
}

