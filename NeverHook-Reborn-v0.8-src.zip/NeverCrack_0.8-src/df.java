/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

public class df
extends bi {
    @Override
    public String c() {
        return "say";
    }

    @Override
    public int a() {
        return 1;
    }

    @Override
    public String b(bn bn2) {
        return "commands.say.usage";
    }

    @Override
    public void a(MinecraftServer minecraftServer, bn bn2, String[] arrstring) throws ei {
        if (arrstring.length <= 0 || arrstring[0].length() <= 0) {
            throw new ep("commands.say.usage", new Object[0]);
        }
        hh hh2 = df.b(bn2, arrstring, 0, true);
        minecraftServer.am().a(new hp("chat.type.announcement", bn2.i_(), hh2));
    }

    @Override
    public List<String> a(MinecraftServer minecraftServer, bn bn2, String[] arrstring, @Nullable et et2) {
        if (arrstring.length >= 1) {
            return df.a(arrstring, minecraftServer.J());
        }
        return Collections.emptyList();
    }
}

