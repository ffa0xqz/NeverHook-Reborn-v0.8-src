/*
 * Decompiled with CFR 0.150.
 */
public class bzv
extends cad<adb> {
    private static final nd a = new nd("textures/entity/slime/magmacube.png");

    public bzv(bzd bzd2) {
        super(bzd2, new bpy(), 0.25f);
    }

    @Override
    protected nd a(adb adb2) {
        return a;
    }

    @Override
    protected void a(adb adb2, float f2) {
        int n2 = adb2.dl();
        float \u26032 = (adb2.c + (adb2.b - adb2.c) * f2) / ((float)n2 * 0.5f + 1.0f);
        float \u26033 = 1.0f / (\u26032 + 1.0f);
        buq.b(\u26033 * (float)n2, 1.0f / \u26033 * (float)n2, \u26033 * (float)n2);
    }
}

