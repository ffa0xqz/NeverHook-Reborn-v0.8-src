/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.base.MoreObjects
 *  com.google.common.collect.Lists
 *  javax.annotation.Nullable
 */
import com.google.common.base.MoreObjects;
import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import optifine.Config;
import optifine.CustomColors;

public class akg {
    public static List<uy> a(ain stack) {
        return akg.a(stack.p());
    }

    public static List<uy> a(ake potionIn, Collection<uy> effects) {
        ArrayList list = Lists.newArrayList();
        list.addAll(potionIn.a());
        list.addAll(effects);
        return list;
    }

    public static List<uy> a(@Nullable fy tag) {
        ArrayList list = Lists.newArrayList();
        list.addAll(akg.c(tag).a());
        akg.a(tag, list);
        return list;
    }

    public static List<uy> b(ain itemIn) {
        return akg.b(itemIn.p());
    }

    public static List<uy> b(@Nullable fy tag) {
        ArrayList list = Lists.newArrayList();
        akg.a(tag, list);
        return list;
    }

    public static void a(@Nullable fy tag, List<uy> effectList) {
        if (tag != null && tag.b("CustomPotionEffects", 9)) {
            ge nbttaglist = tag.c("CustomPotionEffects", 10);
            for (int i2 = 0; i2 < nbttaglist.c(); ++i2) {
                fy nbttagcompound = nbttaglist.b(i2);
                uy potioneffect = uy.b(nbttagcompound);
                if (potioneffect == null) continue;
                effectList.add(potioneffect);
            }
        }
    }

    public static int c(ain p_190932_0_) {
        fy nbttagcompound = p_190932_0_.p();
        if (nbttagcompound != null && nbttagcompound.b("CustomPotionColor", 99)) {
            return nbttagcompound.h("CustomPotionColor");
        }
        return akg.d(p_190932_0_) == akh.a ? 0xF800F8 : akg.a(akg.a(p_190932_0_));
    }

    public static int a(ake potionIn) {
        return potionIn == akh.a ? 0xF800F8 : akg.a(potionIn.a());
    }

    public static int a(Collection<uy> effects) {
        int i2 = 3694022;
        if (effects.isEmpty()) {
            return Config.isCustomColors() ? CustomColors.getPotionColor(null, i2) : 3694022;
        }
        float f2 = 0.0f;
        float f1 = 0.0f;
        float f22 = 0.0f;
        int j2 = 0;
        for (uy potioneffect : effects) {
            if (!potioneffect.e()) continue;
            int k2 = potioneffect.a().g();
            if (Config.isCustomColors()) {
                k2 = CustomColors.getPotionColor(potioneffect.a(), k2);
            }
            int l2 = potioneffect.c() + 1;
            f2 += (float)(l2 * (k2 >> 16 & 0xFF)) / 255.0f;
            f1 += (float)(l2 * (k2 >> 8 & 0xFF)) / 255.0f;
            f22 += (float)(l2 * (k2 >> 0 & 0xFF)) / 255.0f;
            j2 += l2;
        }
        if (j2 == 0) {
            return 0;
        }
        f2 = f2 / (float)j2 * 255.0f;
        f1 = f1 / (float)j2 * 255.0f;
        f22 = f22 / (float)j2 * 255.0f;
        return (int)f2 << 16 | (int)f1 << 8 | (int)f22;
    }

    public static ake d(ain itemIn) {
        return akg.c(itemIn.p());
    }

    public static ake c(@Nullable fy tag) {
        return tag == null ? akh.a : ake.a(tag.l("Potion"));
    }

    public static ain a(ain itemIn, ake potionIn) {
        nd resourcelocation = ake.a.b(potionIn);
        if (potionIn == akh.a) {
            if (itemIn.o()) {
                fy nbttagcompound = itemIn.p();
                nbttagcompound.r("Potion");
                if (nbttagcompound.b_()) {
                    itemIn.b((fy)null);
                }
            }
        } else {
            fy nbttagcompound1 = itemIn.o() ? itemIn.p() : new fy();
            nbttagcompound1.a("Potion", resourcelocation.toString());
            itemIn.b(nbttagcompound1);
        }
        return itemIn;
    }

    public static ain a(ain itemIn, Collection<uy> effects) {
        if (effects.isEmpty()) {
            return itemIn;
        }
        fy nbttagcompound = (fy)MoreObjects.firstNonNull((Object)itemIn.p(), (Object)new fy());
        ge nbttaglist = nbttagcompound.c("CustomPotionEffects", 9);
        for (uy potioneffect : effects) {
            nbttaglist.a(potioneffect.a(new fy()));
        }
        nbttagcompound.a("CustomPotionEffects", nbttaglist);
        itemIn.b(nbttagcompound);
        return itemIn;
    }

    public static void a(ain itemIn, List<String> lores, float durationFactor) {
        List<uy> list = akg.a(itemIn);
        ArrayList list1 = Lists.newArrayList();
        if (list.isEmpty()) {
            String s2 = ft.a("effect.none").trim();
            lores.add((Object)((Object)a.h) + s2);
        } else {
            for (uy potioneffect : list) {
                String s1 = ft.a(potioneffect.f()).trim();
                ux potion = potioneffect.a();
                Map<wa, wc> map = potion.h();
                if (!map.isEmpty()) {
                    for (Map.Entry<wa, wc> entry : map.entrySet()) {
                        wc attributemodifier = entry.getValue();
                        wc attributemodifier1 = new wc(attributemodifier.b(), potion.a(potioneffect.c(), attributemodifier), attributemodifier.c());
                        list1.add(new rp<String, wc>(entry.getKey().a(), attributemodifier1));
                    }
                }
                if (potioneffect.c() > 0) {
                    s1 = s1 + " " + ft.a("potion.potency." + potioneffect.c()).trim();
                }
                if (potioneffect.b() > 20) {
                    s1 = s1 + " (" + ux.a(potioneffect, durationFactor) + ")";
                }
                if (potion.e()) {
                    lores.add((Object)((Object)a.m) + s1);
                    continue;
                }
                lores.add((Object)((Object)a.j) + s1);
            }
        }
        if (!list1.isEmpty()) {
            lores.add("");
            lores.add((Object)((Object)a.f) + ft.a("potion.whenDrank"));
            for (rp tuple : list1) {
                wc attributemodifier2 = (wc)tuple.b();
                double d0 = attributemodifier2.d();
                double d1 = attributemodifier2.c() != 1 && attributemodifier2.c() != 2 ? attributemodifier2.d() : attributemodifier2.d() * 100.0;
                if (d0 > 0.0) {
                    lores.add((Object)((Object)a.j) + ft.a("attribute.modifier.plus." + attributemodifier2.c(), ain.b.format(d1), ft.a("attribute.name." + (String)tuple.a())));
                    continue;
                }
                if (!(d0 < 0.0)) continue;
                lores.add((Object)((Object)a.m) + ft.a("attribute.modifier.take." + attributemodifier2.c(), ain.b.format(d1 *= -1.0), ft.a("attribute.name." + (String)tuple.a())));
            }
        }
    }
}

