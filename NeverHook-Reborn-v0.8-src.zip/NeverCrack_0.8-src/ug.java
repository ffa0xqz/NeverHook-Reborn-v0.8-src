/*
 * Decompiled with CFR 0.150.
 */
public interface ug {
    public String h_();

    public boolean n_();

    public hh i_();
}

