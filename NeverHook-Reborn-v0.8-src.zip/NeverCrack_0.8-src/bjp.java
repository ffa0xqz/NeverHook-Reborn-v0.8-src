/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Mouse
 */
import org.lwjgl.input.Mouse;

public abstract class bjp {
    protected final bhz a;
    protected int b;
    protected int c;
    protected int d;
    protected int e;
    protected int f;
    protected int g;
    protected final int h;
    private int u;
    private int v;
    protected int i;
    protected int j;
    protected boolean k = true;
    protected int l = -2;
    protected float m;
    protected float n;
    protected int o = -1;
    protected long p;
    protected boolean q = true;
    protected boolean r = true;
    protected boolean s;
    protected int t;
    private boolean w = true;

    public bjp(bhz mcIn, int width, int height, int topIn, int bottomIn, int slotHeightIn) {
        this.a = mcIn;
        this.b = width;
        this.c = height;
        this.d = topIn;
        this.e = bottomIn;
        this.h = slotHeightIn;
        this.g = 0;
        this.f = width;
    }

    public void a(int widthIn, int heightIn, int topIn, int bottomIn) {
        this.b = widthIn;
        this.c = heightIn;
        this.d = topIn;
        this.e = bottomIn;
        this.g = 0;
        this.f = widthIn;
    }

    public void b(boolean p_193651_1_) {
        this.r = p_193651_1_;
    }

    protected void a(boolean hasListHeaderIn, int headerPaddingIn) {
        this.s = hasListHeaderIn;
        this.t = headerPaddingIn;
        if (!hasListHeaderIn) {
            this.t = 0;
        }
    }

    protected abstract int b();

    protected abstract void a(int var1, boolean var2, int var3, int var4);

    protected abstract boolean a(int var1);

    protected int k() {
        return this.b() * this.h + this.t;
    }

    protected abstract void a();

    protected void a(int p_192639_1_, int p_192639_2_, int p_192639_3_, float p_192639_4_) {
    }

    protected abstract void a(int var1, int var2, int var3, int var4, int var5, int var6, float var7);

    protected void a(int insideLeft, int insideTop, bvc tessellatorIn) {
    }

    protected void a(int p_148132_1_, int p_148132_2_) {
    }

    protected void b(int mouseXIn, int mouseYIn) {
    }

    public int c(int posX, int posY) {
        int i2 = this.g + this.b / 2 - this.c() / 2;
        int j2 = this.g + this.b / 2 + this.c() / 2;
        int k2 = posY - this.d - this.t + (int)this.n - 4;
        int l2 = k2 / this.h;
        return posX < this.d() && posX >= i2 && posX <= j2 && l2 >= 0 && k2 >= 0 && l2 < this.b() ? l2 : -1;
    }

    public void d(int scrollUpButtonIDIn, int scrollDownButtonIDIn) {
        this.u = scrollUpButtonIDIn;
        this.v = scrollDownButtonIDIn;
    }

    protected void l() {
        this.n = ri.a(this.n, 0.0f, (float)this.m());
    }

    public int m() {
        return Math.max(0, this.k() - (this.e - this.d - 4));
    }

    public int n() {
        return (int)this.n;
    }

    public boolean g(int p_148141_1_) {
        return p_148141_1_ >= this.d && p_148141_1_ <= this.e && this.i >= this.g && this.i <= this.f;
    }

    public void h(int amount) {
        this.n += (float)amount;
        this.l();
        this.l = -2;
    }

    public void a(biy button) {
        if (button.l) {
            if (button.k == this.u) {
                this.n -= (float)(this.h * 2 / 3);
                this.l = -2;
                this.l();
            } else if (button.k == this.v) {
                this.n += (float)(this.h * 2 / 3);
                this.l = -2;
                this.l();
            }
        }
    }

    public void a(int mouseXIn, int mouseYIn, float partialTicks) {
        if (this.q) {
            this.i = mouseXIn;
            this.j = mouseYIn;
            this.a();
            int i2 = this.d();
            int j2 = i2 + 6;
            this.l();
            buq.g();
            buq.p();
            bvc tessellator = bvc.a();
            bui bufferbuilder = tessellator.c();
            this.drawContainerBackground(tessellator);
            int k2 = this.g + this.b / 2 - this.c() / 2 + 2;
            int l2 = this.d + 4 - (int)this.n;
            if (this.s) {
                this.a(k2, l2, tessellator);
            }
            this.a(k2, l2, mouseXIn, mouseYIn, partialTicks);
            buq.j();
            this.b(0, this.d, 255, 255);
            this.b(this.e, this.c, 255, 255);
            buq.m();
            buq.a(buq.r.l, buq.l.j, buq.r.o, buq.l.e);
            buq.d();
            buq.j(7425);
            buq.z();
            int i1 = 4;
            bufferbuilder.a(7, cdw.i);
            bufferbuilder.b((double)this.g, (double)(this.d + 4), 0.0).a(0.0, 1.0).b(0, 0, 0, 0).d();
            bufferbuilder.b((double)this.f, (double)(this.d + 4), 0.0).a(1.0, 1.0).b(0, 0, 0, 0).d();
            bufferbuilder.b((double)this.f, (double)this.d, 0.0).a(1.0, 0.0).b(0, 0, 0, 255).d();
            bufferbuilder.b((double)this.g, (double)this.d, 0.0).a(0.0, 0.0).b(0, 0, 0, 255).d();
            tessellator.b();
            bufferbuilder.a(7, cdw.i);
            bufferbuilder.b((double)this.g, (double)this.e, 0.0).a(0.0, 1.0).b(0, 0, 0, 255).d();
            bufferbuilder.b((double)this.f, (double)this.e, 0.0).a(1.0, 1.0).b(0, 0, 0, 255).d();
            bufferbuilder.b((double)this.f, (double)(this.e - 4), 0.0).a(1.0, 0.0).b(0, 0, 0, 0).d();
            bufferbuilder.b((double)this.g, (double)(this.e - 4), 0.0).a(0.0, 0.0).b(0, 0, 0, 0).d();
            tessellator.b();
            int j1 = this.m();
            if (j1 > 0) {
                int k1 = (this.e - this.d) * (this.e - this.d) / this.k();
                int l1 = (int)this.n * (this.e - this.d - (k1 = ri.a(k1, 32, this.e - this.d - 8))) / j1 + this.d;
                if (l1 < this.d) {
                    l1 = this.d;
                }
                bufferbuilder.a(7, cdw.i);
                bufferbuilder.b((double)i2, (double)this.e, 0.0).a(0.0, 1.0).b(0, 0, 0, 255).d();
                bufferbuilder.b((double)j2, (double)this.e, 0.0).a(1.0, 1.0).b(0, 0, 0, 255).d();
                bufferbuilder.b((double)j2, (double)this.d, 0.0).a(1.0, 0.0).b(0, 0, 0, 255).d();
                bufferbuilder.b((double)i2, (double)this.d, 0.0).a(0.0, 0.0).b(0, 0, 0, 255).d();
                tessellator.b();
                bufferbuilder.a(7, cdw.i);
                bufferbuilder.b((double)i2, (double)(l1 + k1), 0.0).a(0.0, 1.0).b(128, 128, 128, 255).d();
                bufferbuilder.b((double)j2, (double)(l1 + k1), 0.0).a(1.0, 1.0).b(128, 128, 128, 255).d();
                bufferbuilder.b((double)j2, (double)l1, 0.0).a(1.0, 0.0).b(128, 128, 128, 255).d();
                bufferbuilder.b((double)i2, (double)l1, 0.0).a(0.0, 0.0).b(128, 128, 128, 255).d();
                tessellator.b();
                bufferbuilder.a(7, cdw.i);
                bufferbuilder.b((double)i2, (double)(l1 + k1 - 1), 0.0).a(0.0, 1.0).b(192, 192, 192, 255).d();
                bufferbuilder.b((double)(j2 - 1), (double)(l1 + k1 - 1), 0.0).a(1.0, 1.0).b(192, 192, 192, 255).d();
                bufferbuilder.b((double)(j2 - 1), (double)l1, 0.0).a(1.0, 0.0).b(192, 192, 192, 255).d();
                bufferbuilder.b((double)i2, (double)l1, 0.0).a(0.0, 0.0).b(192, 192, 192, 255).d();
                tessellator.b();
            }
            this.b(mouseXIn, mouseYIn);
            buq.y();
            buq.j(7424);
            buq.e();
            buq.l();
        }
    }

    public void p() {
        if (this.g(this.j)) {
            int i2;
            if (Mouse.getEventButton() == 0 && Mouse.getEventButtonState() && this.j >= this.d && this.j <= this.e) {
                int i3 = (this.b - this.c()) / 2;
                int j2 = (this.b + this.c()) / 2;
                int k2 = this.j - this.d - this.t + (int)this.n - 4;
                int l2 = k2 / this.h;
                if (l2 < this.b() && this.i >= i3 && this.i <= j2 && l2 >= 0 && k2 >= 0) {
                    this.a(l2, false, this.i, this.j);
                    this.o = l2;
                } else if (this.i >= i3 && this.i <= j2 && k2 < 0) {
                    this.a(this.i - i3, this.j - this.d + (int)this.n - 4);
                }
            }
            if (Mouse.isButtonDown((int)0) && this.q()) {
                if (this.l != -1) {
                    if (this.l >= 0) {
                        this.n -= (float)(this.j - this.l) * this.m;
                        this.l = this.j;
                    }
                } else {
                    boolean flag1 = true;
                    if (this.j >= this.d && this.j <= this.e) {
                        int j2 = (this.b - this.c()) / 2;
                        int k2 = (this.b + this.c()) / 2;
                        int l2 = this.j - this.d - this.t + (int)this.n - 4;
                        int i1 = l2 / this.h;
                        if (i1 < this.b() && this.i >= j2 && this.i <= k2 && i1 >= 0 && l2 >= 0) {
                            boolean flag = i1 == this.o && bhz.I() - this.p < 250L;
                            this.a(i1, flag, this.i, this.j);
                            this.o = i1;
                            this.p = bhz.I();
                        } else if (this.i >= j2 && this.i <= k2 && l2 < 0) {
                            this.a(this.i - j2, this.j - this.d + (int)this.n - 4);
                            flag1 = false;
                        }
                        int i3 = this.d();
                        int j1 = i3 + 6;
                        if (this.i >= i3 && this.i <= j1) {
                            this.m = -1.0f;
                            int k1 = this.m();
                            if (k1 < 1) {
                                k1 = 1;
                            }
                            int l1 = (int)((float)((this.e - this.d) * (this.e - this.d)) / (float)this.k());
                            l1 = ri.a(l1, 32, this.e - this.d - 8);
                            this.m /= (float)(this.e - this.d - l1) / (float)k1;
                        } else {
                            this.m = 1.0f;
                        }
                        this.l = flag1 ? this.j : -2;
                    } else {
                        this.l = -2;
                    }
                }
            } else {
                this.l = -1;
            }
            if ((i2 = Mouse.getEventDWheel()) != 0) {
                if (i2 > 0) {
                    i2 = -1;
                } else if (i2 < 0) {
                    i2 = 1;
                }
                this.n += (float)(i2 * this.h / 2);
            }
        }
    }

    public void d(boolean enabledIn) {
        this.w = enabledIn;
    }

    public boolean q() {
        return this.w;
    }

    public int c() {
        return 220;
    }

    protected void a(int p_192638_1_, int p_192638_2_, int p_192638_3_, int p_192638_4_, float p_192638_5_) {
        int i2 = this.b();
        bvc tessellator = bvc.a();
        bui bufferbuilder = tessellator.c();
        for (int j2 = 0; j2 < i2; ++j2) {
            int k2 = p_192638_2_ + j2 * this.h + this.t;
            int l2 = this.h - 4;
            if (k2 > this.e || k2 + l2 < this.d) {
                this.a(j2, p_192638_1_, k2, p_192638_5_);
            }
            if (this.r && this.a(j2)) {
                int i1 = this.g + (this.b / 2 - this.c() / 2);
                int j1 = this.g + this.b / 2 + this.c() / 2;
                buq.c(1.0f, 1.0f, 1.0f, 1.0f);
                buq.z();
                bufferbuilder.a(7, cdw.i);
                bufferbuilder.b((double)i1, (double)(k2 + l2 + 2), 0.0).a(0.0, 1.0).b(128, 128, 128, 255).d();
                bufferbuilder.b((double)j1, (double)(k2 + l2 + 2), 0.0).a(1.0, 1.0).b(128, 128, 128, 255).d();
                bufferbuilder.b((double)j1, (double)(k2 - 2), 0.0).a(1.0, 0.0).b(128, 128, 128, 255).d();
                bufferbuilder.b((double)i1, (double)(k2 - 2), 0.0).a(0.0, 0.0).b(128, 128, 128, 255).d();
                bufferbuilder.b((double)(i1 + 1), (double)(k2 + l2 + 1), 0.0).a(0.0, 1.0).b(0, 0, 0, 255).d();
                bufferbuilder.b((double)(j1 - 1), (double)(k2 + l2 + 1), 0.0).a(1.0, 1.0).b(0, 0, 0, 255).d();
                bufferbuilder.b((double)(j1 - 1), (double)(k2 - 1), 0.0).a(1.0, 0.0).b(0, 0, 0, 255).d();
                bufferbuilder.b((double)(i1 + 1), (double)(k2 - 1), 0.0).a(0.0, 0.0).b(0, 0, 0, 255).d();
                tessellator.b();
                buq.y();
            }
            if (k2 < this.d - this.h || k2 > this.e) continue;
            this.a(j2, p_192638_1_, k2, l2, p_192638_3_, p_192638_4_, p_192638_5_);
        }
    }

    protected int d() {
        return this.b / 2 + 124;
    }

    protected void b(int startY, int endY, int startAlpha, int endAlpha) {
        bvc tessellator = bvc.a();
        bui bufferbuilder = tessellator.c();
        this.a.N().a(bip.b);
        buq.c(1.0f, 1.0f, 1.0f, 1.0f);
        float f2 = 32.0f;
        bufferbuilder.a(7, cdw.i);
        bufferbuilder.b((double)this.g, (double)endY, 0.0).a(0.0, (float)endY / 32.0f).b(64, 64, 64, endAlpha).d();
        bufferbuilder.b((double)(this.g + this.b), (double)endY, 0.0).a((float)this.b / 32.0f, (float)endY / 32.0f).b(64, 64, 64, endAlpha).d();
        bufferbuilder.b((double)(this.g + this.b), (double)startY, 0.0).a((float)this.b / 32.0f, (float)startY / 32.0f).b(64, 64, 64, startAlpha).d();
        bufferbuilder.b((double)this.g, (double)startY, 0.0).a(0.0, (float)startY / 32.0f).b(64, 64, 64, startAlpha).d();
        tessellator.b();
    }

    public void i(int leftIn) {
        this.g = leftIn;
        this.f = leftIn + this.b;
    }

    public int r() {
        return this.h;
    }

    protected void drawContainerBackground(bvc p_drawContainerBackground_1_) {
        bui bufferbuilder = p_drawContainerBackground_1_.c();
        this.a.N().a(bip.b);
        buq.c(1.0f, 1.0f, 1.0f, 1.0f);
        float f2 = 32.0f;
        bufferbuilder.a(7, cdw.i);
        bufferbuilder.b((double)this.g, (double)this.e, 0.0).a((float)this.g / 32.0f, (float)(this.e + (int)this.n) / 32.0f).b(32, 32, 32, 255).d();
        bufferbuilder.b((double)this.f, (double)this.e, 0.0).a((float)this.f / 32.0f, (float)(this.e + (int)this.n) / 32.0f).b(32, 32, 32, 255).d();
        bufferbuilder.b((double)this.f, (double)this.d, 0.0).a((float)this.f / 32.0f, (float)(this.d + (int)this.n) / 32.0f).b(32, 32, 32, 255).d();
        bufferbuilder.b((double)this.g, (double)this.d, 0.0).a((float)this.g / 32.0f, (float)(this.d + (int)this.n) / 32.0f).b(32, 32, 32, 255).d();
        p_drawContainerBackground_1_.b();
    }
}

