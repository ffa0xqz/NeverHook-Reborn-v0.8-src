/*
 * Decompiled with CFR 0.150.
 */
public class bys
extends cau<acp> {
    private static final nd a = new nd("textures/entity/spider/cave_spider.png");

    public bys(bzd bzd2) {
        super(bzd2);
        this.c *= 0.7f;
    }

    @Override
    protected void a(acp acp2, float f2) {
        buq.b(0.7f, 0.7f, 0.7f);
    }

    @Override
    protected nd a(acp acp2) {
        return a;
    }
}

