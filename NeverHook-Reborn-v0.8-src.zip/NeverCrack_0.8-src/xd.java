/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Sets
 *  javax.annotation.Nullable
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.common.collect.Sets;
import java.util.Iterator;
import java.util.Set;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class xd {
    private static final Logger a = LogManager.getLogger();
    private final Set<a> b = Sets.newLinkedHashSet();
    private final Set<a> c = Sets.newLinkedHashSet();
    private final rj d;
    private int e;
    private int f = 3;
    private int g;

    public xd(rj rj2) {
        this.d = rj2;
    }

    public void a(int n2, xc xc2) {
        this.b.add(new a(n2, xc2));
    }

    public void a(xc xc2) {
        Iterator<a> iterator = this.b.iterator();
        while (iterator.hasNext()) {
            a a2 = iterator.next();
            xc \u26032 = a2.a;
            if (\u26032 != xc2) continue;
            if (a2.c) {
                a2.c = false;
                a2.a.d();
                this.c.remove(a2);
            }
            iterator.remove();
            return;
        }
    }

    public void a() {
        this.d.a("goalSetup");
        if (this.e++ % this.f == 0) {
            for (a a2 : this.b) {
                if (a2.c) {
                    if (this.b(a2) && this.a(a2)) continue;
                    a2.c = false;
                    a2.a.d();
                    this.c.remove(a2);
                    continue;
                }
                if (!this.b(a2) || !a2.a.a()) continue;
                a2.c = true;
                a2.a.c();
                this.c.add(a2);
            }
        } else {
            Iterator<a> iterator = this.c.iterator();
            while (iterator.hasNext()) {
                a a2;
                a2 = iterator.next();
                if (this.a(a2)) continue;
                a2.c = false;
                a2.a.d();
                iterator.remove();
            }
        }
        this.d.b();
        if (!this.c.isEmpty()) {
            this.d.a("goalTick");
            for (a a2 : this.c) {
                a2.a.e();
            }
            this.d.b();
        }
    }

    private boolean a(a a2) {
        return a2.a.b();
    }

    private boolean b(a a2) {
        if (this.c.isEmpty()) {
            return true;
        }
        if (this.b(a2.a.h())) {
            return false;
        }
        for (a a3 : this.c) {
            if (a3 == a2 || !(a2.b >= a3.b ? !this.a(a2, a3) : !a3.a.g())) continue;
            return false;
        }
        return true;
    }

    private boolean a(a a2, a a3) {
        return (a2.a.h() & a3.a.h()) == 0;
    }

    public boolean b(int n2) {
        return (this.g & n2) > 0;
    }

    public void c(int n2) {
        this.g |= n2;
    }

    public void d(int n2) {
        this.g &= ~n2;
    }

    public void a(int n2, boolean bl2) {
        if (bl2) {
            this.d(n2);
        } else {
            this.c(n2);
        }
    }

    class a {
        public final xc a;
        public final int b;
        public boolean c;

        public a(int n2, xc xc2) {
            this.b = n2;
            this.a = xc2;
        }

        public boolean equals(@Nullable Object object) {
            if (this == object) {
                return true;
            }
            if (object == null || this.getClass() != object.getClass()) {
                return false;
            }
            return this.a.equals(((a)object).a);
        }

        public int hashCode() {
            return this.a.hashCode();
        }
    }
}

