/*
 * Decompiled with CFR 0.150.
 */
public abstract class wu
extends xc {
    protected vo a;
    protected et b = et.a;
    protected apy c;
    boolean d;
    float e;
    float f;

    public wu(vo vo2) {
        this.a = vo2;
        if (!(vo2.x() instanceof zb)) {
            throw new IllegalArgumentException("Unsupported mob type for DoorInteractGoal");
        }
    }

    @Override
    public boolean a() {
        if (!this.a.A) {
            return false;
        }
        zb zb2 = (zb)this.a.x();
        bej \u26032 = zb2.l();
        if (\u26032 == null || \u26032.b() || !zb2.g()) {
            return false;
        }
        for (int i2 = 0; i2 < Math.min(\u26032.e() + 2, \u26032.d()); ++i2) {
            beh beh2 = \u26032.a(i2);
            this.b = new et(beh2.a, beh2.b + 1, beh2.c);
            if (this.a.d(this.b.p(), this.a.q, this.b.r()) > 2.25) continue;
            this.c = this.a(this.b);
            if (this.c == null) continue;
            return true;
        }
        this.b = new et(this.a).a();
        this.c = this.a(this.b);
        return this.c != null;
    }

    @Override
    public boolean b() {
        return !this.d;
    }

    @Override
    public void c() {
        this.d = false;
        this.e = (float)((double)((float)this.b.p() + 0.5f) - this.a.p);
        this.f = (float)((double)((float)this.b.r() + 0.5f) - this.a.r);
    }

    @Override
    public void e() {
        float f2 = (float)((double)((float)this.b.p() + 0.5f) - this.a.p);
        \u2603 = this.e * f2 + this.f * (\u2603 = (float)((double)((float)this.b.r() + 0.5f) - this.a.r));
        if (\u2603 < 0.0f) {
            this.d = true;
        }
    }

    private apy a(et et2) {
        awr awr2 = this.a.l.o(et2);
        aou \u26032 = awr2.u();
        if (\u26032 instanceof apy && awr2.a() == bcx.d) {
            return (apy)\u26032;
        }
        return null;
    }
}

