/*
 * Decompiled with CFR 0.150.
 */
import java.io.IOException;

public class lc
implements ht<kw> {
    private String a;
    private int b;
    private aeb.b c;
    private boolean d;
    private int e;
    private vm f;

    public lc() {
    }

    public lc(String string, int n2, aeb.b b2, boolean bl2, int n3, vm vm2) {
        this.a = string;
        this.b = n2;
        this.c = b2;
        this.d = bl2;
        this.e = n3;
        this.f = vm2;
    }

    @Override
    public void a(gy gy2) throws IOException {
        this.a = gy2.e(16);
        this.b = gy2.readByte();
        this.c = gy2.a(aeb.b.class);
        this.d = gy2.readBoolean();
        this.e = gy2.readUnsignedByte();
        this.f = gy2.a(vm.class);
    }

    @Override
    public void b(gy gy2) throws IOException {
        gy2.a(this.a);
        gy2.writeByte(this.b);
        gy2.a(this.c);
        gy2.writeBoolean(this.d);
        gy2.writeByte(this.e);
        gy2.a(this.f);
    }

    @Override
    public void a(kw kw2) {
        kw2.a(this);
    }

    public String a() {
        return this.a;
    }

    public aeb.b c() {
        return this.c;
    }

    public boolean d() {
        return this.d;
    }

    public int e() {
        return this.e;
    }

    public vm f() {
        return this.f;
    }
}

