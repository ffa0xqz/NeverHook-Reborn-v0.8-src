/*
 * Decompiled with CFR 0.150.
 */
public class byv
extends cad<acq> {
    private static final nd a = new nd("textures/entity/creeper/creeper.png");

    public byv(bzd bzd2) {
        super(bzd2, new bpm(), 0.5f);
        this.a(new cbr(this));
    }

    @Override
    protected void a(acq acq2, float f2) {
        \u2603 = acq2.a(f2);
        \u2603 = 1.0f + ri.a(\u2603 * 100.0f) * \u2603 * 0.01f;
        \u2603 = ri.a(\u2603, 0.0f, 1.0f);
        \u2603 *= \u2603;
        \u2603 *= \u2603;
        \u2603 = (1.0f + \u2603 * 0.4f) * \u2603;
        \u2603 = (1.0f + \u2603 * 0.1f) / \u2603;
        buq.b(\u2603, \u2603, \u2603);
    }

    @Override
    protected int a(acq acq2, float f2, float f3) {
        \u2603 = acq2.a(f3);
        if ((int)(\u2603 * 10.0f) % 2 == 0) {
            return 0;
        }
        int n2 = (int)(\u2603 * 0.2f * 255.0f);
        n2 = ri.a(n2, 0, 255);
        return n2 << 24 | 0x30FFFFFF;
    }

    @Override
    protected nd a(acq acq2) {
        return a;
    }
}

