/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 *  org.apache.commons.lang3.Validate
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import java.awt.image.BufferedImage;
import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.imageio.ImageIO;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class boj
implements bjk.a {
    private static final Logger a = LogManager.getLogger();
    private static final DateFormat b = new SimpleDateFormat();
    private static final nd c = new nd("textures/misc/unknown_server.png");
    private static final nd d = new nd("textures/gui/world_selection.png");
    private final bhz e;
    private final boi f;
    private final bff g;
    private final nd h;
    private final bok i;
    private File j;
    private cde k;
    private long l;

    public boj(bok listWorldSelIn, bff p_i46591_2_, bfe p_i46591_3_) {
        this.i = listWorldSelIn;
        this.f = listWorldSelIn.g();
        this.g = p_i46591_2_;
        this.e = bhz.z();
        this.h = new nd("worlds/" + p_i46591_2_.a() + "/icon");
        this.j = p_i46591_3_.b(p_i46591_2_.a(), "icon.png");
        if (!this.j.isFile()) {
            this.j = null;
        }
        this.f();
    }

    @Override
    public void a(int p_192634_1_, int p_192634_2_, int p_192634_3_, int p_192634_4_, int p_192634_5_, int p_192634_6_, int p_192634_7_, boolean p_192634_8_, float p_192634_9_) {
        String s2 = this.g.b();
        String s1 = this.g.a() + " (" + b.format(new Date(this.g.e())) + ")";
        String s22 = "";
        if (StringUtils.isEmpty((CharSequence)s2)) {
            s2 = cew.a("selectWorld.world", new Object[0]) + " " + (p_192634_1_ + 1);
        }
        if (this.g.d()) {
            s22 = cew.a("selectWorld.conversion", new Object[0]) + " " + s22;
        } else {
            s22 = cew.a("gameMode." + this.g.f().b(), new Object[0]);
            if (this.g.g()) {
                s22 = (Object)((Object)a.e) + cew.a("gameMode.hardcore", new Object[0]) + (Object)((Object)a.v);
            }
            if (this.g.h()) {
                s22 = s22 + ", " + cew.a("selectWorld.cheats", new Object[0]);
            }
            String s3 = this.g.i();
            s22 = this.g.l() ? (this.g.m() ? s22 + ", " + cew.a("selectWorld.version", new Object[0]) + " " + (Object)((Object)a.m) + s3 + (Object)((Object)a.v) : s22 + ", " + cew.a("selectWorld.version", new Object[0]) + " " + (Object)((Object)a.u) + s3 + (Object)((Object)a.v)) : s22 + ", " + cew.a("selectWorld.version", new Object[0]) + " " + s3;
        }
        bhz.k.drawString(s2, p_192634_2_ + 32 + 3, p_192634_3_ + 1, 0xFFFFFF);
        bhz.k.drawString(s1, p_192634_2_ + 32 + 3, p_192634_3_ + bhz.k.a + 3, 0x808080);
        bhz.k.drawString(s22, p_192634_2_ + 32 + 3, p_192634_3_ + bhz.k.a + bhz.k.a + 3, 0x808080);
        buq.c(1.0f, 1.0f, 1.0f, 1.0f);
        this.e.N().a(this.k != null ? this.h : c);
        buq.m();
        bip.drawModalRectWithCustomSizedTexture(p_192634_2_, p_192634_3_, 0.0f, 0.0f, 32.0, 32.0, 32.0, 32.0);
        buq.l();
        if (this.e.t.B || p_192634_8_) {
            int i2;
            this.e.N().a(d);
            bip.drawRect(p_192634_2_, p_192634_3_, p_192634_2_ + 32, p_192634_3_ + 32, -1601138544);
            buq.c(1.0f, 1.0f, 1.0f, 1.0f);
            int j2 = p_192634_6_ - p_192634_2_;
            int n2 = i2 = j2 < 32 ? 32 : 0;
            if (this.g.l()) {
                bip.drawModalRectWithCustomSizedTexture(p_192634_2_, p_192634_3_, 32.0f, i2, 32.0, 32.0, 256.0, 256.0);
                if (this.g.m()) {
                    bip.drawModalRectWithCustomSizedTexture(p_192634_2_, p_192634_3_, 96.0f, i2, 32.0, 32.0, 256.0, 256.0);
                    if (j2 < 32) {
                        this.f.a((Object)((Object)a.m) + cew.a("selectWorld.tooltip.fromNewerVersion1", new Object[0]) + "\n" + (Object)((Object)a.m) + cew.a("selectWorld.tooltip.fromNewerVersion2", new Object[0]));
                    }
                } else {
                    bip.drawModalRectWithCustomSizedTexture(p_192634_2_, p_192634_3_, 64.0f, i2, 32.0, 32.0, 256.0, 256.0);
                    if (j2 < 32) {
                        this.f.a((Object)((Object)a.g) + cew.a("selectWorld.tooltip.snapshot1", new Object[0]) + "\n" + (Object)((Object)a.g) + cew.a("selectWorld.tooltip.snapshot2", new Object[0]));
                    }
                }
            } else {
                bip.drawModalRectWithCustomSizedTexture(p_192634_2_, p_192634_3_, 0.0f, i2, 32.0, 32.0, 256.0, 256.0);
            }
        }
    }

    @Override
    public boolean a(int slotIndex, int mouseX, int mouseY, int mouseEvent, int relativeX, int relativeY) {
        this.i.d(slotIndex);
        if (relativeX <= 32 && relativeX < 32) {
            this.a();
            return true;
        }
        if (bhz.I() - this.l < 250L) {
            this.a();
            return true;
        }
        this.l = bhz.I();
        return false;
    }

    public void a() {
        if (this.g.m()) {
            this.e.a(new bko(new bkn(){

                @Override
                public void a(boolean result, int id2) {
                    if (result) {
                        boj.this.e();
                    } else {
                        boj.this.e.a(boj.this.f);
                    }
                }
            }, cew.a("selectWorld.versionQuestion", new Object[0]), cew.a("selectWorld.versionWarning", this.g.i()), cew.a("selectWorld.versionJoinButton", new Object[0]), cew.a("gui.cancel", new Object[0]), 0));
        } else {
            this.e();
        }
    }

    public void b() {
        this.e.a(new bko(new bkn(){

            @Override
            public void a(boolean result, int id2) {
                if (result) {
                    boj.this.e.a(new blg());
                    bfe isaveformat = boj.this.e.g();
                    isaveformat.d();
                    isaveformat.e(boj.this.g.a());
                    boj.this.i.e();
                }
                boj.this.e.a(boj.this.f);
            }
        }, cew.a("selectWorld.deleteQuestion", new Object[0]), "'" + this.g.b() + "' " + cew.a("selectWorld.deleteWarning", new Object[0]), cew.a("selectWorld.deleteButton", new Object[0]), cew.a("gui.cancel", new Object[0]), 0));
    }

    public void c() {
        this.e.a(new boh(this.f, this.g.a()));
    }

    public void d() {
        this.e.a(new blg());
        bog guicreateworld = new bog(this.f);
        bfc isavehandler = this.e.g().a(this.g.a(), false);
        bfb worldinfo = isavehandler.d();
        isavehandler.a();
        if (worldinfo != null) {
            guicreateworld.a(worldinfo);
            this.e.a(guicreateworld);
        }
    }

    private void e() {
        this.e.U().a(cgn.a(qd.ic, 1.0f));
        if (this.e.g().f(this.g.a())) {
            this.e.a(this.g.a(), this.g.b(), null);
        }
    }

    private void f() {
        boolean flag;
        boolean bl2 = flag = this.j != null && this.j.isFile();
        if (flag) {
            BufferedImage bufferedimage;
            try {
                bufferedimage = ImageIO.read(this.j);
                Validate.validState((bufferedimage.getWidth() == 64 ? 1 : 0) != 0, (String)"Must be 64 pixels wide", (Object[])new Object[0]);
                Validate.validState((bufferedimage.getHeight() == 64 ? 1 : 0) != 0, (String)"Must be 64 pixels high", (Object[])new Object[0]);
            }
            catch (Throwable throwable) {
                a.error("Invalid icon for world {}", (Object)this.g.a(), (Object)throwable);
                this.j = null;
                return;
            }
            if (this.k == null) {
                this.k = new cde(bufferedimage.getWidth(), bufferedimage.getHeight());
                this.e.N().a(this.h, (cdq)this.k);
            }
            bufferedimage.getRGB(0, 0, bufferedimage.getWidth(), bufferedimage.getHeight(), this.k.e(), 0, bufferedimage.getWidth());
            this.k.d();
        } else if (!flag) {
            this.e.N().c(this.h);
            this.k = null;
        }
    }

    @Override
    public void b(int slotIndex, int x2, int y2, int mouseEvent, int relativeX, int relativeY) {
    }

    @Override
    public void a(int p_192633_1_, int p_192633_2_, int p_192633_3_, float p_192633_4_) {
    }
}

