/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 *  javax.annotation.Nullable
 */
import com.google.common.base.Predicate;
import java.util.Calendar;
import java.util.UUID;
import javax.annotation.Nullable;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class adr
extends adc {
    protected static final wa a = new wh(null, "zombie.spawnReinforcements", 0.0, 0.0, 1.0).a("Spawn Reinforcements Chance");
    private static final UUID b = UUID.fromString("B9766B59-9566-4402-BC1F-2EE2A276D836");
    private static final wc c = new wc(b, "Baby speed boost", 0.5, 1);
    private static final mx<Boolean> bx = na.a(adr.class, mz.h);
    private static final mx<Integer> by = na.a(adr.class, mz.b);
    private static final mx<Boolean> bz = na.a(adr.class, mz.h);
    private final ws bA = new ws(this);
    private boolean bB;
    private float bC = -1.0f;
    private float bD;

    public adr(ams ams2) {
        super(ams2);
        this.a(0.6f, 1.95f);
    }

    @Override
    protected void r() {
        this.br.a(0, new wx(this));
        this.br.a(2, new yo(this, 1.0, false));
        this.br.a(5, new xq(this, 1.0));
        this.br.a(7, new yn(this, 1.0));
        this.br.a(8, new xj(this, aeb.class, 8.0f));
        this.br.a(8, new xz(this));
        this.do();
    }

    protected void do() {
        this.br.a(6, new xo(this, 1.0, false));
        this.bs.a(1, new yr((vv)this, true, add.class));
        this.bs.a(2, new yu<aeb>((vv)this, aeb.class, true));
        this.bs.a(3, new yu<adw>((vv)this, adw.class, false));
        this.bs.a(3, new yu<aai>((vv)this, aai.class, true));
    }

    @Override
    protected void bM() {
        super.bM();
        this.a(adf.b).a(35.0);
        this.a(adf.d).a(0.23f);
        this.a(adf.f).a(3.0);
        this.a(adf.h).a(2.0);
        this.cm().b(a).a(this.S.nextDouble() * (double)0.1f);
    }

    @Override
    protected void i() {
        super.i();
        this.V().a(bx, false);
        this.V().a(by, 0);
        this.V().a(bz, false);
    }

    public void a(boolean bl2) {
        this.V().b(bz, bl2);
    }

    public boolean dq() {
        return this.V().a(bz);
    }

    public boolean dr() {
        return this.bB;
    }

    public void p(boolean bl2) {
        if (this.bB != bl2) {
            this.bB = bl2;
            ((zb)this.x()).a(bl2);
            if (bl2) {
                this.br.a(1, this.bA);
            } else {
                this.br.a(this.bA);
            }
        }
    }

    @Override
    public boolean l_() {
        return this.V().a(bx);
    }

    @Override
    protected int b(aeb aeb2) {
        if (this.l_()) {
            this.b_ = (int)((float)this.b_ * 2.5f);
        }
        return super.b(aeb2);
    }

    public void q(boolean bl22) {
        boolean bl22;
        this.V().b(bx, bl22);
        if (this.l != null && !this.l.G) {
            wb wb2 = this.a(adf.d);
            wb2.c(c);
            if (bl22) {
                wb2.b(c);
            }
        }
        this.r(bl22);
    }

    @Override
    public void a(mx<?> mx2) {
        if (bx.equals(mx2)) {
            this.r(this.l_());
        }
        super.a(mx2);
    }

    @Override
    public void n() {
        float f2;
        if (this.l.D() && !this.l.G && !this.l_() && this.p() && (f2 = this.aw()) > 0.5f && this.S.nextFloat() * 30.0f < (f2 - 0.4f) * 2.0f && this.l.h(new et(this.p, this.q + (double)this.by(), this.r))) {
            boolean bl2 = true;
            ain \u26032 = this.b(vj.f);
            if (!\u26032.b()) {
                if (\u26032.f()) {
                    \u26032.b(\u26032.i() + this.S.nextInt(2));
                    if (\u26032.i() >= \u26032.k()) {
                        this.b(\u26032);
                        this.a(vj.f, ain.a);
                    }
                }
                bl2 = false;
            }
            if (bl2) {
                this.i(8);
            }
        }
        super.n();
    }

    protected boolean p() {
        return true;
    }

    @Override
    public boolean a(up up2, float f2) {
        if (super.a(up2, f2)) {
            vn vn2 = this.z();
            if (vn2 == null && up2.j() instanceof vn) {
                vn2 = (vn)up2.j();
            }
            if (vn2 != null && this.l.ag() == tx.d && (double)this.S.nextFloat() < this.a(a).e() && this.l.W().b("doMobSpawning")) {
                int n2 = ri.c(this.p);
                \u2603 = ri.c(this.q);
                \u2603 = ri.c(this.r);
                adr \u26032 = new adr(this.l);
                for (\u2603 = 0; \u2603 < 50; ++\u2603) {
                    \u2603 = n2 + ri.a(this.S, 7, 40) * ri.a(this.S, -1, 1);
                    if (!this.l.o(new et(\u2603, (\u2603 = \u2603 + ri.a(this.S, 7, 40) * ri.a(this.S, -1, 1)) - 1, \u2603 = \u2603 + ri.a(this.S, 7, 40) * ri.a(this.S, -1, 1))).q() || this.l.k(new et(\u2603, \u2603, \u2603)) >= 10) continue;
                    \u26032.b(\u2603, \u2603, \u2603);
                    if (this.l.a((double)\u2603, (double)\u2603, (double)\u2603, 7.0) || !this.l.a(\u26032.bw(), \u26032) || !this.l.a((ve)\u26032, \u26032.bw()).isEmpty() || this.l.d(\u26032.bw())) continue;
                    this.l.a(\u26032);
                    \u26032.d(vn2);
                    \u26032.a(this.l.D(new et(\u26032)), null);
                    this.a(a).b(new wc("Zombie reinforcement caller charge", -0.05f, 0));
                    \u26032.a(a).b(new wc("Zombie reinforcement callee charge", -0.05f, 0));
                    break;
                }
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean B(ve ve2) {
        boolean bl2 = super.B(ve2);
        if (bl2) {
            float f2 = this.l.D(new et(this)).b();
            if (this.co().b() && this.aR() && this.S.nextFloat() < f2 * 0.3f) {
                ve2.i(2 * (int)f2);
            }
        }
        return bl2;
    }

    @Override
    protected qc F() {
        return qd.ji;
    }

    @Override
    protected qc d(up up2) {
        return qd.jq;
    }

    @Override
    protected qc cf() {
        return qd.jm;
    }

    protected qc dm() {
        return qd.jw;
    }

    @Override
    protected void a(et et2, aou aou2) {
        this.a(this.dm(), 0.15f, 1.0f);
    }

    @Override
    public vs cn() {
        return vs.b;
    }

    @Override
    @Nullable
    protected nd J() {
        return bfl.am;
    }

    @Override
    protected void a(ty ty2) {
        super.a(ty2);
        float f2 = this.S.nextFloat();
        float f3 = this.l.ag() == tx.d ? 0.05f : 0.01f;
        if (f2 < f3) {
            int n2 = this.S.nextInt(3);
            if (n2 == 0) {
                this.a(vj.a, new ain(aip.o));
            } else {
                this.a(vj.a, new ain(aip.b));
            }
        }
    }

    public static void c(rw rw2) {
        vo.a(rw2, adr.class);
    }

    @Override
    public void b(fy fy2) {
        super.b(fy2);
        if (this.l_()) {
            fy2.a("IsBaby", true);
        }
        fy2.a("CanBreakDoors", this.dr());
    }

    @Override
    public void a(fy fy2) {
        super.a(fy2);
        if (fy2.q("IsBaby")) {
            this.q(true);
        }
        this.p(fy2.q("CanBreakDoors"));
    }

    @Override
    public void b(vn vn2) {
        super.b(vn2);
        if ((this.l.ag() == tx.c || this.l.ag() == tx.d) && vn2 instanceof adw) {
            if (this.l.ag() != tx.d && this.S.nextBoolean()) {
                return;
            }
            adw adw2 = (adw)vn2;
            ads \u26032 = new ads(this.l);
            \u26032.u(adw2);
            this.l.e(adw2);
            \u26032.a(this.l.D(new et(\u26032)), new a(false));
            \u26032.a(adw2.dl());
            \u26032.q(adw2.l_());
            \u26032.n(adw2.dc());
            if (adw2.n_()) {
                \u26032.c(adw2.bq());
                \u26032.j(adw2.br());
            }
            this.l.a(\u26032);
            this.l.a(null, 1026, new et(this), 0);
        }
    }

    @Override
    public float by() {
        float f2 = 1.74f;
        if (this.l_()) {
            f2 = (float)((double)f2 - 0.81);
        }
        return f2;
    }

    @Override
    protected boolean c(ain ain2) {
        if (ain2.c() == aip.aX && this.l_() && this.aS()) {
            return false;
        }
        return super.c(ain2);
    }

    @Override
    @Nullable
    public vq a(ty ty2, @Nullable vq vq22) {
        vq vq22;
        vq22 = super.a(ty2, vq22);
        float f2 = ty2.d();
        this.m(this.S.nextFloat() < 0.55f * f2);
        if (vq22 == null) {
            vq22 = new a(this.l.r.nextFloat() < 0.05f);
        }
        if (vq22 instanceof a) {
            Object object = (a)vq22;
            if (((a)object).a) {
                this.q(true);
                if ((double)this.l.r.nextFloat() < 0.05) {
                    Predicate<ve> predicate = this.l.a(zu.class, this.bw().c(5.0, 3.0, 5.0), vi.b);
                    if (!predicate.isEmpty()) {
                        zu zu2 = (zu)predicate.get(0);
                        zu2.p(true);
                        this.m(zu2);
                    }
                } else if ((double)this.l.r.nextFloat() < 0.05) {
                    zu zu3 = new zu(this.l);
                    zu3.b(this.p, this.q, this.r, this.v, 0.0f);
                    zu3.a(ty2, null);
                    zu3.p(true);
                    this.l.a(zu3);
                    this.m(zu3);
                }
            }
        }
        this.p(this.S.nextFloat() < f2 * 0.1f);
        this.a(ty2);
        this.b(ty2);
        if (this.b(vj.f).b() && ((Calendar)(object = this.l.ae())).get(2) + 1 == 10 && ((Calendar)object).get(5) == 31 && this.S.nextFloat() < 0.25f) {
            this.a(vj.f, new ain(this.S.nextFloat() < 0.1f ? aov.aZ : aov.aU));
            this.bu[vj.f.b()] = 0.0f;
        }
        this.a(adf.c).b(new wc("Random spawn bonus", this.S.nextDouble() * (double)0.05f, 0));
        double \u26032 = this.S.nextDouble() * 1.5 * (double)f2;
        if (\u26032 > 1.0) {
            this.a(adf.b).b(new wc("Random zombie-spawn bonus", \u26032, 2));
        }
        if (this.S.nextFloat() < f2 * 0.05f) {
            this.a(a).b(new wc("Leader zombie bonus", this.S.nextDouble() * 0.25 + 0.5, 0));
            this.a(adf.a).b(new wc("Leader zombie bonus", this.S.nextDouble() * 3.0 + 1.0, 2));
            this.p(true);
        }
        return vq22;
    }

    public void r(boolean bl2) {
        this.a(bl2 ? 0.5f : 1.0f);
    }

    @Override
    protected final void a(float f2, float f3) {
        boolean bl2 = this.bC > 0.0f && this.bD > 0.0f;
        this.bC = f2;
        this.bD = f3;
        if (!bl2) {
            this.a(1.0f);
        }
    }

    protected final void a(float f2) {
        super.a(this.bC * f2, this.bD * f2);
    }

    @Override
    public double aF() {
        return this.l_() ? 0.0 : -0.45;
    }

    @Override
    public void a(up up2) {
        super.a(up2);
        if (up2.j() instanceof acq && (\u2603 = (acq)up2.j()).p() && \u2603.dp()) {
            \u2603.dq();
            ain ain2 = this.dn();
            if (!ain2.b()) {
                this.a(ain2, 0.0f);
            }
        }
    }

    protected ain dn() {
        return new ain(aip.ci, 1, 2);
    }

    class a
    implements vq {
        public boolean a;

        private a(boolean bl2) {
            this.a = bl2;
        }
    }
}

