/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import javax.annotation.Nullable;

public interface btf {
    @Nullable
    public btd a(int var1, ams var2, double var3, double var5, double var7, double var9, double var11, double var13, int ... var15);
}

