/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonDeserializationContext
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonSerializationContext
 */
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import java.util.Random;

public class bgo
implements bgj {
    private final float a;
    private final float b;

    public bgo(float f2, float f3) {
        this.a = f2;
        this.b = f3;
    }

    @Override
    public boolean a(Random random, bfr bfr2) {
        int n2 = 0;
        if (bfr2.c() instanceof vn) {
            n2 = alk.g((vn)bfr2.c());
        }
        return random.nextFloat() < this.a + (float)n2 * this.b;
    }

    public static class a
    extends bgj.a<bgo> {
        protected a() {
            super(new nd("random_chance_with_looting"), bgo.class);
        }

        @Override
        public void a(JsonObject jsonObject, bgo bgo2, JsonSerializationContext jsonSerializationContext) {
            jsonObject.addProperty("chance", (Number)Float.valueOf(bgo2.a));
            jsonObject.addProperty("looting_multiplier", (Number)Float.valueOf(bgo2.b));
        }

        public bgo a(JsonObject jsonObject, JsonDeserializationContext jsonDeserializationContext) {
            return new bgo(ra.l(jsonObject, "chance"), ra.l(jsonObject, "looting_multiplier"));
        }

        @Override
        public /* synthetic */ bgj b(JsonObject jsonObject, JsonDeserializationContext jsonDeserializationContext) {
            return this.a(jsonObject, jsonDeserializationContext);
        }
    }
}

