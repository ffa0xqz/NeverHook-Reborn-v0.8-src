/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 */
import com.mojang.authlib.GameProfile;
import java.net.SocketAddress;
import net.minecraft.server.MinecraftServer;

public class cha
extends pj {
    private fy f;

    public cha(chb chb2) {
        super(chb2);
        this.a(10);
    }

    @Override
    protected void b(oo oo2) {
        if (oo2.h_().equals(this.b().Q())) {
            this.f = oo2.e(new fy());
        }
        super.b(oo2);
    }

    @Override
    public String a(SocketAddress socketAddress, GameProfile gameProfile) {
        if (gameProfile.getName().equalsIgnoreCase(this.b().Q()) && this.a(gameProfile.getName()) != null) {
            return "That name is already taken.";
        }
        return super.a(socketAddress, gameProfile);
    }

    public chb b() {
        return (chb)super.c();
    }

    @Override
    public fy t() {
        return this.f;
    }

    @Override
    public /* synthetic */ MinecraftServer c() {
        return this.b();
    }
}

