/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.common.collect.Lists;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class cdy {
    private static final Logger a = LogManager.getLogger();
    private final List<cdz> b = Lists.newArrayList();
    private final List<Integer> c = Lists.newArrayList();
    private int d;
    private int e = -1;
    private final List<Integer> f = Lists.newArrayList();
    private int g = -1;

    public cdy(cdy cdy22) {
        this();
        cdy cdy22;
        for (int i2 = 0; i2 < cdy22.i(); ++i2) {
            this.a(cdy22.c(i2));
        }
        this.d = cdy22.g();
    }

    public cdy() {
    }

    public void a() {
        this.b.clear();
        this.c.clear();
        this.e = -1;
        this.f.clear();
        this.g = -1;
        this.d = 0;
    }

    public cdy a(cdz cdz2) {
        if (cdz2.f() && this.j()) {
            a.warn("VertexFormat error: Trying to add a position VertexFormatElement when one already exists, ignoring.");
            return this;
        }
        this.b.add(cdz2);
        this.c.add(this.d);
        switch (cdz2.b()) {
            case b: {
                this.g = this.d;
                break;
            }
            case c: {
                this.e = this.d;
                break;
            }
            case d: {
                this.f.add(cdz2.d(), this.d);
                break;
            }
        }
        this.d += cdz2.e();
        return this;
    }

    public boolean b() {
        return this.g >= 0;
    }

    public int c() {
        return this.g;
    }

    public boolean d() {
        return this.e >= 0;
    }

    public int e() {
        return this.e;
    }

    public boolean a(int n2) {
        return this.f.size() - 1 >= n2;
    }

    public int b(int n2) {
        return this.f.get(n2);
    }

    public String toString() {
        String string = "format: " + this.b.size() + " elements: ";
        for (int i2 = 0; i2 < this.b.size(); ++i2) {
            string = string + this.b.get(i2).toString();
            if (i2 == this.b.size() - 1) continue;
            string = string + " ";
        }
        return string;
    }

    private boolean j() {
        int n2 = this.b.size();
        for (\u2603 = 0; \u2603 < n2; ++\u2603) {
            cdz cdz2 = this.b.get(\u2603);
            if (!cdz2.f()) continue;
            return true;
        }
        return false;
    }

    public int f() {
        return this.g() / 4;
    }

    public int g() {
        return this.d;
    }

    public List<cdz> h() {
        return this.b;
    }

    public int i() {
        return this.b.size();
    }

    public cdz c(int n2) {
        return this.b.get(n2);
    }

    public int d(int n2) {
        return this.c.get(n2);
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null || this.getClass() != object.getClass()) {
            return false;
        }
        cdy cdy2 = (cdy)object;
        if (this.d != cdy2.d) {
            return false;
        }
        if (!this.b.equals(cdy2.b)) {
            return false;
        }
        return this.c.equals(cdy2.c);
    }

    public int hashCode() {
        int n2 = this.b.hashCode();
        n2 = 31 * n2 + this.c.hashCode();
        n2 = 31 * n2 + this.d;
        return n2;
    }
}

