/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import io.netty.buffer.ByteBuf;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

public abstract class amh
implements bn {
    private static final SimpleDateFormat a = new SimpleDateFormat("HH:mm:ss");
    private long b = -1L;
    private boolean c = true;
    private int d;
    private boolean e = true;
    private hh f;
    private String g = "";
    private String h = "@";
    private final bp i = new bp();

    public int k() {
        return this.d;
    }

    public void a(int n2) {
        this.d = n2;
    }

    public hh l() {
        return this.f == null ? new ho("") : this.f;
    }

    public fy a(fy fy2) {
        fy2.a("Command", this.g);
        fy2.a("SuccessCount", this.d);
        fy2.a("CustomName", this.h);
        fy2.a("TrackOutput", this.e);
        if (this.f != null && this.e) {
            fy2.a("LastOutput", hh.a.a(this.f));
        }
        fy2.a("UpdateLastExecution", this.c);
        if (this.c && this.b > 0L) {
            fy2.a("LastExecution", this.b);
        }
        this.i.b(fy2);
        return fy2;
    }

    public void b(fy fy22) {
        fy fy22;
        this.g = fy22.l("Command");
        this.d = fy22.h("SuccessCount");
        if (fy22.b("CustomName", 8)) {
            this.h = fy22.l("CustomName");
        }
        if (fy22.b("TrackOutput", 1)) {
            this.e = fy22.q("TrackOutput");
        }
        if (fy22.b("LastOutput", 8) && this.e) {
            try {
                this.f = hh.a.a(fy22.l("LastOutput"));
            }
            catch (Throwable throwable) {
                this.f = new ho(throwable.getMessage());
            }
        } else {
            this.f = null;
        }
        if (fy22.e("UpdateLastExecution")) {
            this.c = fy22.q("UpdateLastExecution");
        }
        this.b = this.c && fy22.e("LastExecution") ? fy22.i("LastExecution") : -1L;
        this.i.a(fy22);
    }

    @Override
    public boolean a(int n2, String string) {
        return n2 <= 2;
    }

    public void a(String string) {
        this.g = string;
        this.d = 0;
    }

    public String m() {
        return this.g;
    }

    public boolean a(ams ams2) {
        if (ams2.G || ams2.R() == this.b) {
            return false;
        }
        if ("Searge".equalsIgnoreCase(this.g)) {
            this.f = new ho("#itzlipofutzli");
            this.d = 1;
            return true;
        }
        MinecraftServer minecraftServer = this.C_();
        if (minecraftServer != null && minecraftServer.M() && minecraftServer.ai()) {
            try {
                this.f = null;
                this.d = minecraftServer.N().a(this, this.g);
            }
            catch (Throwable throwable) {
                b b2 = b.a(throwable, "Executing command block");
                c \u26032 = b2.a("Command to be executed");
                \u26032.a("Command", new d<String>(){

                    public String a() throws Exception {
                        return amh.this.m();
                    }

                    @Override
                    public /* synthetic */ Object call() throws Exception {
                        return this.a();
                    }
                });
                \u26032.a("Name", new d<String>(){

                    public String a() throws Exception {
                        return amh.this.h_();
                    }

                    @Override
                    public /* synthetic */ Object call() throws Exception {
                        return this.a();
                    }
                });
                throw new f(b2);
            }
        } else {
            this.d = 0;
        }
        this.b = this.c ? ams2.R() : -1L;
        return true;
    }

    @Override
    public String h_() {
        return this.h;
    }

    public void b(String string) {
        this.h = string;
    }

    @Override
    public void a(hh hh2) {
        if (this.e && this.e() != null && !this.e().G) {
            this.f = new ho("[" + a.format(new Date()) + "] ").a(hh2);
            this.i();
        }
    }

    @Override
    public boolean g() {
        MinecraftServer minecraftServer = this.C_();
        return minecraftServer == null || !minecraftServer.M() || minecraftServer.d[0].W().b("commandBlockOutput");
    }

    @Override
    public void a(bp.a a2, int n2) {
        this.i.a(this.C_(), this, a2, n2);
    }

    public abstract void i();

    public abstract int j();

    public abstract void a(ByteBuf var1);

    public void b(@Nullable hh hh2) {
        this.f = hh2;
    }

    public void a(boolean bl2) {
        this.e = bl2;
    }

    public boolean n() {
        return this.e;
    }

    public boolean a(aeb aeb2) {
        if (!aeb2.dv()) {
            return false;
        }
        if (aeb2.e().G) {
            aeb2.a(this);
        }
        return true;
    }

    public bp o() {
        return this.i;
    }
}

