/*
 * Decompiled with CFR 0.150.
 */
public class bcx {
    public static final bcx a = new bcv(bcy.c);
    public static final bcx b = new bcx(bcy.d);
    public static final bcx c = new bcx(bcy.m);
    public static final bcx d = new bcx(bcy.p).g();
    public static final bcx e = new bcx(bcy.n).f();
    public static final bcx f = new bcx(bcy.i).f();
    public static final bcx g = new bcx(bcy.i).f().o();
    public static final bcx h = new bcw(bcy.o).n();
    public static final bcx i = new bcw(bcy.g).n();
    public static final bcx j = new bcx(bcy.j).g().s().n();
    public static final bcx k = new bcu(bcy.j).n();
    public static final bcx l = new bcu(bcy.j).g().n().i();
    public static final bcx m = new bcx(bcy.u);
    public static final bcx n = new bcx(bcy.f).g();
    public static final bcx o = new bcv(bcy.c).n();
    public static final bcx p = new bcx(bcy.e);
    public static final bcx q = new bcu(bcy.c).n();
    public static final bcx r = new bcu(bcy.f).g();
    public static final bcx s = new bcx(bcy.c).s().p();
    public static final bcx t = new bcx(bcy.c).p();
    public static final bcx u = new bcx(bcy.g).g().s();
    public static final bcx v = new bcx(bcy.j).n();
    public static final bcx w = new bcx(bcy.h).s().p();
    public static final bcx x = new bcx(bcy.h).p();
    public static final bcx y = new bcu(bcy.k).i().s().f().n();
    public static final bcx z = new bcx(bcy.k).f();
    public static final bcx A = new bcx(bcy.j).s().n();
    public static final bcx B = new bcx(bcy.l);
    public static final bcx C = new bcx(bcy.j).n();
    public static final bcx D = new bcx(bcy.j).n();
    public static final bcx E = new bcz(bcy.c).o();
    public static final bcx F = new bcx(bcy.c).n();
    public static final bcx G = new bcx(bcy.f){

        @Override
        public boolean c() {
            return false;
        }
    }.f().n();
    public static final bcx H = new bcx(bcy.n).o();
    public static final bcx I = new bcx(bcy.c).f().o();
    public static final bcx J = new bcv(bcy.c);
    private boolean K;
    private boolean L;
    private boolean M;
    private final bcy N;
    private boolean O = true;
    private bda P = bda.a;
    private boolean Q;

    public bcx(bcy bcy2) {
        this.N = bcy2;
    }

    public boolean d() {
        return false;
    }

    public boolean a() {
        return true;
    }

    public boolean b() {
        return true;
    }

    public boolean c() {
        return true;
    }

    private bcx s() {
        this.M = true;
        return this;
    }

    protected bcx f() {
        this.O = false;
        return this;
    }

    protected bcx g() {
        this.K = true;
        return this;
    }

    public boolean h() {
        return this.K;
    }

    public bcx i() {
        this.L = true;
        return this;
    }

    public boolean j() {
        return this.L;
    }

    public boolean k() {
        if (this.M) {
            return false;
        }
        return this.c();
    }

    public boolean l() {
        return this.O;
    }

    public bda m() {
        return this.P;
    }

    protected bcx n() {
        this.P = bda.b;
        return this;
    }

    protected bcx o() {
        this.P = bda.c;
        return this;
    }

    protected bcx p() {
        this.Q = true;
        return this;
    }

    public bcy r() {
        return this.N;
    }
}

