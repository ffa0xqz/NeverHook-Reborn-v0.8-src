/*
 * Decompiled with CFR 0.150.
 */
public class ajh
extends ail {
    private final aou a;
    private final aou b;

    public ajh(aou aou2, aou aou3) {
        this.a = aou2;
        this.b = aou3;
        this.b(ahn.l);
    }

    @Override
    public ub a(aeb aeb2, ams ams2, et et2, tz tz2, fa fa2, float f2, float f3, float f4) {
        ain ain2 = aeb2.b(tz2);
        if (fa2 != fa.b || !aeb2.a(et2.a(fa2), fa2, ain2) || ams2.o(et2).u() != this.b || !ams2.d(et2.a())) {
            return ub.c;
        }
        ams2.a(et2.a(), this.a.t());
        if (aeb2 instanceof oo) {
            m.x.a((oo)aeb2, et2.a(), ain2);
        }
        ain2.g(1);
        return ub.a;
    }
}

