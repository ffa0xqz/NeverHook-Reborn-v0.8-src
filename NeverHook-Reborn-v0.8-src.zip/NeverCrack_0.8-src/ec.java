/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import java.util.Collections;
import java.util.EnumSet;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

public class ec
extends bi {
    @Override
    public String c() {
        return "tp";
    }

    @Override
    public int a() {
        return 2;
    }

    @Override
    public String b(bn bn2) {
        return "commands.tp.usage";
    }

    @Override
    public void a(MinecraftServer minecraftServer, bn bn2, String[] arrstring) throws ei {
        if (arrstring.length < 1) {
            throw new ep("commands.tp.usage", new Object[0]);
        }
        int \u26032 = 0;
        if (arrstring.length == 2 || arrstring.length == 4 || arrstring.length == 6) {
            ve ve2 = ec.c(minecraftServer, bn2, arrstring[0]);
            \u26032 = 1;
        } else {
            ve2 = ec.a(bn2);
        }
        if (arrstring.length == 1 || arrstring.length == 2) {
            \u2603 = ec.c(minecraftServer, bn2, arrstring[arrstring.length - 1]);
            if (\u2603.l != ve2.l) {
                throw new ei("commands.tp.notSameDimension", new Object[0]);
            }
            ve2.o();
            if (ve2 instanceof oo) {
                ((oo)ve2).a.a(\u2603.p, \u2603.q, \u2603.r, \u2603.v, \u2603.w);
            } else {
                ve2.b(\u2603.p, \u2603.q, \u2603.r, \u2603.v, \u2603.w);
            }
            ec.a(bn2, (bk)this, "commands.tp.success", ve2.h_(), \u2603.h_());
            return;
        }
        if (arrstring.length < \u26032 + 3) {
            throw new ep("commands.tp.usage", new Object[0]);
        }
        if (ve2.l == null) {
            return;
        }
        int n2 = \u26032;
        \u2603 = 4096;
        bi.a \u26033 = ec.a(ve2.p, arrstring[n2++], true);
        bi.a \u26034 = ec.a(ve2.q, arrstring[n2++], -4096, 4096, false);
        bi.a \u26035 = ec.a(ve2.r, arrstring[n2++], true);
        bi.a \u26036 = ec.a(ve2.v, arrstring.length > n2 ? arrstring[n2++] : "~", false);
        bi.a \u26037 = ec.a(ve2.w, arrstring.length > n2 ? arrstring[n2] : "~", false);
        ec.a(ve2, \u26033, \u26034, \u26035, \u26036, \u26037);
        ec.a(bn2, (bk)this, "commands.tp.success.coordinates", ve2.h_(), \u26033.a(), \u26034.a(), \u26035.a());
    }

    private static void a(ve ve2, bi.a a2, bi.a a3, bi.a a4, bi.a a5, bi.a a6) {
        if (ve2 instanceof oo) {
            EnumSet<jp.a> enumSet = EnumSet.noneOf(jp.a.class);
            if (a2.c()) {
                enumSet.add(jp.a.a);
            }
            if (a3.c()) {
                enumSet.add(jp.a.b);
            }
            if (a4.c()) {
                enumSet.add(jp.a.c);
            }
            if (a6.c()) {
                enumSet.add(jp.a.e);
            }
            if (a5.c()) {
                enumSet.add(jp.a.d);
            }
            float \u26032 = (float)a5.b();
            if (!a5.c()) {
                \u26032 = ri.g(\u26032);
            }
            float \u26033 = (float)a6.b();
            if (!a6.c()) {
                \u26033 = ri.g(\u26033);
            }
            ve2.o();
            ((oo)ve2).a.a(a2.b(), a3.b(), a4.b(), \u26032, \u26033, enumSet);
            ve2.g(\u26032);
        } else {
            float \u26034 = (float)ri.g(a5.a());
            float \u26035 = (float)ri.g(a6.a());
            \u26035 = ri.a(\u26035, -90.0f, 90.0f);
            ve2.b(a2.a(), a3.a(), a4.a(), \u26034, \u26035);
            ve2.g(\u26034);
        }
        if (!(ve2 instanceof vn) || !((vn)ve2).cP()) {
            ve2.t = 0.0;
            ve2.z = true;
        }
    }

    @Override
    public List<String> a(MinecraftServer minecraftServer, bn bn2, String[] arrstring, @Nullable et et2) {
        if (arrstring.length == 1 || arrstring.length == 2) {
            return ec.a(arrstring, minecraftServer.J());
        }
        return Collections.emptyList();
    }

    @Override
    public boolean b(String[] arrstring, int n2) {
        return n2 == 0;
    }
}

