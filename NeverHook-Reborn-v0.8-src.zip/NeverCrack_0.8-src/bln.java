/*
 * Decompiled with CFR 0.150.
 */
public interface bln {
    public void a(String ... var1);
}

