/*
 * Decompiled with CFR 0.150.
 */
public class bue
implements ua {
    private final String a;
    private final hh b;

    public bue(String string, hh hh2) {
        this.a = string;
        this.b = hh2;
    }

    @Override
    public afp a(aea aea2, aeb aeb2) {
        throw new UnsupportedOperationException();
    }

    @Override
    public String h_() {
        return this.b.c();
    }

    @Override
    public boolean n_() {
        return true;
    }

    @Override
    public String l() {
        return this.a;
    }

    @Override
    public hh i_() {
        return this.b;
    }
}

