/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonParseException
 *  javax.annotation.Nullable
 */
import com.google.gson.JsonParseException;
import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

public class du
extends bi {
    @Override
    public String c() {
        return "tellraw";
    }

    @Override
    public int a() {
        return 2;
    }

    @Override
    public String b(bn bn2) {
        return "commands.tellraw.usage";
    }

    @Override
    public void a(MinecraftServer minecraftServer, bn bn2, String[] arrstring) throws ei {
        if (arrstring.length < 2) {
            throw new ep("commands.tellraw.usage", new Object[0]);
        }
        oo oo2 = du.b(minecraftServer, bn2, arrstring[0]);
        String \u26032 = du.a(arrstring, 1);
        try {
            hh hh2 = hh.a.a(\u26032);
            ((ve)oo2).a(hi.a(bn2, hh2, oo2));
        }
        catch (JsonParseException jsonParseException) {
            throw du.a(jsonParseException);
        }
    }

    @Override
    public List<String> a(MinecraftServer minecraftServer, bn bn2, String[] arrstring, @Nullable et et2) {
        if (arrstring.length == 1) {
            return du.a(arrstring, minecraftServer.J());
        }
        return Collections.emptyList();
    }

    @Override
    public boolean b(String[] arrstring, int n2) {
        return n2 == 0;
    }
}

