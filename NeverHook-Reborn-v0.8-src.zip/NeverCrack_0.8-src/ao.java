/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Maps
 *  com.google.common.collect.Sets
 *  com.google.gson.JsonDeserializationContext
 *  com.google.gson.JsonObject
 */
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ao
implements p<b> {
    private final Map<nn, a> a = Maps.newHashMap();
    private final nd b;

    public ao(nd nd2) {
        this.b = nd2;
    }

    @Override
    public nd a() {
        return this.b;
    }

    @Override
    public void a(nn nn2, p.a<b> a2) {
        a a3 = this.a.get(nn2);
        if (a3 == null) {
            a3 = new a(nn2);
            this.a.put(nn2, a3);
        }
        a3.a(a2);
    }

    @Override
    public void b(nn nn2, p.a<b> a2) {
        a a3 = this.a.get(nn2);
        if (a3 != null) {
            a3.b(a2);
            if (a3.a()) {
                this.a.remove(nn2);
            }
        }
    }

    @Override
    public void a(nn nn2) {
        this.a.remove(nn2);
    }

    public b b(JsonObject jsonObject, JsonDeserializationContext jsonDeserializationContext) {
        return new b(this.b, aj.a(jsonObject.get("entity")), ac.a(jsonObject.get("killing_blow")));
    }

    public void a(oo oo2, ve ve2, up up2) {
        a a2 = this.a.get(oo2.P());
        if (a2 != null) {
            a2.a(oo2, ve2, up2);
        }
    }

    @Override
    public /* synthetic */ q a(JsonObject jsonObject, JsonDeserializationContext jsonDeserializationContext) {
        return this.b(jsonObject, jsonDeserializationContext);
    }

    static class a {
        private final nn a;
        private final Set<p.a<b>> b = Sets.newHashSet();

        public a(nn nn2) {
            this.a = nn2;
        }

        public boolean a() {
            return this.b.isEmpty();
        }

        public void a(p.a<b> a2) {
            this.b.add(a2);
        }

        public void b(p.a<b> a2) {
            this.b.remove(a2);
        }

        public void a(oo oo2, ve ve2, up up2) {
            List list = null;
            for (p.a<b> a2 : this.b) {
                if (!a2.a().a(oo2, ve2, up2)) continue;
                if (list == null) {
                    list = Lists.newArrayList();
                }
                list.add(a2);
            }
            if (list != null) {
                for (p.a<b> a2 : list) {
                    a2.a(this.a);
                }
            }
        }
    }

    public static class b
    extends u {
        private final aj a;
        private final ac b;

        public b(nd nd2, aj aj2, ac ac2) {
            super(nd2);
            this.a = aj2;
            this.b = ac2;
        }

        public boolean a(oo oo2, ve ve2, up up2) {
            if (!this.b.a(oo2, up2)) {
                return false;
            }
            return this.a.a(oo2, ve2);
        }
    }
}

