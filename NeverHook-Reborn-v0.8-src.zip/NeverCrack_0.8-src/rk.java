/*
 * Decompiled with CFR 0.150.
 */
public interface rk {
    public void a(String var1);

    public void b(String var1);

    public void c(String var1);

    public void a(int var1);

    public void a();
}

