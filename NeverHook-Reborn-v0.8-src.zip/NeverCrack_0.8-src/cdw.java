/*
 * Decompiled with CFR 0.150.
 */
import optifine.Config;
import optifine.Reflector;
import shadersmod.client.SVertexFormat;

public class cdw {
    public static cdy a = new cdy();
    public static cdy b = new cdy();
    private static final cdy BLOCK_VANILLA = a;
    private static final cdy ITEM_VANILLA = b;
    public static final cdy c = new cdy();
    public static final cdy d = new cdy();
    public static final cdy e = new cdy();
    public static final cdy f = new cdy();
    public static final cdy g = new cdy();
    public static final cdy h = new cdy();
    public static final cdy i = new cdy();
    public static final cdy j = new cdy();
    public static final cdy k = new cdy();
    public static final cdy l = new cdy();
    public static final cdz m = new cdz(0, cdz.a.a, cdz.b.a, 3);
    public static final cdz n = new cdz(0, cdz.a.b, cdz.b.c, 4);
    public static final cdz o = new cdz(0, cdz.a.a, cdz.b.d, 2);
    public static final cdz p = new cdz(1, cdz.a.e, cdz.b.d, 2);
    public static final cdz q = new cdz(0, cdz.a.c, cdz.b.b, 3);
    public static final cdz r = new cdz(0, cdz.a.c, cdz.b.g, 1);

    public static void updateVertexFormats() {
        if (Config.isShaders()) {
            a = SVertexFormat.makeDefVertexFormatBlock();
            b = SVertexFormat.makeDefVertexFormatItem();
        } else {
            a = BLOCK_VANILLA;
            b = ITEM_VANILLA;
        }
        if (Reflector.Attributes_DEFAULT_BAKED_FORMAT.exists()) {
            cdy vertexformat = b;
            cdy vertexformat1 = (cdy)Reflector.getFieldValue(Reflector.Attributes_DEFAULT_BAKED_FORMAT);
            vertexformat1.a();
            for (int i2 = 0; i2 < vertexformat.i(); ++i2) {
                vertexformat1.a(vertexformat.c(i2));
            }
        }
    }

    static {
        a.a(m);
        a.a(n);
        a.a(o);
        a.a(p);
        b.a(m);
        b.a(n);
        b.a(o);
        b.a(q);
        b.a(r);
        c.a(m);
        c.a(o);
        c.a(q);
        c.a(r);
        d.a(m);
        d.a(o);
        d.a(n);
        d.a(p);
        e.a(m);
        f.a(m);
        f.a(n);
        g.a(m);
        g.a(o);
        h.a(m);
        h.a(q);
        h.a(r);
        i.a(m);
        i.a(o);
        i.a(n);
        j.a(m);
        j.a(o);
        j.a(q);
        j.a(r);
        k.a(m);
        k.a(o);
        k.a(p);
        k.a(n);
        l.a(m);
        l.a(o);
        l.a(n);
        l.a(q);
        l.a(r);
    }
}

