/*
 * Decompiled with CFR 0.150.
 */
public class alv
extends ali {
    public alv(ali.a a2, vj ... arrvj) {
        super(a2, alj.g, arrvj);
    }

    @Override
    public int a(int n2) {
        return 5 + (n2 - 1) * 9;
    }

    @Override
    public int b(int n2) {
        return this.a(n2) + 15;
    }

    @Override
    public int b() {
        return 3;
    }

    public static float e(int n2) {
        return 1.0f - 1.0f / (float)(n2 + 1);
    }

    @Override
    public String a() {
        return "enchantment.sweeping";
    }
}

