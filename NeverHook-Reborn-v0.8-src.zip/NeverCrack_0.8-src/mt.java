/*
 * Decompiled with CFR 0.150.
 */
public interface mt
extends hb {
    public void a(mu var1);

    public void a(mv var1);
}

