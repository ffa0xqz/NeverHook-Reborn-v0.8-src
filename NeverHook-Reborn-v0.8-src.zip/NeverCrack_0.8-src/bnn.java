/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  javax.annotation.Nullable
 */
import com.google.common.collect.Lists;
import java.util.List;
import javax.annotation.Nullable;

public class bnn {
    private List<bnp> a = Lists.newArrayListWithCapacity((int)20);
    private bnp b;
    private bnl c = new bnl();
    private bhz d;
    private List<bnr> e = Lists.newArrayList();
    private List<bnq> f;
    private bjr g;
    private bjr h;
    private int i;
    private int j;
    private qj k;
    private akr l;
    private bnq m;

    public bnn() {
        for (int i2 = 0; i2 < 20; ++i2) {
            this.a.add(new bnp());
        }
    }

    public void a(bhz p_194194_1_, int p_194194_2_, int p_194194_3_) {
        this.d = p_194194_1_;
        this.k = p_194194_1_.h.E();
        for (int i2 = 0; i2 < this.a.size(); ++i2) {
            this.a.get(i2).c(p_194194_2_ + 11 + 25 * (i2 % 5), p_194194_3_ + 31 + 25 * (i2 / 5));
        }
        this.g = new bjr(0, p_194194_2_ + 93, p_194194_3_ + 137, 12, 17, false);
        this.g.a(1, 208, 13, 18, bnm.a);
        this.h = new bjr(0, p_194194_2_ + 38, p_194194_3_ + 137, 12, 17, true);
        this.h.a(1, 208, 13, 18, bnm.a);
    }

    public void a(bnm p_193732_1_) {
        this.e.remove(p_193732_1_);
        this.e.add(p_193732_1_);
    }

    public void a(List<bnq> p_194192_1_, boolean p_194192_2_) {
        this.f = p_194192_1_;
        this.i = (int)Math.ceil((double)p_194192_1_.size() / 20.0);
        if (this.i <= this.j || p_194192_2_) {
            this.j = 0;
        }
        this.d();
    }

    private void d() {
        int i2 = 20 * this.j;
        for (int j2 = 0; j2 < this.a.size(); ++j2) {
            bnp guibuttonrecipe = this.a.get(j2);
            if (i2 + j2 < this.f.size()) {
                bnq recipelist = this.f.get(i2 + j2);
                guibuttonrecipe.a(recipelist, this, this.k);
                guibuttonrecipe.m = true;
                continue;
            }
            guibuttonrecipe.m = false;
        }
        this.e();
    }

    private void e() {
        this.g.m = this.i > 1 && this.j < this.i - 1;
        this.h.m = this.i > 1 && this.j > 0;
    }

    public void a(int p_194191_1_, int p_194191_2_, int p_194191_3_, int p_194191_4_, float p_194191_5_) {
        if (this.i > 1) {
            String s2 = this.j + 1 + "/" + this.i;
            int i2 = bhz.k.a(s2);
            bhz.k.drawString(s2, p_194191_1_ - i2 / 2 + 73, p_194191_2_ + 141, -1);
        }
        bhx.a();
        this.b = null;
        for (bnp guibuttonrecipe : this.a) {
            guibuttonrecipe.a(this.d, p_194191_3_, p_194191_4_, p_194191_5_);
            if (!guibuttonrecipe.m || !guibuttonrecipe.a()) continue;
            this.b = guibuttonrecipe;
        }
        this.h.a(this.d, p_194191_3_, p_194191_4_, p_194191_5_);
        this.g.a(this.d, p_194191_3_, p_194191_4_, p_194191_5_);
        this.c.a(p_194191_3_, p_194191_4_, p_194191_5_);
    }

    public void a(int p_193721_1_, int p_193721_2_) {
        if (this.d.m != null && this.b != null && !this.c.c()) {
            this.d.m.a(this.b.a(this.d.m), p_193721_1_, p_193721_2_);
        }
    }

    @Nullable
    public akr a() {
        return this.l;
    }

    @Nullable
    public bnq b() {
        return this.m;
    }

    public void c() {
        this.c.a(false);
    }

    public boolean a(int p_194196_1_, int p_194196_2_, int p_194196_3_, int p_194196_4_, int p_194196_5_, int p_194196_6_, int p_194196_7_) {
        this.l = null;
        this.m = null;
        if (this.c.c()) {
            if (this.c.a(p_194196_1_, p_194196_2_, p_194196_3_)) {
                this.l = this.c.b();
                this.m = this.c.a();
            } else {
                this.c.a(false);
            }
            return true;
        }
        if (this.g.b(this.d, p_194196_1_, p_194196_2_) && p_194196_3_ == 0) {
            this.g.a(this.d.U());
            ++this.j;
            this.d();
            return true;
        }
        if (this.h.b(this.d, p_194196_1_, p_194196_2_) && p_194196_3_ == 0) {
            this.h.a(this.d.U());
            --this.j;
            this.d();
            return true;
        }
        for (bnp guibuttonrecipe : this.a) {
            if (!guibuttonrecipe.b(this.d, p_194196_1_, p_194196_2_)) continue;
            guibuttonrecipe.a(this.d.U());
            if (p_194196_3_ == 0) {
                this.l = guibuttonrecipe.e();
                this.m = guibuttonrecipe.c();
            } else if (!this.c.c() && !guibuttonrecipe.d()) {
                this.c.a(this.d, guibuttonrecipe.c(), guibuttonrecipe.h, guibuttonrecipe.i, p_194196_4_ + p_194196_6_ / 2, p_194196_5_ + 13 + p_194196_7_ / 2, guibuttonrecipe.b(), this.k);
            }
            return true;
        }
        return false;
    }

    public void a(List<akr> p_194195_1_) {
        for (bnr irecipeupdatelistener : this.e) {
            irecipeupdatelistener.a(p_194195_1_);
        }
    }
}

