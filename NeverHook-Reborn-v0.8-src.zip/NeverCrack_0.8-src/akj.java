/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 */
import com.google.common.collect.Lists;
import java.util.ArrayList;

public class akj
implements akr {
    @Override
    public boolean a(afw afw2, ams ams2) {
        ain ain2 = ain.a;
        ArrayList \u26032 = Lists.newArrayList();
        for (int i2 = 0; i2 < afw2.w_(); ++i2) {
            ain ain3 = afw2.a(i2);
            if (ain3.b()) continue;
            if (ain3.c() instanceof agt) {
                agt agt2 = (agt)ain3.c();
                if (agt2.d() == agt.a.a && ain2.b()) {
                    ain2 = ain3;
                    continue;
                }
                return false;
            }
            if (ain3.c() == aip.be) {
                \u26032.add(ain3);
                continue;
            }
            return false;
        }
        return !ain2.b() && !\u26032.isEmpty();
    }

    @Override
    public ain a(afw afw2) {
        float \u26037;
        float \u26036;
        int n2;
        ain ain2 = ain.a;
        int[] \u26032 = new int[3];
        int \u26033 = 0;
        int \u26034 = 0;
        agt \u26035 = null;
        for (n2 = 0; n2 < afw2.w_(); ++n2) {
            ain ain3 = afw2.a(n2);
            if (ain3.b()) continue;
            if (ain3.c() instanceof agt) {
                \u26035 = (agt)ain3.c();
                if (\u26035.d() == agt.a.a && ain2.b()) {
                    ain2 = ain3.l();
                    ain2.e(1);
                    if (!\u26035.e_(ain3)) continue;
                    int n3 = \u26035.c(ain2);
                    \u26036 = (float)(n3 >> 16 & 0xFF) / 255.0f;
                    \u26037 = (float)(n3 >> 8 & 0xFF) / 255.0f;
                    float \u26038 = (float)(n3 & 0xFF) / 255.0f;
                    \u26033 = (int)((float)\u26033 + Math.max(\u26036, Math.max(\u26037, \u26038)) * 255.0f);
                    \u26032[0] = (int)((float)\u26032[0] + \u26036 * 255.0f);
                    \u26032[1] = (int)((float)\u26032[1] + \u26037 * 255.0f);
                    \u26032[2] = (int)((float)\u26032[2] + \u26038 * 255.0f);
                    ++\u26034;
                    continue;
                }
                return ain.a;
            }
            if (ain3.c() == aip.be) {
                float[] arrf = ahq.a(ain3.j()).f();
                int \u26039 = (int)(arrf[0] * 255.0f);
                int \u260310 = (int)(arrf[1] * 255.0f);
                int \u260311 = (int)(arrf[2] * 255.0f);
                \u26033 += Math.max(\u26039, Math.max(\u260310, \u260311));
                \u26032[0] = \u26032[0] + \u26039;
                \u26032[1] = \u26032[1] + \u260310;
                \u26032[2] = \u26032[2] + \u260311;
                ++\u26034;
                continue;
            }
            return ain.a;
        }
        if (\u26035 == null) {
            return ain.a;
        }
        n2 = \u26032[0] / \u26034;
        \u2603 = \u26032[1] / \u26034;
        n3 = \u26032[2] / \u26034;
        \u26036 = (float)\u26033 / (float)\u26034;
        \u26037 = Math.max(n2, Math.max(\u2603, n3));
        n2 = (int)((float)n2 * \u26036 / \u26037);
        \u2603 = (int)((float)\u2603 * \u26036 / \u26037);
        n3 = (int)((float)n3 * \u26036 / \u26037);
        \u2603 = n2;
        \u2603 = (\u2603 << 8) + \u2603;
        \u2603 = (\u2603 << 8) + n3;
        \u26035.a(ain2, \u2603);
        return ain2;
    }

    @Override
    public ain b() {
        return ain.a;
    }

    @Override
    public fi<ain> b(afw afw2) {
        fi<ain> fi2 = fi.a(afw2.w_(), ain.a);
        for (int i2 = 0; i2 < fi2.size(); ++i2) {
            ain ain2 = afw2.a(i2);
            if (!ain2.c().r()) continue;
            fi2.set(i2, new ain(ain2.c().q()));
        }
        return fi2;
    }

    @Override
    public boolean c() {
        return true;
    }

    @Override
    public boolean a(int n2, int n3) {
        return n2 * n3 >= 2;
    }
}

