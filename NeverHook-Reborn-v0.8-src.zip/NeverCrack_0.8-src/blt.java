/*
 * Decompiled with CFR 0.150.
 */
public interface blt {
    public static final String[] c_ = new String[]{"oooooo", "Oooooo", "oOoooo", "ooOooo", "oooOoo", "ooooOo", "oooooO"};

    public void g();
}

