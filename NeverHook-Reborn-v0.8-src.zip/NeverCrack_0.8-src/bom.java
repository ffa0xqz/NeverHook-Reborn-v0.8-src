/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 */
import com.mojang.authlib.GameProfile;

public class bom
implements boq {
    private final GameProfile a;
    private final nd b;

    public bom(GameProfile gameProfile) {
        this.a = gameProfile;
        this.b = bty.e(gameProfile.getName());
        bty.a(this.b, gameProfile.getName());
    }

    @Override
    public void a(boo boo2) {
        bhz.z().v().a(new ly(this.a.getId()));
    }

    @Override
    public hh J_() {
        return new ho(this.a.getName());
    }

    @Override
    public void a(float f2, int n2) {
        bhz.z().N().a(this.b);
        buq.c(1.0f, 1.0f, 1.0f, (float)n2 / 255.0f);
        bip.a(2, 2, 8.0f, 8.0f, 8, 8, 12, 12, 64.0f, 64.0f);
        bip.a(2, 2, 40.0f, 8.0f, 8, 8, 12, 12, 64.0f, 64.0f);
    }

    @Override
    public boolean K_() {
        return true;
    }
}

