/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonDeserializationContext
 *  com.google.gson.JsonDeserializer
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParseException
 *  javax.annotation.Nullable
 */
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.lang.reflect.Type;
import javax.annotation.Nullable;

public class bvr {
    public float[] a;
    public final int b;

    public bvr(@Nullable float[] arrf, int n2) {
        this.a = arrf;
        this.b = n2;
    }

    public float a(int n2) {
        if (this.a == null) {
            throw new NullPointerException("uvs");
        }
        \u2603 = this.d(n2);
        return \u2603 == 0 || \u2603 == 1 ? this.a[0] : this.a[2];
    }

    public float b(int n2) {
        if (this.a == null) {
            throw new NullPointerException("uvs");
        }
        \u2603 = this.d(n2);
        return \u2603 == 0 || \u2603 == 3 ? this.a[1] : this.a[3];
    }

    private int d(int n2) {
        return (n2 + this.b / 90) % 4;
    }

    public int c(int n2) {
        return (n2 + (4 - this.b / 90)) % 4;
    }

    public void a(float[] arrf) {
        if (this.a == null) {
            this.a = arrf;
        }
    }

    static class a
    implements JsonDeserializer<bvr> {
        a() {
        }

        public bvr a(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            JsonObject jsonObject = jsonElement.getAsJsonObject();
            float[] \u26032 = this.b(jsonObject);
            int \u26033 = this.a(jsonObject);
            return new bvr(\u26032, \u26033);
        }

        protected int a(JsonObject jsonObject) {
            int n2 = ra.a(jsonObject, "rotation", 0);
            if (n2 < 0 || n2 % 90 != 0 || n2 / 90 > 3) {
                throw new JsonParseException("Invalid rotation " + n2 + " found, only 0/90/180/270 allowed");
            }
            return n2;
        }

        @Nullable
        private float[] b(JsonObject jsonObject) {
            if (!jsonObject.has("uv")) {
                return null;
            }
            JsonArray jsonArray = ra.u(jsonObject, "uv");
            if (jsonArray.size() != 4) {
                throw new JsonParseException("Expected 4 uv values, found: " + jsonArray.size());
            }
            float[] \u26032 = new float[4];
            for (int i2 = 0; i2 < \u26032.length; ++i2) {
                \u26032[i2] = ra.e(jsonArray.get(i2), "uv[" + i2 + "]");
            }
            return \u26032;
        }

        public /* synthetic */ Object deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            return this.a(jsonElement, type, jsonDeserializationContext);
        }
    }
}

