/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;

public class aqf
extends aoo {
    protected static final bgz a = new bgz(0.0, 0.0, 0.0, 1.0, 0.75, 1.0);

    protected aqf(bcx materialIn) {
        super(materialIn);
        this.a(1.0f);
    }

    @Override
    public avh a(ams worldIn, int meta) {
        return new awe();
    }

    @Override
    public bgz b(awr state, amw source, et pos) {
        return a;
    }

    @Override
    public boolean a(awr blockState, amw blockAccess, et pos, fa side) {
        return side == fa.a ? super.a(blockState, blockAccess, pos, side) : false;
    }

    @Override
    public void a(awr state, ams worldIn, et pos, bgz entityBox, List<bgz> collidingBoxes, @Nullable ve entityIn, boolean p_185477_7_) {
    }

    @Override
    public boolean b(awr state) {
        return false;
    }

    @Override
    public boolean c(awr state) {
        return false;
    }

    @Override
    public int a(Random random) {
        return 0;
    }

    @Override
    public void a(ams worldIn, et pos, awr state, ve entityIn) {
        if (!worldIn.G && !entityIn.aS() && !entityIn.aT() && entityIn.bf() && entityIn.bw().c(state.e(worldIn, pos).a(pos))) {
            entityIn.b(1);
        }
    }

    @Override
    public void a(awr stateIn, ams worldIn, et pos, Random rand) {
        double d0 = (float)pos.p() + rand.nextFloat();
        double d1 = (float)pos.q() + 0.8f;
        double d2 = (float)pos.r() + rand.nextFloat();
        double d3 = 0.0;
        double d4 = 0.0;
        double d5 = 0.0;
        worldIn.a(fj.l, d0, d1, d2, 0.0, 0.0, 0.0, new int[0]);
    }

    @Override
    public ain a(ams worldIn, et pos, awr state) {
        return ain.a;
    }

    @Override
    public bcy c(awr state, amw p_180659_2_, et p_180659_3_) {
        return bcy.F;
    }

    @Override
    public awp a(amw p_193383_1_, awr p_193383_2_, et p_193383_3_, fa p_193383_4_) {
        return awp.i;
    }
}

