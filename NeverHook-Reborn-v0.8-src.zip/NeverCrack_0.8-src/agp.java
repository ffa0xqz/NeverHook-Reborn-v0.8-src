/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import javax.annotation.Nullable;

public class agp {
    private final int a;
    public final tt d;
    public int e;
    public int f;
    public int g;

    public agp(tt tt2, int n2, int n3, int n4) {
        this.d = tt2;
        this.a = n2;
        this.f = n3;
        this.g = n4;
    }

    public void a(ain ain2, ain ain3) {
        int n2 = ain3.E() - ain2.E();
        if (n2 > 0) {
            this.a(ain3, n2);
        }
    }

    protected void a(ain ain2, int n2) {
    }

    protected void b(int n2) {
    }

    protected void c(ain ain2) {
    }

    public ain a(aeb aeb2, ain ain2) {
        this.f();
        return ain2;
    }

    public boolean a(ain ain2) {
        return true;
    }

    public ain d() {
        return this.d.a(this.a);
    }

    public boolean e() {
        return !this.d().b();
    }

    public void d(ain ain2) {
        this.d.a(this.a, ain2);
        this.f();
    }

    public void f() {
        this.d.y_();
    }

    public int a() {
        return this.d.z_();
    }

    public int b(ain ain2) {
        return this.a();
    }

    @Nullable
    public String c() {
        return null;
    }

    public ain a(int n2) {
        return this.d.a(this.a, n2);
    }

    public boolean a(tt tt2, int n2) {
        return tt2 == this.d && n2 == this.a;
    }

    public boolean a(aeb aeb2) {
        return true;
    }

    public boolean b() {
        return true;
    }
}

