/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Maps
 *  javax.annotation.Nullable
 */
import com.google.common.base.Predicate;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;

public class cgc
implements cfw {
    private final Map<Predicate<awr>, cfw> f;
    protected final boolean a;
    protected final boolean b;
    protected final cdo c;
    protected final bwa d;
    protected final bvy e;

    public cgc(Map<Predicate<awr>, cfw> map) {
        this.f = map;
        cfw cfw2 = map.values().iterator().next();
        this.a = cfw2.a();
        this.b = cfw2.b();
        this.c = cfw2.d();
        this.d = cfw2.e();
        this.e = cfw2.f();
    }

    @Override
    public List<bvn> a(@Nullable awr awr2, @Nullable fa fa2, long l2) {
        ArrayList arrayList = Lists.newArrayList();
        if (awr2 != null) {
            for (Map.Entry<Predicate<awr>, cfw> entry : this.f.entrySet()) {
                if (!entry.getKey().apply((Object)awr2)) continue;
                arrayList.addAll(entry.getValue().a(awr2, fa2, l2++));
            }
        }
        return arrayList;
    }

    @Override
    public boolean a() {
        return this.a;
    }

    @Override
    public boolean b() {
        return this.b;
    }

    @Override
    public boolean c() {
        return false;
    }

    @Override
    public cdo d() {
        return this.c;
    }

    @Override
    public bwa e() {
        return this.d;
    }

    @Override
    public bvy f() {
        return this.e;
    }

    public static class a {
        private final Map<Predicate<awr>, cfw> a = Maps.newLinkedHashMap();

        public void a(Predicate<awr> predicate, cfw cfw2) {
            this.a.put(predicate, cfw2);
        }

        public cfw a() {
            return new cgc(this.a);
        }
    }
}

