/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import java.io.IOException;
import javax.annotation.Nullable;

public class jx
implements ht<hw> {
    @Nullable
    private nd a;

    public jx() {
    }

    public jx(@Nullable nd nd2) {
        this.a = nd2;
    }

    @Override
    public void a(hw hw2) {
        hw2.a(this);
    }

    @Override
    public void a(gy gy2) throws IOException {
        if (gy2.readBoolean()) {
            this.a = gy2.l();
        }
    }

    @Override
    public void b(gy gy2) throws IOException {
        gy2.writeBoolean(this.a != null);
        if (this.a != null) {
            gy2.a(this.a);
        }
    }

    @Nullable
    public nd a() {
        return this.a;
    }
}

