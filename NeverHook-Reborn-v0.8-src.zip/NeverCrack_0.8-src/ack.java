/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import javax.annotation.Nullable;

public class ack
extends ve {
    private static final mx<Integer> a = na.a(ack.class, mz.b);
    @Nullable
    private vn b;
    private int c = 80;

    public ack(ams ams2) {
        super(ams2);
        this.i = true;
        this.X = true;
        this.a(0.98f, 0.98f);
    }

    public ack(ams ams2, double d2, double d3, double d4, vn vn2) {
        this(ams2);
        this.b(d2, d3, d4);
        float f2 = (float)(Math.random() * 6.2831854820251465);
        this.s = -((float)Math.sin(f2)) * 0.02f;
        this.t = 0.2f;
        this.u = -((float)Math.cos(f2)) * 0.02f;
        this.a(80);
        this.m = d2;
        this.n = d3;
        this.o = d4;
        this.b = vn2;
    }

    @Override
    protected void i() {
        this.Y.a(a, 80);
    }

    @Override
    protected boolean ak() {
        return false;
    }

    @Override
    public boolean ay() {
        return !this.F;
    }

    @Override
    public void B_() {
        this.m = this.p;
        this.n = this.q;
        this.o = this.r;
        if (!this.aj()) {
            this.t -= (double)0.04f;
        }
        this.a(vt.a, this.s, this.t, this.u);
        this.s *= (double)0.98f;
        this.t *= (double)0.98f;
        this.u *= (double)0.98f;
        if (this.z) {
            this.s *= (double)0.7f;
            this.u *= (double)0.7f;
            this.t *= -0.5;
        }
        --this.c;
        if (this.c <= 0) {
            this.X();
            if (!this.l.G) {
                this.n();
            }
        } else {
            this.aq();
            this.l.a(fj.l, this.p, this.q + 0.5, this.r, 0.0, 0.0, 0.0, new int[0]);
        }
    }

    private void n() {
        float f2 = 4.0f;
        this.l.a(this, this.p, this.q + (double)(this.H / 16.0f), this.r, 4.0f, true);
    }

    @Override
    protected void b(fy fy2) {
        fy2.a("Fuse", (short)this.l());
    }

    @Override
    protected void a(fy fy2) {
        this.a(fy2.g("Fuse"));
    }

    @Nullable
    public vn j() {
        return this.b;
    }

    @Override
    public float by() {
        return 0.0f;
    }

    public void a(int n2) {
        this.Y.b(a, n2);
        this.c = n2;
    }

    @Override
    public void a(mx<?> mx2) {
        if (a.equals(mx2)) {
            this.c = this.k();
        }
    }

    public int k() {
        return this.Y.a(a);
    }

    public int l() {
        return this.c;
    }
}

