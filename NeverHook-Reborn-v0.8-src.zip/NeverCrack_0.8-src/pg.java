/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
import com.google.gson.JsonObject;
import java.io.File;
import java.net.SocketAddress;

public class pg
extends pn<String, ph> {
    public pg(File file) {
        super(file);
    }

    @Override
    protected pm<String> a(JsonObject jsonObject) {
        return new ph(jsonObject);
    }

    public boolean a(SocketAddress socketAddress) {
        String string = this.c(socketAddress);
        return this.d(string);
    }

    @Override
    public ph b(SocketAddress socketAddress) {
        String string = this.c(socketAddress);
        return (ph)this.b(string);
    }

    private String c(SocketAddress socketAddress) {
        String string = socketAddress.toString();
        if (string.contains("/")) {
            string = string.substring(string.indexOf(47) + 1);
        }
        if (string.contains(":")) {
            string = string.substring(0, string.indexOf(58));
        }
        return string;
    }
}

