/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.annotations.VisibleForTesting
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Maps
 *  com.google.common.collect.Sets
 *  com.google.gson.Gson
 *  com.google.gson.GsonBuilder
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonDeserializationContext
 *  com.google.gson.JsonDeserializer
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParseException
 *  javax.annotation.Nullable
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.io.Reader;
import java.io.StringReader;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class bvs {
    private static final Logger f = LogManager.getLogger();
    @VisibleForTesting
    static final Gson a = new GsonBuilder().registerTypeAdapter(bvs.class, (Object)new b()).registerTypeAdapter(bvo.class, (Object)new bvo.a()).registerTypeAdapter(bvp.class, (Object)new bvp.a()).registerTypeAdapter(bvr.class, (Object)new bvr.a()).registerTypeAdapter(bvz.class, (Object)new bvz.a()).registerTypeAdapter(bwa.class, (Object)new bwa.a()).registerTypeAdapter(bvx.class, (Object)new bvx.a()).create();
    private final List<bvo> g;
    private final boolean h;
    private final boolean i;
    private final bwa j;
    private final List<bvx> k;
    public String b = "";
    @VisibleForTesting
    protected final Map<String, String> c;
    @VisibleForTesting
    protected bvs d;
    @VisibleForTesting
    protected nd e;

    public static bvs a(Reader reader) {
        return ra.a(a, reader, bvs.class, false);
    }

    public static bvs a(String string) {
        return bvs.a(new StringReader(string));
    }

    public bvs(@Nullable nd nd2, List<bvo> list, Map<String, String> map, boolean bl2, boolean bl3, bwa bwa2, List<bvx> list2) {
        this.g = list;
        this.i = bl2;
        this.h = bl3;
        this.c = map;
        this.e = nd2;
        this.j = bwa2;
        this.k = list2;
    }

    public List<bvo> a() {
        if (this.g.isEmpty() && this.k()) {
            return this.d.a();
        }
        return this.g;
    }

    private boolean k() {
        return this.d != null;
    }

    public boolean b() {
        if (this.k()) {
            return this.d.b();
        }
        return this.i;
    }

    public boolean c() {
        return this.h;
    }

    public boolean d() {
        return this.e == null || this.d != null && this.d.d();
    }

    public void a(Map<nd, bvs> map) {
        if (this.e != null) {
            this.d = map.get(this.e);
        }
    }

    public Collection<nd> e() {
        HashSet hashSet = Sets.newHashSet();
        for (bvx bvx2 : this.k) {
            hashSet.add(bvx2.a());
        }
        return hashSet;
    }

    protected List<bvx> f() {
        return this.k;
    }

    public bvy g() {
        if (this.k.isEmpty()) {
            return bvy.a;
        }
        return new bvy(this.k);
    }

    public boolean b(String string) {
        return !"missingno".equals(this.c(string));
    }

    public String c(String string) {
        if (!this.d(string)) {
            string = '#' + string;
        }
        return this.a(string, new a(this));
    }

    private String a(String string2, a a2) {
        String string2;
        if (this.d(string2)) {
            if (this == a2.b) {
                f.warn("Unable to resolve texture due to upward reference: {} in {}", (Object)string2, (Object)this.b);
                return "missingno";
            }
            String string3 = this.c.get(string2.substring(1));
            if (string3 == null && this.k()) {
                string3 = this.d.a(string2, a2);
            }
            a2.b = this;
            if (string3 != null && this.d(string3)) {
                string3 = a2.a.a(string3, a2);
            }
            if (string3 == null || this.d(string3)) {
                return "missingno";
            }
            return string3;
        }
        return string2;
    }

    private boolean d(String string) {
        return string.charAt(0) == '#';
    }

    @Nullable
    public nd h() {
        return this.e;
    }

    public bvs i() {
        return this.k() ? this.d.i() : this;
    }

    public bwa j() {
        bvz bvz2 = this.a(bwa.b.b);
        \u2603 = this.a(bwa.b.c);
        \u2603 = this.a(bwa.b.d);
        \u2603 = this.a(bwa.b.e);
        \u2603 = this.a(bwa.b.f);
        \u2603 = this.a(bwa.b.g);
        \u2603 = this.a(bwa.b.h);
        \u2603 = this.a(bwa.b.i);
        return new bwa(bvz2, \u2603, \u2603, \u2603, \u2603, \u2603, \u2603, \u2603);
    }

    private bvz a(bwa.b b2) {
        if (this.d != null && !this.j.c(b2)) {
            return this.d.a(b2);
        }
        return this.j.b(b2);
    }

    public static void b(Map<nd, bvs> map) {
        for (bvs bvs2 : map.values()) {
            try {
                \u2603 = bvs2.d;
                \u2603 = \u2603.d;
                while (\u2603 != \u2603) {
                    \u2603 = \u2603.d;
                    \u2603 = \u2603.d.d;
                }
                throw new c();
            }
            catch (NullPointerException nullPointerException) {
            }
        }
    }

    public static class c
    extends RuntimeException {
    }

    public static class b
    implements JsonDeserializer<bvs> {
        public bvs a(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext2) throws JsonParseException {
            JsonDeserializationContext jsonDeserializationContext2;
            Object \u26037;
            JsonObject jsonObject = jsonElement.getAsJsonObject();
            List<bvo> \u26032 = this.b(jsonDeserializationContext2, jsonObject);
            String \u26033 = this.c(jsonObject);
            Map<String, String> \u26034 = this.b(jsonObject);
            boolean \u26035 = this.a(jsonObject);
            bwa \u26036 = bwa.a;
            if (jsonObject.has("display")) {
                \u26037 = ra.t(jsonObject, "display");
                \u26036 = (bwa)jsonDeserializationContext2.deserialize((JsonElement)\u26037, bwa.class);
            }
            \u26037 = this.a(jsonDeserializationContext2, jsonObject);
            nd \u26038 = \u26033.isEmpty() ? null : new nd(\u26033);
            return new bvs(\u26038, \u26032, \u26034, \u26035, true, \u26036, (List<bvx>)\u26037);
        }

        protected List<bvx> a(JsonDeserializationContext jsonDeserializationContext, JsonObject jsonObject) {
            ArrayList arrayList = Lists.newArrayList();
            if (jsonObject.has("overrides")) {
                JsonArray jsonArray = ra.u(jsonObject, "overrides");
                for (JsonElement jsonElement : jsonArray) {
                    arrayList.add((bvx)jsonDeserializationContext.deserialize(jsonElement, bvx.class));
                }
            }
            return arrayList;
        }

        private Map<String, String> b(JsonObject jsonObject) {
            HashMap hashMap = Maps.newHashMap();
            if (jsonObject.has("textures")) {
                JsonObject jsonObject2 = jsonObject.getAsJsonObject("textures");
                for (Map.Entry entry : jsonObject2.entrySet()) {
                    hashMap.put(entry.getKey(), ((JsonElement)entry.getValue()).getAsString());
                }
            }
            return hashMap;
        }

        private String c(JsonObject jsonObject) {
            return ra.a(jsonObject, "parent", "");
        }

        protected boolean a(JsonObject jsonObject) {
            return ra.a(jsonObject, "ambientocclusion", true);
        }

        protected List<bvo> b(JsonDeserializationContext jsonDeserializationContext, JsonObject jsonObject) {
            ArrayList arrayList = Lists.newArrayList();
            if (jsonObject.has("elements")) {
                for (JsonElement jsonElement : ra.u(jsonObject, "elements")) {
                    arrayList.add((bvo)jsonDeserializationContext.deserialize(jsonElement, bvo.class));
                }
            }
            return arrayList;
        }

        public /* synthetic */ Object deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            return this.a(jsonElement, type, jsonDeserializationContext);
        }
    }

    static final class a {
        public final bvs a;
        public bvs b;

        private a(bvs bvs2) {
            this.a = bvs2;
        }
    }
}

