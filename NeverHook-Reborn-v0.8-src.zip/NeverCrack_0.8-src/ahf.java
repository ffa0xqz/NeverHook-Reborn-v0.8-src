/*
 * Decompiled with CFR 0.150.
 */
public class ahf
extends aih {
    public ahf(int n2) {
        super(n2, false);
        this.d(1);
    }

    @Override
    public ain a(ain ain2, ams ams2, vn vn2) {
        super.a(ain2, ams2, vn2);
        return new ain(aip.C);
    }
}

