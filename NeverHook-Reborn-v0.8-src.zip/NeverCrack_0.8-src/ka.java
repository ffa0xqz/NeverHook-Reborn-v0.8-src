/*
 * Decompiled with CFR 0.150.
 */
import java.io.IOException;

public class ka
implements ht<hw> {
    private int a;

    public ka() {
    }

    public ka(int n2) {
        this.a = n2;
    }

    @Override
    public void a(gy gy2) throws IOException {
        this.a = gy2.readByte();
    }

    @Override
    public void b(gy gy2) throws IOException {
        gy2.writeByte(this.a);
    }

    @Override
    public void a(hw hw2) {
        hw2.a(this);
    }

    public int a() {
        return this.a;
    }
}

