/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 *  javax.annotation.Nullable
 *  org.apache.commons.io.IOUtils
 */
import com.google.common.collect.Maps;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;
import org.apache.commons.io.IOUtils;

public class bce {
    private final Map<String, bch> a = Maps.newHashMap();
    private final String b;
    private final rw c;

    public bce(String string, rw rw2) {
        this.b = string;
        this.c = rw2;
    }

    public bch a(@Nullable MinecraftServer minecraftServer, nd nd2) {
        bch bch2 = this.b(minecraftServer, nd2);
        if (bch2 == null) {
            bch2 = new bch();
            this.a.put(nd2.a(), bch2);
        }
        return bch2;
    }

    @Nullable
    public bch b(@Nullable MinecraftServer minecraftServer, nd nd2) {
        String string = nd2.a();
        if (this.a.containsKey(string)) {
            return this.a.get(string);
        }
        if (minecraftServer == null) {
            this.c(nd2);
        } else {
            this.a(nd2);
        }
        if (this.a.containsKey(string)) {
            return this.a.get(string);
        }
        return null;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public boolean a(nd nd2) {
        String string = nd2.a();
        File \u26032 = new File(this.b, string + ".nbt");
        if (!\u26032.exists()) {
            return this.c(nd2);
        }
        FileInputStream \u26033 = null;
        try {
            \u26033 = new FileInputStream(\u26032);
            this.a(string, \u26033);
        }
        catch (Throwable \u26034) {
            boolean bl2;
            try {
                bl2 = false;
            }
            catch (Throwable throwable) {
                IOUtils.closeQuietly(\u26033);
                throw throwable;
            }
            IOUtils.closeQuietly((InputStream)\u26033);
            return bl2;
        }
        IOUtils.closeQuietly((InputStream)\u26033);
        return true;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private boolean c(nd nd2) {
        String string = nd2.b();
        \u2603 = nd2.a();
        InputStream \u26032 = null;
        try {
            \u26032 = MinecraftServer.class.getResourceAsStream("/assets/" + string + "/structures/" + \u2603 + ".nbt");
            this.a(\u2603, \u26032);
        }
        catch (Throwable \u26033) {
            try {
                boolean bl2 = false;
                return bl2;
            }
            catch (Throwable throwable) {
                throw throwable;
            }
            finally {
                IOUtils.closeQuietly(\u26032);
            }
        }
        IOUtils.closeQuietly((InputStream)\u26032);
        return true;
    }

    private void a(String string, InputStream inputStream) throws IOException {
        fy fy2 = gi.a(inputStream);
        if (!fy2.b("DataVersion", 99)) {
            fy2.a("DataVersion", 500);
        }
        bch \u26032 = new bch();
        \u26032.b(this.c.a((rt)ru.h, fy2));
        this.a.put(string, \u26032);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public boolean c(@Nullable MinecraftServer minecraftServer, nd nd2) {
        String string = nd2.a();
        if (minecraftServer == null || !this.a.containsKey(string)) {
            return false;
        }
        File \u26032 = new File(this.b);
        if (!\u26032.exists() ? !\u26032.mkdirs() : !\u26032.isDirectory()) {
            return false;
        }
        File \u26033 = new File(\u26032, string + ".nbt");
        bch \u26034 = this.a.get(string);
        FileOutputStream \u26035 = null;
        try {
            fy fy2 = \u26034.a(new fy());
            \u26035 = new FileOutputStream(\u26033);
            gi.a(fy2, \u26035);
        }
        catch (Throwable throwable) {
            try {
                boolean bl2 = false;
                return bl2;
            }
            catch (Throwable throwable2) {
                throw throwable2;
            }
            finally {
                IOUtils.closeQuietly(\u26035);
            }
        }
        IOUtils.closeQuietly((OutputStream)\u26035);
        return true;
    }

    public void b(nd nd2) {
        this.a.remove(nd2.a());
    }
}

