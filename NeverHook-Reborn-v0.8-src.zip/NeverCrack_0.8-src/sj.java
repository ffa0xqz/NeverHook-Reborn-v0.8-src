/*
 * Decompiled with CFR 0.150.
 */
public class sj
implements rs {
    @Override
    public int a() {
        return 110;
    }

    @Override
    public fy a(fy fy2) {
        if ("EntityHorse".equals(fy2.l("id")) && !fy2.b("SaddleItem", 10) && fy2.q("Saddle")) {
            \u2603 = new fy();
            \u2603.a("id", "minecraft:saddle");
            \u2603.a("Count", (byte)1);
            \u2603.a("Damage", (short)0);
            fy2.a("SaddleItem", \u2603);
            fy2.r("Saddle");
        }
        return fy2;
    }
}

