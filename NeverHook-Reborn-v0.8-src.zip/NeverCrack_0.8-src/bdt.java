/*
 * Decompiled with CFR 0.150.
 */
public class bdt
extends bdo {
    public bdt(long l2, bdo bdo2) {
        super(l2);
        this.a = bdo2;
    }

    @Override
    public int[] a(int n2, int n3, int n4, int n5) {
        int[] arrn;
        \u2603 = n2 - 1;
        \u2603 = n3 - 1;
        \u2603 = n4 + 2;
        \u2603 = n5 + 2;
        int[] arrn2 = this.a.a(\u2603, \u2603, \u2603, \u2603);
        arrn = bdm.a(n4 * n5);
        for (int i2 = 0; i2 < n5; ++i2) {
            for (\u2603 = 0; \u2603 < n4; ++\u2603) {
                \u2603 = this.c(arrn2[\u2603 + 0 + (i2 + 1) * \u2603]);
                \u2603 = this.c(arrn2[\u2603 + 2 + (i2 + 1) * \u2603]);
                \u2603 = this.c(arrn2[\u2603 + 1 + (i2 + 0) * \u2603]);
                \u2603 = this.c(arrn2[\u2603 + 1 + (i2 + 2) * \u2603]);
                \u2603 = this.c(arrn2[\u2603 + 1 + (i2 + 1) * \u2603]);
                arrn[\u2603 + i2 * n4] = \u2603 != \u2603 || \u2603 != \u2603 || \u2603 != \u2603 || \u2603 != \u2603 ? anf.a(ank.i) : -1;
            }
        }
        return arrn;
    }

    private int c(int n2) {
        if (n2 >= 2) {
            return 2 + (n2 & 1);
        }
        return n2;
    }
}

