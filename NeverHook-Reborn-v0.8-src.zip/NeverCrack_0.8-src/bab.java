/*
 * Decompiled with CFR 0.150.
 */
import java.util.Random;

public class bab
extends azs {
    @Override
    public boolean b(ams ams2, Random random, et et22) {
        int \u26032;
        int n2;
        while (ams2.d(et22) && et22.q() > 2) {
            et22 = et22.b();
        }
        if (ams2.o(et22).u() != aov.aJ) {
            return false;
        }
        et22 = et22.b(random.nextInt(4));
        int n3 = random.nextInt(4) + 7;
        \u2603 = n3 / 4 + random.nextInt(2);
        if (\u2603 > 1 && random.nextInt(60) == 0) {
            et et22 = et22.b(10 + random.nextInt(30));
        }
        for (n2 = 0; n2 < n3; ++n2) {
            float f2 = (1.0f - (float)n2 / (float)n3) * (float)\u2603;
            \u26032 = ri.f(f2);
            for (int i2 = -\u26032; i2 <= \u26032; ++i2) {
                float f3 = (float)ri.a(i2) - 0.25f;
                for (int i3 = -\u26032; i3 <= \u26032; ++i3) {
                    float f4 = (float)ri.a(i3) - 0.25f;
                    if ((i2 != 0 || i3 != 0) && f3 * f3 + f4 * f4 > f2 * f2 || (i2 == -\u26032 || i2 == \u26032 || i3 == -\u26032 || i3 == \u26032) && random.nextFloat() > 0.75f) continue;
                    awr \u26033 = ams2.o(et22.a(i2, n2, i3));
                    aou \u26034 = \u26033.u();
                    if (\u26033.a() == bcx.a || \u26034 == aov.d || \u26034 == aov.aJ || \u26034 == aov.aI) {
                        this.a(ams2, et22.a(i2, n2, i3), aov.cB.t());
                    }
                    if (n2 == 0 || \u26032 <= 1) continue;
                    \u26033 = ams2.o(et22.a(i2, -n2, i3));
                    \u26034 = \u26033.u();
                    if (\u26033.a() != bcx.a && \u26034 != aov.d && \u26034 != aov.aJ && \u26034 != aov.aI) continue;
                    this.a(ams2, et22.a(i2, -n2, i3), aov.cB.t());
                }
            }
        }
        n2 = \u2603 - 1;
        if (n2 < 0) {
            n2 = 0;
        } else if (n2 > 1) {
            n2 = 1;
        }
        for (\u2603 = -n2; \u2603 <= n2; ++\u2603) {
            block5: for (\u26032 = -n2; \u26032 <= n2; ++\u26032) {
                et \u26037 = et22.a(\u2603, -1, \u26032);
                int \u26035 = 50;
                if (Math.abs(\u2603) == 1 && Math.abs(\u26032) == 1) {
                    \u26035 = random.nextInt(5);
                }
                while (\u26037.q() > 50) {
                    awr awr2 = ams2.o(\u26037);
                    aou \u26036 = awr2.u();
                    if (awr2.a() != bcx.a && \u26036 != aov.d && \u26036 != aov.aJ && \u26036 != aov.aI && \u26036 != aov.cB) continue block5;
                    this.a(ams2, \u26037, aov.cB.t());
                    \u26037 = \u26037.b();
                    if (--\u26035 > 0) continue;
                    \u26037 = \u26037.c(random.nextInt(5) + 1);
                    \u26035 = random.nextInt(5);
                }
            }
        }
        return true;
    }
}

