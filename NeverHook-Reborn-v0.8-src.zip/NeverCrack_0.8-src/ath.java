/*
 * Decompiled with CFR 0.150.
 */
public enum ath {
    a,
    b,
    c,
    d;

}

