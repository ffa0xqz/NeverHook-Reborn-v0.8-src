/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Maps
 *  com.google.common.collect.Sets
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class cey
implements ceo {
    private static final Logger b = LogManager.getLogger();
    private final cfe c;
    private String d;
    protected static final cez a = new cez();
    private final Map<String, cex> e = Maps.newHashMap();

    public cey(cfe cfe2, String string) {
        this.c = cfe2;
        this.d = string;
        cew.a(a);
    }

    public void a(List<cep> list) {
        this.e.clear();
        for (cep cep2 : list) {
            try {
                cfm cfm2 = (cfm)cep2.a(this.c, "language");
                if (cfm2 == null) continue;
                for (cex cex2 : cfm2.a()) {
                    if (this.e.containsKey(cex2.a())) continue;
                    this.e.put(cex2.a(), cex2);
                }
            }
            catch (RuntimeException runtimeException) {
                b.warn("Unable to parse language metadata section of resourcepack: {}", (Object)cep2.b(), (Object)runtimeException);
            }
            catch (IOException iOException) {
                b.warn("Unable to parse language metadata section of resourcepack: {}", (Object)cep2.b(), (Object)iOException);
            }
        }
    }

    @Override
    public void a(cen cen2) {
        ArrayList arrayList = Lists.newArrayList((Object[])new String[]{"en_us"});
        if (!"en_us".equals(this.d)) {
            arrayList.add(this.d);
        }
        a.a(cen2, arrayList);
        fu.a(cey.a.a);
    }

    public boolean a() {
        return a.a();
    }

    public boolean b() {
        return this.c() != null && this.c().b();
    }

    public void a(cex cex2) {
        this.d = cex2.a();
    }

    public cex c() {
        String string = this.e.containsKey(this.d) ? this.d : "en_us";
        return this.e.get(string);
    }

    public SortedSet<cex> d() {
        return Sets.newTreeSet(this.e.values());
    }

    public cex a(String string) {
        return this.e.get(string);
    }
}

