/*
 * Decompiled with CFR 0.150.
 */
public class agc
extends agp {
    private final aeb a;
    private int b;

    public agc(aeb aeb2, tt tt2, int n2, int n3, int n4) {
        super(tt2, n2, n3, n4);
        this.a = aeb2;
    }

    @Override
    public boolean a(ain ain2) {
        return false;
    }

    @Override
    public ain a(int n2) {
        if (this.e()) {
            this.b += Math.min(n2, this.d().E());
        }
        return super.a(n2);
    }

    @Override
    public ain a(aeb aeb2, ain ain2) {
        this.c(ain2);
        super.a(aeb2, ain2);
        return ain2;
    }

    @Override
    protected void a(ain ain2, int n2) {
        this.b += n2;
        this.c(ain2);
    }

    @Override
    protected void c(ain ain2) {
        ain2.a(this.a.l, this.a, this.b);
        if (!this.a.l.G) {
            int n2 = this.b;
            float \u26032 = akn.a().b(ain2);
            if (\u26032 == 0.0f) {
                n2 = 0;
            } else if (\u26032 < 1.0f) {
                \u2603 = ri.d((float)n2 * \u26032);
                if (\u2603 < ri.f((float)n2 * \u26032) && Math.random() < (double)((float)n2 * \u26032 - (float)\u2603)) {
                    ++\u2603;
                }
                n2 = \u2603;
            }
            while (n2 > 0) {
                \u2603 = vk.a(n2);
                n2 -= \u2603;
                this.a.l.a(new vk(this.a.l, this.a.p, this.a.q + 0.5, this.a.r + 0.5, \u2603));
            }
        }
        this.b = 0;
    }
}

