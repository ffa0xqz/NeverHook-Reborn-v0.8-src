/*
 * Decompiled with CFR 0.150.
 */
public class auc
extends atq {
    public static final axg b = axg.a("rotation", 0, 15);

    public auc() {
        this.w(this.A.b().a(b, 0));
    }

    @Override
    public void a(awr awr2, ams ams2, et et2, aou aou2, et et3) {
        if (!ams2.o(et2.b()).a().a()) {
            this.b(ams2, et2, awr2, 0);
            ams2.g(et2);
        }
        super.a(awr2, ams2, et2, aou2, et3);
    }

    @Override
    public awr a(int n2) {
        return this.t().a(b, n2);
    }

    @Override
    public int e(awr awr2) {
        return awr2.c(b);
    }

    @Override
    public awr a(awr awr2, atk atk2) {
        return awr2.a(b, atk2.a(awr2.c(b), 16));
    }

    @Override
    public awr a(awr awr2, arw arw2) {
        return awr2.a(b, arw2.a(awr2.c(b), 16));
    }

    @Override
    protected aws b() {
        return new aws((aou)this, b);
    }
}

