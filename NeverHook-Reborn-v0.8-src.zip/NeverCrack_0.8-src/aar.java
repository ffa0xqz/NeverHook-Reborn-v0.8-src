/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import javax.annotation.Nullable;

public class aar
extends aal {
    public aar(ams ams2) {
        super(ams2);
    }

    public static void a(rw rw2) {
        aal.b(rw2, aar.class);
    }

    @Override
    @Nullable
    protected nd J() {
        return bfl.I;
    }

    @Override
    protected qc F() {
        super.F();
        return qd.ej;
    }

    @Override
    protected qc cf() {
        super.cf();
        return qd.el;
    }

    @Override
    protected qc d(up up2) {
        super.d(up2);
        return qd.em;
    }

    @Override
    protected void dp() {
        this.a(qd.ek, 1.0f, (this.S.nextFloat() - this.S.nextFloat()) * 0.2f + 1.0f);
    }
}

