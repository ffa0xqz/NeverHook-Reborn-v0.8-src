/*
 * Decompiled with CFR 0.150.
 */
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class gf
extends gn {
    private long[] b;

    gf() {
    }

    public gf(long[] arrl) {
        this.b = arrl;
    }

    public gf(List<Long> list) {
        this(gf.a(list));
    }

    private static long[] a(List<Long> list) {
        long[] arrl = new long[list.size()];
        for (int i2 = 0; i2 < list.size(); ++i2) {
            Long l2 = list.get(i2);
            arrl[i2] = l2 == null ? 0L : l2;
        }
        return arrl;
    }

    @Override
    void a(DataOutput dataOutput) throws IOException {
        dataOutput.writeInt(this.b.length);
        for (long l2 : this.b) {
            dataOutput.writeLong(l2);
        }
    }

    @Override
    void a(DataInput dataInput, int n2, gh gh2) throws IOException {
        gh2.a(192L);
        int n3 = dataInput.readInt();
        gh2.a(64 * n3);
        this.b = new long[n3];
        for (\u2603 = 0; \u2603 < n3; ++\u2603) {
            this.b[\u2603] = dataInput.readLong();
        }
    }

    @Override
    public byte a() {
        return 12;
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder("[L;");
        for (int i2 = 0; i2 < this.b.length; ++i2) {
            if (i2 != 0) {
                stringBuilder.append(',');
            }
            stringBuilder.append(this.b[i2]).append('L');
        }
        return stringBuilder.append(']').toString();
    }

    public gf c() {
        long[] arrl = new long[this.b.length];
        System.arraycopy(this.b, 0, arrl, 0, this.b.length);
        return new gf(arrl);
    }

    @Override
    public boolean equals(Object object) {
        return super.equals(object) && Arrays.equals(this.b, ((gf)object).b);
    }

    @Override
    public int hashCode() {
        return super.hashCode() ^ Arrays.hashCode(this.b);
    }

    @Override
    public /* synthetic */ gn b() {
        return this.c();
    }
}

