/*
 * Decompiled with CFR 0.150.
 */
import java.util.Random;

public abstract class arp
extends aou {
    public static final axd a = axd.a("decayable");
    public static final axd b = axd.a("check_decay");
    protected boolean c;
    int[] d;

    public arp() {
        super(bcx.j);
        this.a(true);
        this.a(ahn.c);
        this.c(0.2f);
        this.e(1);
        this.a(atw.c);
    }

    @Override
    public void b(ams ams2, et et2, awr awr2) {
        boolean bl2 = true;
        int \u26032 = 2;
        int \u26033 = et2.p();
        if (ams2.a(new et(\u26033 - 2, (\u2603 = et2.q()) - 2, (\u2603 = et2.r()) - 2), new et(\u26033 + 2, \u2603 + 2, \u2603 + 2))) {
            for (int i2 = -1; i2 <= 1; ++i2) {
                for (\u2603 = -1; \u2603 <= 1; ++\u2603) {
                    for (\u2603 = -1; \u2603 <= 1; ++\u2603) {
                        et et3 = et2.a(i2, \u2603, \u2603);
                        awr \u26034 = ams2.o(et3);
                        if (\u26034.a() != bcx.j || \u26034.c(b).booleanValue()) continue;
                        ams2.a(et3, \u26034.a(b, true), 4);
                    }
                }
            }
        }
    }

    @Override
    public void b(ams ams2, et et2, awr awr2, Random random) {
        if (ams2.G) {
            return;
        }
        if (awr2.c(b).booleanValue() && awr2.c(a).booleanValue()) {
            int n2;
            int n3 = 4;
            \u2603 = 5;
            \u2603 = et2.p();
            \u2603 = et2.q();
            \u2603 = et2.r();
            \u2603 = 32;
            \u2603 = 1024;
            \u2603 = 16;
            if (this.d == null) {
                this.d = new int[32768];
            }
            if (ams2.a(new et(\u2603 - 5, \u2603 - 5, \u2603 - 5), new et(\u2603 + 5, \u2603 + 5, \u2603 + 5))) {
                int n4;
                et.a a2 = new et.a();
                for (n4 = -4; n4 <= 4; ++n4) {
                    for (\u2603 = -4; \u2603 <= 4; ++\u2603) {
                        for (\u2603 = -4; \u2603 <= 4; ++\u2603) {
                            awr awr3 = ams2.o(a2.c(\u2603 + n4, \u2603 + \u2603, \u2603 + \u2603));
                            aou \u26032 = awr3.u();
                            this.d[(n4 + 16) * 1024 + (\u2603 + 16) * 32 + \u2603 + 16] = \u26032 == aov.r || \u26032 == aov.s ? 0 : (awr3.a() == bcx.j ? -2 : -1);
                        }
                    }
                }
                for (n4 = 1; n4 <= 4; ++n4) {
                    for (\u2603 = -4; \u2603 <= 4; ++\u2603) {
                        for (\u2603 = -4; \u2603 <= 4; ++\u2603) {
                            for (\u2603 = -4; \u2603 <= 4; ++\u2603) {
                                if (this.d[(\u2603 + 16) * 1024 + (\u2603 + 16) * 32 + \u2603 + 16] != n4 - 1) continue;
                                if (this.d[(\u2603 + 16 - 1) * 1024 + (\u2603 + 16) * 32 + \u2603 + 16] == -2) {
                                    this.d[(\u2603 + 16 - 1) * 1024 + (\u2603 + 16) * 32 + \u2603 + 16] = n4;
                                }
                                if (this.d[(\u2603 + 16 + 1) * 1024 + (\u2603 + 16) * 32 + \u2603 + 16] == -2) {
                                    this.d[(\u2603 + 16 + 1) * 1024 + (\u2603 + 16) * 32 + \u2603 + 16] = n4;
                                }
                                if (this.d[(\u2603 + 16) * 1024 + (\u2603 + 16 - 1) * 32 + \u2603 + 16] == -2) {
                                    this.d[(\u2603 + 16) * 1024 + (\u2603 + 16 - 1) * 32 + \u2603 + 16] = n4;
                                }
                                if (this.d[(\u2603 + 16) * 1024 + (\u2603 + 16 + 1) * 32 + \u2603 + 16] == -2) {
                                    this.d[(\u2603 + 16) * 1024 + (\u2603 + 16 + 1) * 32 + \u2603 + 16] = n4;
                                }
                                if (this.d[(\u2603 + 16) * 1024 + (\u2603 + 16) * 32 + (\u2603 + 16 - 1)] == -2) {
                                    this.d[(\u2603 + 16) * 1024 + (\u2603 + 16) * 32 + (\u2603 + 16 - 1)] = n4;
                                }
                                if (this.d[(\u2603 + 16) * 1024 + (\u2603 + 16) * 32 + \u2603 + 16 + 1] != -2) continue;
                                this.d[(\u2603 + 16) * 1024 + (\u2603 + 16) * 32 + \u2603 + 16 + 1] = n4;
                            }
                        }
                    }
                }
            }
            if ((n2 = this.d[16912]) >= 0) {
                ams2.a(et2, awr2.a(b, false), 4);
            } else {
                this.b(ams2, et2);
            }
        }
    }

    @Override
    public void a(awr awr2, ams ams2, et et2, Random random) {
        if (ams2.B(et2.a()) && !ams2.o(et2.b()).q() && random.nextInt(15) == 1) {
            double d2 = (float)et2.p() + random.nextFloat();
            \u2603 = (double)et2.q() - 0.05;
            \u2603 = (float)et2.r() + random.nextFloat();
            ams2.a(fj.s, d2, \u2603, \u2603, 0.0, 0.0, 0.0, new int[0]);
        }
    }

    private void b(ams ams2, et et2) {
        this.b(ams2, et2, ams2.o(et2), 0);
        ams2.g(et2);
    }

    @Override
    public int a(Random random) {
        return random.nextInt(20) == 0 ? 1 : 0;
    }

    @Override
    public ail a(awr awr2, Random random, int n2) {
        return ail.a(aov.g);
    }

    @Override
    public void a(ams ams2, et et2, awr awr2, float f2, int n2) {
        if (!ams2.G) {
            n3 = this.x(awr2);
            if (n2 > 0 && (n3 -= 2 << n2) < 10) {
                n3 = 10;
            }
            if (ams2.r.nextInt(n3) == 0) {
                ail ail2 = this.a(awr2, ams2.r, n2);
                arp.a(ams2, et2, new ain(ail2, 1, this.d(awr2)));
            }
            int n3 = 200;
            if (n2 > 0 && (n3 -= 10 << n2) < 40) {
                n3 = 40;
            }
            this.a(ams2, et2, awr2, n3);
        }
    }

    protected void a(ams ams2, et et2, awr awr2, int n2) {
    }

    protected int x(awr awr2) {
        return 20;
    }

    @Override
    public boolean b(awr awr2) {
        return !this.c;
    }

    public void b(boolean bl2) {
        this.c = bl2;
    }

    @Override
    public amk f() {
        return this.c ? amk.b : amk.a;
    }

    @Override
    public boolean t(awr awr2) {
        return false;
    }

    public abstract asp.a b(int var1);

    @Override
    public boolean a(awr awr2, amw amw2, et et2, fa fa2) {
        if (!this.c && amw2.o(et2.a(fa2)).u() == this) {
            return false;
        }
        return super.a(awr2, amw2, et2, fa2);
    }
}

