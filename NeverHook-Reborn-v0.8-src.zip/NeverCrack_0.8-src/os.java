/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 *  com.google.common.collect.AbstractIterator
 *  com.google.common.collect.ComparisonChain
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Sets
 *  it.unimi.dsi.fastutil.longs.Long2ObjectMap
 *  it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap
 *  javax.annotation.Nullable
 */
import com.google.common.base.Predicate;
import com.google.common.collect.AbstractIterator;
import com.google.common.collect.ComparisonChain;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.annotation.Nullable;

public class os {
    private static final Predicate<oo> a = new Predicate<oo>(){

        public boolean a(@Nullable oo oo2) {
            return oo2 != null && !oo2.y();
        }

        public /* synthetic */ boolean apply(@Nullable Object object) {
            return this.a((oo)object);
        }
    };
    private static final Predicate<oo> b = new Predicate<oo>(){

        public boolean a(@Nullable oo oo2) {
            return oo2 != null && (!oo2.y() || oo2.x().W().b("spectatorsGenerateChunks"));
        }

        public /* synthetic */ boolean apply(@Nullable Object object) {
            return this.a((oo)object);
        }
    };
    private final om c;
    private final List<oo> d = Lists.newArrayList();
    private final Long2ObjectMap<or> e = new Long2ObjectOpenHashMap(4096);
    private final Set<or> f = Sets.newHashSet();
    private final List<or> g = Lists.newLinkedList();
    private final List<or> h = Lists.newLinkedList();
    private final List<or> i = Lists.newArrayList();
    private int j;
    private long k;
    private boolean l = true;
    private boolean m = true;

    public os(om om2) {
        this.c = om2;
        this.a(om2.u().am().s());
    }

    public om a() {
        return this.c;
    }

    public Iterator<axu> b() {
        final Iterator<or> iterator = this.i.iterator();
        return new AbstractIterator<axu>(){

            protected axu a() {
                while (iterator.hasNext()) {
                    or or2 = (or)iterator.next();
                    axu \u26032 = or2.f();
                    if (\u26032 == null) continue;
                    if (!\u26032.v() && \u26032.u()) {
                        return \u26032;
                    }
                    if (!\u26032.j()) {
                        return \u26032;
                    }
                    if (!or2.a(128.0, (Predicate<oo>)a)) continue;
                    return \u26032;
                }
                return (axu)this.endOfData();
            }

            protected /* synthetic */ Object computeNext() {
                return this.a();
            }
        };
    }

    public void c() {
        ayk ayk2;
        long l2 = this.c.R();
        if (l2 - this.k > 8000L) {
            this.k = l2;
            for (int n2 = 0; n2 < this.i.size(); ++n2) {
                or or2 = this.i.get(n2);
                or2.d();
                or2.c();
            }
        }
        if (!this.f.isEmpty()) {
            for (or or3 : this.f) {
                or3.d();
            }
            this.f.clear();
        }
        if (this.l && l2 % 4L == 0L) {
            this.l = false;
            Collections.sort(this.h, new Comparator<or>(){

                public int a(or or2, or or3) {
                    return ComparisonChain.start().compare(or2.g(), or3.g()).result();
                }

                @Override
                public /* synthetic */ int compare(Object object, Object object2) {
                    return this.a((or)object, (or)object2);
                }
            });
        }
        if (this.m && l2 % 4L == 2L) {
            this.m = false;
            Collections.sort(this.g, new Comparator<or>(){

                public int a(or or2, or or3) {
                    return ComparisonChain.start().compare(or2.g(), or3.g()).result();
                }

                @Override
                public /* synthetic */ int compare(Object object, Object object2) {
                    return this.a((or)object, (or)object2);
                }
            });
        }
        if (!this.h.isEmpty()) {
            long l3 = System.nanoTime() + 50000000L;
            int n3 = 49;
            Iterator<or> \u26032 = this.h.iterator();
            while (\u26032.hasNext()) {
                or or2 = \u26032.next();
                if (or2.f() != null || !or2.a(\u2603 = or2.a(b))) continue;
                \u26032.remove();
                if (or2.b()) {
                    this.g.remove(or2);
                }
                if (--n3 >= 0 && System.nanoTime() <= l3) continue;
                break;
            }
        }
        if (!this.g.isEmpty()) {
            int n2 = 81;
            Iterator<or> iterator = this.g.iterator();
            while (iterator.hasNext()) {
                or or3 = iterator.next();
                if (!or3.b()) continue;
                iterator.remove();
                if (--n2 >= 0) continue;
                break;
            }
        }
        if (this.d.isEmpty() && !(ayk2 = this.c.s).e()) {
            this.c.r().b();
        }
    }

    public boolean a(int n2, int n3) {
        long l2 = os.d(n2, n3);
        return this.e.get(l2) != null;
    }

    @Nullable
    public or b(int n2, int n3) {
        return (or)this.e.get(os.d(n2, n3));
    }

    private or c(int n2, int n3) {
        long l2 = os.d(n2, n3);
        or \u26032 = (or)this.e.get(l2);
        if (\u26032 == null) {
            \u26032 = new or(this, n2, n3);
            this.e.put(l2, (Object)\u26032);
            this.i.add(\u26032);
            if (\u26032.f() == null) {
                this.h.add(\u26032);
            }
            if (!\u26032.b()) {
                this.g.add(\u26032);
            }
        }
        return \u26032;
    }

    public void a(et et2) {
        int n2 = et2.p() >> 4;
        or \u26032 = this.b(n2, \u2603 = et2.r() >> 4);
        if (\u26032 != null) {
            \u26032.a(et2.p() & 0xF, et2.q(), et2.r() & 0xF);
        }
    }

    public void a(oo oo2) {
        int n2 = (int)oo2.p >> 4;
        \u2603 = (int)oo2.r >> 4;
        oo2.d = oo2.p;
        oo2.e = oo2.r;
        for (\u2603 = n2 - this.j; \u2603 <= n2 + this.j; ++\u2603) {
            for (\u2603 = \u2603 - this.j; \u2603 <= \u2603 + this.j; ++\u2603) {
                this.c(\u2603, \u2603).a(oo2);
            }
        }
        this.d.add(oo2);
        this.e();
    }

    public void b(oo oo22) {
        oo oo22;
        int n2 = (int)oo22.d >> 4;
        \u2603 = (int)oo22.e >> 4;
        for (\u2603 = n2 - this.j; \u2603 <= n2 + this.j; ++\u2603) {
            for (\u2603 = \u2603 - this.j; \u2603 <= \u2603 + this.j; ++\u2603) {
                or or2 = this.b(\u2603, \u2603);
                if (or2 == null) continue;
                or2.b(oo22);
            }
        }
        this.d.remove(oo22);
        this.e();
    }

    private boolean a(int n2, int n3, int n4, int n5, int n6) {
        \u2603 = n2 - n4;
        \u2603 = n3 - n5;
        if (\u2603 < -n6 || \u2603 > n6) {
            return false;
        }
        return \u2603 >= -n6 && \u2603 <= n6;
    }

    public void c(oo oo2) {
        int n2 = (int)oo2.p >> 4;
        \u2603 = (int)oo2.r >> 4;
        double \u26032 = oo2.d - oo2.p;
        double \u26033 = oo2.e - oo2.r;
        double \u26034 = \u26032 * \u26032 + \u26033 * \u26033;
        if (\u26034 < 64.0) {
            return;
        }
        \u2603 = (int)oo2.d >> 4;
        \u2603 = (int)oo2.e >> 4;
        \u2603 = this.j;
        \u2603 = n2 - \u2603;
        \u2603 = \u2603 - \u2603;
        if (\u2603 == 0 && \u2603 == 0) {
            return;
        }
        for (\u2603 = n2 - \u2603; \u2603 <= n2 + \u2603; ++\u2603) {
            for (\u2603 = \u2603 - \u2603; \u2603 <= \u2603 + \u2603; ++\u2603) {
                if (!this.a(\u2603, \u2603, \u2603, \u2603, \u2603)) {
                    this.c(\u2603, \u2603).a(oo2);
                }
                if (this.a(\u2603 - \u2603, \u2603 - \u2603, n2, \u2603, \u2603) || (\u2603 = this.b(\u2603 - \u2603, \u2603 - \u2603)) == null) continue;
                \u2603.b(oo2);
            }
        }
        oo2.d = oo2.p;
        oo2.e = oo2.r;
        this.e();
    }

    public boolean a(oo oo2, int n2, int n3) {
        or or2 = this.b(n2, n3);
        return or2 != null && or2.d(oo2) && or2.e();
    }

    public void a(int n22) {
        int n22;
        if ((n22 = ri.a(n22, 3, 32)) == this.j) {
            return;
        }
        \u2603 = n22 - this.j;
        ArrayList arrayList = Lists.newArrayList(this.d);
        for (oo oo2 : arrayList) {
            int n3 = (int)oo2.p >> 4;
            \u2603 = (int)oo2.r >> 4;
            if (\u2603 > 0) {
                for (i2 = n3 - n22; i2 <= n3 + n22; ++i2) {
                    for (\u2603 = \u2603 - n22; \u2603 <= \u2603 + n22; ++\u2603) {
                        or or2 = this.c(i2, \u2603);
                        if (or2.d(oo2)) continue;
                        or2.a(oo2);
                    }
                }
                continue;
            }
            for (int i2 = n3 - this.j; i2 <= n3 + this.j; ++i2) {
                for (\u2603 = \u2603 - this.j; \u2603 <= \u2603 + this.j; ++\u2603) {
                    if (this.a(i2, \u2603, n3, \u2603, n22)) continue;
                    this.c(i2, \u2603).b(oo2);
                }
            }
        }
        this.j = n22;
        this.e();
    }

    private void e() {
        this.l = true;
        this.m = true;
    }

    public static int b(int n2) {
        return n2 * 16 - 16;
    }

    private static long d(int n2, int n3) {
        return (long)n2 + Integer.MAX_VALUE | (long)n3 + Integer.MAX_VALUE << 32;
    }

    public void a(or or2) {
        this.f.add(or2);
    }

    public void b(or or2) {
        aml aml2 = or2.a();
        long \u26032 = os.d(aml2.a, aml2.b);
        or2.c();
        this.e.remove(\u26032);
        this.i.remove(or2);
        this.f.remove(or2);
        this.g.remove(or2);
        this.h.remove(or2);
        axu \u26033 = or2.f();
        if (\u26033 != null) {
            this.a().r().a(\u26033);
        }
    }
}

