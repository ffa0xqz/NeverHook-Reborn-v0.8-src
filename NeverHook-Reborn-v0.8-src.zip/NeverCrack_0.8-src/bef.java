/*
 * Decompiled with CFR 0.150.
 */
public enum bef {
    a(-1.0f),
    b(0.0f),
    c(0.0f),
    d(0.0f),
    e(-1.0f),
    f(-1.0f),
    g(8.0f),
    h(0.0f),
    i(8.0f),
    j(16.0f),
    k(8.0f),
    l(-1.0f),
    m(8.0f),
    n(-1.0f),
    o(0.0f),
    p(-1.0f),
    q(-1.0f);

    private final float r;

    private bef(float f2) {
        this.r = f2;
    }

    public float a() {
        return this.r;
    }
}

