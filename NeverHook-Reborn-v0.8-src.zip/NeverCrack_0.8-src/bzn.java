/*
 * Decompiled with CFR 0.150.
 */
public class bzn
extends cad<acy> {
    private static final nd a = new nd("textures/entity/guardian.png");
    private static final nd j = new nd("textures/entity/guardian_beam.png");

    public bzn(bzd bzd2) {
        super(bzd2, new bps(), 0.5f);
    }

    @Override
    public boolean a(acy acy2, bxw bxw2, double d2, double d3, double d4) {
        if (super.a(acy2, bxw2, d2, d3, d4)) {
            return true;
        }
        if (acy2.dp() && (\u2603 = acy2.dq()) != null) {
            bhc bhc2 = this.a(\u2603, (double)\u2603.H * 0.5, 1.0f);
            \u2603 = this.a(acy2, (double)acy2.by(), 1.0f);
            if (bxw2.a(new bgz(\u2603.b, \u2603.c, \u2603.d, bhc2.b, bhc2.c, bhc2.d))) {
                return true;
            }
        }
        return false;
    }

    private bhc a(vn vn2, double d2, float f2) {
        double d3 = vn2.M + (vn2.p - vn2.M) * (double)f2;
        \u2603 = d2 + vn2.N + (vn2.q - vn2.N) * (double)f2;
        \u2603 = vn2.O + (vn2.r - vn2.O) * (double)f2;
        return new bhc(d3, \u2603, \u2603);
    }

    @Override
    public void a(acy acy2, double d2, double d3, double d4, float f2, float f3) {
        super.a(acy2, d2, d3, d4, f2, f3);
        vn vn2 = acy2.dq();
        if (vn2 != null) {
            float f4 = acy2.s(f3);
            bvc \u26032 = bvc.a();
            bui \u26033 = \u26032.c();
            this.a(j);
            buq.b(3553, 10242, 10497);
            buq.b(3553, 10243, 10497);
            buq.g();
            buq.r();
            buq.l();
            buq.a(true);
            \u2603 = 240.0f;
            cig.a(cig.r, 240.0f, 240.0f);
            buq.a(buq.r.l, buq.l.e, buq.r.e, buq.l.n);
            \u2603 = (float)acy2.l.R() + f3;
            \u2603 = \u2603 * 0.5f % 1.0f;
            \u2603 = acy2.by();
            buq.G();
            buq.c((float)d2, (float)d3 + \u2603, (float)d4);
            bhc \u26034 = this.a(vn2, (double)vn2.H * 0.5, f3);
            bhc \u26035 = this.a(acy2, (double)\u2603, f3);
            bhc \u26036 = \u26034.d(\u26035);
            double \u26037 = \u26036.b() + 1.0;
            \u26036 = \u26036.a();
            \u2603 = (float)Math.acos(\u26036.c);
            \u2603 = (float)Math.atan2(\u26036.d, \u26036.b);
            buq.b((1.5707964f + -\u2603) * 57.295776f, 0.0f, 1.0f, 0.0f);
            buq.b(\u2603 * 57.295776f, 1.0f, 0.0f, 0.0f);
            boolean \u26038 = true;
            double \u26039 = (double)\u2603 * 0.05 * -1.5;
            \u26033.a(7, cdw.i);
            \u2603 = f4 * f4;
            int \u260310 = 64 + (int)(\u2603 * 191.0f);
            int \u260311 = 32 + (int)(\u2603 * 191.0f);
            int \u260312 = 128 - (int)(\u2603 * 64.0f);
            double \u260313 = 0.2;
            double \u260314 = 0.282;
            double \u260315 = 0.0 + Math.cos(\u26039 + 2.356194490192345) * 0.282;
            double \u260316 = 0.0 + Math.sin(\u26039 + 2.356194490192345) * 0.282;
            double \u260317 = 0.0 + Math.cos(\u26039 + 0.7853981633974483) * 0.282;
            double \u260318 = 0.0 + Math.sin(\u26039 + 0.7853981633974483) * 0.282;
            double \u260319 = 0.0 + Math.cos(\u26039 + 3.9269908169872414) * 0.282;
            double \u260320 = 0.0 + Math.sin(\u26039 + 3.9269908169872414) * 0.282;
            double \u260321 = 0.0 + Math.cos(\u26039 + 5.497787143782138) * 0.282;
            double \u260322 = 0.0 + Math.sin(\u26039 + 5.497787143782138) * 0.282;
            double \u260323 = 0.0 + Math.cos(\u26039 + Math.PI) * 0.2;
            double \u260324 = 0.0 + Math.sin(\u26039 + Math.PI) * 0.2;
            double \u260325 = 0.0 + Math.cos(\u26039 + 0.0) * 0.2;
            double \u260326 = 0.0 + Math.sin(\u26039 + 0.0) * 0.2;
            double \u260327 = 0.0 + Math.cos(\u26039 + 1.5707963267948966) * 0.2;
            double \u260328 = 0.0 + Math.sin(\u26039 + 1.5707963267948966) * 0.2;
            double \u260329 = 0.0 + Math.cos(\u26039 + 4.71238898038469) * 0.2;
            double \u260330 = 0.0 + Math.sin(\u26039 + 4.71238898038469) * 0.2;
            double \u260331 = \u26037;
            double \u260332 = 0.0;
            double \u260333 = 0.4999;
            double \u260334 = -1.0f + \u2603;
            double \u260335 = \u26037 * 2.5 + \u260334;
            \u26033.b(\u260323, \u260331, \u260324).a(0.4999, \u260335).b(\u260310, \u260311, \u260312, 255).d();
            \u26033.b(\u260323, 0.0, \u260324).a(0.4999, \u260334).b(\u260310, \u260311, \u260312, 255).d();
            \u26033.b(\u260325, 0.0, \u260326).a(0.0, \u260334).b(\u260310, \u260311, \u260312, 255).d();
            \u26033.b(\u260325, \u260331, \u260326).a(0.0, \u260335).b(\u260310, \u260311, \u260312, 255).d();
            \u26033.b(\u260327, \u260331, \u260328).a(0.4999, \u260335).b(\u260310, \u260311, \u260312, 255).d();
            \u26033.b(\u260327, 0.0, \u260328).a(0.4999, \u260334).b(\u260310, \u260311, \u260312, 255).d();
            \u26033.b(\u260329, 0.0, \u260330).a(0.0, \u260334).b(\u260310, \u260311, \u260312, 255).d();
            \u26033.b(\u260329, \u260331, \u260330).a(0.0, \u260335).b(\u260310, \u260311, \u260312, 255).d();
            double \u260336 = 0.0;
            if (acy2.T % 2 == 0) {
                \u260336 = 0.5;
            }
            \u26033.b(\u260315, \u260331, \u260316).a(0.5, \u260336 + 0.5).b(\u260310, \u260311, \u260312, 255).d();
            \u26033.b(\u260317, \u260331, \u260318).a(1.0, \u260336 + 0.5).b(\u260310, \u260311, \u260312, 255).d();
            \u26033.b(\u260321, \u260331, \u260322).a(1.0, \u260336).b(\u260310, \u260311, \u260312, 255).d();
            \u26033.b(\u260319, \u260331, \u260320).a(0.5, \u260336).b(\u260310, \u260311, \u260312, 255).d();
            \u26032.b();
            buq.H();
        }
    }

    @Override
    protected nd a(acy acy2) {
        return a;
    }
}

