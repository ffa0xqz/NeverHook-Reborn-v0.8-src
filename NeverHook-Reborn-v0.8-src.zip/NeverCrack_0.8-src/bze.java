/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import javax.annotation.Nullable;
import net.optifine.entity.model.IEntityRenderer;
import optifine.Config;
import shadersmod.client.Shaders;

public abstract class bze<T extends ve>
implements IEntityRenderer {
    private static final nd a = new nd("textures/misc/shadow.png");
    protected final bzd b;
    public float c;
    protected float d = 1.0f;
    protected boolean e;
    private Class entityClass = null;
    private nd locationTextureCustom = null;

    protected bze(bzd renderManager) {
        this.b = renderManager;
    }

    public void a(boolean renderOutlinesIn) {
        this.e = renderOutlinesIn;
    }

    public boolean a(T livingEntity, bxw camera, double camX, double camY, double camZ) {
        bgz axisalignedbb = ((ve)livingEntity).bx().g(0.5);
        if (axisalignedbb.b() || axisalignedbb.a() == 0.0) {
            axisalignedbb = new bgz(((ve)livingEntity).p - 2.0, ((ve)livingEntity).q - 2.0, ((ve)livingEntity).r - 2.0, ((ve)livingEntity).p + 2.0, ((ve)livingEntity).q + 2.0, ((ve)livingEntity).r + 2.0);
        }
        return ((ve)livingEntity).g(camX, camY, camZ) && (((ve)livingEntity).ah || camera.a(axisalignedbb));
    }

    public void a(T entity, double x2, double y2, double z2, float entityYaw, float partialTicks) {
        if (!this.e) {
            this.a(entity, x2, y2, z2);
        }
    }

    protected int c(T entityIn) {
        String s2;
        int i2 = 0xFFFFFF;
        bhf scoreplayerteam = (bhf)((ve)entityIn).aY();
        if (scoreplayerteam != null && (s2 = bin.b(scoreplayerteam.e())).length() >= 2) {
            i2 = this.d().b(s2.charAt(1));
        }
        return i2;
    }

    protected void a(T entity, double x2, double y2, double z2) {
        if (this.b(entity)) {
            this.a(entity, ((ve)entity).i_().d(), x2, y2, z2, 64);
        }
    }

    protected boolean b(T entity) {
        return ((ve)entity).bs() && ((ve)entity).n_();
    }

    protected void a(T entityIn, double x2, double y2, double z2, String name, double distanceSq) {
        this.a(entityIn, name, x2, y2, z2, 64);
    }

    @Nullable
    protected abstract nd a(T var1);

    protected boolean d(T entity) {
        nd resourcelocation = this.a(entity);
        if (this.locationTextureCustom != null) {
            resourcelocation = this.locationTextureCustom;
        }
        if (resourcelocation == null) {
            return false;
        }
        this.a(resourcelocation);
        return true;
    }

    public void a(nd location) {
        this.b.a.a(location);
    }

    private void a(ve entity, double x2, double y2, double z2, float partialTicks) {
        buq.g();
        cdn texturemap = bhz.z().R();
        cdo textureatlassprite = texturemap.a("minecraft:blocks/fire_layer_0");
        cdo textureatlassprite1 = texturemap.a("minecraft:blocks/fire_layer_1");
        buq.G();
        buq.c((float)x2, (float)y2, (float)z2);
        float f2 = entity.G * 1.4f;
        buq.b(f2, f2, f2);
        bvc tessellator = bvc.a();
        bui bufferbuilder = tessellator.c();
        float f1 = 0.5f;
        float f22 = 0.0f;
        float f3 = entity.H / f2;
        float f4 = (float)(entity.q - entity.bw().b);
        buq.b(-bzd.e, 0.0f, 1.0f, 0.0f);
        buq.c(0.0f, 0.0f, -0.3f + (float)((int)f3) * 0.02f);
        buq.c(1.0f, 1.0f, 1.0f, 1.0f);
        float f5 = 0.0f;
        int i2 = 0;
        bufferbuilder.a(7, cdw.g);
        while (f3 > 0.0f) {
            cdo textureatlassprite2 = i2 % 2 == 0 ? textureatlassprite : textureatlassprite1;
            this.a(cdn.g);
            float f6 = textureatlassprite2.e();
            float f7 = textureatlassprite2.g();
            float f8 = textureatlassprite2.f();
            float f9 = textureatlassprite2.h();
            if (i2 / 2 % 2 == 0) {
                float f10 = f8;
                f8 = f6;
                f6 = f10;
            }
            bufferbuilder.b((double)(f1 - 0.0f), (double)(0.0f - f4), (double)f5).a(f8, f9).d();
            bufferbuilder.b((double)(-f1 - 0.0f), (double)(0.0f - f4), (double)f5).a(f6, f9).d();
            bufferbuilder.b((double)(-f1 - 0.0f), (double)(1.4f - f4), (double)f5).a(f6, f7).d();
            bufferbuilder.b((double)(f1 - 0.0f), (double)(1.4f - f4), (double)f5).a(f8, f7).d();
            f3 -= 0.45f;
            f4 -= 0.45f;
            f1 *= 0.9f;
            f5 += 0.03f;
            ++i2;
        }
        tessellator.b();
        buq.H();
        buq.f();
    }

    private void d(ve entityIn, double x2, double y2, double z2, float shadowAlpha, float partialTicks) {
        if (!Config.isShaders() || !Shaders.shouldSkipDefaultShadow) {
            buq.m();
            buq.a(buq.r.l, buq.l.j);
            this.b.a.a(a);
            ams world = this.b();
            buq.a(false);
            float f2 = this.c;
            if (entityIn instanceof vo) {
                vo entityliving = (vo)entityIn;
                f2 *= entityliving.R();
                if (entityliving.l_()) {
                    f2 *= 0.5f;
                }
            }
            double d5 = entityIn.M + (entityIn.p - entityIn.M) * (double)partialTicks;
            double d0 = entityIn.N + (entityIn.q - entityIn.N) * (double)partialTicks;
            double d1 = entityIn.O + (entityIn.r - entityIn.O) * (double)partialTicks;
            int i2 = ri.c(d5 - (double)f2);
            int j2 = ri.c(d5 + (double)f2);
            int k2 = ri.c(d0 - (double)f2);
            int l2 = ri.c(d0);
            int i1 = ri.c(d1 - (double)f2);
            int j1 = ri.c(d1 + (double)f2);
            double d2 = x2 - d5;
            double d3 = y2 - d0;
            double d4 = z2 - d1;
            bvc tessellator = bvc.a();
            bui bufferbuilder = tessellator.c();
            bufferbuilder.a(7, cdw.i);
            for (et et2 : et.b(new et(i2, k2, i1), new et(j2, l2, j1))) {
                awr iblockstate = world.o(et2.b());
                if (iblockstate.i() == ath.a || world.k(et2) <= 3) continue;
                this.a(iblockstate, x2, y2, z2, et2, shadowAlpha, f2, d2, d3, d4);
            }
            tessellator.b();
            buq.c(1.0f, 1.0f, 1.0f, 1.0f);
            buq.l();
            buq.a(true);
        }
    }

    private ams b() {
        return this.b.b;
    }

    private void a(awr state, double p_188299_2_, double p_188299_4_, double p_188299_6_, et p_188299_8_, float p_188299_9_, float p_188299_10_, double p_188299_11_, double p_188299_13_, double p_188299_15_) {
        if (state.g()) {
            bvc tessellator = bvc.a();
            bui bufferbuilder = tessellator.c();
            double d0 = ((double)p_188299_9_ - (p_188299_4_ - ((double)p_188299_8_.q() + p_188299_13_)) / 2.0) * 0.5 * (double)this.b().n(p_188299_8_);
            if (d0 >= 0.0) {
                if (d0 > 1.0) {
                    d0 = 1.0;
                }
                bgz axisalignedbb = state.e(this.b(), p_188299_8_);
                double d1 = (double)p_188299_8_.p() + axisalignedbb.a + p_188299_11_;
                double d2 = (double)p_188299_8_.p() + axisalignedbb.d + p_188299_11_;
                double d3 = (double)p_188299_8_.q() + axisalignedbb.b + p_188299_13_ + 0.015625;
                double d4 = (double)p_188299_8_.r() + axisalignedbb.c + p_188299_15_;
                double d5 = (double)p_188299_8_.r() + axisalignedbb.f + p_188299_15_;
                float f2 = (float)((p_188299_2_ - d1) / 2.0 / (double)p_188299_10_ + 0.5);
                float f1 = (float)((p_188299_2_ - d2) / 2.0 / (double)p_188299_10_ + 0.5);
                float f22 = (float)((p_188299_6_ - d4) / 2.0 / (double)p_188299_10_ + 0.5);
                float f3 = (float)((p_188299_6_ - d5) / 2.0 / (double)p_188299_10_ + 0.5);
                bufferbuilder.b(d1, d3, d4).a(f2, f22).a(1.0f, 1.0f, 1.0f, (float)d0).d();
                bufferbuilder.b(d1, d3, d5).a(f2, f3).a(1.0f, 1.0f, 1.0f, (float)d0).d();
                bufferbuilder.b(d2, d3, d5).a(f1, f3).a(1.0f, 1.0f, 1.0f, (float)d0).d();
                bufferbuilder.b(d2, d3, d4).a(f1, f22).a(1.0f, 1.0f, 1.0f, (float)d0).d();
            }
        }
    }

    public static void a(bgz boundingBox, double x2, double y2, double z2) {
        buq.z();
        bvc tessellator = bvc.a();
        bui bufferbuilder = tessellator.c();
        buq.c(1.0f, 1.0f, 1.0f, 1.0f);
        bufferbuilder.c(x2, y2, z2);
        bufferbuilder.a(7, cdw.h);
        bufferbuilder.b(boundingBox.a, boundingBox.e, boundingBox.c).c(0.0f, 0.0f, -1.0f).d();
        bufferbuilder.b(boundingBox.d, boundingBox.e, boundingBox.c).c(0.0f, 0.0f, -1.0f).d();
        bufferbuilder.b(boundingBox.d, boundingBox.b, boundingBox.c).c(0.0f, 0.0f, -1.0f).d();
        bufferbuilder.b(boundingBox.a, boundingBox.b, boundingBox.c).c(0.0f, 0.0f, -1.0f).d();
        bufferbuilder.b(boundingBox.a, boundingBox.b, boundingBox.f).c(0.0f, 0.0f, 1.0f).d();
        bufferbuilder.b(boundingBox.d, boundingBox.b, boundingBox.f).c(0.0f, 0.0f, 1.0f).d();
        bufferbuilder.b(boundingBox.d, boundingBox.e, boundingBox.f).c(0.0f, 0.0f, 1.0f).d();
        bufferbuilder.b(boundingBox.a, boundingBox.e, boundingBox.f).c(0.0f, 0.0f, 1.0f).d();
        bufferbuilder.b(boundingBox.a, boundingBox.b, boundingBox.c).c(0.0f, -1.0f, 0.0f).d();
        bufferbuilder.b(boundingBox.d, boundingBox.b, boundingBox.c).c(0.0f, -1.0f, 0.0f).d();
        bufferbuilder.b(boundingBox.d, boundingBox.b, boundingBox.f).c(0.0f, -1.0f, 0.0f).d();
        bufferbuilder.b(boundingBox.a, boundingBox.b, boundingBox.f).c(0.0f, -1.0f, 0.0f).d();
        bufferbuilder.b(boundingBox.a, boundingBox.e, boundingBox.f).c(0.0f, 1.0f, 0.0f).d();
        bufferbuilder.b(boundingBox.d, boundingBox.e, boundingBox.f).c(0.0f, 1.0f, 0.0f).d();
        bufferbuilder.b(boundingBox.d, boundingBox.e, boundingBox.c).c(0.0f, 1.0f, 0.0f).d();
        bufferbuilder.b(boundingBox.a, boundingBox.e, boundingBox.c).c(0.0f, 1.0f, 0.0f).d();
        bufferbuilder.b(boundingBox.a, boundingBox.b, boundingBox.f).c(-1.0f, 0.0f, 0.0f).d();
        bufferbuilder.b(boundingBox.a, boundingBox.e, boundingBox.f).c(-1.0f, 0.0f, 0.0f).d();
        bufferbuilder.b(boundingBox.a, boundingBox.e, boundingBox.c).c(-1.0f, 0.0f, 0.0f).d();
        bufferbuilder.b(boundingBox.a, boundingBox.b, boundingBox.c).c(-1.0f, 0.0f, 0.0f).d();
        bufferbuilder.b(boundingBox.d, boundingBox.b, boundingBox.c).c(1.0f, 0.0f, 0.0f).d();
        bufferbuilder.b(boundingBox.d, boundingBox.e, boundingBox.c).c(1.0f, 0.0f, 0.0f).d();
        bufferbuilder.b(boundingBox.d, boundingBox.e, boundingBox.f).c(1.0f, 0.0f, 0.0f).d();
        bufferbuilder.b(boundingBox.d, boundingBox.b, boundingBox.f).c(1.0f, 0.0f, 0.0f).d();
        tessellator.b();
        bufferbuilder.c(0.0, 0.0, 0.0);
        buq.y();
    }

    public void c(ve entityIn, double x2, double y2, double z2, float yaw, float partialTicks) {
        if (this.b.g != null) {
            double d0;
            float f2;
            if (this.b.g.M && this.c > 0.0f && !entityIn.aX() && this.b.a() && (f2 = (float)((1.0 - (d0 = this.b.b(entityIn.p, entityIn.q, entityIn.r)) / 256.0) * (double)this.d)) > 0.0f) {
                this.d(entityIn, x2, y2, z2, f2, partialTicks);
            }
            if (!(!entityIn.bl() || entityIn instanceof aeb && ((aeb)entityIn).y())) {
                this.a(entityIn, x2, y2, z2, partialTicks);
            }
        }
    }

    public bin d() {
        return this.b.c();
    }

    protected void a(T entityIn, String str, double x2, double y2, double z2, int maxDistance) {
        double d0 = ((ve)entityIn).h(this.b.c);
        if (d0 <= (double)(maxDistance * maxDistance)) {
            boolean flag = ((ve)entityIn).aU();
            float f2 = bzd.e;
            float f1 = bzd.f;
            boolean flag1 = this.b.g.aw == 2;
            float f22 = ((ve)entityIn).H + 0.5f - (flag ? 0.25f : 0.0f);
            int i2 = "deadmau5".equals(str) ? -10 : 0;
            buo.a(this.d(), str, (float)x2, (float)y2 + f22, (float)z2, i2, f2, f1, flag1, flag);
        }
    }

    public bzd e() {
        return this.b;
    }

    public boolean L_() {
        return false;
    }

    public void b(T p_188300_1_, double p_188300_2_, double p_188300_4_, double p_188300_6_, float p_188300_8_, float p_188300_9_) {
    }

    @Override
    public Class getEntityClass() {
        return this.entityClass;
    }

    @Override
    public void setEntityClass(Class p_setEntityClass_1_) {
        this.entityClass = p_setEntityClass_1_;
    }

    @Override
    public nd getLocationTextureCustom() {
        return this.locationTextureCustom;
    }

    @Override
    public void setLocationTextureCustom(nd p_setLocationTextureCustom_1_) {
        this.locationTextureCustom = p_setLocationTextureCustom_1_;
    }
}

