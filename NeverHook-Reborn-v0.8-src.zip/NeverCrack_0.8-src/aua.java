/*
 * Decompiled with CFR 0.150.
 */
public class aua
extends apl {
    private static final bcy[] b = new bcy[]{bcy.M, bcy.N, bcy.O, bcy.P, bcy.Q, bcy.R, bcy.S, bcy.T, bcy.U, bcy.V, bcy.W, bcy.X, bcy.Y, bcy.Z, bcy.aa, bcy.ab};

    public aua() {
        super(bcx.e);
    }

    @Override
    public bcy c(awr awr2, amw amw2, et et2) {
        return b[((ahq)awr2.c(a)).a()];
    }
}

