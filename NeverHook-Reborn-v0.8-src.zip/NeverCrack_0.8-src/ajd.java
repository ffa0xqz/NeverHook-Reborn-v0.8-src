/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 *  javax.annotation.Nullable
 */
import com.google.common.collect.Maps;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;

public class ajd
extends ail {
    private static final Map<qc, ajd> a = Maps.newHashMap();
    private final qc b;
    private final String c;

    protected ajd(String string, qc qc2) {
        this.c = "item.record." + string + ".desc";
        this.b = qc2;
        this.k = 1;
        this.b(ahn.f);
        a.put(this.b, this);
    }

    @Override
    public ub a(aeb aeb2, ams ams2, et et2, tz tz2, fa fa2, float f2, float f3, float f4) {
        awr awr2 = ams2.o(et2);
        if (awr2.u() != aov.aN || awr2.c(arn.a).booleanValue()) {
            return ub.b;
        }
        if (!ams2.G) {
            ain ain2 = aeb2.b(tz2);
            ((arn)aov.aN).a(ams2, et2, awr2, ain2);
            ams2.a(null, 1010, et2, ail.a(this));
            ain2.g(1);
            aeb2.b(qq.X);
        }
        return ub.a;
    }

    @Override
    public void a(ain ain2, @Nullable ams ams2, List<String> list, ajz ajz2) {
        list.add(this.g());
    }

    public String g() {
        return ft.a(this.c);
    }

    @Override
    public ajc g(ain ain2) {
        return ajc.c;
    }

    @Nullable
    public static ajd a(qc qc2) {
        return a.get(qc2);
    }

    public qc h() {
        return this.b;
    }
}

