/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import java.io.IOException;
import javax.annotation.Nullable;

public class lt
implements ht<kw> {
    private a a;
    private nd b;

    public lt() {
    }

    public lt(a a2, @Nullable nd nd2) {
        this.a = a2;
        this.b = nd2;
    }

    public static lt a(i i2) {
        return new lt(lt$a.a, i2.h());
    }

    public static lt a() {
        return new lt(lt$a.b, null);
    }

    @Override
    public void a(gy gy2) throws IOException {
        this.a = gy2.a(a.class);
        if (this.a == lt$a.a) {
            this.b = gy2.l();
        }
    }

    @Override
    public void b(gy gy2) throws IOException {
        gy2.a(this.a);
        if (this.a == lt$a.a) {
            gy2.a(this.b);
        }
    }

    @Override
    public void a(kw kw2) {
        kw2.a(this);
    }

    public a b() {
        return this.a;
    }

    public nd c() {
        return this.b;
    }

    public static enum a {
        a,
        b;

    }
}

