/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import java.util.Random;
import javax.annotation.Nullable;

public abstract class aop
extends aou {
    protected static final bgz a = new bgz(0.0625, 0.0, 0.0625, 0.9375, 0.03125, 0.9375);
    protected static final bgz b = new bgz(0.0625, 0.0, 0.0625, 0.9375, 0.0625, 0.9375);
    protected static final bgz c = new bgz(0.125, 0.0, 0.125, 0.875, 0.25, 0.875);

    protected aop(bcx bcx2) {
        this(bcx2, bcx2.r());
    }

    protected aop(bcx bcx2, bcy bcy2) {
        super(bcx2, bcy2);
        this.a(ahn.d);
        this.a(true);
    }

    @Override
    public bgz b(awr awr2, amw amw2, et et2) {
        boolean bl2 = \u2603 = this.i(awr2) > 0;
        if (\u2603) {
            return a;
        }
        return b;
    }

    @Override
    public int a(ams ams2) {
        return 20;
    }

    @Override
    @Nullable
    public bgz a(awr awr2, amw amw2, et et2) {
        return k;
    }

    @Override
    public boolean b(awr awr2) {
        return false;
    }

    @Override
    public boolean c(awr awr2) {
        return false;
    }

    @Override
    public boolean b(amw amw2, et et2) {
        return true;
    }

    @Override
    public boolean d() {
        return true;
    }

    @Override
    public boolean a(ams ams2, et et2) {
        return this.i(ams2, et2.b());
    }

    @Override
    public void a(awr awr2, ams ams2, et et2, aou aou2, et et3) {
        if (!this.i(ams2, et2.b())) {
            this.b(ams2, et2, awr2, 0);
            ams2.g(et2);
        }
    }

    private boolean i(ams ams2, et et2) {
        return ams2.o(et2).q() || ams2.o(et2).u() instanceof aqm;
    }

    @Override
    public void a(ams ams2, et et2, awr awr2, Random random) {
    }

    @Override
    public void b(ams ams2, et et2, awr awr2, Random random) {
        if (ams2.G) {
            return;
        }
        int n2 = this.i(awr2);
        if (n2 > 0) {
            this.a(ams2, et2, awr2, n2);
        }
    }

    @Override
    public void a(ams ams2, et et2, awr awr2, ve ve2) {
        if (ams2.G) {
            return;
        }
        int n2 = this.i(awr2);
        if (n2 == 0) {
            this.a(ams2, et2, awr2, n2);
        }
    }

    protected void a(ams ams2, et et2, awr awr22, int n2) {
        boolean bl2;
        \u2603 = this.e(ams2, et2);
        boolean bl3 = n2 > 0;
        boolean bl4 = bl2 = \u2603 > 0;
        if (n2 != \u2603) {
            awr awr22 = this.a(awr22, \u2603);
            ams2.a(et2, awr22, 2);
            this.d(ams2, et2);
            ams2.b(et2, et2);
        }
        if (!bl2 && bl3) {
            this.c(ams2, et2);
        } else if (bl2 && !bl3) {
            this.b(ams2, et2);
        }
        if (bl2) {
            ams2.a(new et(et2), (aou)this, this.a(ams2));
        }
    }

    protected abstract void b(ams var1, et var2);

    protected abstract void c(ams var1, et var2);

    @Override
    public void b(ams ams2, et et2, awr awr2) {
        if (this.i(awr2) > 0) {
            this.d(ams2, et2);
        }
        super.b(ams2, et2, awr2);
    }

    protected void d(ams ams2, et et2) {
        ams2.b(et2, (aou)this, false);
        ams2.b(et2.b(), (aou)this, false);
    }

    @Override
    public int b(awr awr2, amw amw2, et et2, fa fa2) {
        return this.i(awr2);
    }

    @Override
    public int c(awr awr2, amw amw2, et et2, fa fa2) {
        if (fa2 == fa.b) {
            return this.i(awr2);
        }
        return 0;
    }

    @Override
    public boolean g(awr awr2) {
        return true;
    }

    @Override
    public bda h(awr awr2) {
        return bda.b;
    }

    protected abstract int e(ams var1, et var2);

    protected abstract int i(awr var1);

    protected abstract awr a(awr var1, int var2);

    @Override
    public awp a(amw amw2, awr awr2, et et2, fa fa2) {
        return awp.i;
    }
}

