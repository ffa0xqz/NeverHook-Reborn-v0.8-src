/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.apache.commons.io.IOUtils
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
import java.awt.image.BufferedImage;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.nio.IntBuffer;
import javax.imageio.ImageIO;
import optifine.Config;
import optifine.Mipmaps;
import optifine.Reflector;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class cdr {
    private static final Logger c = LogManager.getLogger();
    private static final IntBuffer d = bhy.f(0x400000);
    public static final cde a = new cde(16, 16);
    public static final int[] b = a.e();
    private static final float[] e;
    private static final int[] f;

    private static float d(int p_188543_0_) {
        return e[p_188543_0_ & 0xFF];
    }

    public static int a() {
        return buq.A();
    }

    public static void a(int textureId) {
        buq.h(textureId);
    }

    public static int a(int textureId, BufferedImage texture) {
        return cdr.a(textureId, texture, false, false);
    }

    public static void a(int textureId, int[] p_110988_1_, int p_110988_2_, int p_110988_3_) {
        cdr.b(textureId);
        cdr.a(0, p_110988_1_, p_110988_2_, p_110988_3_, 0, 0, false, false, false);
    }

    public static int[][] a(int p_147949_0_, int p_147949_1_, int[][] p_147949_2_) {
        int[][] aint = new int[p_147949_0_ + 1][];
        aint[0] = p_147949_2_[0];
        if (p_147949_0_ > 0) {
            boolean flag = false;
            for (int i2 = 0; i2 < p_147949_2_.length; ++i2) {
                if (p_147949_2_[0][i2] >> 24 != 0) continue;
                flag = true;
                break;
            }
            for (int l1 = 1; l1 <= p_147949_0_; ++l1) {
                if (p_147949_2_[l1] != null) {
                    aint[l1] = p_147949_2_[l1];
                    continue;
                }
                int[] aint1 = aint[l1 - 1];
                int[] aint2 = new int[aint1.length >> 2];
                int j2 = p_147949_1_ >> l1;
                int k2 = aint2.length / j2;
                int l2 = j2 << 1;
                for (int i1 = 0; i1 < j2; ++i1) {
                    for (int j1 = 0; j1 < k2; ++j1) {
                        int k1 = 2 * (i1 + j1 * l2);
                        aint2[i1 + j1 * j2] = cdr.a(aint1[k1 + 0], aint1[k1 + 1], aint1[k1 + 0 + l2], aint1[k1 + 1 + l2], flag);
                    }
                }
                aint[l1] = aint2;
            }
        }
        return aint;
    }

    private static int a(int p_147943_0_, int p_147943_1_, int p_147943_2_, int p_147943_3_, boolean p_147943_4_) {
        return Mipmaps.alphaBlend(p_147943_0_, p_147943_1_, p_147943_2_, p_147943_3_);
    }

    private static int a(int p_147944_0_, int p_147944_1_, int p_147944_2_, int p_147944_3_, int p_147944_4_) {
        float f2 = cdr.d(p_147944_0_ >> p_147944_4_);
        float f1 = cdr.d(p_147944_1_ >> p_147944_4_);
        float f22 = cdr.d(p_147944_2_ >> p_147944_4_);
        float f3 = cdr.d(p_147944_3_ >> p_147944_4_);
        float f4 = (float)((double)((float)Math.pow((double)(f2 + f1 + f22 + f3) * 0.25, 0.45454545454545453)));
        return (int)((double)f4 * 255.0);
    }

    public static void a(int[][] p_147955_0_, int p_147955_1_, int p_147955_2_, int p_147955_3_, int p_147955_4_, boolean p_147955_5_, boolean p_147955_6_) {
        for (int i2 = 0; i2 < p_147955_0_.length; ++i2) {
            int[] aint = p_147955_0_[i2];
            cdr.a(i2, aint, p_147955_1_ >> i2, p_147955_2_ >> i2, p_147955_3_ >> i2, p_147955_4_ >> i2, p_147955_5_, p_147955_6_, p_147955_0_.length > 1);
        }
    }

    private static void a(int p_147947_0_, int[] p_147947_1_, int p_147947_2_, int p_147947_3_, int p_147947_4_, int p_147947_5_, boolean p_147947_6_, boolean p_147947_7_, boolean p_147947_8_) {
        int j2;
        int i2 = 0x400000 / p_147947_2_;
        cdr.a(p_147947_6_, p_147947_8_);
        cdr.a(p_147947_7_);
        for (int k2 = 0; k2 < p_147947_2_ * p_147947_3_; k2 += p_147947_2_ * j2) {
            int l2 = k2 / p_147947_2_;
            j2 = Math.min(i2, p_147947_3_ - l2);
            int i1 = p_147947_2_ * j2;
            cdr.b(p_147947_1_, k2, i1);
            buq.b(3553, p_147947_0_, p_147947_4_, p_147947_5_ + l2, p_147947_2_, j2, 32993, 33639, d);
        }
    }

    public static int a(int textureId, BufferedImage texture, boolean blur, boolean clamp) {
        cdr.a(textureId, texture.getWidth(), texture.getHeight());
        return cdr.a(textureId, texture, 0, 0, blur, clamp);
    }

    public static void a(int textureId, int width, int height) {
        cdr.a(textureId, 0, width, height);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void a(int glTextureId, int mipmapLevels, int width, int height) {
        Class object = cdr.class;
        if (Reflector.SplashScreen.exists()) {
            object = Reflector.SplashScreen.getTargetClass();
        }
        Class class_ = object;
        synchronized (class_) {
            cdr.a(glTextureId);
            cdr.b(glTextureId);
        }
        if (mipmapLevels >= 0) {
            buq.b(3553, 33085, mipmapLevels);
            buq.b(3553, 33082, 0);
            buq.b(3553, 33083, mipmapLevels);
            buq.b(3553, 34049, 0.0f);
        }
        for (int i2 = 0; i2 <= mipmapLevels; ++i2) {
            buq.a(3553, i2, 6408, width >> i2, height >> i2, 0, 32993, 33639, null);
        }
    }

    public static int a(int textureId, BufferedImage p_110995_1_, int p_110995_2_, int p_110995_3_, boolean p_110995_4_, boolean p_110995_5_) {
        cdr.b(textureId);
        cdr.a(p_110995_1_, p_110995_2_, p_110995_3_, p_110995_4_, p_110995_5_);
        return textureId;
    }

    private static void a(BufferedImage p_110993_0_, int p_110993_1_, int p_110993_2_, boolean p_110993_3_, boolean p_110993_4_) {
        int i2 = p_110993_0_.getWidth();
        int j2 = p_110993_0_.getHeight();
        int k2 = 0x400000 / i2;
        int[] aint = new int[k2 * i2];
        cdr.b(p_110993_3_);
        cdr.a(p_110993_4_);
        for (int l2 = 0; l2 < i2 * j2; l2 += i2 * k2) {
            int i1 = l2 / i2;
            int j1 = Math.min(k2, j2 - i1);
            int k1 = i2 * j1;
            p_110993_0_.getRGB(0, i1, i2, j1, aint, 0, i2);
            cdr.a(aint, k1);
            buq.b(3553, 0, p_110993_1_, p_110993_2_ + i1, i2, j1, 32993, 33639, d);
        }
    }

    public static void a(boolean p_110997_0_) {
        if (p_110997_0_) {
            buq.b(3553, 10242, 33071);
            buq.b(3553, 10243, 33071);
        } else {
            buq.b(3553, 10242, 10497);
            buq.b(3553, 10243, 10497);
        }
    }

    private static void b(boolean p_147951_0_) {
        cdr.a(p_147951_0_, false);
    }

    public static void a(boolean p_147954_0_, boolean p_147954_1_) {
        if (p_147954_0_) {
            buq.b(3553, 10241, p_147954_1_ ? 9987 : 9729);
            buq.b(3553, 10240, 9729);
        } else {
            int i2 = Config.getMipmapType();
            buq.b(3553, 10241, p_147954_1_ ? i2 : 9728);
            buq.b(3553, 10240, 9728);
        }
    }

    private static void a(int[] p_110990_0_, int p_110990_1_) {
        cdr.b(p_110990_0_, 0, p_110990_1_);
    }

    private static void b(int[] p_110994_0_, int p_110994_1_, int p_110994_2_) {
        int[] aint = p_110994_0_;
        if (bhz.z().t.g) {
            aint = cdr.a(p_110994_0_);
        }
        d.clear();
        d.put(aint, p_110994_1_, p_110994_2_);
        d.position(0).limit(p_110994_2_);
    }

    static void b(int p_94277_0_) {
        buq.i(p_94277_0_);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static int[] a(cen resourceManager, nd imageLocation) throws IOException {
        Object i2;
        cem iresource = null;
        try {
            iresource = resourceManager.a(imageLocation);
            BufferedImage bufferedimage = cdr.a(iresource.b());
            if (bufferedimage != null) {
                int[] aint;
                int j2 = bufferedimage.getWidth();
                int i1 = bufferedimage.getHeight();
                int[] aint1 = new int[j2 * i1];
                bufferedimage.getRGB(0, 0, j2, i1, aint1, 0, j2);
                int[] arrn = aint = aint1;
                return arrn;
            }
            i2 = null;
        }
        finally {
            IOUtils.closeQuietly((Closeable)iresource);
        }
        return i2;
    }

    public static BufferedImage a(InputStream imageStream) throws IOException {
        BufferedImage bufferedimage;
        if (imageStream == null) {
            return null;
        }
        try {
            bufferedimage = ImageIO.read(imageStream);
        }
        finally {
            IOUtils.closeQuietly((InputStream)imageStream);
        }
        return bufferedimage;
    }

    public static int[] a(int[] p_110985_0_) {
        int[] aint = new int[p_110985_0_.length];
        for (int i2 = 0; i2 < p_110985_0_.length; ++i2) {
            aint[i2] = cdr.c(p_110985_0_[i2]);
        }
        return aint;
    }

    public static int c(int p_177054_0_) {
        int i2 = p_177054_0_ >> 24 & 0xFF;
        int j2 = p_177054_0_ >> 16 & 0xFF;
        int k2 = p_177054_0_ >> 8 & 0xFF;
        int l2 = p_177054_0_ & 0xFF;
        int i1 = (j2 * 30 + k2 * 59 + l2 * 11) / 100;
        int j1 = (j2 * 30 + k2 * 70) / 100;
        int k1 = (j2 * 30 + l2 * 70) / 100;
        return i2 << 24 | i1 << 16 | j1 << 8 | k1;
    }

    public static void a(int[] p_147953_0_, int p_147953_1_, int p_147953_2_) {
        int[] aint = new int[p_147953_1_];
        int i2 = p_147953_2_ / 2;
        for (int j2 = 0; j2 < i2; ++j2) {
            System.arraycopy(p_147953_0_, j2 * p_147953_1_, aint, 0, p_147953_1_);
            System.arraycopy(p_147953_0_, (p_147953_2_ - 1 - j2) * p_147953_1_, p_147953_0_, j2 * p_147953_1_, p_147953_1_);
            System.arraycopy(aint, 0, p_147953_0_, (p_147953_2_ - 1 - j2) * p_147953_1_, p_147953_1_);
        }
    }

    static {
        int i2 = -16777216;
        int j2 = -524040;
        int[] aint = new int[]{-524040, -524040, -524040, -524040, -524040, -524040, -524040, -524040};
        int[] aint1 = new int[]{-16777216, -16777216, -16777216, -16777216, -16777216, -16777216, -16777216, -16777216};
        int k2 = aint.length;
        for (int l2 = 0; l2 < 16; ++l2) {
            System.arraycopy(l2 < k2 ? aint : aint1, 0, b, 16 * l2, k2);
            System.arraycopy(l2 < k2 ? aint1 : aint, 0, b, 16 * l2 + k2, k2);
        }
        a.d();
        e = new float[256];
        for (int i1 = 0; i1 < e.length; ++i1) {
            cdr.e[i1] = (float)Math.pow((float)i1 / 255.0f, 2.2);
        }
        f = new int[4];
    }
}

