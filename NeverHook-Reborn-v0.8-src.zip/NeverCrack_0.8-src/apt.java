/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 *  javax.annotation.Nullable
 */
import com.google.common.base.Predicate;
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;

public class apt
extends aoq {
    public static final axf<aoq.b> d = axf.a("shape", aoq.b.class, new Predicate<aoq.b>(){

        public boolean a(@Nullable aoq.b b2) {
            return b2 != aoq.b.j && b2 != aoq.b.i && b2 != aoq.b.g && b2 != aoq.b.h;
        }

        public /* synthetic */ boolean apply(@Nullable Object object) {
            return this.a((aoq.b)object);
        }
    });
    public static final axd e = axd.a("powered");

    public apt() {
        super(true);
        this.w(this.A.b().a(e, false).a(d, aoq.b.a));
        this.a(true);
    }

    @Override
    public int a(ams ams2) {
        return 20;
    }

    @Override
    public boolean g(awr awr2) {
        return true;
    }

    @Override
    public void a(ams ams2, et et2, awr awr2, ve ve2) {
        if (ams2.G) {
            return;
        }
        if (awr2.c(e).booleanValue()) {
            return;
        }
        this.e(ams2, et2, awr2);
    }

    @Override
    public void a(ams ams2, et et2, awr awr2, Random random) {
    }

    @Override
    public void b(ams ams2, et et2, awr awr2, Random random) {
        if (ams2.G || !awr2.c(e).booleanValue()) {
            return;
        }
        this.e(ams2, et2, awr2);
    }

    @Override
    public int b(awr awr2, amw amw2, et et2, fa fa2) {
        return awr2.c(e) != false ? 15 : 0;
    }

    @Override
    public int c(awr awr2, amw amw2, et et2, fa fa2) {
        if (!awr2.c(e).booleanValue()) {
            return 0;
        }
        return fa2 == fa.b ? 15 : 0;
    }

    private void e(ams ams2, et et2, awr awr2) {
        boolean bl2 = awr2.c(e);
        \u2603 = false;
        List<afc> \u26032 = this.a(ams2, et2, afc.class, new Predicate[0]);
        if (!\u26032.isEmpty()) {
            \u2603 = true;
        }
        if (\u2603 && !bl2) {
            ams2.a(et2, awr2.a(e, true), 3);
            this.b(ams2, et2, awr2, true);
            ams2.b(et2, (aou)this, false);
            ams2.b(et2.b(), (aou)this, false);
            ams2.b(et2, et2);
        }
        if (!\u2603 && bl2) {
            ams2.a(et2, awr2.a(e, false), 3);
            this.b(ams2, et2, awr2, false);
            ams2.b(et2, (aou)this, false);
            ams2.b(et2.b(), (aou)this, false);
            ams2.b(et2, et2);
        }
        if (\u2603) {
            ams2.a(new et(et2), (aou)this, this.a(ams2));
        }
        ams2.d(et2, this);
    }

    protected void b(ams ams2, et et2, awr awr2, boolean bl2) {
        aoq.a a2 = new aoq.a(ams2, et2, awr2);
        List<et> \u26032 = a2.a();
        for (et et3 : \u26032) {
            awr awr3 = ams2.o(et3);
            if (awr3 == null) continue;
            awr3.a(ams2, et3, awr3.u(), et2);
        }
    }

    @Override
    public void c(ams ams2, et et2, awr awr2) {
        super.c(ams2, et2, awr2);
        this.e(ams2, et2, awr2);
    }

    @Override
    public axh<aoq.b> g() {
        return d;
    }

    @Override
    public boolean v(awr awr2) {
        return true;
    }

    @Override
    public int c(awr awr2, ams ams2, et et2) {
        if (awr2.c(e).booleanValue()) {
            List<afe> list = this.a(ams2, et2, afe.class, new Predicate[0]);
            if (!list.isEmpty()) {
                return list.get(0).j().k();
            }
            List<afc> \u26032 = this.a(ams2, et2, afc.class, vi.c);
            if (!\u26032.isEmpty()) {
                return afp.b((tt)((Object)\u26032.get(0)));
            }
        }
        return 0;
    }

    protected <T extends afc> List<T> a(ams ams2, et et2, Class<T> class_, Predicate<ve> ... arrpredicate) {
        bgz bgz2 = this.a(et2);
        if (arrpredicate.length != 1) {
            return ams2.a(class_, bgz2);
        }
        return ams2.a(class_, bgz2, arrpredicate[0]);
    }

    private bgz a(et et2) {
        float f2 = 0.2f;
        return new bgz((float)et2.p() + 0.2f, et2.q(), (float)et2.r() + 0.2f, (float)(et2.p() + 1) - 0.2f, (float)(et2.q() + 1) - 0.2f, (float)(et2.r() + 1) - 0.2f);
    }

    @Override
    public awr a(int n2) {
        return this.t().a(d, aoq.b.a(n2 & 7)).a(e, (n2 & 8) > 0);
    }

    @Override
    public int e(awr awr2) {
        int n2 = 0;
        n2 |= awr2.c(d).a();
        if (awr2.c(e).booleanValue()) {
            n2 |= 8;
        }
        return n2;
    }

    @Override
    public awr a(awr awr2, atk atk2) {
        switch (atk2) {
            case c: {
                switch (awr2.c(d)) {
                    case c: {
                        return awr2.a(d, aoq.b.d);
                    }
                    case d: {
                        return awr2.a(d, aoq.b.c);
                    }
                    case e: {
                        return awr2.a(d, aoq.b.f);
                    }
                    case f: {
                        return awr2.a(d, aoq.b.e);
                    }
                    case g: {
                        return awr2.a(d, aoq.b.i);
                    }
                    case h: {
                        return awr2.a(d, aoq.b.j);
                    }
                    case i: {
                        return awr2.a(d, aoq.b.g);
                    }
                    case j: {
                        return awr2.a(d, aoq.b.h);
                    }
                }
            }
            case d: {
                switch (awr2.c(d)) {
                    case a: {
                        return awr2.a(d, aoq.b.b);
                    }
                    case b: {
                        return awr2.a(d, aoq.b.a);
                    }
                    case c: {
                        return awr2.a(d, aoq.b.e);
                    }
                    case d: {
                        return awr2.a(d, aoq.b.f);
                    }
                    case e: {
                        return awr2.a(d, aoq.b.d);
                    }
                    case f: {
                        return awr2.a(d, aoq.b.c);
                    }
                    case g: {
                        return awr2.a(d, aoq.b.j);
                    }
                    case h: {
                        return awr2.a(d, aoq.b.g);
                    }
                    case i: {
                        return awr2.a(d, aoq.b.h);
                    }
                    case j: {
                        return awr2.a(d, aoq.b.i);
                    }
                }
            }
            case b: {
                switch (awr2.c(d)) {
                    case a: {
                        return awr2.a(d, aoq.b.b);
                    }
                    case b: {
                        return awr2.a(d, aoq.b.a);
                    }
                    case c: {
                        return awr2.a(d, aoq.b.f);
                    }
                    case d: {
                        return awr2.a(d, aoq.b.e);
                    }
                    case e: {
                        return awr2.a(d, aoq.b.c);
                    }
                    case f: {
                        return awr2.a(d, aoq.b.d);
                    }
                    case g: {
                        return awr2.a(d, aoq.b.h);
                    }
                    case h: {
                        return awr2.a(d, aoq.b.i);
                    }
                    case i: {
                        return awr2.a(d, aoq.b.j);
                    }
                    case j: {
                        return awr2.a(d, aoq.b.g);
                    }
                }
            }
        }
        return awr2;
    }

    @Override
    public awr a(awr awr2, arw arw2) {
        aoq.b b2 = awr2.c(d);
        switch (arw2) {
            case b: {
                switch (b2) {
                    case e: {
                        return awr2.a(d, aoq.b.f);
                    }
                    case f: {
                        return awr2.a(d, aoq.b.e);
                    }
                    case g: {
                        return awr2.a(d, aoq.b.j);
                    }
                    case h: {
                        return awr2.a(d, aoq.b.i);
                    }
                    case i: {
                        return awr2.a(d, aoq.b.h);
                    }
                    case j: {
                        return awr2.a(d, aoq.b.g);
                    }
                }
                break;
            }
            case c: {
                switch (b2) {
                    case c: {
                        return awr2.a(d, aoq.b.d);
                    }
                    case d: {
                        return awr2.a(d, aoq.b.c);
                    }
                    case g: {
                        return awr2.a(d, aoq.b.h);
                    }
                    case h: {
                        return awr2.a(d, aoq.b.g);
                    }
                    case i: {
                        return awr2.a(d, aoq.b.j);
                    }
                    case j: {
                        return awr2.a(d, aoq.b.i);
                    }
                }
                break;
            }
        }
        return super.a(awr2, arw2);
    }

    @Override
    protected aws b() {
        return new aws((aou)this, d, e);
    }
}

