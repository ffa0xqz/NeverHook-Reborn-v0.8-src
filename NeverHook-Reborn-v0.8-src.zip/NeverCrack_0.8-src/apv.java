/*
 * Decompiled with CFR 0.150.
 */
public abstract class apv
extends aou {
    public static final axe H = axe.a("facing");

    protected apv(bcx bcx2) {
        super(bcx2);
    }
}

