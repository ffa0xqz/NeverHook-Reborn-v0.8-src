/*
 * Decompiled with CFR 0.150.
 */
public class ajr
extends agz {
    public ajr(aou aou2) {
        super(aou2);
        this.e(0);
    }

    @Override
    public ub a(aeb aeb22, ams ams2, et et2, tz tz2, fa fa2, float f2, float f3, float f4) {
        aeb aeb22;
        ain ain2 = aeb22.b(tz2);
        if (ain2.b() || !aeb22.a(et2, fa2, ain2)) {
            return ub.c;
        }
        awr \u26032 = ams2.o(et2);
        aou \u26033 = \u26032.u();
        et \u26034 = et2;
        if (!(fa2 == fa.b && \u26033 == this.a || \u26033.a((amw)ams2, et2))) {
            \u26034 = et2.a(fa2);
            \u26032 = ams2.o(\u26034);
            \u26033 = \u26032.u();
        }
        if (\u26033 == this.a && (\u2603 = \u26032.c(atu.a).intValue()) < 8 && (\u2603 = (\u2603 = \u26032.a(atu.a, \u2603 + 1)).d(ams2, \u26034)) != aou.k && ams2.b(\u2603.a(\u26034)) && ams2.a(\u26034, \u2603, 10)) {
            atw atw2 = this.a.v();
            ams2.a(aeb22, \u26034, atw2.e(), qe.e, (atw2.a() + 1.0f) / 2.0f, atw2.b() * 0.8f);
            if (aeb22 instanceof oo) {
                m.x.a((oo)aeb22, et2, ain2);
            }
            ain2.g(1);
            return ub.a;
        }
        return super.a(aeb22, ams2, et2, tz2, fa2, f2, f3, f4);
    }

    @Override
    public int a(int n2) {
        return n2;
    }
}

