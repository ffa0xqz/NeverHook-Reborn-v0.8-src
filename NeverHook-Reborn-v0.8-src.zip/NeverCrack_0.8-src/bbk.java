/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 */
import com.google.common.collect.Lists;
import java.util.List;
import java.util.Random;

public class bbk
extends bbs {
    private final List<anf.c> a = Lists.newArrayList();

    public bbk() {
        this.a.add(new anf.c(aco.class, 10, 2, 3));
        this.a.add(new anf.c(add.class, 5, 4, 4));
        this.a.add(new anf.c(adq.class, 8, 5, 5));
        this.a.add(new anf.c(adi.class, 2, 5, 5));
        this.a.add(new anf.c(adb.class, 3, 4, 4));
    }

    @Override
    public String a() {
        return "Fortress";
    }

    public List<anf.c> b() {
        return this.a;
    }

    @Override
    protected boolean a(int n2, int n3) {
        \u2603 = n2 >> 4;
        \u2603 = n3 >> 4;
        this.f.setSeed((long)(\u2603 ^ \u2603 << 4) ^ this.g.Q());
        this.f.nextInt();
        if (this.f.nextInt(3) != 0) {
            return false;
        }
        if (n2 != (\u2603 << 4) + 4 + this.f.nextInt(8)) {
            return false;
        }
        return n3 == (\u2603 << 4) + 4 + this.f.nextInt(8);
    }

    @Override
    protected bbw b(int n2, int n3) {
        return new a(this.g, this.f, n2, n3);
    }

    @Override
    public et a(ams ams2, et et2, boolean bl2) {
        int n2 = 1000;
        \u2603 = et2.p() >> 4;
        \u2603 = et2.r() >> 4;
        for (\u2603 = 0; \u2603 <= 1000; ++\u2603) {
            for (\u2603 = -\u2603; \u2603 <= \u2603; ++\u2603) {
                boolean bl3 = \u2603 == -\u2603 || \u2603 == \u2603;
                for (int i2 = -\u2603; i2 <= \u2603; ++i2) {
                    boolean bl4 = \u2603 = i2 == -\u2603 || i2 == \u2603;
                    if (!bl3 && !\u2603 || !this.a(\u2603 = \u2603 + \u2603, \u2603 = \u2603 + i2) || bl2 && ams2.b(\u2603, \u2603)) continue;
                    return new et((\u2603 << 4) + 8, 64, (\u2603 << 4) + 8);
                }
            }
        }
        return null;
    }

    public static class a
    extends bbw {
        public a() {
        }

        public a(ams ams2, Random random, int n2, int n3) {
            super(n2, n3);
            bbl.q q2 = new bbl.q(random, (n2 << 4) + 2, (n3 << 4) + 2);
            this.a.add(q2);
            q2.a(q2, this.a, random);
            List<bbv> \u26032 = q2.d;
            while (!\u26032.isEmpty()) {
                int n4 = random.nextInt(\u26032.size());
                bbv \u26033 = \u26032.remove(n4);
                \u26033.a(q2, this.a, random);
            }
            this.d();
            this.a(ams2, random, 48, 70);
        }
    }
}

