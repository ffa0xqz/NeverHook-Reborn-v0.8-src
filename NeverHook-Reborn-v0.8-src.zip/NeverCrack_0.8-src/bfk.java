/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Maps
 *  javax.annotation.Nullable
 */
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;

public class bfk {
    private final bfc b;
    protected Map<String, ber> a = Maps.newHashMap();
    private final List<ber> c = Lists.newArrayList();
    private final Map<String, Short> d = Maps.newHashMap();

    public bfk(bfc bfc2) {
        this.b = bfc2;
        this.b();
    }

    @Nullable
    public ber a(Class<? extends ber> class_, String string) {
        ber ber2;
        block7: {
            ber2 = this.a.get(string);
            if (ber2 != null) {
                return ber2;
            }
            if (this.b != null) {
                try {
                    File file = this.b.a(string);
                    if (file == null || !file.exists()) break block7;
                    try {
                        ber2 = class_.getConstructor(String.class).newInstance(string);
                    }
                    catch (Exception exception) {
                        throw new RuntimeException("Failed to instantiate " + class_, exception);
                    }
                    FileInputStream fileInputStream = new FileInputStream(file);
                    fy \u26032 = gi.a(fileInputStream);
                    fileInputStream.close();
                    ber2.a(\u26032.p("data"));
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
            }
        }
        if (ber2 != null) {
            this.a.put(string, ber2);
            this.c.add(ber2);
        }
        return ber2;
    }

    public void a(String string, ber ber2) {
        if (this.a.containsKey(string)) {
            this.c.remove(this.a.remove(string));
        }
        this.a.put(string, ber2);
        this.c.add(ber2);
    }

    public void a() {
        for (int i2 = 0; i2 < this.c.size(); ++i2) {
            ber ber2 = this.c.get(i2);
            if (!ber2.d()) continue;
            this.a(ber2);
            ber2.a(false);
        }
    }

    private void a(ber ber2) {
        if (this.b == null) {
            return;
        }
        try {
            File file = this.b.a(ber2.a);
            if (file != null) {
                fy fy2 = new fy();
                fy2.a("data", ber2.b(new fy()));
                FileOutputStream \u26032 = new FileOutputStream(file);
                gi.a(fy2, \u26032);
                \u26032.close();
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private void b() {
        try {
            this.d.clear();
            if (this.b == null) {
                return;
            }
            File file = this.b.a("idcounts");
            if (file != null && file.exists()) {
                DataInputStream dataInputStream = new DataInputStream(new FileInputStream(file));
                fy \u26032 = gi.a(dataInputStream);
                dataInputStream.close();
                for (String string : \u26032.c()) {
                    gn gn2 = \u26032.c(string);
                    if (!(gn2 instanceof gl)) continue;
                    gl \u26033 = (gl)gn2;
                    short \u26034 = \u26033.f();
                    this.d.put(string, \u26034);
                }
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public int a(String string) {
        Short s2 = this.d.get(string);
        if (s2 == null) {
            s2 = 0;
        } else {
            Short s3 = s2;
            Short s4 = s2 = Short.valueOf((short)(s2 + 1));
        }
        this.d.put(string, s2);
        if (this.b == null) {
            return s2.shortValue();
        }
        try {
            File file = this.b.a("idcounts");
            if (file != null) {
                fy fy2 = new fy();
                for (String string2 : this.d.keySet()) {
                    fy2.a(string2, this.d.get(string2));
                }
                DataOutputStream \u26032 = new DataOutputStream(new FileOutputStream(file));
                gi.a(fy2, (DataOutput)\u26032);
                \u26032.close();
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return s2.shortValue();
    }
}

