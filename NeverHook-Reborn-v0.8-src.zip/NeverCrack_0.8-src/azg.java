/*
 * Decompiled with CFR 0.150.
 */
import java.util.Random;

public class azg
extends aze {
    private static final awr a = aov.r.t().a(asm.b, asp.a.c);
    private static final awr b = aov.t.t().a(asl.e, asp.a.c).a(asl.b, false);
    private final boolean c;

    public azg(boolean bl2, boolean bl3) {
        super(bl2);
        this.c = bl3;
    }

    @Override
    public boolean b(ams ams22, Random random, et et2) {
        int n2;
        ams ams22;
        int n3 = random.nextInt(3) + 5;
        if (this.c) {
            n3 += random.nextInt(7);
        }
        boolean \u26032 = true;
        if (et2.q() < 1 || et2.q() + n3 + 1 > 256) {
            return false;
        }
        for (\u2603 = et2.q(); \u2603 <= et2.q() + 1 + n3; ++\u2603) {
            n2 = 1;
            if (\u2603 == et2.q()) {
                n2 = 0;
            }
            if (\u2603 >= et2.q() + 1 + n3 - 2) {
                n2 = 2;
            }
            et.a a2 = new et.a();
            for (int i2 = et2.p() - n2; i2 <= et2.p() + n2 && \u26032; ++i2) {
                for (\u2603 = et2.r() - n2; \u2603 <= et2.r() + n2 && \u26032; ++\u2603) {
                    if (\u2603 >= 0 && \u2603 < 256) {
                        if (this.a(ams22.o(a2.c(i2, \u2603, \u2603)).u())) continue;
                        \u26032 = false;
                        continue;
                    }
                    \u26032 = false;
                }
            }
        }
        if (!\u26032) {
            return false;
        }
        aou \u26033 = ams22.o(et2.b()).u();
        if (\u26033 != aov.c && \u26033 != aov.d && \u26033 != aov.ak || et2.q() >= 256 - n3 - 1) {
            return false;
        }
        this.a(ams22, et2.b());
        for (n2 = et2.q() - 3 + n3; n2 <= et2.q() + n3; ++n2) {
            \u2603 = n2 - (et2.q() + n3);
            i2 = 1 - \u2603 / 2;
            for (\u2603 = et2.p() - i2; \u2603 <= et2.p() + i2; ++\u2603) {
                \u2603 = \u2603 - et2.p();
                for (\u2603 = et2.r() - i2; \u2603 <= et2.r() + i2; ++\u2603) {
                    \u2603 = \u2603 - et2.r();
                    if (Math.abs(\u2603) == i2 && Math.abs(\u2603) == i2 && (random.nextInt(2) == 0 || \u2603 == 0) || (\u2603 = ams22.o(\u2603 = new et(\u2603, n2, \u2603)).a()) != bcx.a && \u2603 != bcx.j) continue;
                    this.a(ams22, \u2603, b);
                }
            }
        }
        for (n2 = 0; n2 < n3; ++n2) {
            bcx bcx2 = ams22.o(et2.b(n2)).a();
            if (bcx2 != bcx.a && bcx2 != bcx.j) continue;
            this.a(ams22, et2.b(n2), a);
        }
        return true;
    }
}

