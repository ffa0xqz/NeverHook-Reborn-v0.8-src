/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;

public class apf
extends aou {
    public static final axg a = axg.a("level", 0, 3);
    protected static final bgz b = new bgz(0.0, 0.0, 0.0, 1.0, 0.3125, 1.0);
    protected static final bgz c = new bgz(0.0, 0.0, 0.0, 1.0, 1.0, 0.125);
    protected static final bgz d = new bgz(0.0, 0.0, 0.875, 1.0, 1.0, 1.0);
    protected static final bgz e = new bgz(0.875, 0.0, 0.0, 1.0, 1.0, 1.0);
    protected static final bgz f = new bgz(0.0, 0.0, 0.0, 0.125, 1.0, 1.0);

    public apf() {
        super(bcx.f, bcy.n);
        this.w(this.A.b().a(a, 0));
    }

    @Override
    public void a(awr awr2, ams ams2, et et2, bgz bgz2, List<bgz> list, @Nullable ve ve2, boolean bl2) {
        apf.a(et2, bgz2, list, b);
        apf.a(et2, bgz2, list, f);
        apf.a(et2, bgz2, list, c);
        apf.a(et2, bgz2, list, e);
        apf.a(et2, bgz2, list, d);
    }

    @Override
    public bgz b(awr awr2, amw amw2, et et2) {
        return j;
    }

    @Override
    public boolean b(awr awr2) {
        return false;
    }

    @Override
    public boolean c(awr awr2) {
        return false;
    }

    @Override
    public void a(ams ams2, et et2, awr awr2, ve ve2) {
        int n2 = awr2.c(a);
        float \u26032 = (float)et2.q() + (6.0f + (float)(3 * n2)) / 16.0f;
        if (!ams2.G && ve2.aR() && n2 > 0 && ve2.bw().b <= (double)\u26032) {
            ve2.ab();
            this.a(ams2, et2, awr2, n2 - 1);
        }
    }

    @Override
    public boolean a(ams ams2, et et2, awr awr2, aeb aeb2, tz tz2, fa fa2, float f2, float f3, float f4) {
        ain ain2 = aeb2.b(tz2);
        if (ain2.b()) {
            return true;
        }
        int \u26032 = awr2.c(a);
        ail \u26033 = ain2.c();
        if (\u26033 == aip.aA) {
            if (\u26032 < 3 && !ams2.G) {
                if (!aeb2.bO.d) {
                    aeb2.a(tz2, new ain(aip.az));
                }
                aeb2.b(qq.I);
                this.a(ams2, et2, awr2, 3);
                ams2.a(null, et2, qd.Q, qe.e, 1.0f, 1.0f);
            }
            return true;
        }
        if (\u26033 == aip.az) {
            if (\u26032 == 3 && !ams2.G) {
                if (!aeb2.bO.d) {
                    ain2.g(1);
                    if (ain2.b()) {
                        aeb2.a(tz2, new ain(aip.aA));
                    } else if (!aeb2.bv.e(new ain(aip.aA))) {
                        aeb2.a(new ain(aip.aA), false);
                    }
                }
                aeb2.b(qq.J);
                this.a(ams2, et2, awr2, 0);
                ams2.a(null, et2, qd.S, qe.e, 1.0f, 1.0f);
            }
            return true;
        }
        if (\u26033 == aip.bK) {
            if (\u26032 > 0 && !ams2.G) {
                if (!aeb2.bO.d) {
                    \u2603 = akg.a(new ain(aip.bH), akh.b);
                    aeb2.b(qq.J);
                    ain2.g(1);
                    if (ain2.b()) {
                        aeb2.a(tz2, \u2603);
                    } else if (!aeb2.bv.e(\u2603)) {
                        aeb2.a(\u2603, false);
                    } else if (aeb2 instanceof oo) {
                        ((oo)aeb2).a(aeb2.bx);
                    }
                }
                ams2.a(null, et2, qd.N, qe.e, 1.0f, 1.0f);
                this.a(ams2, et2, awr2, \u26032 - 1);
            }
            return true;
        }
        if (\u26033 == aip.bH && akg.d(ain2) == akh.b) {
            if (\u26032 < 3 && !ams2.G) {
                if (!aeb2.bO.d) {
                    \u2603 = new ain(aip.bK);
                    aeb2.b(qq.J);
                    aeb2.a(tz2, \u2603);
                    if (aeb2 instanceof oo) {
                        ((oo)aeb2).a(aeb2.bx);
                    }
                }
                ams2.a(null, et2, qd.M, qe.e, 1.0f, 1.0f);
                this.a(ams2, et2, awr2, \u26032 + 1);
            }
            return true;
        }
        if (\u26032 > 0 && \u26033 instanceof agt && ((agt)(object = (agt)\u26033)).d() == agt.a.a && ((agt)object).e_(ain2) && !ams2.G) {
            ((agt)object).d(ain2);
            this.a(ams2, et2, awr2, \u26032 - 1);
            aeb2.b(qq.K);
            return true;
        }
        if (\u26032 > 0 && \u26033 instanceof agx) {
            if (avd.b(ain2) > 0 && !ams2.G) {
                Object object = ain2.l();
                ((ain)object).e(1);
                avd.c((ain)object);
                aeb2.b(qq.L);
                if (!aeb2.bO.d) {
                    ain2.g(1);
                    this.a(ams2, et2, awr2, \u26032 - 1);
                }
                if (ain2.b()) {
                    aeb2.a(tz2, (ain)object);
                } else if (!aeb2.bv.e((ain)object)) {
                    aeb2.a((ain)object, false);
                } else if (aeb2 instanceof oo) {
                    ((oo)aeb2).a(aeb2.bx);
                }
            }
            return true;
        }
        return false;
    }

    public void a(ams ams2, et et2, awr awr2, int n2) {
        ams2.a(et2, awr2.a(a, ri.a(n2, 0, 3)), 2);
        ams2.d(et2, this);
    }

    @Override
    public void h(ams ams2, et et2) {
        if (ams2.r.nextInt(20) != 1) {
            return;
        }
        float f2 = ams2.b(et2).a(et2);
        if (ams2.C().a(f2, et2.q()) < 0.15f) {
            return;
        }
        awr \u26032 = ams2.o(et2);
        if (\u26032.c(a) < 3) {
            ams2.a(et2, \u26032.a(a), 2);
        }
    }

    @Override
    public ail a(awr awr2, Random random, int n2) {
        return aip.bR;
    }

    @Override
    public ain a(ams ams2, et et2, awr awr2) {
        return new ain(aip.bR);
    }

    @Override
    public boolean v(awr awr2) {
        return true;
    }

    @Override
    public int c(awr awr2, ams ams2, et et2) {
        return awr2.c(a);
    }

    @Override
    public awr a(int n2) {
        return this.t().a(a, n2);
    }

    @Override
    public int e(awr awr2) {
        return awr2.c(a);
    }

    @Override
    protected aws b() {
        return new aws((aou)this, a);
    }

    @Override
    public boolean b(amw amw2, et et2) {
        return true;
    }

    @Override
    public awp a(amw amw2, awr awr2, et et2, fa fa2) {
        if (fa2 == fa.b) {
            return awp.b;
        }
        if (fa2 == fa.a) {
            return awp.i;
        }
        return awp.a;
    }
}

