/*
 * Decompiled with CFR 0.150.
 */
import java.util.List;

public class bjw
implements bjz {
    private final i c;
    private boolean d = false;

    public bjw(i p_i47490_1_) {
        this.c = p_i47490_1_;
    }

    @Override
    public bjz.a a(bka p_193653_1_, long p_193653_2_) {
        p_193653_1_.b().N().a(a);
        buq.d(1.0f, 1.0f, 1.0f);
        r displayinfo = this.c.c();
        p_193653_1_.b(0, 0, 0, 0, 160, 32);
        if (displayinfo != null) {
            int i2;
            p_193653_1_.b();
            List<String> list = bhz.k.c(displayinfo.a().d(), 125);
            int n2 = i2 = displayinfo.e() == s.b ? 0xFF88FF : 0xFFFF00;
            if (list.size() == 1) {
                p_193653_1_.b();
                bhz.k.drawString(cew.a("advancements.toast." + displayinfo.e().a(), new Object[0]), 30.0f, 7.0f, i2 | 0xFF000000);
                p_193653_1_.b();
                bhz.k.drawString(displayinfo.a().d(), 30.0f, 18.0f, -1);
            } else {
                int j2 = 1500;
                float f2 = 300.0f;
                if (p_193653_2_ < 1500L) {
                    int k2 = ri.d(ri.a((float)(1500L - p_193653_2_) / 300.0f, 0.0f, 1.0f) * 255.0f) << 24 | 0x4000000;
                    p_193653_1_.b();
                    bhz.k.drawString(cew.a("advancements.toast." + displayinfo.e().a(), new Object[0]), 30.0f, 11.0f, i2 | k2);
                } else {
                    int i1 = ri.d(ri.a((float)(p_193653_2_ - 1500L) / 300.0f, 0.0f, 1.0f) * 252.0f) << 24 | 0x4000000;
                    int n3 = list.size();
                    p_193653_1_.b();
                    int l2 = 16 - n3 * bhz.k.a / 2;
                    for (String s2 : list) {
                        p_193653_1_.b();
                        bhz.k.drawString(s2, 30.0f, l2, 0xFFFFFF | i1);
                        p_193653_1_.b();
                        l2 += bhz.k.a;
                    }
                }
            }
            if (!this.d && p_193653_2_ > 0L) {
                this.d = true;
                if (displayinfo.e() == s.b) {
                    p_193653_1_.b().U().a(cgn.a(qd.if, 1.0f, 1.0f));
                }
            }
            bhx.c();
            p_193653_1_.b().ad().a((vn)null, displayinfo.c(), 8, 8);
            return p_193653_2_ >= 5000L ? bjz.a.b : bjz.a.a;
        }
        return bjz.a.b;
    }
}

