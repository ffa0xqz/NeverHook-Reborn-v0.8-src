/*
 * Decompiled with CFR 0.150.
 */
import java.io.IOException;

public class le
implements ht<kw> {
    private int a;
    private int b;

    public le() {
    }

    public le(int n2, int n3) {
        this.a = n2;
        this.b = n3;
    }

    @Override
    public void a(kw kw2) {
        kw2.a(this);
    }

    @Override
    public void a(gy gy2) throws IOException {
        this.a = gy2.readByte();
        this.b = gy2.readByte();
    }

    @Override
    public void b(gy gy2) throws IOException {
        gy2.writeByte(this.a);
        gy2.writeByte(this.b);
    }

    public int a() {
        return this.a;
    }

    public int b() {
        return this.b;
    }
}

