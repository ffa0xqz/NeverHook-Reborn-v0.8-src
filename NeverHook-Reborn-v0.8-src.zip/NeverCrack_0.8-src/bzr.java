/*
 * Decompiled with CFR 0.150.
 */
public class bzr
extends cad<adc> {
    private static final nd a = new nd("textures/entity/illager/illusionist.png");

    public bzr(bzd bzd2) {
        super(bzd2, new bpw(0.0f, 0.0f, 64, 64), 0.5f);
        this.a(new cca(this){

            @Override
            public void a(vn vn2, float f2, float f3, float f4, float f5, float f6, float f7, float f8) {
                if (((ada)vn2).dn() || ((ada)vn2).dl()) {
                    super.a(vn2, f2, f3, f4, f5, f6, f7, f8);
                }
            }

            @Override
            protected void a(vm vm2) {
                ((bpw)this.b.b()).a(vm2).c(0.0625f);
            }
        });
        ((bpw)this.b()).b.j = true;
    }

    @Override
    protected nd a(adc adc2) {
        return a;
    }

    @Override
    protected void a(adc adc2, float f2) {
        \u2603 = 0.9375f;
        buq.b(0.9375f, 0.9375f, 0.9375f);
    }

    @Override
    public void a(adc adc22, double d2, double d3, double d4, float f2, float f3) {
        if (adc22.aX()) {
            bhc[] arrbhc = ((ada)adc22).a(f3);
            float \u26032 = this.b(adc22, f3);
            for (int i2 = 0; i2 < arrbhc.length; ++i2) {
                super.a(adc22, d2 + arrbhc[i2].b + (double)ri.b((float)i2 + \u26032 * 0.5f) * 0.025, d3 + arrbhc[i2].c + (double)ri.b((float)i2 + \u26032 * 0.75f) * 0.0125, d4 + arrbhc[i2].d + (double)ri.b((float)i2 + \u26032 * 0.7f) * 0.025, f2, f3);
            }
        } else {
            adc adc22;
            super.a(adc22, d2, d3, d4, f2, f3);
        }
    }

    @Override
    public void a(adc adc2, double d2, double d3, double d4) {
        super.a(adc2, d2, d3, d4);
    }

    @Override
    protected boolean b(adc adc2) {
        return true;
    }

    @Override
    protected /* synthetic */ boolean c(vn vn2) {
        return this.b((adc)vn2);
    }
}

