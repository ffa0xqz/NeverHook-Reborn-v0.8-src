/*
 * Decompiled with CFR 0.150.
 */
public class btj
extends btd {
    private final int a;
    private final int b;
    private final float L;
    private float M = 0.91f;
    private float N;
    private float O;
    private float P;
    private boolean Q;

    public btj(ams ams2, double d2, double d3, double d4, int n2, int n3, float f2) {
        super(ams2, d2, d3, d4);
        this.a = n2;
        this.b = n3;
        this.L = f2;
    }

    public void c(int n2) {
        float f2 = (float)((n2 & 0xFF0000) >> 16) / 255.0f;
        \u2603 = (float)((n2 & 0xFF00) >> 8) / 255.0f;
        \u2603 = (float)((n2 & 0xFF) >> 0) / 255.0f;
        \u2603 = 1.0f;
        this.a(f2 * 1.0f, \u2603 * 1.0f, \u2603 * 1.0f);
    }

    public void d(int n2) {
        this.N = (float)((n2 & 0xFF0000) >> 16) / 255.0f;
        this.O = (float)((n2 & 0xFF00) >> 8) / 255.0f;
        this.P = (float)((n2 & 0xFF) >> 0) / 255.0f;
        this.Q = true;
    }

    @Override
    public boolean c() {
        return true;
    }

    @Override
    public void a() {
        this.d = this.g;
        this.e = this.h;
        this.f = this.i;
        if (this.w++ >= this.x) {
            this.i();
        }
        if (this.w > this.x / 2) {
            this.e(1.0f - ((float)this.w - (float)(this.x / 2)) / (float)this.x);
            if (this.Q) {
                this.A += (this.N - this.A) * 0.2f;
                this.B += (this.O - this.B) * 0.2f;
                this.C += (this.P - this.C) * 0.2f;
            }
        }
        this.b(this.a + (this.b - 1 - this.w * this.b / this.x));
        this.k += (double)this.L;
        this.a(this.j, this.k, this.l);
        this.j *= (double)this.M;
        this.k *= (double)this.M;
        this.l *= (double)this.M;
        if (this.m) {
            this.j *= (double)0.7f;
            this.l *= (double)0.7f;
        }
    }

    @Override
    public int a(float f2) {
        return 0xF000F0;
    }

    protected void f(float f2) {
        this.M = f2;
    }
}

