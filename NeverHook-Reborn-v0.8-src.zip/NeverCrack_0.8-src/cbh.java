/*
 * Decompiled with CFR 0.150.
 */
public class cbh
extends cad<abv> {
    private static final nd a = new nd("textures/entity/wither/wither_invulnerable.png");
    private static final nd j = new nd("textures/entity/wither/wither.png");

    public cbh(bzd bzd2) {
        super(bzd2, new brh(0.0f), 1.0f);
        this.a(new ccn(this));
    }

    @Override
    protected nd a(abv abv2) {
        int n2 = abv2.dm();
        if (n2 <= 0 || n2 <= 80 && n2 / 5 % 2 == 1) {
            return j;
        }
        return a;
    }

    @Override
    protected void a(abv abv2, float f2) {
        \u2603 = 2.0f;
        int n2 = abv2.dm();
        if (n2 > 0) {
            \u2603 -= ((float)n2 - f2) / 220.0f * 0.5f;
        }
        buq.b(\u2603, \u2603, \u2603);
    }
}

