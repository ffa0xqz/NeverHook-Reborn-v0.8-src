/*
 * Decompiled with CFR 0.150.
 */
public class bkk
extends bli {
    private static final bib.a[] a = new bib.a[]{bib.a.p, bib.a.q, bib.a.r, bib.a.s, bib.a.t, bib.a.z, bib.a.B, bib.a.C, bib.a.A, bib.a.F, bib.a.N};
    private final bli f;
    private final bib g;
    private String h;
    private bjl i;

    public bkk(bli bli2, bib bib2) {
        this.f = bli2;
        this.g = bib2;
    }

    @Override
    public void b() {
        this.h = cew.a("options.chat.title", new Object[0]);
        int n2 = 0;
        for (bib.a a2 : a) {
            if (a2.a()) {
                this.n.add(new bjq(a2.c(), this.l / 2 - 155 + n2 % 2 * 160, this.m / 6 + 24 * (n2 >> 1), a2));
            } else {
                bjl bjl2 = new bjl(a2.c(), this.l / 2 - 155 + n2 % 2 * 160, this.m / 6 + 24 * (n2 >> 1), a2, this.g.c(a2));
                this.n.add(bjl2);
                if (a2 == bib.a.N) {
                    this.i = bjl2;
                    bjl2.l = bit.a.a();
                }
            }
            ++n2;
        }
        this.n.add(new biy(200, this.l / 2 - 100, this.m / 6 + 144, cew.a("gui.done", new Object[0])));
    }

    @Override
    protected void a(char c2, int n2) {
        if (n2 == 1) {
            this.j.t.b();
        }
        super.a(c2, n2);
    }

    @Override
    protected void a(biy biy2) {
        if (!biy2.l) {
            return;
        }
        if (biy2.k < 100 && biy2 instanceof bjl) {
            this.g.a(((bjl)biy2).c(), 1);
            biy2.j = this.g.c(bib.a.a(biy2.k));
        }
        if (biy2.k == 200) {
            this.j.t.b();
            this.j.a(this.f);
        }
    }

    @Override
    public void a(int n2, int n3, float f2) {
        this.c();
        this.a(this.q, this.h, this.l / 2, 20, 0xFFFFFF);
        super.a(n2, n3, f2);
    }

    public void a() {
        this.i.j = this.g.c(bib.a.a(this.i.k));
    }
}

