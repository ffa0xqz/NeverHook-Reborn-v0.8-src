/*
 * Decompiled with CFR 0.150.
 */
public class cbk
extends cad<aak> {
    private static final nd a = new nd("textures/entity/wolf/wolf.png");
    private static final nd j = new nd("textures/entity/wolf/wolf_tame.png");
    private static final nd k = new nd("textures/entity/wolf/wolf_angry.png");

    public cbk(bzd bzd2) {
        super(bzd2, new bri(), 0.5f);
        this.a(new cco(this));
    }

    protected float a(aak aak2, float f2) {
        return aak2.du();
    }

    @Override
    public void a(aak aak2, double d2, double d3, double d4, float f2, float f3) {
        if (aak2.dt()) {
            \u2603 = aak2.aw() * aak2.r(f3);
            buq.d(\u2603, \u2603, \u2603);
        }
        super.a(aak2, d2, d3, d4, f2, f3);
    }

    @Override
    protected nd a(aak aak2) {
        if (aak2.dl()) {
            return j;
        }
        if (aak2.dv()) {
            return k;
        }
        return a;
    }

    @Override
    protected /* synthetic */ float b(vn vn2, float f2) {
        return this.a((aak)vn2, f2);
    }
}

