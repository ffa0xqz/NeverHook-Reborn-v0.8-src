/*
 * Decompiled with CFR 0.150.
 */
public class aug
extends aou {
    public static final axf<a> a = axf.a("variant", a.class);
    public static final int b = aug$a.a.a();
    public static final int c = aug$a.b.a();
    public static final int d = aug$a.c.a();
    public static final int e = aug$a.d.a();

    public aug() {
        super(bcx.e);
        this.w(this.A.b().a(a, aug$a.a));
        this.a(ahn.b);
    }

    @Override
    public int d(awr awr2) {
        return awr2.c(a).a();
    }

    @Override
    public void a(ahn ahn2, fi<ain> fi2) {
        for (a a2 : aug$a.values()) {
            fi2.add(new ain(this, 1, a2.a()));
        }
    }

    @Override
    public awr a(int n2) {
        return this.t().a(a, aug$a.a(n2));
    }

    @Override
    public int e(awr awr2) {
        return awr2.c(a).a();
    }

    @Override
    protected aws b() {
        return new aws((aou)this, a);
    }

    public static enum a implements rm
    {
        a(0, "stonebrick", "default"),
        b(1, "mossy_stonebrick", "mossy"),
        c(2, "cracked_stonebrick", "cracked"),
        d(3, "chiseled_stonebrick", "chiseled");

        private static final a[] e;
        private final int f;
        private final String g;
        private final String h;

        private a(int n3, String string2, String string3) {
            this.f = n3;
            this.g = string2;
            this.h = string3;
        }

        public int a() {
            return this.f;
        }

        public String toString() {
            return this.g;
        }

        public static a a(int n2) {
            if (n2 < 0 || n2 >= e.length) {
                n2 = 0;
            }
            return e[n2];
        }

        @Override
        public String m() {
            return this.g;
        }

        public String c() {
            return this.h;
        }

        static {
            e = new a[aug$a.values().length];
            a[] arra = aug$a.values();
            int n2 = arra.length;
            for (int i2 = 0; i2 < n2; ++i2) {
                a a2;
                aug$a.e[a2.a()] = a2 = arra[i2];
            }
        }
    }
}

