/*
 * Decompiled with CFR 0.150.
 */
public class bjq
extends biy {
    private float p = 1.0f;
    public boolean o;
    private final bib.a q;
    private final float r;
    private final float s;

    public bjq(int n2, int n3, int n4, bib.a a2) {
        this(n2, n3, n4, a2, 0.0f, 1.0f);
    }

    public bjq(int n2, int n3, int n4, bib.a a2, float f2, float f3) {
        super(n2, n3, n4, 150, 20, "");
        this.q = a2;
        this.r = f2;
        this.s = f3;
        bhz bhz2 = bhz.z();
        this.p = a2.c(bhz2.t.a(a2));
        this.j = bhz2.t.c(a2);
    }

    @Override
    protected int a(boolean bl2) {
        return 0;
    }

    @Override
    protected void a(bhz bhz22, int n2, int n3) {
        bhz bhz22;
        if (!this.m) {
            return;
        }
        if (this.o) {
            this.p = (float)(n2 - (this.h + 4)) / (float)(this.f - 8);
            this.p = ri.a(this.p, 0.0f, 1.0f);
            float f2 = this.q.d(this.p);
            bhz22.t.a(this.q, f2);
            this.p = this.q.c(f2);
            this.j = bhz22.t.c(this.q);
        }
        bhz22.N().a(a);
        buq.c(1.0f, 1.0f, 1.0f, 1.0f);
        this.b(this.h + (int)(this.p * (float)(this.f - 8)), this.i, 0, 66, 4, 20);
        this.b(this.h + (int)(this.p * (float)(this.f - 8)) + 4, this.i, 196, 66, 4, 20);
    }

    @Override
    public boolean b(bhz bhz2, int n2, int n3) {
        if (super.b(bhz2, n2, n3)) {
            this.p = (float)(n2 - (this.h + 4)) / (float)(this.f - 8);
            this.p = ri.a(this.p, 0.0f, 1.0f);
            bhz2.t.a(this.q, this.q.d(this.p));
            this.j = bhz2.t.c(this.q);
            this.o = true;
            return true;
        }
        return false;
    }

    @Override
    public void a(int n2, int n3) {
        this.o = false;
    }
}

