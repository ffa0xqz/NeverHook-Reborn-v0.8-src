/*
 * Decompiled with CFR 0.150.
 */
import java.util.Random;

public class bao
extends azs {
    private final aou a;
    private final int b;

    public bao(aou aou2, int n2) {
        this.a = aou2;
        this.b = n2;
    }

    @Override
    public boolean b(ams ams2, Random random, et et2) {
        if (ams2.o(et2).a() != bcx.h) {
            return false;
        }
        int n2 = random.nextInt(this.b - 2) + 2;
        \u2603 = 2;
        for (\u2603 = et2.p() - n2; \u2603 <= et2.p() + n2; ++\u2603) {
            for (\u2603 = et2.r() - n2; \u2603 <= et2.r() + n2; ++\u2603) {
                \u2603 = \u2603 - et2.p();
                if (\u2603 * \u2603 + (\u2603 = \u2603 - et2.r()) * \u2603 > n2 * n2) continue;
                for (\u2603 = et2.q() - 2; \u2603 <= et2.q() + 2; ++\u2603) {
                    et et3 = new et(\u2603, \u2603, \u2603);
                    aou \u26032 = ams2.o(et3).u();
                    if (\u26032 != aov.d && \u26032 != aov.c) continue;
                    ams2.a(et3, this.a.t(), 2);
                }
            }
        }
        return true;
    }
}

