/*
 * Decompiled with CFR 0.150.
 */
public class qi
extends qm {
    private final ail g;

    public qi(String string, String string2, hh hh2, ail ail2) {
        super(string + string2, hh2);
        this.g = ail2;
    }

    public ail b() {
        return this.g;
    }
}

