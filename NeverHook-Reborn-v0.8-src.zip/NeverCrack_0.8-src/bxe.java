/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  com.mojang.authlib.minecraft.MinecraftProfileTexture
 *  com.mojang.authlib.minecraft.MinecraftProfileTexture$Type
 *  javax.annotation.Nullable
 */
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.minecraft.MinecraftProfileTexture;
import java.util.Map;
import java.util.UUID;
import javax.annotation.Nullable;

public class bxe
extends bww<awb> {
    private static final nd d = new nd("textures/entity/skeleton/skeleton.png");
    private static final nd e = new nd("textures/entity/skeleton/wither_skeleton.png");
    private static final nd f = new nd("textures/entity/zombie/zombie.png");
    private static final nd g = new nd("textures/entity/creeper/creeper.png");
    private static final nd h = new nd("textures/entity/enderdragon/dragon.png");
    private final brk i = new brk(0.0f);
    public static bxe a;
    private final bqt j = new bqt(0, 0, 64, 32);
    private final bqt k = new bpu();

    @Override
    public void a(awb awb2, double d2, double d3, double d4, float f2, int n2, float f3) {
        fa fa2 = fa.a(awb2.v() & 7);
        float \u26032 = awb2.a(f2);
        this.a((float)d2, (float)d3, (float)d4, fa2, (float)(awb2.h() * 360) / 16.0f, awb2.f(), awb2.a(), n2, \u26032);
    }

    @Override
    public void a(bwv bwv2) {
        super.a(bwv2);
        a = this;
    }

    public void a(float f22, float f3, float f4, fa fa22, float f52, int n2, @Nullable GameProfile gameProfile2, int n3, float f6) {
        fa fa22;
        bqd bqd2 = this.j;
        if (n3 >= 0) {
            this.a(b[n3]);
            buq.n(5890);
            buq.G();
            buq.b(4.0f, 2.0f, 1.0f);
            buq.c(0.0625f, 0.0625f, 0.0625f);
            buq.n(5888);
        } else {
            switch (n2) {
                default: {
                    this.a(d);
                    break;
                }
                case 1: {
                    this.a(e);
                    break;
                }
                case 2: {
                    this.a(f);
                    bqd2 = this.k;
                    break;
                }
                case 3: {
                    bqd2 = this.k;
                    nd \u26034 = ced.a();
                    if (gameProfile2 != null) {
                        bhz bhz2 = bhz.z();
                        Map<MinecraftProfileTexture.Type, MinecraftProfileTexture> \u26032 = bhz2.Y().a(gameProfile2);
                        if (\u26032.containsKey((Object)MinecraftProfileTexture.Type.SKIN)) {
                            \u26034 = bhz2.Y().a(\u26032.get((Object)MinecraftProfileTexture.Type.SKIN), MinecraftProfileTexture.Type.SKIN);
                        } else {
                            GameProfile gameProfile2;
                            UUID \u26033 = aeb.a(gameProfile2);
                            \u26034 = ced.a(\u26033);
                        }
                    }
                    this.a(\u26034);
                    break;
                }
                case 4: {
                    this.a(g);
                    break;
                }
                case 5: {
                    this.a(h);
                    bqd2 = this.i;
                }
            }
        }
        buq.G();
        buq.r();
        if (fa22 == fa.b) {
            buq.c(f22 + 0.5f, f3, f4 + 0.5f);
        } else {
            switch (fa22) {
                case c: {
                    buq.c(f22 + 0.5f, f3 + 0.25f, f4 + 0.74f);
                    break;
                }
                case d: {
                    buq.c(f22 + 0.5f, f3 + 0.25f, f4 + 0.26f);
                    float f52 = 180.0f;
                    break;
                }
                case e: {
                    float f22;
                    buq.c(f22 + 0.74f, f3 + 0.25f, f4 + 0.5f);
                    f52 = 270.0f;
                    break;
                }
                default: {
                    float f22;
                    buq.c(f22 + 0.26f, f3 + 0.25f, f4 + 0.5f);
                    f52 = 90.0f;
                }
            }
        }
        float f7 = 0.0625f;
        buq.D();
        buq.b(-1.0f, -1.0f, 1.0f);
        buq.e();
        if (n2 == 3) {
            buq.a(buq.q.b);
        }
        bqd2.a(null, f6, 0.0f, 0.0f, f52, 0.0f, 0.0625f);
        buq.H();
        if (n3 >= 0) {
            buq.n(5890);
            buq.H();
            buq.n(5888);
        }
    }
}

