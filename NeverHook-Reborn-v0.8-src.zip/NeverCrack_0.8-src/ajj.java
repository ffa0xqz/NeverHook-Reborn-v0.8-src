/*
 * Decompiled with CFR 0.150.
 */
public class ajj
extends ail {
    public ajj() {
        this.d(1);
        this.e(238);
        this.b(ahn.i);
    }

    @Override
    public boolean a(ain ain2, ams ams2, awr awr2, et et2, vn vn2) {
        if (!ams2.G) {
            ain2.a(1, vn2);
        }
        aou aou2 = awr2.u();
        if (awr2.a() == bcx.j || aou2 == aov.G || aou2 == aov.H || aou2 == aov.bn || aou2 == aov.bS || aou2 == aov.L) {
            return true;
        }
        return super.a(ain2, ams2, awr2, et2, vn2);
    }

    @Override
    public boolean a(awr awr2) {
        aou aou2 = awr2.u();
        return aou2 == aov.G || aou2 == aov.af || aou2 == aov.bS;
    }

    @Override
    public float a(ain ain2, awr awr2) {
        aou aou2 = awr2.u();
        if (aou2 == aov.G || awr2.a() == bcx.j) {
            return 15.0f;
        }
        if (aou2 == aov.L) {
            return 5.0f;
        }
        return super.a(ain2, awr2);
    }
}

