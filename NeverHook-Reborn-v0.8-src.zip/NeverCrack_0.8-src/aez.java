/*
 * Decompiled with CFR 0.150.
 */
public class aez
extends aej {
    private static final mx<Boolean> e = na.a(aez.class, mz.h);

    public aez(ams ams2) {
        super(ams2);
        this.a(0.3125f, 0.3125f);
    }

    public aez(ams ams2, vn vn2, double d2, double d3, double d4) {
        super(ams2, vn2, d2, d3, d4);
        this.a(0.3125f, 0.3125f);
    }

    public static void a(rw rw2) {
        aej.a(rw2, "WitherSkull");
    }

    @Override
    protected float l() {
        return this.n() ? 0.73f : super.l();
    }

    public aez(ams ams2, double d2, double d3, double d4, double d5, double d6, double d7) {
        super(ams2, d2, d3, d4, d5, d6, d7);
        this.a(0.3125f, 0.3125f);
    }

    @Override
    public boolean aR() {
        return false;
    }

    @Override
    public float a(amn amn2, ams ams2, et et2, awr awr2) {
        float f2 = super.a(amn2, ams2, et2, awr2);
        aou \u26032 = awr2.u();
        if (this.n() && abv.a(\u26032)) {
            f2 = Math.min(0.8f, f2);
        }
        return f2;
    }

    @Override
    protected void a(bha bha2) {
        if (!this.l.G) {
            if (bha2.d != null) {
                if (this.a != null) {
                    if (bha2.d.a(up.a(this.a), 8.0f)) {
                        if (bha2.d.aC()) {
                            this.a(this.a, bha2.d);
                        } else {
                            this.a.b(5.0f);
                        }
                    }
                } else {
                    bha2.d.a(up.o, 5.0f);
                }
                if (bha2.d instanceof vn) {
                    int n2 = 0;
                    if (this.l.ag() == tx.c) {
                        n2 = 10;
                    } else if (this.l.ag() == tx.d) {
                        n2 = 40;
                    }
                    if (n2 > 0) {
                        ((vn)bha2.d).c(new uy(uz.t, 20 * n2, 1));
                    }
                }
            }
            this.l.a(this, this.p, this.q, this.r, 1.0f, false, this.l.W().b("mobGriefing"));
            this.X();
        }
    }

    @Override
    public boolean ay() {
        return false;
    }

    @Override
    public boolean a(up up2, float f2) {
        return false;
    }

    @Override
    protected void i() {
        this.Y.a(e, false);
    }

    public boolean n() {
        return this.Y.a(e);
    }

    public void a(boolean bl2) {
        this.Y.b(e, bl2);
    }

    @Override
    protected boolean k() {
        return false;
    }
}

