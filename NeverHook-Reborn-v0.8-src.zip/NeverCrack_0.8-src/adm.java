/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import javax.annotation.Nullable;

public class adm
extends acn {
    public adm(ams ams2) {
        super(ams2);
    }

    public static void a(rw rw2) {
        vo.a(rw2, adm.class);
    }

    @Override
    public boolean P() {
        return super.P() && this.l.h(new et(this));
    }

    @Override
    @Nullable
    protected nd J() {
        return bfl.aq;
    }

    @Override
    protected qc F() {
        return qd.hR;
    }

    @Override
    protected qc d(up up2) {
        return qd.hT;
    }

    @Override
    protected qc cf() {
        return qd.hS;
    }

    @Override
    qc p() {
        return qd.hU;
    }

    @Override
    protected aef a(float f2) {
        aef aef2 = super.a(f2);
        if (aef2 instanceof aey) {
            ((aey)aef2).a(new uy(uz.b, 600));
        }
        return aef2;
    }
}

