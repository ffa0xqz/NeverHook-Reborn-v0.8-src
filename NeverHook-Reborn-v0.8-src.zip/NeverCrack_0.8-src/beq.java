/*
 * Decompiled with CFR 0.150.
 */
public class beq
implements Runnable {
    private final ber a;

    public beq(ber ber2) {
        this.a = ber2;
    }

    @Override
    public void run() {
        this.a.c();
    }
}

