/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 */
import com.google.common.collect.Maps;
import java.util.LinkedHashMap;
import java.util.Map;

public class bvj {
    private final Map<awr, cfw> a = Maps.newIdentityHashMap();
    private final bwn b = new bwn();
    private final cga c;

    public bvj(cga cga2) {
        this.c = cga2;
        this.d();
    }

    public bwn a() {
        return this.b;
    }

    public cdo a(awr awr2) {
        aou aou2 = awr2.u();
        cfw \u26032 = this.b(awr2);
        if (\u26032 == null || \u26032 == this.c.a()) {
            if (aou2 == aov.ax || aou2 == aov.an || aou2 == aov.ae || aou2 == aov.cg || aou2 == aov.cK || aou2 == aov.cL || aou2 == aov.C) {
                return this.c.b().a("minecraft:blocks/planks_oak");
            }
            if (aou2 == aov.bQ) {
                return this.c.b().a("minecraft:blocks/obsidian");
            }
            if (aou2 == aov.k || aou2 == aov.l) {
                return this.c.b().a("minecraft:blocks/lava_still");
            }
            if (aou2 == aov.i || aou2 == aov.j) {
                return this.c.b().a("minecraft:blocks/water_still");
            }
            if (aou2 == aov.ce) {
                return this.c.b().a("minecraft:blocks/soul_sand");
            }
            if (aou2 == aov.cv) {
                return this.c.b().a("minecraft:items/barrier");
            }
            if (aou2 == aov.dj) {
                return this.c.b().a("minecraft:items/structure_void");
            }
            if (aou2 == aov.dl) {
                return this.c.b().a("minecraft:blocks/shulker_top_white");
            }
            if (aou2 == aov.dm) {
                return this.c.b().a("minecraft:blocks/shulker_top_orange");
            }
            if (aou2 == aov.dn) {
                return this.c.b().a("minecraft:blocks/shulker_top_magenta");
            }
            if (aou2 == aov.do) {
                return this.c.b().a("minecraft:blocks/shulker_top_light_blue");
            }
            if (aou2 == aov.dp) {
                return this.c.b().a("minecraft:blocks/shulker_top_yellow");
            }
            if (aou2 == aov.dq) {
                return this.c.b().a("minecraft:blocks/shulker_top_lime");
            }
            if (aou2 == aov.dr) {
                return this.c.b().a("minecraft:blocks/shulker_top_pink");
            }
            if (aou2 == aov.ds) {
                return this.c.b().a("minecraft:blocks/shulker_top_gray");
            }
            if (aou2 == aov.dt) {
                return this.c.b().a("minecraft:blocks/shulker_top_silver");
            }
            if (aou2 == aov.du) {
                return this.c.b().a("minecraft:blocks/shulker_top_cyan");
            }
            if (aou2 == aov.dv) {
                return this.c.b().a("minecraft:blocks/shulker_top_purple");
            }
            if (aou2 == aov.dw) {
                return this.c.b().a("minecraft:blocks/shulker_top_blue");
            }
            if (aou2 == aov.dx) {
                return this.c.b().a("minecraft:blocks/shulker_top_brown");
            }
            if (aou2 == aov.dy) {
                return this.c.b().a("minecraft:blocks/shulker_top_green");
            }
            if (aou2 == aov.dz) {
                return this.c.b().a("minecraft:blocks/shulker_top_red");
            }
            if (aou2 == aov.dA) {
                return this.c.b().a("minecraft:blocks/shulker_top_black");
            }
        }
        if (\u26032 == null) {
            \u26032 = this.c.a();
        }
        return \u26032.d();
    }

    public cfw b(awr awr2) {
        cfw cfw2 = this.a.get(awr2);
        if (cfw2 == null) {
            cfw2 = this.c.a();
        }
        return cfw2;
    }

    public cga b() {
        return this.c;
    }

    public void c() {
        this.a.clear();
        for (Map.Entry<awr, cgb> entry : this.b.a().entrySet()) {
            this.a.put(entry.getKey(), this.c.a(entry.getValue()));
        }
    }

    public void a(aou aou2, bwq bwq2) {
        this.b.a(aou2, bwq2);
    }

    public void a(aou ... arraou) {
        this.b.a(arraou);
    }

    private void d() {
        this.a(aov.a, aov.i, aov.j, aov.k, aov.l, aov.M, aov.ae, aov.bQ, aov.cg, aov.an, aov.ce, aov.bF, aov.cv, aov.ax, aov.cL, aov.cK, aov.db, aov.dj, aov.dl, aov.dm, aov.dn, aov.do, aov.dp, aov.dq, aov.dr, aov.ds, aov.dt, aov.du, aov.dv, aov.dw, aov.dx, aov.dy, aov.dz, aov.dA, aov.C);
        this.a(aov.b, new bwp.a().a((axh<?>)auf.a).a());
        this.a(aov.cI, new bwp.a().a((axh<?>)asv.a).a());
        this.a((aou)aov.t, new bwp.a().a((axh<?>)asl.e).a("_leaves").a(arp.b, arp.a).a());
        this.a((aou)aov.u, new bwp.a().a((axh<?>)ase.e).a("_leaves").a(arp.b, arp.a).a());
        this.a((aou)aov.aK, new bwp.a().a(new axh[]{apc.a}).a());
        this.a((aou)aov.aM, new bwp.a().a(new axh[]{atg.a}).a());
        this.a(aov.aN, new bwp.a().a(new axh[]{arn.a}).a());
        this.a(aov.bZ, new bwp.a().a((axh<?>)aut.f).a("_wall").a());
        this.a((aou)aov.cF, new bwp.a().a((axh<?>)apz.a).a(new axh[]{apz.d}).a());
        this.a(aov.bo, new bwp.a().a(new axh[]{aqn.b}).a());
        this.a(aov.bp, new bwp.a().a(new axh[]{aqn.b}).a());
        this.a(aov.bq, new bwp.a().a(new axh[]{aqn.b}).a());
        this.a(aov.br, new bwp.a().a(new axh[]{aqn.b}).a());
        this.a(aov.bs, new bwp.a().a(new axh[]{aqn.b}).a());
        this.a(aov.bt, new bwp.a().a(new axh[]{aqn.b}).a());
        this.a(aov.bS, new bwp.a().a(auq.c, auq.a).a());
        this.a((aou)aov.bL, new bwp.a().a((axh<?>)asp.a).a("_double_slab").a());
        this.a((aou)aov.bM, new bwp.a().a((axh<?>)asp.a).a("_slab").a());
        this.a(aov.W, new bwp.a().a(new axh[]{aun.a}).a());
        this.a((aou)aov.ab, new bwp.a().a(new axh[]{aqo.a}).a());
        this.a((aou)aov.af, new bwp.a().a(new axh[]{atd.e}).a());
        this.a((aou)aov.ao, new bwp.a().a(new axh[]{apy.d}).a());
        this.a((aou)aov.ap, new bwp.a().a(new axh[]{apy.d}).a());
        this.a((aou)aov.aq, new bwp.a().a(new axh[]{apy.d}).a());
        this.a((aou)aov.ar, new bwp.a().a(new axh[]{apy.d}).a());
        this.a((aou)aov.as, new bwp.a().a(new axh[]{apy.d}).a());
        this.a((aou)aov.at, new bwp.a().a(new axh[]{apy.d}).a());
        this.a((aou)aov.aA, new bwp.a().a(new axh[]{apy.d}).a());
        this.a(aov.L, new bwp.a().a((axh<?>)apl.a).a("_wool").a());
        this.a(aov.cy, new bwp.a().a((axh<?>)apl.a).a("_carpet").a());
        this.a(aov.cu, new bwp.a().a((axh<?>)apl.a).a("_stained_hardened_clay").a());
        this.a((aou)aov.cH, new bwp.a().a((axh<?>)apl.a).a("_stained_glass_pane").a());
        this.a((aou)aov.cG, new bwp.a().a((axh<?>)apl.a).a("_stained_glass").a());
        this.a(aov.A, new bwp.a().a((axh<?>)atm.a).a());
        this.a(aov.cM, new bwp.a().a((axh<?>)atb.a).a());
        this.a((aou)aov.H, new bwp.a().a((axh<?>)aul.a).a());
        this.a((aou)aov.N, new bwp.a().a((axh<?>)aov.N.g()).a());
        this.a((aou)aov.O, new bwp.a().a((axh<?>)aov.O.g()).a());
        this.a((aou)aov.U, new bwp.a().a((axh<?>)aui.e).a("_slab").a());
        this.a((aou)aov.cP, new bwp.a().a((axh<?>)asg.e).a("_slab").a());
        this.a(aov.be, new bwp.a().a((axh<?>)ary.a).a("_monster_egg").a());
        this.a(aov.bf, new bwp.a().a((axh<?>)aug.a).a());
        this.a(aov.z, new bwp.a().a(new axh[]{apx.b}).a());
        this.a(aov.ct, new bwp.a().a(new axh[]{aqb.b}).a());
        this.a(aov.r, new bwp.a().a((axh<?>)asm.b).a("_log").a());
        this.a(aov.s, new bwp.a().a((axh<?>)asf.b).a("_log").a());
        this.a(aov.f, new bwp.a().a((axh<?>)asp.a).a("_planks").a());
        this.a(aov.g, new bwp.a().a((axh<?>)atn.a).a("_sapling").a());
        this.a((aou)aov.m, new bwp.a().a((axh<?>)atl.a).a());
        this.a((aou)aov.cp, new bwp.a().a(new axh[]{arj.b}).a());
        this.a(aov.ca, new bwp.a().a(new axh[]{aqq.a}).a());
        this.a(aov.dR, new bwp.a().a((axh<?>)apl.a).a("_concrete").a());
        this.a(aov.dS, new bwp.a().a((axh<?>)apl.a).a("_concrete_powder").a());
        this.a(aov.cq, new bwm(){

            @Override
            protected cgb a(awr awr2) {
                asy.a a2 = awr2.c(asy.a);
                switch (a2) {
                    default: {
                        return new cgb("quartz_block", "normal");
                    }
                    case b: {
                        return new cgb("chiseled_quartz_block", "normal");
                    }
                    case c: {
                        return new cgb("quartz_column", "axis=y");
                    }
                    case d: {
                        return new cgb("quartz_column", "axis=x");
                    }
                    case e: 
                }
                return new cgb("quartz_column", "axis=z");
            }
        });
        this.a((aou)aov.I, new bwm(){

            @Override
            protected cgb a(awr awr2) {
                return new cgb("dead_bush", "normal");
            }
        });
        this.a(aov.bl, new bwm(){

            @Override
            protected cgb a(awr awr2) {
                LinkedHashMap linkedHashMap = Maps.newLinkedHashMap(awr2.t());
                if (awr2.c(aue.c) != fa.b) {
                    linkedHashMap.remove(aue.a);
                }
                return new cgb(aou.h.b(awr2.u()), this.a(linkedHashMap));
            }
        });
        this.a(aov.bm, new bwm(){

            @Override
            protected cgb a(awr awr2) {
                LinkedHashMap linkedHashMap = Maps.newLinkedHashMap(awr2.t());
                if (awr2.c(aue.c) != fa.b) {
                    linkedHashMap.remove(aue.a);
                }
                return new cgb(aou.h.b(awr2.u()), this.a(linkedHashMap));
            }
        });
        this.a(aov.d, new bwm(){

            @Override
            protected cgb a(awr awr2) {
                LinkedHashMap linkedHashMap = Maps.newLinkedHashMap(awr2.t());
                String \u26032 = apw.a.a((apw.a)linkedHashMap.remove(apw.a));
                if (apw.a.c != awr2.c(apw.a)) {
                    linkedHashMap.remove(apw.b);
                }
                return new cgb(\u26032, this.a(linkedHashMap));
            }
        });
        this.a((aou)aov.T, new bwm(){

            @Override
            protected cgb a(awr awr2) {
                LinkedHashMap linkedHashMap = Maps.newLinkedHashMap(awr2.t());
                String \u26032 = aui.e.a((aui.a)linkedHashMap.remove(aui.e));
                linkedHashMap.remove(aui.d);
                String \u26033 = awr2.c(aui.d) != false ? "all" : "normal";
                return new cgb(\u26032 + "_double_slab", \u26033);
            }
        });
        this.a((aou)aov.cO, new bwm(){

            @Override
            protected cgb a(awr awr2) {
                LinkedHashMap linkedHashMap = Maps.newLinkedHashMap(awr2.t());
                String \u26032 = asg.e.a((asg.a)linkedHashMap.remove(asg.e));
                linkedHashMap.remove(aui.d);
                String \u26033 = awr2.c(asg.d) != false ? "all" : "normal";
                return new cgb(\u26032 + "_double_slab", \u26033);
            }
        });
    }
}

