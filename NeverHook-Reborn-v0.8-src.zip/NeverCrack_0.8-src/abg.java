/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
import javax.annotation.Nullable;

public class abg
extends abd {
    private bhc b;
    private int c;

    public abg(abb abb2) {
        super(abb2);
    }

    @Override
    public void b() {
        if (this.c++ % 10 == 0) {
            float f2 = (this.a.bR().nextFloat() - 0.5f) * 8.0f;
            \u2603 = (this.a.bR().nextFloat() - 0.5f) * 4.0f;
            \u2603 = (this.a.bR().nextFloat() - 0.5f) * 8.0f;
            this.a.l.a(fj.c, this.a.p + (double)f2, this.a.q + 2.0 + (double)\u2603, this.a.r + (double)\u2603, 0.0, 0.0, 0.0, new int[0]);
        }
    }

    @Override
    public void c() {
        double d2;
        ++this.c;
        if (this.b == null) {
            et et2 = this.a.l.l(azr.a);
            this.b = new bhc(et2.p(), et2.q(), et2.r());
        }
        if ((d2 = this.b.c(this.a.p, this.a.q, this.a.r)) < 100.0 || d2 > 22500.0 || this.a.A || this.a.B) {
            this.a.c(0.0f);
        } else {
            this.a.c(1.0f);
        }
    }

    @Override
    public void d() {
        this.b = null;
        this.c = 0;
    }

    @Override
    public float f() {
        return 3.0f;
    }

    @Override
    @Nullable
    public bhc g() {
        return this.b;
    }

    public abr<abg> i() {
        return abr.j;
    }
}

