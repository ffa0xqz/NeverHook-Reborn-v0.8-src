/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonDeserializationContext
 *  com.google.gson.JsonDeserializer
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParseException
 *  com.google.gson.JsonPrimitive
 *  com.google.gson.JsonSerializationContext
 *  com.google.gson.JsonSerializer
 *  javax.annotation.Nullable
 */
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import java.lang.reflect.Type;
import javax.annotation.Nullable;

public class hn {
    private hn a;
    private a b;
    private Boolean c;
    private Boolean d;
    private Boolean e;
    private Boolean f;
    private Boolean g;
    private hg h;
    private hj i;
    private String j;
    private static final hn k = new hn(){

        @Override
        @Nullable
        public a a() {
            return null;
        }

        @Override
        public boolean b() {
            return false;
        }

        @Override
        public boolean c() {
            return false;
        }

        @Override
        public boolean d() {
            return false;
        }

        @Override
        public boolean e() {
            return false;
        }

        @Override
        public boolean f() {
            return false;
        }

        @Override
        @Nullable
        public hg h() {
            return null;
        }

        @Override
        @Nullable
        public hj i() {
            return null;
        }

        @Override
        @Nullable
        public String j() {
            return null;
        }

        @Override
        public hn a(a a2) {
            throw new UnsupportedOperationException();
        }

        @Override
        public hn a(Boolean bl2) {
            throw new UnsupportedOperationException();
        }

        @Override
        public hn b(Boolean bl2) {
            throw new UnsupportedOperationException();
        }

        @Override
        public hn c(Boolean bl2) {
            throw new UnsupportedOperationException();
        }

        @Override
        public hn d(Boolean bl2) {
            throw new UnsupportedOperationException();
        }

        @Override
        public hn e(Boolean bl2) {
            throw new UnsupportedOperationException();
        }

        @Override
        public hn a(hg hg2) {
            throw new UnsupportedOperationException();
        }

        @Override
        public hn a(hj hj2) {
            throw new UnsupportedOperationException();
        }

        @Override
        public hn a(hn hn2) {
            throw new UnsupportedOperationException();
        }

        @Override
        public String toString() {
            return "Style.ROOT";
        }

        @Override
        public hn m() {
            return this;
        }

        @Override
        public hn n() {
            return this;
        }

        @Override
        public String k() {
            return "";
        }
    };

    @Nullable
    public a a() {
        return this.b == null ? this.o().a() : this.b;
    }

    public boolean b() {
        return this.c == null ? this.o().b() : this.c.booleanValue();
    }

    public boolean c() {
        return this.d == null ? this.o().c() : this.d.booleanValue();
    }

    public boolean d() {
        return this.f == null ? this.o().d() : this.f.booleanValue();
    }

    public boolean e() {
        return this.e == null ? this.o().e() : this.e.booleanValue();
    }

    public boolean f() {
        return this.g == null ? this.o().f() : this.g.booleanValue();
    }

    public boolean g() {
        return this.c == null && this.d == null && this.f == null && this.e == null && this.g == null && this.b == null && this.h == null && this.i == null && this.j == null;
    }

    @Nullable
    public hg h() {
        return this.h == null ? this.o().h() : this.h;
    }

    @Nullable
    public hj i() {
        return this.i == null ? this.o().i() : this.i;
    }

    @Nullable
    public String j() {
        return this.j == null ? this.o().j() : this.j;
    }

    public hn a(a a2) {
        this.b = a2;
        return this;
    }

    public hn a(Boolean bl2) {
        this.c = bl2;
        return this;
    }

    public hn b(Boolean bl2) {
        this.d = bl2;
        return this;
    }

    public hn c(Boolean bl2) {
        this.f = bl2;
        return this;
    }

    public hn d(Boolean bl2) {
        this.e = bl2;
        return this;
    }

    public hn e(Boolean bl2) {
        this.g = bl2;
        return this;
    }

    public hn a(hg hg2) {
        this.h = hg2;
        return this;
    }

    public hn a(hj hj2) {
        this.i = hj2;
        return this;
    }

    public hn a(String string) {
        this.j = string;
        return this;
    }

    public hn a(hn hn2) {
        this.a = hn2;
        return this;
    }

    public String k() {
        if (this.g()) {
            if (this.a != null) {
                return this.a.k();
            }
            return "";
        }
        StringBuilder stringBuilder = new StringBuilder();
        if (this.a() != null) {
            stringBuilder.append((Object)this.a());
        }
        if (this.b()) {
            stringBuilder.append((Object)a.r);
        }
        if (this.c()) {
            stringBuilder.append((Object)a.u);
        }
        if (this.e()) {
            stringBuilder.append((Object)a.t);
        }
        if (this.f()) {
            stringBuilder.append((Object)a.q);
        }
        if (this.d()) {
            stringBuilder.append((Object)a.s);
        }
        return stringBuilder.toString();
    }

    private hn o() {
        return this.a == null ? k : this.a;
    }

    public String toString() {
        return "Style{hasParent=" + (this.a != null) + ", color=" + (Object)((Object)this.b) + ", bold=" + this.c + ", italic=" + this.d + ", underlined=" + this.e + ", obfuscated=" + this.g + ", clickEvent=" + this.h() + ", hoverEvent=" + this.i() + ", insertion=" + this.j() + '}';
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object instanceof hn) {
            hn hn2 = (hn)object;
            return this.b() == hn2.b() && this.a() == hn2.a() && this.c() == hn2.c() && this.f() == hn2.f() && this.d() == hn2.d() && this.e() == hn2.e() && (this.h() != null ? this.h().equals(hn2.h()) : hn2.h() == null) && (this.i() != null ? this.i().equals(hn2.i()) : hn2.i() == null) && (this.j() != null ? this.j().equals(hn2.j()) : hn2.j() == null);
        }
        return false;
    }

    public int hashCode() {
        int n2 = this.b.hashCode();
        n2 = 31 * n2 + this.c.hashCode();
        n2 = 31 * n2 + this.d.hashCode();
        n2 = 31 * n2 + this.e.hashCode();
        n2 = 31 * n2 + this.f.hashCode();
        n2 = 31 * n2 + this.g.hashCode();
        n2 = 31 * n2 + this.h.hashCode();
        n2 = 31 * n2 + this.i.hashCode();
        n2 = 31 * n2 + this.j.hashCode();
        return n2;
    }

    public hn m() {
        hn hn2 = new hn();
        hn2.c = this.c;
        hn2.d = this.d;
        hn2.f = this.f;
        hn2.e = this.e;
        hn2.g = this.g;
        hn2.b = this.b;
        hn2.h = this.h;
        hn2.i = this.i;
        hn2.a = this.a;
        hn2.j = this.j;
        return hn2;
    }

    public hn n() {
        hn hn2 = new hn();
        hn2.a(this.b());
        hn2.b(this.c());
        hn2.c(this.d());
        hn2.d(this.e());
        hn2.e(this.f());
        hn2.a(this.a());
        hn2.a(this.h());
        hn2.a(this.i());
        hn2.a(this.j());
        return hn2;
    }

    public static class a
    implements JsonDeserializer<hn>,
    JsonSerializer<hn> {
        @Nullable
        public hn a(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            if (jsonElement.isJsonObject()) {
                Object \u26034;
                hg.a \u26033;
                hn hn2 = new hn();
                JsonObject \u26032 = jsonElement.getAsJsonObject();
                if (\u26032 == null) {
                    return null;
                }
                if (\u26032.has("bold")) {
                    hn2.c = \u26032.get("bold").getAsBoolean();
                }
                if (\u26032.has("italic")) {
                    hn2.d = \u26032.get("italic").getAsBoolean();
                }
                if (\u26032.has("underlined")) {
                    hn2.e = \u26032.get("underlined").getAsBoolean();
                }
                if (\u26032.has("strikethrough")) {
                    hn2.f = \u26032.get("strikethrough").getAsBoolean();
                }
                if (\u26032.has("obfuscated")) {
                    hn2.g = \u26032.get("obfuscated").getAsBoolean();
                }
                if (\u26032.has("color")) {
                    hn2.b = (a)((Object)jsonDeserializationContext.deserialize(\u26032.get("color"), a.class));
                }
                if (\u26032.has("insertion")) {
                    hn2.j = \u26032.get("insertion").getAsString();
                }
                if (\u26032.has("clickEvent") && (\u2603 = \u26032.getAsJsonObject("clickEvent")) != null) {
                    JsonPrimitive jsonPrimitive = \u2603.getAsJsonPrimitive("action");
                    \u26033 = jsonPrimitive == null ? null : hg.a.a(jsonPrimitive.getAsString());
                    \u26034 = \u2603.getAsJsonPrimitive("value");
                    String string = \u2603 = \u26034 == null ? null : \u26034.getAsString();
                    if (\u26033 != null && \u2603 != null && \u26033.a()) {
                        hn2.h = new hg(\u26033, \u2603);
                    }
                }
                if (\u26032.has("hoverEvent") && (\u2603 = \u26032.getAsJsonObject("hoverEvent")) != null) {
                    jsonPrimitive = \u2603.getAsJsonPrimitive("action");
                    \u26033 = jsonPrimitive == null ? null : hj.a.a(jsonPrimitive.getAsString());
                    \u26034 = (hh)jsonDeserializationContext.deserialize(\u2603.get("value"), hh.class);
                    if (\u26033 != null && \u26034 != null && ((hj.a)((Object)\u26033)).a()) {
                        hn2.i = new hj((hj.a)((Object)\u26033), (hh)\u26034);
                    }
                }
                return hn2;
            }
            return null;
        }

        @Nullable
        public JsonElement a(hn hn2, Type type, JsonSerializationContext jsonSerializationContext) {
            if (hn2.g()) {
                return null;
            }
            JsonObject jsonObject = new JsonObject();
            if (hn2.c != null) {
                jsonObject.addProperty("bold", hn2.c);
            }
            if (hn2.d != null) {
                jsonObject.addProperty("italic", hn2.d);
            }
            if (hn2.e != null) {
                jsonObject.addProperty("underlined", hn2.e);
            }
            if (hn2.f != null) {
                jsonObject.addProperty("strikethrough", hn2.f);
            }
            if (hn2.g != null) {
                jsonObject.addProperty("obfuscated", hn2.g);
            }
            if (hn2.b != null) {
                jsonObject.add("color", jsonSerializationContext.serialize((Object)hn2.b));
            }
            if (hn2.j != null) {
                jsonObject.add("insertion", jsonSerializationContext.serialize((Object)hn2.j));
            }
            if (hn2.h != null) {
                \u2603 = new JsonObject();
                \u2603.addProperty("action", hn2.h.a().b());
                \u2603.addProperty("value", hn2.h.b());
                jsonObject.add("clickEvent", (JsonElement)\u2603);
            }
            if (hn2.i != null) {
                \u2603 = new JsonObject();
                \u2603.addProperty("action", hn2.i.a().b());
                \u2603.add("value", jsonSerializationContext.serialize((Object)hn2.i.b()));
                jsonObject.add("hoverEvent", (JsonElement)\u2603);
            }
            return jsonObject;
        }

        @Nullable
        public /* synthetic */ JsonElement serialize(Object object, Type type, JsonSerializationContext jsonSerializationContext) {
            return this.a((hn)object, type, jsonSerializationContext);
        }

        @Nullable
        public /* synthetic */ Object deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            return this.a(jsonElement, type, jsonDeserializationContext);
        }
    }
}

