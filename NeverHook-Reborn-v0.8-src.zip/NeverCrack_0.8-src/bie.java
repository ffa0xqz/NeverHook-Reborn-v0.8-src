/*
 * Decompiled with CFR 0.150.
 */
public class bie
extends Error {
}

