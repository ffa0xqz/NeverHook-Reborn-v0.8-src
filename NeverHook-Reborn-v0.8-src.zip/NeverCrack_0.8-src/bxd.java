/*
 * Decompiled with CFR 0.150.
 */
import java.util.List;
import optifine.Config;
import optifine.CustomColors;

public class bxd
extends bww<awa> {
    private static final nd a = new nd("textures/entity/sign.png");
    private final bqr d = new bqr();

    @Override
    public void a(awa p_192841_1_, double p_192841_2_, double p_192841_4_, double p_192841_6_, float p_192841_8_, int p_192841_9_, float p_192841_10_) {
        aou block = p_192841_1_.x();
        buq.G();
        float f2 = 0.6666667f;
        if (block == aov.an) {
            buq.c((float)p_192841_2_ + 0.5f, (float)p_192841_4_ + 0.5f, (float)p_192841_6_ + 0.5f);
            float f1 = (float)(p_192841_1_.v() * 360) / 16.0f;
            buq.b(-f1, 0.0f, 1.0f, 0.0f);
            this.d.b.j = true;
        } else {
            int k2 = p_192841_1_.v();
            float f22 = 0.0f;
            if (k2 == 2) {
                f22 = 180.0f;
            }
            if (k2 == 4) {
                f22 = 90.0f;
            }
            if (k2 == 5) {
                f22 = -90.0f;
            }
            buq.c((float)p_192841_2_ + 0.5f, (float)p_192841_4_ + 0.5f, (float)p_192841_6_ + 0.5f);
            buq.b(-f22, 0.0f, 1.0f, 0.0f);
            buq.c(0.0f, -0.3125f, -0.4375f);
            this.d.b.j = false;
        }
        if (p_192841_9_ >= 0) {
            this.a(b[p_192841_9_]);
            buq.n(5890);
            buq.G();
            buq.b(4.0f, 2.0f, 1.0f);
            buq.c(0.0625f, 0.0625f, 0.0625f);
            buq.n(5888);
        } else {
            this.a(a);
        }
        buq.D();
        buq.G();
        buq.b(0.6666667f, -0.6666667f, -0.6666667f);
        this.d.a();
        buq.H();
        bin fontrenderer = this.b();
        float f3 = 0.010416667f;
        buq.c(0.0f, 0.33333334f, 0.046666667f);
        buq.b(0.010416667f, -0.010416667f, 0.010416667f);
        buq.a(0.0f, 0.0f, -0.010416667f);
        buq.a(false);
        int i2 = 0;
        if (Config.isCustomColors()) {
            i2 = CustomColors.getSignTextColor(i2);
        }
        if (p_192841_9_ < 0) {
            for (int j2 = 0; j2 < p_192841_1_.a.length; ++j2) {
                String s2;
                if (p_192841_1_.a[j2] == null) continue;
                hh itextcomponent = p_192841_1_.a[j2];
                List<hh> list = bja.a(itextcomponent, 90, fontrenderer, false, true);
                String string = s2 = list != null && !list.isEmpty() ? list.get(0).d() : "";
                if (j2 == p_192841_1_.f) {
                    s2 = "> " + s2 + " <";
                    fontrenderer.drawString(s2, -fontrenderer.a(s2) / 2, j2 * 10 - p_192841_1_.a.length * 5, i2);
                    continue;
                }
                fontrenderer.drawString(s2, -fontrenderer.a(s2) / 2, j2 * 10 - p_192841_1_.a.length * 5, i2);
            }
        }
        buq.a(true);
        buq.c(1.0f, 1.0f, 1.0f, 1.0f);
        buq.H();
        if (p_192841_9_ >= 0) {
            buq.n(5890);
            buq.H();
            buq.n(5888);
        }
    }
}

