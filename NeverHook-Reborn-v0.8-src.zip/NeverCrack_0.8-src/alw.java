/*
 * Decompiled with CFR 0.150.
 */
import java.util.Random;

public class alw
extends ali {
    public alw(ali.a a2, vj ... arrvj) {
        super(a2, alj.e, arrvj);
        this.c("thorns");
    }

    @Override
    public int a(int n2) {
        return 10 + 20 * (n2 - 1);
    }

    @Override
    public int b(int n2) {
        return super.a(n2) + 50;
    }

    @Override
    public int b() {
        return 3;
    }

    @Override
    public boolean a(ain ain2) {
        if (ain2.c() instanceof agt) {
            return true;
        }
        return super.a(ain2);
    }

    @Override
    public void b(vn vn2, ve ve2, int n2) {
        Random random = vn2.bR();
        ain \u26032 = alk.b(alm.h, vn2);
        if (alw.a(n2, random)) {
            if (ve2 != null) {
                ve2.a(up.a((ve)vn2), (float)alw.b(n2, random));
            }
            if (!\u26032.b()) {
                \u26032.a(3, vn2);
            }
        } else if (!\u26032.b()) {
            \u26032.a(1, vn2);
        }
    }

    public static boolean a(int n2, Random random) {
        if (n2 <= 0) {
            return false;
        }
        return random.nextFloat() < 0.15f * (float)n2;
    }

    public static int b(int n2, Random random) {
        if (n2 > 10) {
            return n2 - 10;
        }
        return 1 + random.nextInt(4);
    }
}

