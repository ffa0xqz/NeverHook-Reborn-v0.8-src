/*
 * Decompiled with CFR 0.150.
 */
import java.io.IOException;

public class lq
implements ht<kw> {
    private float a;
    private float b;
    private boolean c;
    private boolean d;

    public lq() {
    }

    public lq(float f2, float f3, boolean bl2, boolean bl3) {
        this.a = f2;
        this.b = f3;
        this.c = bl2;
        this.d = bl3;
    }

    @Override
    public void a(gy gy2) throws IOException {
        this.a = gy2.readFloat();
        this.b = gy2.readFloat();
        byte by2 = gy2.readByte();
        this.c = (by2 & 1) > 0;
        this.d = (by2 & 2) > 0;
    }

    @Override
    public void b(gy gy2) throws IOException {
        gy2.writeFloat(this.a);
        gy2.writeFloat(this.b);
        byte by2 = 0;
        if (this.c) {
            by2 = (byte)(by2 | true ? 1 : 0);
        }
        if (this.d) {
            by2 = (byte)(by2 | 2);
        }
        gy2.writeByte(by2);
    }

    @Override
    public void a(kw kw2) {
        kw2.a(this);
    }

    public float a() {
        return this.a;
    }

    public float b() {
        return this.b;
    }

    public boolean c() {
        return this.c;
    }

    public boolean d() {
        return this.d;
    }
}

